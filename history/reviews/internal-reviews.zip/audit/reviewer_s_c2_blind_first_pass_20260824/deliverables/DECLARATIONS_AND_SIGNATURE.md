# Declarations and verifiable signature

## Qualification/scope statement

This audit covers partially linear models, semiparametric and orthogonal/debiased estimation, nuisance-function learning, minimax quantifiers and information-theoretic lower-bound positioning, empirical-process citations, causal-versus-statistical interpretation, literature collision search, novelty and ICLR significance. The work used independent model reconstruction, full-paper/source reading, theorem-field comparison, version/timeline checks and open literature search.

This is a simulated expert review produced by an AI model. It does not claim a human degree, title, institution, publication history, reviewer record or personal scholarly reputation. It does not replace a full proof referee or a credentialed human gate review.

## Conflict-of-interest statement

No conflict with an identified author, institution, funder, competing work or source author was detected. Because the package is anonymous, identity-based conflicts cannot be fully evaluated. The execution system has no personal, financial, employment or authorship interests. Prior C1 topical exposure within the conversation is disclosed; no C1 output was used in the C2 evidentiary record.

## Independence statement

No author internal audit, reference answer, completed audit form, Expert M report, other reviewer opinion, solution file or reference-stage report was read. Conclusions were formed from the anonymous C2 manuscript, the blank forms and neutral source-locator instructions, supplied primary PDFs, and public literature checked during this run.

## Search-limit statement

Network access was available for public web, arXiv, PMLR and official ICLR sources. Recent-preprint indexing in Scholar-like databases may be incomplete; Google Scholar was not available as a reproducible export; paywalled, private, unindexed and post-cutoff materials may have been missed. The checked source versions are recorded explicitly. A non-hit is not evidence that no collision exists.

## Human-only gate statement

The archive says credited review is strictly human-only. This output is therefore **AI red-team/simulated review material and earns zero independent-human-review credit under that package rule**. No signature or credentials have been fabricated.

## Signature

- Reviewer: **Reviewer S — simulated independent expert review**
- System: Codex desktop
- Underlying model/version: not exposed to this task
- Session/task ID: not provided
- Completion date: 2026-08-24
- Time zone: Asia/Shanghai (UTC+08:00)
- Input archive SHA-256: `DD3BF129F48D02F19D4A45C8E799226F52088A3F8A59FE5B7958E6D48356A442`
- Manuscript SHA-256: `A7372F5436DC2EA48F1A6499D9908FEEB9CACB604CD403CAF537E52735E20E49`
- Output-file SHA-256: see `SHA256SUMS.txt`; final archive SHA-256 is recorded in the adjacent `.sha256.txt` sidecar and the handoff message.
