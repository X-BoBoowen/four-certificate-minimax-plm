# Manuscript and prior-work timeline

Priority rule used: earliest public availability of the relevant technical content, while separately recording formal publication when known.

| Date | Work/event | Status relative to local manuscript | Technical relevance |
|---:|---|---|---|
| 2004-05-14 | BBM supplied author version | Prior | Relevant concentration theorem available. |
| 2005 | BBM, *Annals of Statistics* 33(4) | Prior/formal | Formal publication of Theorem 2.1. |
| 2016–2018 | Double/debiased ML preprint/journal lineage | Prior | Orthogonal PLM product-rate context. |
| 2023-05-06 | Balakrishnan–Kennedy–Wasserman arXiv v1 | Prior | Structure-agnostic functional lower-bound lineage. |
| 2024-02 | Jin–Syrgkanis ATE preprint line | Prior | Neighboring black-box/minimax functional work. |
| 2025 | Gu COLT/PMLR open problem | Prior/formal | Four-budget public-class PLM problem publicly posed. |
| 2025-07-03 | Jin–Mackey–Syrgkanis arXiv v1 | Prior | Adjacent PLM noise/barrier lower results. |
| 2025-11-07 | Same work, checked v3 | Prior/current version | Version used for theorem comparison. |
| 2025-12-19 | Jin–Syrgkanis general-functional v1 | Prior | General structure-agnostic lower framework. |
| 2026-01-05 | Same work, checked v2 | Prior/current version | Version used for comparison. |
| 2026-06-04 | Gu–Yin–Cai–Fan arXiv:2606.06368v1 | Prior to local artifact | Closest `q+AB+M` theorem. |
| 2026-07-23 | TAME arXiv:2607.21541v1 | Prior to local artifact | Closest upper architecture. |
| 2026-08-24 17:20:58 +08:00 | Local manuscript PDF creation metadata | Audit artifact date | Earliest manuscript date that this audit can verify locally. Exact public/submission date is unknown. |
| 2026-08-24 | Exact-title/public collision search | Audit cutoff | No public exact-title copy or complete same-field collision found in recorded search. |
| 2026-09-18 AOE | ICLR 2027 abstract deadline | Future relative to audit | Official schedule reference. |
| 2026-09-25 AOE | ICLR 2027 full-paper deadline | Future relative to audit | Official schedule reference. |

## Temporal conclusion

Gu–Yin–Cai–Fan v1 and TAME v1 are prior-public relative to the local artifact and are already cited. Because the manuscript's earliest public date and actual submission time were not included, I cannot make a stronger priority statement. Work first made public after the relevant submission deadline must not be used retrospectively to negate submission-time originality; it may only update current positioning.

**Verdict: CONDITIONAL PASS; MINOR at present; HIGH confidence in recorded dates, LOW confidence in the unknown manuscript-priority date.**
