# `ab` and `M` proof-attribution audit

## Definitions in this manuscript

The manuscript defines `A=a+s^2`, `B=b+t^2`, `M=(s∧t)^2`, so `AB` contains the approximation-product term `ab`. These are rate components, not theorem labels or author names.

## Attribution graph

| Component | First manuscript appearance | Formal result/proof | Internal proof route | External ancestry | Independent contribution of this manuscript | Attribution class |
|---|---|---|---|---|---|---|
| `ab` | PDF pp. 3–5, rate display and contribution discussion | Theorem 1; native certificate in Appendix E, PDF pp. 24–25 | A singleton public pair is constructed; alternatives share the public interface and exact variance while their coefficients are separated; a two-point testing argument gives the product obstruction. | Gu–Yin–Cai–Fan Theorem A.1 already has `[a+s^2][b+t^2]`, hence already contains `ab`. Standard two-point/Le Cam reasoning supplies the generic testing step. | A self-contained witness tailored to the exact M1 envelope, variance, measurability and target field. It does not create a new `ab` rate. | **3 — technical adaptation/native theorem-field certificate.** Rate attribution remains prior. |
| `M=(s∧t)^2` | PDF pp. 3–5 and eq. (9) | Theorem 1; finite-dictionary certificate in Appendix F, PDF pp. 25–28 | A public finite dictionary is scaled to satisfy the localized-complexity budget and exact envelope; a testing family creates the common-stochastic obstruction under equal variance. | Gu–Yin–Cai–Fan Theorem A.1 explicitly contains `(s∧t)^2`. The one-learner analogue also appears in the TAME line. Standard Assouad/Fano-style testing supplies generic ingredients. | A native exact-variance/public-representation construction with rescaling `lambda_rho=min{1,192 c_rad/23}`. It does not create a new `M` rate. | **3 — technical adaptation/native theorem-field certificate.** Rate attribution remains prior. |

## What is new and what is not

- Not new: the existence of the `ab` obstruction; the rate `M=(s∧t)^2`; the generic testing principles; the fact that a minimax theorem can combine upper and lower bounds.
- Potentially new in this manuscript: the exact witnesses showing that those inherited components survive simultaneously inside the manuscript's bounded, represented-public-class, fixed-conditional-variance theorem field.
- More substantively new, subject to proof correctness: the directional lower mechanisms for `O=t(a∧t)` and `P=s(b∧s)`, which are not obtained by merely expanding `AB+M`.

## Fairness check

I initially treated the long native appendices as possible evidence of a stronger originality claim. Reading the contribution table and the prior-source theorem field changed that view: the manuscript expressly says the `ab` and `M` rates are not new. Conversely, the native constructions are not empty copying; exact constant variance, envelopes, positive-radius complexity and public representation do require nontrivial bookkeeping. The fair classification is therefore technical adaptation, not direct proof plagiarism or substantive rate invention.

**Verdict: PASS; MAJOR attribution question; HIGH confidence; PRIMARY VERIFIED.**
