# Novelty and collision search log

## Query record

### Query record 1 — exact manuscript identity

Query text: `"Four-Budget Minimax Rates for Bounded Partially Linear Models"`  
Date searched: 2026-08-24  
Database, venue, or repository: General web index; arXiv-indexed results  
Date window: All indexed dates through 2026-08-24  
Formulation synonyms used: Exact title; hyphenated/non-hyphenated four-budget  
Backward theorem ancestors checked: N/A for exact-title query  
Forward/current results checked: No public exact-title hit found  

### Query record 2 — exact directional terms

Query text: `"t(a∧t)" partially linear minimax OR "s(b∧s)"`; variants using `min(a,t)`, `min(b,s)`, directional nuisance interaction  
Date searched: 2026-08-24  
Database, venue, or repository: General web index; arXiv-indexed results  
Date window: 1988–2026  
Formulation synonyms used: directional lower bound; outcome-easier/treatment-easier; separate nuisance learners; approximation × stochastic interaction  
Backward theorem ancestors checked: Gu (2025); Gu–Yin–Cai–Fan (2026); Gu TAME (2026)  
Forward/current results checked: TAME-related indexed pages and recent structure-agnostic PLM results  

### Query record 3 — model/rate decomposition

Query text: `partially linear model structure-agnostic minimax approximation stochastic error four budgets`; `"structure-agnostic" "approximation error" "stochastic error" "partial linear model" minimax`  
Date searched: 2026-08-24  
Database, venue, or repository: General web index; arXiv; PMLR; DBLP  
Date window: 2018–2026, with classical PLM ancestors back to 1988  
Formulation synonyms used: black-box learner; nuisance misspecification/variance; critical radius; class-pair minimax; orthogonal/debiased learning  
Backward theorem ancestors checked: DML; orthogonal statistical learning; BKW; Gu COLT open problem  
Forward/current results checked: Gu–Yin–Cai–Fan v1; TAME v1; Jin–Mackey–Syrgkanis; Jin–Syrgkanis  

### Query record 4 — separate/two learners and upper architecture

Query text: `"two learners" "partial linear model" structure-agnostic minimax`; `"Transductive Adversarial Moment-calibrated Editing"`; `"2607.21541"`  
Date searched: 2026-08-24  
Database, venue, or repository: arXiv; general web index  
Date window: 2025–2026  
Formulation synonyms used: TAME-2; O-branch; R-branch; editing; adversarial moment calibration; under-smoothing  
Backward theorem ancestors checked: Gu–Yin–Cai–Fan/SADE; covariate balancing line cited in TAME  
Forward/current results checked: Exact TAME title/acronym and indexed derivative pages; no separate theorem with manuscript's O/P lower terms found  

### Query record 5 — database-specific metadata and venue history

Query text: `site:dblp.org "structure-agnostic" "partial linear model"`; `site:semanticscholar.org "Optimal use of a black-box learner"`; `site:openalex.org "structure-agnostic minimax" "partial linear"`; Crossref title query for the COLT open problem  
Date searched: 2026-08-24  
Database, venue, or repository: DBLP; Semantic Scholar/OpenAlex/Crossref indexed search via web; PMLR  
Date window: All indexed dates  
Formulation synonyms used: structure agnostic/agnostic; partial linear/semilinear; treatment-effect coefficient  
Backward theorem ancestors checked: PMLR/DBLP record for Gu (2025); COLT structure-agnostic ATE work  
Forward/current results checked: Recent author/title records; database coverage for June–July 2026 arXiv papers was incomplete  

### Query record 6 — source version and forward-current check

Query text: `"2606.06368"`; `"Optimally taming biases" cited by`; `"2607.21541"`; exact author-title combinations  
Date searched: 2026-08-24  
Database, venue, or repository: arXiv; general web index; source reference lists  
Date window: 2026-06-04 through 2026-08-24  
Formulation synonyms used: SADE; TAME; black-box semiparametric estimation  
Backward theorem ancestors checked: References within both supplied papers  
Forward/current results checked: Public indexed mentions; no independent paper containing the full five-mechanism law located  

### Query record 7 — ICLR time and review standard

Query text: `site:iclr.cc/Conferences/2027 Reviewer Guidelines`; `ICLR 2027 Author Guidelines`; `ICLR 2027 Call for Papers`  
Date searched: 2026-08-24  
Database, venue, or repository: Official ICLR website  
Date window: ICLR 2027 cycle  
Formulation synonyms used: reviewer criteria; significance; contemporaneous work; submission deadline  
Backward theorem ancestors checked: N/A  
Forward/current results checked: Reviewer guide, author guide, call for papers, AI-review policy  

## Candidate overlap

### Candidate overlap 1 — Gu–Yin–Cai–Fan (STRONG OVERLAP)

Source title and version: “Optimally taming biases in black-box models for efficient semiparametric estimation,” arXiv:2606.06368v1, 2026-06-04.  
Exact overlapping theorem or claim: Appendix A.1, Theorem A.1 lower bound `q+[a+s^2][b+t^2]+(s∧t)^2`; same four budget roles and class-outer minimax logic.  
Input/access comparison: Source outer target classes admit tailored black-box learner classes; manuscript publishes represented learner classes and exact upper budgets directly. Both allow class-specific estimators.  
Assumption comparison: Both use bounded PLMs and exact constant conditional treatment variance in their lower theorem; manuscript generalizes the covariate space but adds standard-Borel representation, shared envelope/variance interval and positive-radius `c_rad` field.  
Quantifier comparison: Both are `sup_class inf_estimator sup_law`; manuscript makes `n`/budget dependence and Borel access explicit.  
Conclusion/rate/loss comparison: Source lower has `q+AB+M`; manuscript obtains matching expected-absolute `q+AB+M+O+P` and E/I/S boundary.  
Direct collision, routine implication, partial overlap, or no verified collision: STRONG OVERLAP, not a DIRECT COLLISION with the full law.  
Exact supporting locator: Source pp. 19–20, eq. (A.2), Theorem A.1; manuscript pp. 1, 3, 6, 9 and Table 5.  
Reviewer confidence: HIGH; PRIMARY VERIFIED.  

### Candidate overlap 2 — Gu TAME (STRONG OVERLAP)

Source title and version: “Optimal use of a black-box learner in semiparametric estimation,” arXiv:2607.21541v1, 2026-07-23.  
Exact overlapping theorem or claim: TAME Algorithm 1, Theorem 3.1, Corollary 3.2; O/R editing/calibration branches and two-learner remainder.  
Input/access comparison: Source takes initial fits, a reference class, branch, and tuning; manuscript constructs public class fits, edits and a deterministic budget-based branch.  
Assumption comparison: Source requires its stochastic-radius definition/floor, easier-estimate inclusion and nondegenerate residual variance; manuscript uses a positive-radius public-class condition, exact constant conditional variance, countable representation and all budgets including zero.  
Quantifier comparison: Source is a high-probability oracle inequality for a fixed input/class; manuscript closes it as a uniform fixed-pair Borel rule before taking an outer pair supremum.  
Conclusion/rate/loss comparison: Source gives the two-branch upper mechanism; manuscript does not claim that mechanism as new and adds lower O/P necessity plus global minimax assembly.  
Direct collision, routine implication, partial overlap, or no verified collision: STRONG OVERLAP for the upper architecture; no full-theorem collision.  
Exact supporting locator: Source pp. 14–16, Algorithm 1, Theorem 3.1, Corollary 3.2; manuscript pp. 1, 4, 9 and Appendix B.  
Reviewer confidence: HIGH; PRIMARY VERIFIED.  

### Candidate overlap 3 — Gu COLT open problem

Source title and version: “Open Problem: Structure-Agnostic Minimax Risk for Partial Linear Model,” PMLR 291, 2025.  
Exact overlapping theorem or claim: Four-budget PLM minimax problem, DML upper and earlier lower gap.  
Input/access comparison: Public/tailored black-box classes and known budgets in both.  
Assumption comparison: Source uses bounded uniform-covariate PLM with treatment-variance lower bound; manuscript fixed conditional variance/standard-Borel represented model.  
Quantifier comparison: Same outer-class/pair-specific minimax architecture.  
Conclusion/rate/loss comparison: Source poses the unresolved gap; manuscript claims a scoped sharp law.  
Direct collision, routine implication, partial overlap, or no verified collision: CONTEXTUAL problem origin, not a collision.  
Exact supporting locator: Source Question 1, eqs. (7)–(9), p. 4; manuscript Sections 2–3 and 11.  
Reviewer confidence: HIGH; PRIMARY VERIFIED.  

### Candidate overlap 4 — Jin–Mackey–Syrgkanis

Source title and version: “It's Hard to Be Normal: The Impact of Noise on Structure-agnostic Estimation,” arXiv:2507.02275v3 / NeurIPS 2025.  
Exact overlapping theorem or claim: PLM coefficient, structure-agnostic lower bounds, known Gaussian noise distribution/variance barrier, binary-treatment lower bound, fuzzy testing.  
Input/access comparison: Supplied nuisance point estimates and `L_s` error balls, not represented public learner classes with approximation/stochastic complexity budgets.  
Assumption comparison: Binary, Gaussian, or independent non-Gaussian noise depending on result; Gaussian support is unbounded and noise distributional shape is central.  
Quantifier comparison: Local minimax quantile risk around nuisance estimates, not the manuscript's `sup_Gamma inf_delta sup_P` class cell.  
Conclusion/rate/loss comparison: DML product lower/ACE higher-order rates; no `q+AB+M+O+P` four-budget law.  
Direct collision, routine implication, partial overlap, or no verified collision: PARTIAL/CONTEXTUAL overlap; excluded as direct collision.  
Exact supporting locator: Source Definition 2.3 and Theorems 3.1–3.2, pp. 3–5.  
Reviewer confidence: HIGH; PRIMARY VERIFIED.  

### Candidate overlap 5 — Jin–Syrgkanis general linear functionals

Source title and version: “Sharp Structure-Agnostic Lower Bounds for General Linear Functional Estimation,” arXiv:2512.17341v2, 2026-01-05.  
Exact overlapping theorem or claim: General fuzzy-hypothesis lower principles; mixed-bias product rate; PLM expected conditional covariance submodel.  
Input/access comparison: Point nuisance estimates/error neighborhoods, not public learner classes/budget cells.  
Assumption comparison: General linear/generalized regression functionals; PLM example uses binary variables.  
Quantifier comparison: Anchored local/quantile minimax; not Q1.  
Conclusion/rate/loss comparison: Product or product-plus-square lower fields; no directional O/P four-budget statement.  
Direct collision, routine implication, partial overlap, or no verified collision: PARTIAL OVERLAP; lower-bound technology/phenomenology only.  
Exact supporting locator: Source main contribution, informal Theorem 2.1, and Section 7.5/Theorem 7.5.  
Reviewer confidence: HIGH; PRIMARY VERIFIED.  

### Candidate overlap 6 — BKW

Source title and version: “The Fundamental Limits of Structure-Agnostic Functional Estimation,” arXiv:2305.04116v2, 2025-06-07.  
Exact overlapping theorem or claim: Structure-agnostic lower-bound framework and fuzzy/constrained-risk technology for canonical functionals.  
Input/access comparison: Black-box nuisance estimates/error neighborhoods, not public class complexity budgets.  
Assumption comparison: Different target functionals and model families.  
Quantifier comparison: Instance/local structure-agnostic minimax rather than the manuscript's public pair outer game.  
Conclusion/rate/loss comparison: First-order/product-rate lower limits; no PLM coefficient directional terms.  
Direct collision, routine implication, partial overlap, or no verified collision: CONTEXTUAL.  
Exact supporting locator: Source Theorems 1–2 and Appendix lower-bound setup.  
Reviewer confidence: HIGH; PRIMARY VERIFIED.  

### Candidate overlap 7 — classical DML/orthogonal learning

Source title and version: Chernozhukov et al. (2018); Foster–Syrgkanis (2023 version supplied).  
Exact overlapping theorem or claim: Product-rate nuisance remainder, sample splitting/cross-fitting, orthogonal PLM learning.  
Input/access comparison: Fitted nuisance estimates or algorithms, not outer public budget cells.  
Assumption comparison: Orthogonality/product rates under regularity/curvature; no exact fixed-variance four-budget lower model.  
Quantifier comparison: Uniform/asymptotic or excess-risk bounds, not the Q1 outer game.  
Conclusion/rate/loss comparison: Root-n/product upper benchmarks.  
Direct collision, routine implication, partial overlap, or no verified collision: CONTEXTUAL background.  
Exact supporting locator: DML PLR example/main theory; Orthogonal Statistical Learning main framework.  
Reviewer confidence: HIGH; PRIMARY VERIFIED.  

### Candidate overlap 8 — unrelated minimax PLM design papers

Source title and version: “Minimax designs for partially linear models” and older quasi-minimax/partially-linear design results returned by broad searches.  
Exact overlapping theorem or claim: Only the words “minimax” and “partially linear.”  
Input/access comparison: Experimental-design or shrinkage settings, no black-box nuisance classes.  
Assumption comparison: Different regression/design problem.  
Quantifier comparison: Design minimax, not estimator/class/law minimax.  
Conclusion/rate/loss comparison: No semiparametric coefficient four-budget rate.  
Direct collision, routine implication, partial overlap, or no verified collision: FALSE LEAD.  
Exact supporting locator: Search metadata/abstract; excluded before relying on it as evidence.  
Reviewer confidence: HIGH on exclusion.  

Do not convert an unproductive search into novelty credit. The conclusion is therefore: **在我记录的检索范围和时间边界内，我没有找到直接 prior-work collision。** This is a conditional search result, not proof of nonexistence.
