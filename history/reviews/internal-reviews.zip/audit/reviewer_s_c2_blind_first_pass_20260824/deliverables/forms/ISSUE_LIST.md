# Auditor S issue list

## Issue

### Issue S-C2-01 — M1 statistical experiment and identification

Manuscript page/section/claim: PDF pp. 2 and 10–11; Section 2; Appendix A.1; eqs. (2)–(3).  
Source title/version: Manuscript-authoritative model; comparison checked against Gu (2025) and Gu–Yin–Cai–Fan (2026 v1).  
Source theorem/page/equation: Gu (2025), eqs. (7)–(9); Gu–Yin–Cai–Fan, Appendix A.1, (A.1)–(A.2).  
Issue type: PASS — model definition/identification.  
Exact concern: Whether the observables, product sigma-field, boundedness, target, nuisances, residual conditions, and nondegenerate treatment variation jointly define a nonempty identifiable PLM.  
Model or quantifier mismatch: No internal mismatch found. In the interior `0<v_-<B0^2`, positive conditional residual variance identifies `beta`; the manuscript expressly assigns no minimax risk to the empty `v_->B0^2` regime and separately handles saturation.  
Attribution or wording impact: Supports the statistical-coefficient claim; no causal estimand is established or claimed.  
Collision strength: CONTEXTUAL model ancestry only.  
Severity: MAJOR if wrong; no failure found.  
Evidence needed: None beyond the supplied manuscript and primary-source comparison for this audit scope.  
Reviewer confidence: HIGH; PRIMARY VERIFIED.  

### Issue S-C2-02 — Q1 order and public-pair-specific rules

Manuscript page/section/claim: PDF p. 2, eq. (4); pp. 10–11, Appendix A.2–A.3.  
Source title/version: Gu (2025), COLT/PMLR final; Gu–Yin–Cai–Fan (2026 v1).  
Source theorem/page/equation: Gu (2025), eq. (8); Gu–Yin–Cai–Fan, eq. (A.2).  
Issue type: PASS — quantifier order.  
Exact concern: Whether the manuscript exchanges `sup_Gamma inf_delta` with `inf_delta sup_Gamma`, permits a law-dependent rule, or exposes a latent hard label.  
Model or quantifier mismatch: The paper consistently uses `sup_Gamma inf_{delta_Gamma} sup_P`. `Gamma`, `rho`, and budgets are known before rule design; the rule is fixed before `P`; data are generated under `P`; the same rule is evaluated uniformly over `P`. Public pairs may depend on `n`/budget but not realized data or hard labels.  
Attribution or wording impact: The result is pair-specific information-theoretic minimax, not one universal adaptive algorithm. The wording now says so.  
Collision strength: STRONG OVERLAP in minimax architecture with Gu (2025) and Gu–Yin–Cai–Fan, accurately acknowledged.  
Severity: MAJOR if misread; no logical exchange found.  
Evidence needed: None; retain the explicit order in any revision.  
Reviewer confidence: HIGH; PRIMARY VERIFIED.  

### Issue S-C2-03 — fixed conditional variance is restrictive, not WLOG

Manuscript page/section/claim: PDF pp. 2–3; Sections 2–3 and 8; Appendix A.1, C.2–H.  
Source title/version: Gu–Yin–Cai–Fan (2026 v1); Jin–Mackey–Syrgkanis (2025 v3).  
Source theorem/page/equation: Gu–Yin–Cai–Fan (A.1); Jin–Mackey–Syrgkanis Theorems 3.1–3.2.  
Issue type: CONDITIONAL PASS — scope/positioning, not a detected theorem error.  
Exact concern: `E[u^2|X]=v` constant might be silently treated as a scale normalization or generalized to heteroskedastic PLMs.  
Model or quantifier mismatch: It is a genuine homoskedastic restriction. Rescaling `T*=T/c` sends `pi*=pi/c`, `u*=u/c`, `v*=v/c^2`, and `beta*=c beta` if `Y` is unchanged; envelopes, approximation budgets, target range, and absolute loss all change. An `x`-dependent rescaling would also alter the PLM coefficient structure. Therefore setting `v=1` is not WLOG for the stated minimax problem. The manuscript does not make that WLOG claim and constructs every lower witness at exact `v_-`.  
Attribution or wording impact: All novelty and significance claims must retain “fixed conditional variance/homoskedastic.”  
Collision strength: PARTIAL OVERLAP with prior fixed-variance PLM lower models; no full-rate collision found.  
Severity: MAJOR scope limitation.  
Evidence needed: A heteroskedastic theorem would be new evidence and would materially broaden the claim.  
Reviewer confidence: HIGH; PRIMARY VERIFIED.  

### Issue S-C2-04 — public represented classes and exact budgets are oracle-level inputs

Manuscript page/section/claim: PDF pp. 1–2, Table 1; pp. 6–10, Sections 8–11; pp. 10–11, Appendix A.2–A.3.  
Source title/version: Gu (2025); Gu–Yin–Cai–Fan (2026 v1); Gu TAME (2026 v1).  
Source theorem/page/equation: Gu (2025), eq. (8); Gu–Yin–Cai–Fan (A.2), Theorem A.1; TAME Algorithm 1, Theorem 3.1 and Corollary 3.2.  
Issue type: CONDITIONAL PASS — information-structure interpretation.  
Exact concern: The selector knows the entire represented class pair, exact upper budgets and ordering, and may be tailored to each pair; this can be mistaken for adaptivity to unknown nuisance difficulty.  
Model or quantifier mismatch: No hidden truth, population best approximant, realized error, or hard label is supplied. Nevertheless, class representation and exact budgets are substantial oracle information. The paper explicitly disclaims unknown-budget adaptation, universal pair-independent estimation, optimization oracles, and polynomial time.  
Attribution or wording impact: Valid only as a public-class information-theoretic minimax theorem. Any broader practical/adaptive wording would fail.  
Collision strength: STRONG OVERLAP in information architecture with the Gu line of work; the measurable-interface closure is the narrower increment.  
Severity: MAJOR for significance/interpretation, not correctness.  
Evidence needed: A budget-adaptive or computationally specified procedure would change the judgment.  
Reviewer confidence: HIGH; PRIMARY VERIFIED.  

### Issue S-C2-05 — BBM transfer

Manuscript page/section/claim: PDF p. 12, Lemma 4, eq. (B.2).  
Source title/version: Peter L. Bartlett, Olivier Bousquet, Shahar Mendelson, “Local Rademacher Complexities,” author version dated 2004-05-14 / Annals of Statistics 33(4), 2005.  
Source theorem/page/equation: Theorem 2.1, journal pp. 1503–1504 (author PDF pp. 6–7).  
Issue type: PASS — exact citation transfer.  
Exact concern: Whether symmetrizing the class, setting source `alpha=1`, replacing `[a,b]` by `[-B,B]`, and weakening the failure probability produce the displayed constants.  
Model or quantifier mismatch: None. The source gives `4 E R_n + sqrt(2 sigma^2 z/n) + 8Bz/(3n)` after the stated substitutions; adjoining negatives turns the one-sided supremum into the absolute supremum, and countability supplies source measurability.  
Attribution or wording impact: Lemma 4 is a direct transfer, not an original concentration result; the manuscript says so.  
Collision strength: ROUTINE IMPLICATION/technical tool.  
Severity: MINOR; no failure found.  
Evidence needed: None.  
Reviewer confidence: HIGH; PRIMARY VERIFIED.  

### Issue S-C2-06 — Gu–Yin–Cai–Fan and TAME theorem-field mapping

Manuscript page/section/claim: PDF pp. 1, 4, 6, 9; Table 5; Sections 4, 6, 11.  
Source title/version: Gu–Yin–Cai–Fan, arXiv:2606.06368v1 (2026-06-04); Gu, arXiv:2607.21541v1 (2026-07-23).  
Source theorem/page/equation: Gu–Yin–Cai–Fan Theorem A.1, source pp. 19–20; TAME Algorithm 1, Theorem 3.1 and Corollary 3.2, source pp. 14–16.  
Issue type: PASS — attribution.  
Exact concern: Whether the paper understates prior lower rates or presents TAME's upper architecture as its own.  
Model or quantifier mismatch: The source Theorem A.1 explicitly lower-bounds `q+[a+s^2][b+t^2]+(s∧t)^2`; TAME explicitly supplies O/R editing/calibration branches and a two-learner rate. The manuscript credits both, does not claim `ab`, `M`, generic editing, or the branch architecture as new, and supplies a self-contained proof because its exact access/complexity field differs from TAME's theorem assumptions.  
Attribution or wording impact: The residual novelty must remain O/P necessity, exact M1 closure/assembly, and E/I/S boundary.  
Collision strength: STRONG OVERLAP, accurately positioned; not a DIRECT COLLISION with the full theorem.  
Severity: MAJOR; no attribution failure found.  
Evidence needed: None for the checked versions; later versions should be rechecked before submission.  
Reviewer confidence: HIGH; PRIMARY VERIFIED.  

### Issue S-C2-07 — `ab` and `M` proof ownership

Manuscript page/section/claim: PDF pp. 5–6 and 24–28; eq. (9); Appendices E and F.  
Source title/version: Gu–Yin–Cai–Fan, arXiv:2606.06368v1; Gu TAME, arXiv:2607.21541v1.  
Source theorem/page/equation: Gu–Yin–Cai–Fan Theorem A.1; TAME Proposition 2.3/Corollary 2.2 for the one-learner analogue.  
Issue type: PASS — restrained proof attribution.  
Exact concern: Whether proof length is being used to rebrand known `ab` and common-stochastic rates as new.  
Model or quantifier mismatch: `ab` is already contained in `AB`, and `M=(s∧t)^2` is explicit in Theorem A.1. The manuscript's Appendix E singleton-public-pair and Appendix F finite-dictionary equal-variance constructions are self-contained native certificates, but the rates are not new.  
Attribution or wording impact: Category 3, “已有定理在精确 M1/fixed-variance theorem field中的技术性适配/原生证书,” not substantive rate invention. The manuscript adopts this boundary.  
Collision strength: STRONG OVERLAP at rate level; technical adaptation at proof-field level.  
Severity: MAJOR attribution question; PASS as written.  
Evidence needed: None unless the manuscript later claims these rates as novel.  
Reviewer confidence: HIGH; PRIMARY VERIFIED.  

### Issue S-C2-08 — direct prior-work collision search

Manuscript page/section/claim: PDF pp. 1, 3–9 and 11; claimed full law and directional O/P rays.  
Source title/version: Candidate set recorded in `NOVELTY_AND_COLLISION_SEARCH_LOG.md` and `../PRIOR_WORK_COLLISION_MATRIX.md`.  
Source theorem/page/equation: Gu–Yin–Cai–Fan Theorem A.1; TAME Corollary 3.2; Jin–Mackey–Syrgkanis Theorems 3.1–3.2; Jin–Syrgkanis general lower-bound results; BKW Theorems 1–2.  
Issue type: CONDITIONAL PASS — no verified direct collision in the recorded range.  
Exact concern: Whether another work already proves the full `q+AB+M+O+P` law under the same public-class, fixed-variance, expected-absolute-loss order.  
Model or quantifier mismatch: The closest sources either omit O/P, use one common stochastic budget, use point nuisance estimates/error balls rather than public class/budget cells, impose Gaussian/binary/independent-noise structure, or study different functionals/losses.  
Attribution or wording impact: The paper may say no direct collision was found, but not that none exists.  
Collision strength: No DIRECT COLLISION found; two STRONG OVERLAP components and several PARTIAL/CONTEXTUAL candidates.  
Severity: MAJOR novelty uncertainty.  
Evidence needed: Forward-citation updates, OpenReview/venue papers becoming public before the relevant deadline, and later arXiv versions.  
Reviewer confidence: MEDIUM; PRIMARY VERIFIED for inspected candidates, search completeness inherently limited.  

### Issue S-C2-09 — novelty and ICLR significance

Manuscript page/section/claim: PDF pp. 1–9 and 11; abstract, contributions, Figure 1, Tables 3–5, limitations.  
Source title/version: ICLR 2027 Reviewer Guidelines; closest sources above.  
Source theorem/page/equation: ICLR guide's four questions on problem, motivation/literature, support, and significance; Gu–Yin–Cai–Fan Theorem A.1; TAME Corollary 3.2.  
Issue type: CONDITIONAL PASS — BORDERLINE significance.  
Exact concern: Whether the residual increment after removing prior `q+AB+M` and TAME architecture is sufficient for ICLR.  
Model or quantifier mismatch: The O/P terms dominate the inherited rate on explicit rays, so they are not a constant/symbolic refinement. The E/I/S boundary is also conceptually clear. But the theorem is limited to exact public budgets, represented classes, pair-specific Borel rules, fixed conditional variance, and no computational/adaptive deliverable.  
Attribution or wording impact: Novelty is established more strongly than broad significance.  
Collision strength: STRONG OVERLAP plus a real residual increment.  
Severity: MAJOR conference-value judgment.  
Evidence needed: Independent verification of O/P proofs; broader variance/access theorem; adaptive/computable procedure; or a direct collision.  
Reviewer confidence: MEDIUM.  

### Issue S-C2-10 — time boundary and manuscript provenance

Manuscript page/section/claim: PDF header “Under review ... ICLR 2027”; references/version statements.  
Source title/version: Local PDF metadata; arXiv version histories; ICLR 2027 Author/Reviewer Guidelines.  
Source theorem/page/equation: N/A—version/provenance field.  
Issue type: CONDITIONAL PASS — temporal evidence limitation.  
Exact concern: The manuscript's earliest public date and actual submission date are not supplied, so priority can only be conditioned on the local artifact date.  
Model or quantifier mismatch: N/A. The local PDF was created 2026-08-24; Gu–Yin–Cai–Fan v1 was public 2026-06-04 and TAME v1 2026-07-23. Exact-title search found no public manuscript copy as of 2026-08-24. ICLR 2027 full-paper deadline is 2026-09-25 AOE.  
Attribution or wording impact: Both closest sources are prior-public relative to the local artifact and are cited; the manuscript's own priority relative to undiscovered work remains conditional.  
Collision strength: N/A—timeline qualification.  
Severity: MINOR for current attribution, potentially MAJOR if an earlier equivalent source emerges.  
Evidence needed: Public preprint/submission timestamp or an author-supplied provenance record that does not reveal identity.  
Reviewer confidence: HIGH on recorded dates; LOW on unknown earliest-public date.  
