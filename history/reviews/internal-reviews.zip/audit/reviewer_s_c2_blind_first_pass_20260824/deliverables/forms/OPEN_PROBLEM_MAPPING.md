# Open-problem mapping

Source problem statement and exact locator: Yihong Gu, “Open Problem: Structure-Agnostic Minimax Risk for Partial Linear Model,” COLT 2025/PMLR 291, Question 1 (PDF p. 2) and formal definition (7)–(9), Theorem 1 and the paragraph immediately after it (PDF p. 4). Stable source: [PMLR 291 proceedings page](https://proceedings.mlr.press/v291/gu25b.html).  

Source model, loss, and quantifiers: `2n` i.i.d. observations from a bounded PLM with `X~Unif([0,1]^d)`, `E[u|X]=0`, `E[u^2|X]>=1/3`, `E[eps|X,T]=0`, bounded functions/variables, squared-error risk, and the outer order `sup_{F_pi,F_mu in H_n} inf_estimator sup_{P in P(F_pi,F_mu)}`. The source asks for matching upper/lower bounds between the displayed lower `n^-1/2+[a+s^2][b+t^2]` and DML upper `n^-1/2+(a+s)(b+t)`.  

Manuscript model, loss, and quantifiers: `2n` i.i.d. observations on a standard-Borel `X`, expected absolute error, bounded PLM, `E[u^2|X]=v` constant in a known interval, public represented learner classes `Gamma=(G_mu,G_pi)`, known upper budgets `(a,s,b,t)`, and `sup_{Gamma in G_{rho,n}} inf_{Borel delta_Gamma} sup_{P in P(Gamma)} E|delta_Gamma-beta(P)|`; PDF pp. 2 and 10–11, eqs. (2)–(5), Appendix A.  

Exact containment or mismatch: The manuscript preserves the source's public-class-pair-before-law minimax architecture and four approximation/stochastic budgets, but it is not a literal solution to every model in the open note. It changes squared to absolute loss, makes conditional variance exactly constant rather than only lower bounded, enforces a shared finite envelope and standard-Borel/countable representation, and treats public learner classes directly. Its Q1 class pairs may depend on `n` and the budget cell. Thus the relationship is a precise bounded fixed-variance specialization/closure, not equivalence to the unrestricted open question.  

What the manuscript can accurately claim to resolve: It can claim a sharp all-budget expected-absolute-error minimax characterization for its explicitly stated bounded M1 fixed-variance public-class model, with rate `q+AB+M+O+P`, and can state that this resolves the bounded fixed-variance/public-representation version of the COLT four-budget interface.  

What remains outside its scope: Heteroskedastic or merely variance-lower-bounded PLMs; unknown budgets/adaptation; one pair-independent algorithm; uncoded nonseparable classes; computation/runtime; confidence intervals/asymptotic efficiency; causal identification; and the full source formulation under squared risk without the manuscript's access restrictions.  

Does the wording require correction?: No material correction is required in C2. The abstract, introduction, Sections 8–11, and Table 5 repeatedly state the bounded fixed-variance/public M1 scope and nonclaims. A minor clarity improvement would put “fixed conditional variance” in the title itself.  

Reviewer confidence and evidence: HIGH; PRIMARY VERIFIED against the supplied COLT PDF and PMLR page, and against manuscript PDF pp. 1–3, 6–11 and Appendix A.  
