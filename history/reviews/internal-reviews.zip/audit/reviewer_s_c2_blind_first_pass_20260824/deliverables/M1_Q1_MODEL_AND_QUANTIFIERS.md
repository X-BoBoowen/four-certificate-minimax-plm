# M1/Q1 model cards, relationship, and quantifier expansion

## Verdict

**M1: PASS (MAJOR, HIGH confidence, PRIMARY VERIFIED).**  
**Q1: PASS (MAJOR, HIGH confidence, PRIMARY VERIFIED).**

I can reconstruct both objects without supplying missing definitions. The main remaining caution is interpretive: Q1 is an outer supremum over fixed public M1 pairs, each with its own rule; it is not a single unknown-class adaptive estimation problem.

## M1 card — fixed public-pair experiment

| Field | Independent reconstruction | Authoritative locator |
|---|---|---|
| Sample space | A standard-Borel measurable space `(X,A)` and `Z=X×R×R` with product sigma-field; coordinate maps `(X,T,Y)` are measurable | p. 2, Section 2; pp. 10–11, Appendix A.1 |
| Observations | Two independent halves `D1,D2`, each containing `n` i.i.d. copies of `Z`; total `N=2n` | p. 2, eq. (2); p. 11, Appendix A.3 |
| Data-generating factorization | Choose `P_X`; given `X`, generate `T=pi_0(X)+u` with `E[u given X]=0`, `E[u^2 given X]=v`; given `(X,T)`, generate `Y=beta_0 T+mu_0(X)+eps` with `E[eps given X,T]=0` | p. 2, eq. (2); p. 11, Appendix A.1 |
| Independence | The `2n` observations are i.i.d.; the two halves are independent because they consist of disjoint i.i.d. observations. The theorem does not require `u` independent of `X` or `eps` independent of `(X,T)` | p. 2, lines surrounding eq. (2) |
| Conditional variance | `E[u^2 given X]=v` almost surely for one law-specific constant `v∈[v_-,v_+]`; no heteroskedasticity | p. 2; p. 11, Appendix A.1 |
| Boundedness | `abs(Y), abs(T), abs(beta_0), abs(mu_0(X)), abs(pi_0(X)), abs(u), abs(eps) ≤ B0`, with the additional target restriction `beta_0∈[-3,3]`; fixed `B0≥3` | p. 11, Appendix A.1 |
| Target | Statistical PLM conditional-mean coefficient `beta_0`; no potential outcomes or causal estimand | pp. 2, 7; p. 11, Appendix A.1 |
| Nuisance functions | `mu_0:X→R` and `pi_0:X→R`, measurable versions under the declared standard-Borel experiment | pp. 2, 10–11 |
| Public information | A represented pair `Gamma=(G_mu,G_pi)` of bounded nuisance learner classes; each has a supplied pointwise-dense countable measurable representation and measurable evaluation maps; fixed `rho=(B0,v_-,v_+,c_rad)` and known budgets `(a,s,b,t)` | p. 2, Section 2; p. 11, Appendix A.2 |
| Unknown information | `P_X`, `P`, `v` inside its interval, `beta_0`, `mu_0`, `pi_0`, best population approximants, realized errors, hard label/coordinate/sign | Table 1 p. 2; Appendix A.2 |
| Approximation restrictions | `inf over g∈G_mu of norm(g-mu_0)_2 ≤ a`; mirror bound `inf over g∈G_pi of norm(g-pi_0)_2 ≤ b` | p. 2, eq. (3) |
| Stochastic/complexity restrictions | For positive radii only, `sup_{r≥s,r>0} R_n(r;Delta G_mu)/(3r)≤c_rad s` and the mirror bound with `t`; declared budgets are upper bounds, not realized errors | p. 11, eq. (A.1) |
| Parameter space | All laws satisfying the preceding fields for the fixed public pair; denoted `P(Gamma)` | p. 2 and Appendix A |
| Estimator access | A Borel rule `delta_Gamma:Z^(2n)→R` may depend on `Gamma,rho,a,s,b,t` but not on the true law or proof-only objects | p. 2, eq. (4); p. 11, Appendix A.3 |
| Loss/risk | Expected absolute error `E_P abs(delta_Gamma-beta(P))` | p. 2, eq. (4) |
| Sample-size dependence | `Gamma` and hard families may depend on `n` and the declared budget cell, but are fixed before data and latent choices; no one pair must serve all `n` | p. 11, Appendix A.3 |
| Nonemptiness | Q1 admits only represented pairs with nonempty compatible law sets. If `v_->B0^2`, the entire experiment is declared empty and no minimax rate is assigned | pp. 2–3; Appendix A.3 and H |

## Identification check

For a fixed `X=x`, the conditional mean is

`E[Y|X=x,T=t]=beta_0 t+mu_0(x)`.

Because `Var(T|X)=E[u^2|X]=v≥v_->0`, `T` is not conditionally degenerate. If two pairs `(beta,mu)` and `(beta',mu')` give the same conditional mean, then `(beta-beta')T+(mu-mu')(X)=0` almost surely. Conditional variance given `X` yields `(beta-beta')^2 v=0`, hence `beta=beta'` and then `mu=mu'` almost surely. Thus the statistical coefficient is identifiable in every nonempty interior/saturation law. No overlap, SUTVA, consistency, or no-unmeasured-confounding assumption is needed for this statistical target; those would be needed only for a causal reading, which is expressly disclaimed.

## Q1 card — outer public-class game

For each fixed `rho`, `n`, and `(a,s,b,t)`, define `G_{rho,n}(a,s,b,t)` as the represented public pairs satisfying M1's class fields and having `P(Gamma)≠∅`. Then

`R_pair(n,rho;a,s,b,t) = sup_{Gamma∈G_{rho,n}} inf_{delta_Gamma Borel} sup_{P∈P(Gamma)} E_P |delta_Gamma(Z_1:2n)-beta(P)|`.

| Question | Reconstruction |
|---|---|
| Who moves first? | At theorem/game level, the outer adversary selects a legal public pair `Gamma` for the declared cell. |
| What does the learner know? | The full represented pair, fixed regularity tuple, exact budget upper bounds, and `n`. |
| When is the rule selected? | After the public pair is known, before the true `P` is known. |
| May the hard law depend on the rule? | The `inf_delta sup_P` order permits the adversary's worst law to depend on the candidate rule, as in ordinary minimax lower bounds. The paper's fuzzy prior pairs are in fact common testing families inside a fixed published `Gamma`. |
| May `Gamma` depend on data or hard label? | No. It may depend only on `n` and declared budgets and is fixed before sample/latent label/coordinate/sign. |
| Does the theorem require a single estimator across all pairs? | No. It allows a different Borel rule `delta_Gamma` for each public pair. |
| Are constants uniform? | In the interior they depend only on fixed `rho`, not on `n`, budgets, `Gamma`, or `P`; they need not remain uniform as `v_-↑B0^2` or `c_rad↓0`. |

## M1–Q1 relationship

```text
fixed rho, n, budget cell
        |
        v
outer collection G_{rho,n}(a,s,b,t)
        |
        +-- each Gamma defines one M1 fixed-pair experiment P(Gamma)
        |       |
        |       +-- learner knows Gamma and chooses delta_Gamma
        |       +-- nature chooses P in P(Gamma)
        |       +-- expected absolute risk is computed
        |
        v
Q1 takes sup_Gamma of the fixed-pair minimax risks
```

Thus Q1 is neither a lift from another observation model nor an equivalence claim. It is an outer aggregation of M1 experiments. The relation is one-way by construction: every Q1 component is an M1 experiment, while M1 alone does not impose the outer `sup_Gamma` comparison.

## Explicit quantifier table

| Claim | Explicit logic | Audit |
|---|---|---|
| Fixed-pair upper bound | `For all legal Gamma, there exists one Borel delta_Gamma such that for all P∈P(Gamma), risk≤C_rho(q+X)` | PASS; Appendix B builds the rule before uniform law substitution |
| Outer upper bound | `For all Gamma, inf_delta sup_P risk≤C_rho(q+X)`, hence `sup_Gamma inf_delta sup_P≤...` | PASS; no `sup/inf` exchange |
| Component lower bound | For each component `j∈{q,ab,M,O,P}`, `there exists a legal Gamma_j(n,budgets)` such that `for all delta`, `there exists P` (or a two-prior mixture) with risk `≥c_j component_j` | PASS; one public pair per component is enough for an outer supremum |
| Lower assembly | `R_pair≥max_j c_j term_j≥(min_j c_j/5) sum_j term_j` plus deterministic comparison to `q+X` | PASS; it does not add Bayes risks from different experiments |
| Public-pair timing | `For every n,budget cell, Gamma may be selected; then Gamma is fixed before data/latent label` | PASS; Appendix A.3 |
| Uniform constants | `There exist c_rho,C_rho>0` after fixed interior `rho`, `for all n,budgets,Gamma,P` | PASS; boundary nonuniformity is explicitly excluded |
| Empty regime | If `v_->B0^2`, no law exists; no numerical supremum/rate is assigned | PASS; avoids defining a supremum over an empty model |
| Saturation regime | Pairwise root-n upper for every nonempty pair; one singleton pair gives the outer lower | PASS; the differing upper/lower witnesses are consistent with `sup_Gamma inf_delta sup_P` |

## Statistical-learning conditions

- Cross-fitting/sample splitting is built into the two independent halves. The proof does not rely on a Donsker condition for data-dependent nuisance substitutions; it uses countable public representations and uniform empirical-process events before fitted substitution.
- Orthogonality appears through residualized/editing constructions; the exact target remainder is not merely the standard DML product. The product and directional terms are justified by the paper's separate upper/lower mechanisms.
- `c_rad>0` is essential. At `c_rad=0`, positive-budget finite-dictionary lower classes would violate the stated complexity field; C2 explicitly excludes this boundary and rescales the lower dictionaries by `lambda_rho=min{1,192c_rad/23}`.
- Nuisance rates are upper-budget cells, not promises that a particular fitted estimator realizes exactly `a+s` or `b+t`. The upper proof obtains its own approximate empirical minimizers from the public representations.

## Earliest possible failure points checked

1. Product measurable space and evaluation maps: now explicit at Appendix A.1.  
2. Zero-radius quotient: now excluded by `r>0` in (A.1).  
3. Empty compatible cells: excluded from `G_{rho,n}` and separately treated in stratum E.  
4. Rule selected after seeing `P`: prohibited by Appendix A.3.  
5. Public pair selected after hard label/data: prohibited.  
6. Component lower bounds improperly summed: Appendix G uses a maximum then max-to-sum algebra.  
7. Causal interpretation without identification assumptions: not claimed.  

No model-definitional or quantifier failure was found at these first-support points.
