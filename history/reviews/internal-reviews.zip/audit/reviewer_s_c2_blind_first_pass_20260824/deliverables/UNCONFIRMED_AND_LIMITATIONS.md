# Unconfirmed matters and missing-material list

## Missing or unavailable material

| Item | Status | Effect |
|---|---|---|
| Manuscript earliest public timestamp | Not supplied; exact-title search found no indexed copy | Priority can only be stated relative to the local 2026-08-24 artifact. |
| Actual ICLR submission timestamp | Not supplied | Prior/concurrent/later classification remains conditional until the relevant deadline/submission is known. |
| Later versions of Gu et al. and TAME | Only supplied/checked v1 fields were used | A later theorem expansion could alter overlap. |
| Human Reviewer S credentials/signature | Intentionally unavailable because this is an AI-simulated review | This output does not satisfy the package's human-only credited gate. |
| Full Google Scholar export | Not available reproducibly | Citation-forward completeness is limited. |
| Private/nonpublic submissions | Inaccessible and not sought | Cannot affect public-priority findings until public; may explain later concurrent work. |

## Matters not fully confirmed

- A line-by-line independent check of every algebraic and information-divergence step in the O/P appendices was not part of this model/literature/novelty audit. Their novelty credit is conditional on correctness.
- No proof establishes that the same rate holds with heteroskedastic `E[u^2|X]`, unknown budgets, unrepresented classes or a universal pair-independent estimator.
- No polynomial-time implementation or optimization oracle is specified.
- No causal interpretation is established because the manuscript deliberately defines a statistical coefficient without treatment-potential-outcome assumptions.
- Search non-discovery is not evidence of nonexistence; indexing and terminology gaps remain.

## Tool/access limitations

Public web access, arXiv, PMLR and official ICLR pages were available. Supplied PDFs were fully extracted and visually rendered. Some bibliographic databases were accessed only through public indexed pages rather than authenticated APIs. Paywalled content was not used as unsupported evidence.
