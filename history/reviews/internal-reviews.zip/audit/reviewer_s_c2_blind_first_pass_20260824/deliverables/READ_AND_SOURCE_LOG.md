# Actual read-file and external-source log

## Material-isolation decision

The user's request is the controlling review assignment. The archive README, source-audit guide and locator were treated as neutral workflow/locator instructions. `HUMAN_ONLY_REVIEW_NOTICE.md` was treated as a package gate disclosure, not as authority to misrepresent this run as human: the final output is explicitly AI-simulated and receives no human-review credit under that notice. No author internal report, reference answer, filled form, Expert M report, other reviewer opinion, `solution`, `answer`, `internal audit` or `reference report` was present or opened.

## Local files actually read

All paths below are relative to the isolated extraction root.

### Package control and guidance

- `README.md`
- `HUMAN_ONLY_REVIEW_NOTICE.md`
- `PACKAGE_MANIFEST.tsv`
- `PROVENANCE.tsv`
- `MANUSCRIPT_HASH.txt`
- `guides/SOURCE_AND_MODEL_AUDIT_INSTRUCTIONS.md`
- `guides/MANUSCRIPT_SOURCE_LOCATOR.md`

### Blank original forms read and then copied/finalized under deliverables

- `forms/AUDITOR_S_FORM.md`
- `forms/CREDENTIAL_AND_SCOPE_FORM.md`
- `forms/INDEPENDENCE_AND_CONFLICT_FORM.md`
- `forms/ISSUE_LIST.md`
- `forms/NOVELTY_AND_COLLISION_SEARCH_LOG.md`
- `forms/OPEN_PROBLEM_MAPPING.md`
- `forms/SOURCE_VERSION_AND_THEOREM_FIELD_TABLE.md`

### Manuscript

- `manuscript/anonymous_manuscript.pdf` — all 31 pages read as extracted text and visually inspected from page renders/contact sheets.

### Supplied primary/source PDFs

- `sources/balakrishnan_kennedy_wasserman_2305.04116.pdf`
- `sources/bartlett_bousquet_mendelson_author_version.pdf`
- `sources/chernozhukov_et_al_2018_author.pdf`
- `sources/foster_syrgkanis_orthogonal_arxiv.pdf`
- `sources/gu_blackbox_2607.21541.pdf`
- `sources/gu_colt_2025.pdf`
- `sources/gu_yin_cai_fan_2606.06368.pdf`
- `sources/jin_mackey_syrgkanis_2507.02275.pdf`
- `sources/jin_syrgkanis_2402.14264.pdf`
- `sources/jin_syrgkanis_2512.17341.pdf`

## Public external sources actually consulted

| Source | Purpose |
|---|---|
| [BBM DOI record](https://doi.org/10.1214/009053605000000282) | Formal bibliographic metadata and theorem publication. |
| [Gu COLT/PMLR page](https://proceedings.mlr.press/v291/gu25b.html) | Proceedings identity and open-problem version. |
| [Gu et al. arXiv record](https://arxiv.org/abs/2606.06368) | v1 date/version metadata. |
| [TAME arXiv record](https://arxiv.org/abs/2607.21541) | v1 date/version metadata. |
| [BKW arXiv record](https://arxiv.org/abs/2305.04116) | Version/timeline and candidate identity. |
| [Jin–Mackey–Syrgkanis arXiv record](https://arxiv.org/abs/2507.02275) | Version/timeline and candidate identity. |
| [Jin–Syrgkanis general lower bounds](https://arxiv.org/abs/2512.17341) | Version/timeline and candidate identity. |
| [Jin–Syrgkanis ATE work](https://arxiv.org/abs/2402.14264) | Neighboring-lineage check. |
| [ICLR 2027 Reviewer Guidelines](https://iclr.cc/Conferences/2027/ReviewerGuidelines) | Official review criteria. |
| [ICLR 2027 Author Guidelines](https://iclr.cc/Conferences/2027/AuthorGuidelines) | Contemporaneous-work/review context. |
| [ICLR 2027 Call for Papers](https://iclr.cc/Conferences/2027/CallForPapers) | Official cycle deadlines. |

General web, arXiv-indexed, DBLP/PMLR and publicly indexed Semantic Scholar/OpenAlex/Crossref searches are recorded by query in `LITERATURE_SEARCH_LOG.md` and the filled original novelty-search form. Search-result snippets were not used alone as theorem evidence.

## Prior-session exposure disclosure

This same conversation previously contained a separate C1 audit task on the same broad project. For this C2 run, I used only the C2 isolated package, its supplied sources and the newly performed public checks; I did not open or reuse any C1 deliverable, report or filled table. Because topical memory cannot be erased, the run is independent of prohibited materials but not equivalent to a fresh human reviewer with no prior topical exposure. This limitation is declared rather than hidden.
