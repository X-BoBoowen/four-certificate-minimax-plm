# Literature search log

Search cutoff: 2026-08-24, Asia/Shanghai. Time range: classical antecedents through the cutoff, with emphasis on 2018–2026 and version checks for June–August 2026.

| Route | Platforms | Representative queries | Candidates inspected | Result/exclusion logic |
|---|---|---|---|---|
| Exact manuscript identity | General web and arXiv-indexed search | exact title; hyphenation variants of "four-budget minimax rates" | No exact-title public copy | Establishes only that no indexed copy was found, not that none exists. |
| Exact directional algebra | General web/arXiv | `"t(a∧t)" partially linear`; `"s(b∧s)"`; `min(a,t)`/`min(b,s)` directional lower bound | Gu et al.; TAME; recent PLM results | No independent same-field O/P lower theorem located. |
| Model plus rate | General web, arXiv, PMLR, DBLP | structure-agnostic PLM minimax approximation stochastic error four budgets; black-box nuisance critical radius | Gu 2025; Gu et al.; TAME; BKW; Jin et al. | Identified two strong overlaps and several partial/contextual papers. |
| Historical synonyms | Same plus reference lists | semilinear/partial linear coefficient; orthogonal/debiased learning; nuisance misspecification; mixed bias/product rate | DML; orthogonal statistical learning; semiparametric lower-bound line | Contextual ancestry, no complete four-budget theorem. |
| Two-learner architecture | arXiv/general web | `"two learners" "partial linear model"`; TAME acronym/title/ID; editing/calibration | TAME v1 and references | Confirms upper architecture is prior; no matching exact-field lower collision. |
| Metadata/database cross-check | PMLR, DBLP; Semantic Scholar/OpenAlex/Crossref indexed web results | title/author/ID and `site:` queries | Gu COLT record; recent arXiv metadata | Coverage for very recent preprints is incomplete; primary records used for conclusions. |
| Backward/forward-current | Source references, arXiv IDs, web citation leads | exact 2606.06368 and 2607.21541; cited-by/title combinations | Gu et al. v1; TAME v1; cited neighbors | No later public paper with the complete law found by cutoff. |
| Venue/time | Official ICLR pages | ICLR 2027 reviewer guide, author guide, call for papers | Official criteria/deadlines | Used only for venue significance and time boundary. |

## Candidate disposition

- **STRONG OVERLAP:** Gu–Yin–Cai–Fan (2026 v1); TAME (2026 v1).
- **PARTIAL OVERLAP:** Gu (2025 open problem); Balakrishnan–Kennedy–Wasserman; Jin–Mackey–Syrgkanis; general Jin–Syrgkanis lower bounds.
- **CONTEXTUAL:** classical DML/orthogonal learning; neighboring ATE/functionals work.
- **FALSE LEAD:** minimax experimental-design papers sharing only "partially linear" and "minimax."
- **DIRECT COLLISION:** none verified in the recorded range.

Detailed assumption/quantifier/rate comparisons and primary locators are in `forms/NOVELTY_AND_COLLISION_SEARCH_LOG.md` and `PRIOR_WORK_COLLISION_MATRIX.md`.

## Search limitations and confidence

Google Scholar was not available as a reproducible bulk index. Semantic Scholar/OpenAlex/Crossref can lag 2026 preprints. Paywalls, indexing gaps, terminology differences, private submissions and later versions can cause omissions. Primary PDFs/official records were used wherever a candidate affected the conclusion. Search-completeness confidence is **MEDIUM**.

在我记录的检索范围和时间边界内，我没有找到直接 prior-work collision。
