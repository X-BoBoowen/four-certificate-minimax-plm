# Fixed-variance and public-class audit

## Overall findings

- **Fixed variance: CONDITIONAL PASS (MAJOR scope issue, HIGH confidence).** The condition is internally coherent and every displayed lower witness is checked at exact variance, but it is a real homoskedastic restriction and not a WLOG normalization.
- **Public class: CONDITIONAL PASS (MAJOR interpretation issue, HIGH confidence).** The information timeline is now unambiguous and symmetric between upper/lower analyses, but exact class representation and budget knowledge are oracle-level inputs. The theorem is about this public-information model, not unknown-budget adaptation.

## Fixed-variance checklist

| Question | Finding | Locator |
|---|---|---|
| Known or unknown? | The learner knows `[v_-,v_+]`, not the law-specific `v`; at saturation `v_-=B0^2` forces `v=B0^2` | pp. 2–3; Appendix A.1/H |
| Fixed, bounded, or merely finite? | `E[u^2 given X]=v` is exactly constant in `X`, with `v∈[v_-,v_+]` | p. 2, eq. (2); p. 11 |
| Part of model or proof-only? | Part of M1 itself, not a temporary lower-bound device | Sections 2–3; Appendix A.1 |
| May vary with `x`? | No | Same |
| May vary with `n`? | A sequence of adversarial laws may choose different constants inside the fixed interval for different `n`, but each law is conditionally homoskedastic and theorem constants depend only on fixed `rho` | Appendix A.3 |
| May vary with nuisance truth? | Across laws yes, within one law it is constant; the rule is not told the realized `v` | Appendix A.1 |
| Upper/lower same model? | Yes. The upper is uniform over the interval; all interior lower constructions use `v0=v_-` and explicitly verify exact conditional variance | Appendices B–G |
| Singleton interval covered? | Yes, because lower witnesses use exact `v_-` | Appendices D–F; statements after (D.15), (E.13), (F.15) |
| Empty/saturation boundary? | `v_->B0^2`: no law and no rate. `v_-=B0^2`: boundedness forces `u=±B0`, `pi_0=0`, and the risk is root-n | Theorem 1 E/S; Appendix H |
| Does fixed variance reduce difficulty? | Yes. It removes heteroskedastic variance as a learnable nuisance and supports exact moment matching. This is a substantive restriction, openly stated | Sections 8–11 |

## Why `v=1` is not WLOG

Take a constant scaling `T*=T/c`. Then

`T*=pi_0(X)/c+u/c`,  `Var(u/c|X)=v/c^2`.

Keeping `Y` unchanged gives

`Y=(c beta_0)T*+mu_0(X)+eps`,

so the target becomes `beta*=c beta_0`; its permitted range and absolute-error loss scale. The propensity class and approximation/stochastic budgets also scale by `1/c`, while `|T*|`, `|u/c|` and the shared envelope change. Scaling `Y` simultaneously changes `mu_0`, `eps`, and their class budgets. An `x`-dependent normalization `T/sqrt(v(X))` would generally turn a constant coefficient into an `x`-dependent coefficient and change the estimand. Therefore no lossless normalization preserves every object in M1/Q1.

The manuscript does not invoke such a WLOG argument. Its fixed variance should be read as a model choice.

## Lower-witness variance audit

| Mechanism | Variance certificate | Result |
|---|---|---|
| `q` | Appendix C.3 uses a bounded two-point treatment with amplitude capped by `B0/(16 sqrt(v_-))`, and checks the target/envelope | PASS |
| `P` | Three-point channel (C.6) at the label-dependent treatment means; raw-law calculation gives exact residual variance `v0=v_-` under both labels | PASS |
| `O` | Common propensity and the same exact three-point channel; exact variance stated after (D.15) | PASS |
| `ab` | Appendix E applies (C.6) at means `±z eta`; (E.4)–(E.5) certify exact variance and envelopes | PASS |
| `M` | Both labels share `pi=z gamma` and channel (C.6); (F.3) verifies exact `v0` | PASS |
| saturation | Boundedness plus `E[u^2 given X]=B0^2` forces `abs(u)=B0`; centering forces symmetric signs and `pi=0` | PASS |

## Public-class information timeline

The chronological implementation and the mathematical minimax order must be separated:

```text
DESIGN/GAME TIME
1. Fix rho, n, and declared budget cell (a,s,b,t).
2. Outer adversary selects a legal represented public pair Gamma.
3. Learner receives Gamma, its countable representations/evaluation maps,
   rho and exact budget upper bounds; it fixes one Borel rule delta_Gamma.
4. Nature selects P in P(Gamma). For a lower bound this worst P may be
   chosen against the candidate rule; latent labels remain hidden.

RUN TIME
5. P generates 2n i.i.d. observations.
6. delta_Gamma sees the sample and returns an estimate.
7. Expected absolute loss is computed; sup_P, inf_delta, sup_Gamma form Q1.
```

This is exactly `sup_Gamma inf_delta sup_P`, not `inf_delta sup_{Gamma,P}` and not `sup_Gamma sup_P inf_delta`.

## What public information does and does not reveal

| Information | Learner receives it? | Audit consequence |
|---|---|---|
| Full learner class pair and countable coding | Yes | Substantial structural/oracle information; also makes Borel selection auditable |
| Exact upper budgets and their ordering | Yes | Enables deterministic branch choice; claimed “adaptivity” cannot mean unknown-budget adaptation |
| Complexity constant `c_rad`, envelope and variance interval | Yes | Uniform constants may depend on them |
| True nuisance functions | No | No direct oracle truth leakage |
| Population best approximants | No | Upper proof constructs empirical approximate minimizers |
| Realized nuisance errors | No | Branching uses declared budgets, not observed truth-dependent errors |
| Hard coordinate/sign/label | No | Lower dictionaries are public, but the data-generating latent selection is hidden |
| Optimization oracle | No | Existence is information-theoretic via countable/finite-dimensional measurable selections; runtime is unclaimed |

## Alternative interpretations and outcomes

1. **Authoritative interpretation (public pair and exact budgets known before rule design).** The theorem and proofs are coherent; PASS within scope.  
2. **Unknown pair or unknown budgets.** The stated selector is not authorized because branch/tuning and empirical optimization depend on public inputs; the theorem would not establish adaptation.  
3. **Public pair selected after the true law/label or data.** This would leak oracle information and invalidate the lower-game interpretation; Appendix A.3 expressly prohibits it.  
4. **One universal rule required across all pairs.** Q1 does not prove this stronger result, partly because global measurability across an uncoded space of classes is not supplied.  

## Fair comparison to prior work

Gu (2025) and Gu–Yin–Cai–Fan (2026) also use an outer class supremum followed by a class-tailored estimator, so the manuscript does not obtain its comparison by silently giving itself a wholly different minimax order. The exact represented-class interface is more explicit than the sources. TAME's oracle branch/tuning similarly presumes error budgets/order. Accordingly, the public information weakens broad practical interpretation but does not by itself invalidate the paper's within-model prior comparison.

## Minimum positioning repair

C2 already contains the essential repair in the abstract, Table 1, Appendix A, Sections 8–11, and Table 5. I would preserve those restrictions verbatim and, for maximal clarity, add “fixed conditional variance” to the title. No theorem/rate change is required; the effect is on scope and ICLR significance.
