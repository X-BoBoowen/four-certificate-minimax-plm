# Complete Reviewer S issue register

## S-C2-01 — M1 experiment and identification

| Field | Record |
|---|---|
| Task / verdict | M1 model audit — **PASS** |
| Severity / confidence / evidence | CRITICAL if wrong / HIGH / PRIMARY VERIFIED |
| PDF and locator | pp. 2, 10–11; Section 2; Appendix A.1; equations (2)–(3) |
| First possible failure | Definition of the model cell: failure would begin if constant positive treatment-residual variance, conditional means or the common envelope did not jointly hold. |
| Original claim | The displayed bounded PLM defines an identifiable statistical coefficient over a nonempty interior/saturation model. |
| Independent analysis | `E[u given X]=0`, `E[epsilon given X,T]=0` and positive `E[u^2 given X]=v` identify `beta`; the standard-Borel/product-sigma declaration makes conditional objects and Borel rules meaningful. `v_->B0^2` is correctly separated as empty. |
| External source | Gu (2025), [PMLR](https://proceedings.mlr.press/v291/gu25b.html); Gu et al. [arXiv:2606.06368](https://arxiv.org/abs/2606.06368). |
| Nearest-prior difference | Prior models are very close; this manuscript makes the envelope, representation and regime boundary more explicit. |
| Impact | Supports correctness of the estimand and all minimax statements. No causal estimand follows or is claimed. |
| Minimal repair | None. Retain the statistical, not causal, wording. |
| Does repair change theorem/rate/scope/positioning? | N/A—no repair. |
| Unconfirmed | Full line-by-line proof correctness beyond the model/identification layer. |

## S-C2-02 — Q1 quantifier order

| Field | Record |
|---|---|
| Task / verdict | Q1/quantifier audit — **PASS** |
| Severity / confidence / evidence | CRITICAL if exchanged / HIGH / PRIMARY VERIFIED |
| PDF and locator | p. 2 equation (4); pp. 10–11 Appendix A.2–A.3 |
| First possible failure | Moving the learner's `inf` outside `sup_Gamma`, or choosing `delta_Gamma` after nature reveals `P`. |
| Original claim | `sup_Gamma inf_{delta_Gamma} sup_{P in P(Gamma)}` with a rule tailored only to the public pair. |
| Independent analysis | The displayed order is used consistently. `Gamma` may depend on `n` and budgets, but it precedes law/data/hard label; one Borel rule is evaluated uniformly over the cell. |
| External source | Gu (2025), equation (8), [PMLR](https://proceedings.mlr.press/v291/gu25b.html); Gu et al. equation (A.2). |
| Nearest-prior difference | The architecture is prior; explicit Borel access and timing are the manuscript's clarification. |
| Impact | Valid pair-specific information-theoretic minimax, not one universal adaptive algorithm. |
| Minimal repair | None; keep the order and disclaimer prominent. |
| Does repair change theorem/rate/scope/positioning? | Reversing it would materially change the problem; no reversal is needed. |
| Unconfirmed | Whether a practical representation admits computable empirical minimization is outside the theorem. |

## S-C2-03 — fixed variance is not WLOG

| Field | Record |
|---|---|
| Task / verdict | Fixed-variance audit — **CONDITIONAL PASS** |
| Severity / confidence / evidence | MAJOR / HIGH / PRIMARY VERIFIED |
| PDF and locator | pp. 2–3; Sections 2–3, 8; Appendices A.1 and C–H |
| First possible failure | Interpreting `E[u^2 given X]=v` as a harmless normalization or exporting the rate to a heteroskedastic model. |
| Original claim | A sharp theorem for exact constant conditional treatment-residual variance. |
| Independent analysis | Scaling treatment changes coefficient, treatment nuisance, budgets, envelope, target range and absolute loss. Covariate-dependent scaling generally destroys a constant coefficient. Lower witnesses checked use exact `v_-`; upper/lower live in one field. |
| External source | Gu et al. [arXiv:2606.06368](https://arxiv.org/abs/2606.06368); Jin–Mackey–Syrgkanis [arXiv:2507.02275](https://arxiv.org/abs/2507.02275). |
| Nearest-prior difference | Constant variance is not new; exact simultaneous bounded witnesses and E/I/S closure are the increment. |
| Impact | No theorem error, but materially limits breadth and application significance. |
| Minimal repair | Always say "fixed conditional variance/homoskedastic" and avoid WLOG/general-PLM language. |
| Does repair change theorem/rate/scope/positioning? | Changes positioning/scope language, not the stated theorem or rate. A heteroskedastic extension would change the theorem. |
| Unconfirmed | Whether the O/P law persists under unknown heteroskedastic variance. |

## S-C2-04 — public classes and exact budgets are oracle-level inputs

| Field | Record |
|---|---|
| Task / verdict | Public-class information audit — **CONDITIONAL PASS** |
| Severity / confidence / evidence | MAJOR / HIGH / PRIMARY VERIFIED |
| PDF and locator | pp. 1–2 Table 1; pp. 6–11 Sections 8–11 and Appendix A.2–A.3 |
| First possible failure | Reading public exact budgets and pair-specific class representations as unknown-budget adaptation. |
| Original claim | The learner may use the represented class pair and budgets fixed before nature chooses the law. |
| Independent analysis | No truth, best approximant, realized error or label is exposed, but the public objects are substantial structure/oracle information. All algorithms receive the same information within a cell. |
| External source | Gu (2025); Gu et al.; TAME [arXiv:2607.21541](https://arxiv.org/abs/2607.21541). |
| Nearest-prior difference | The Gu line has the same broad class-tailored order; the manuscript's representation/measurability closure is narrower. |
| Impact | Supports a scoped minimax theorem but weakens practical/adaptive significance. |
| Minimal repair | Retain explicit disclaimers: no unknown-budget adaptation, universal pair-independent rule, optimization oracle or runtime guarantee. |
| Does repair change theorem/rate/scope/positioning? | Positioning only. Removing public information would create a different and harder theorem. |
| Unconfirmed | Whether one implementable rule can achieve the field without exact budgets. |

## S-C2-05 — BBM transfer

| Field | Record |
|---|---|
| Task / verdict | Required citation audit — **PASS** |
| Severity / confidence / evidence | MINOR / HIGH / PRIMARY VERIFIED |
| PDF and locator | p. 12; Lemma 4; equation (B.2) |
| First possible failure | Mapping the BBM range/variance parameter or turning a one-sided result into an absolute supremum without symmetrization. |
| Original claim | Lemma 4 is a transferred BBM local Rademacher deviation bound. |
| Independent analysis | Theorem 2.1 gives the displayed constants after `alpha=1`, `[-B,B]`, and adjoining negatives. The manuscript weakens rather than strengthens the success probability. |
| External source | Bartlett–Bousquet–Mendelson, [DOI](https://doi.org/10.1214/009053605000000282), Theorem 2.1. |
| Nearest-prior difference | Direct theorem substitution; no original concentration result. |
| Impact | Citation and technical tool are sound; novelty is unaffected because attribution is explicit. |
| Minimal repair | None. |
| Does repair change theorem/rate/scope/positioning? | N/A. |
| Unconfirmed | None in the checked transfer. |

## S-C2-06 — Gu et al. and TAME mapping

| Field | Record |
|---|---|
| Task / verdict | Required citation/positioning audit — **PASS** |
| Severity / confidence / evidence | MAJOR / HIGH / PRIMARY VERIFIED |
| PDF and locator | pp. 1, 4, 6, 9; Table 5; Sections 4, 6, 11 |
| First possible failure | Omitting that Gu et al. already have `q+AB+M`, or presenting TAME's editing/calibration branches as new. |
| Original claim | Those parts are prior; the residual is O/P lower necessity and exact closure. |
| Independent analysis | Gu et al. Theorem A.1 explicitly states `q+[a+s^2][b+t^2]+(s∧t)^2`. TAME Algorithm 1, Theorem 3.1 and Corollary 3.2 give the upper branch architecture. The manuscript credits both. |
| External source | [arXiv:2606.06368](https://arxiv.org/abs/2606.06368); [arXiv:2607.21541](https://arxiv.org/abs/2607.21541). |
| Nearest-prior difference | Neither checked source gives the complete matching O/P lower theorem in the exact M1/Q1 field. |
| Impact | Narrows but does not eliminate novelty. |
| Minimal repair | Recheck later versions before submission; keep Table 5's boundary. |
| Does repair change theorem/rate/scope/positioning? | Version-driven overlap might change contribution positioning; current text needs no repair. |
| Unconfirmed | Later unpublished/updated theorem fields. |

## S-C2-07 — ownership of `ab` and `M`

| Field | Record |
|---|---|
| Task / verdict | Proof-attribution audit — **PASS** |
| Severity / confidence / evidence | MAJOR / HIGH / PRIMARY VERIFIED |
| PDF and locator | pp. 5–6, 24–28; equation (9); Appendices E–F |
| First possible failure | Treating proof length or a new exact witness as evidence that the rate itself is new. |
| Original claim | Rates are prior; appendices give native certificates. |
| Independent analysis | `ab` is inside source `AB`; `M` is explicit in Gu et al. The manuscript's singleton and finite-dictionary constructions adapt those obstructions to exact variance/envelope/public complexity. |
| External source | Gu et al. Theorem A.1; TAME one-learner analogue. |
| Nearest-prior difference | Exact theorem-field membership, not a new rate or generic proof method. |
| Impact | Attribution is honest; substantive novelty must not count these components. |
| Minimal repair | None while current wording remains. |
| Does repair change theorem/rate/scope/positioning? | A future novelty claim would require positioning repair, not a rate change. |
| Unconfirmed | No evidence that the exact witness construction appeared earlier; that does not make the rate new. |

## S-C2-08 — direct-collision search

| Field | Record |
|---|---|
| Task / verdict | Open prior-work search — **CONDITIONAL PASS** |
| Severity / confidence / evidence | MAJOR / MEDIUM / PRIMARY VERIFIED for inspected candidates |
| PDF and locator | pp. 1, 3–9, 11; abstract, Theorem 1, contribution and limitations sections |
| First possible failure | An earlier public theorem proving both O/P lower terms under the same information, loss and fixed-variance field. |
| Original claim | The full five-term law closes the scoped problem. |
| Independent analysis | Closest sources stop at `q+AB+M`, provide upper architecture only, or use point-nuisance neighborhoods/different noise/loss. No same-field complete collision was located. |
| External source | Sources and queries in `PRIOR_WORK_COLLISION_MATRIX.md` and `LITERATURE_SEARCH_LOG.md`. |
| Nearest-prior difference | O/P matching lower necessity and exact E/I/S assembly. |
| Impact | Supports conditional novelty, never proof of absence. |
| Minimal repair | Run version/forward search at submission; use "no collision found in recorded search," not "first ever." |
| Does repair change theorem/rate/scope/positioning? | Positioning only unless a collision is found; a direct collision would materially change novelty. |
| Unconfirmed | Unindexed, paywalled, private and post-cutoff materials; Scholar coverage. |

## S-C2-09 — novelty and ICLR significance

| Field | Record |
|---|---|
| Task / verdict | Innovation/venue audit — **CONDITIONAL PASS; BORDERLINE** |
| Severity / confidence / evidence | MAJOR / MEDIUM / primary sources plus official criteria |
| PDF and locator | pp. 1–9, 11; abstract, Figure 1, Tables 3–5, limitations |
| First possible failure | Counting inherited `q+AB+M` and TAME architecture as new, or assuming O/P exact closure automatically has broad ML significance. |
| Original claim | Directional phase transitions and a complete scoped minimax theorem warrant ICLR interest. |
| Independent analysis | O/P dominate inherited terms on explicit rays and thus are real. Breadth/practical value remain limited by public exact budgets, Borel pair-specific rules and fixed variance. |
| External source | [ICLR 2027 Reviewer Guidelines](https://iclr.cc/Conferences/2027/ReviewerGuidelines); closest papers above. |
| Nearest-prior difference | Real but concentrated residual increment. |
| Impact | Novelty is more convincing than significance; venue recommendation is borderline. |
| Minimal repair | Keep claims narrow; add broader/adaptive/computable evidence if available. |
| Does repair change theorem/rate/scope/positioning? | Narrow wording changes positioning; a stronger theorem would change scope and significance. |
| Unconfirmed | Independent detailed verification of the O/P appendices and the community breadth of the mechanism. |

## S-C2-10 — time boundary/provenance

| Field | Record |
|---|---|
| Task / verdict | Version and priority audit — **CONDITIONAL PASS** |
| Severity / confidence / evidence | MINOR now, potentially MAJOR / HIGH for recorded dates, LOW for unknown priority / METADATA VERIFIED |
| PDF and locator | ICLR 2027 header; local PDF metadata; source reference/version statements |
| First possible failure | Assuming the local PDF creation time equals earliest public release or submission. |
| Original claim | Current positioning cites the two closest prior-public 2026 sources. |
| Independent analysis | Local creation is 2026-08-24; Gu et al. v1 is 2026-06-04; TAME v1 is 2026-07-23. Exact-title search found no public manuscript copy, but submission/public priority is unknown. |
| External source | arXiv version records; [ICLR 2027 Call for Papers](https://iclr.cc/Conferences/2027/CallForPapers). |
| Nearest-prior difference | Both closest sources are prior to the artifact and accurately cited. |
| Impact | Priority conclusions must be conditional. |
| Minimal repair | Supply a blind-safe public/submission timestamp if priority matters. |
| Does repair change theorem/rate/scope/positioning? | Metadata only unless it changes which works are prior/concurrent/later. |
| Unconfirmed | Earliest public manuscript date and actual submission timestamp. |
