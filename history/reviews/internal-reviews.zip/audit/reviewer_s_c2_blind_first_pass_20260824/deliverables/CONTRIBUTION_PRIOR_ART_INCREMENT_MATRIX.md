# Contribution – prior art – real increment matrix

| Atomic author claim | Nearest verified prior art | What prior art already establishes | Real increment surviving this audit | Novelty/significance judgment |
|---|---|---|---|---|
| Exact five-component minimax law `q+AB+M+O+P` | Gu–Yin–Cai–Fan Theorem A.1; TAME Corollary 3.2 | `q+AB+M` as a close minimax theorem; editing/calibration and two-learner upper architecture | Matching lower necessity for directional `O=t(a∧t)` and `P=s(b∧s)`, plus exact assembly in M1 | **Real theoretical increment.** Not a wholly new theory; stronger than a constant or notation change. |
| Directional phase transitions shown on explicit rays | Same two 2026 sources | Closely related bias/stochastic interactions, but no checked source states both lower directional rays in the exact field | Demonstrates regimes where O or P dominates inherited `q+AB+M` | **Potentially substantive conceptual increment**, contingent on proof correctness. |
| Complete bounded fixed-variance M1 closure | Gu (2025) open problem; Gu et al. Appendix A.1 | Problem architecture and a very close bounded constant-variance theorem | Standard-Borel/measurable public representation, positive-radius complexity, nonempty/empty/saturated regimes and exact envelope-respecting witnesses | **Technical/model-field increment.** Useful rigor, but the model is more special than general PLM practice. |
| E/I/S boundary (`v_->B0^2`, interior, saturation) | Basic bounded-variable extremality; Gu et al. fixed-variance model | Fixed variance is already present; boundedness implies elementary feasibility constraints | Makes emptiness and saturation explicit and proves root-`n` saturation constants | **Conceptually clean but specialized.** The boundary insight is real; not broad semiparametric theory. |
| Upper estimator under the exact public interface | TAME Algorithm 1, Theorem 3.1, Corollary 3.2; BBM concentration | Editing/calibration branch architecture and concentration tools | Self-contained measurable Borel-rule construction for the exact class representation/complexity assumptions | **Technical adaptation**, not a new computational method or general architecture. |
| Native `ab` and `M` lower certificates | Gu et al. Theorem A.1 | Both rate components already appear | Exact fixed-variance/envelope/public-class witnesses | **Attribution PASS, originality limited.** Native proof is useful closure, not rate invention. |
| Public-class/four-budget formulation | Gu (2025), Gu et al. | Outer public-class, exact-budget, rule-tailoring architecture | Clarification and exact interface, not problem invention | **No problem-level novelty.** Information structure is strong and must be prominent. |
| Relevance to causal inference | Classical PLM/orthogonal-learning literature | Under causal assumptions PLM coefficients may have causal interpretations | Manuscript deliberately treats a statistical coefficient and makes no causal claim | **Positioning PASS.** Causal importance cannot be counted as an established contribution here. |

## Six-axis assessment

- Problem novelty: low to moderate; the problem was explicitly posed and close cases solved.
- Model novelty: moderate at the level of exact measurable closure, but the model is restrictive and highly informed.
- Theoretical novelty: moderate; O/P lower necessity and full assembly are the strongest residual.
- Technical novelty: moderate if the directional lower constructions withstand detailed proof audit; upper and inherited lower components rely on known architecture/tools.
- Conceptual novelty: moderate; the two asymmetric rays and E/I/S boundary expose real phenomena.
- Practical/method value: limited in the current form because budgets/classes are public, the rule is pair-specific, and no optimization or runtime guarantee is supplied.

**Overall novelty: CONDITIONAL PASS. Overall ICLR significance: BORDERLINE.**
