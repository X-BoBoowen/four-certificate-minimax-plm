# Claims that survived Reviewer S audit

The following claims passed the model/literature/novelty checks at the stated scope:

1. M1 is a nonempty, identifiable statistical PLM in the interior and saturation regimes, with a correctly separated empty regime.
2. Q1 uses `sup_Gamma inf_delta_Gamma sup_P`; the rule is public-pair-specific but law-independent.
3. The public representation is countable/measurable and the complexity condition is imposed only at positive radii, avoiding a zero-radius quotient.
4. The lower witnesses checked at the model level satisfy exact constant conditional treatment-residual variance, not merely a lower bound.
5. Fixed variance is a genuine restriction; the manuscript does not claim it is WLOG.
6. BBM Theorem 2.1 supports Lemma 4 after the stated symmetrization/substitution.
7. Gu–Yin–Cai–Fan already supplies `q+AB+M`; the manuscript credits this.
8. TAME already supplies the editing/calibration upper architecture; the manuscript credits this and presents its upper proof as an exact-interface adaptation.
9. The `ab` and `M` rates are not claimed as new; their appendices are native theorem-field certificates.
10. The directional `O` and `P` components are not algebraic renamings of `AB+M` and can dominate inherited terms on explicit parameter rays.
11. In the recorded search scope, no earlier complete theorem with the same `q+AB+M+O+P` law and the same information/variance/loss field was found.
12. The manuscript makes no causal-effect, unknown-budget adaptation, universal-estimator, optimization-oracle or polynomial-time claim.

Claims 10–11 remain conditional on full mathematical proof verification and continued collision/version searching. They are not converted into unconditional novelty credit merely because the search was unproductive.
