# Reviewer S independent domain report

Reviewer: **Reviewer S — simulated independent expert review**  
Manuscript: *Four-Budget Minimax Rates for Bounded Partially Linear Models*  
Review date: 2026-08-24 (Asia/Shanghai)  
Overall audit verdict: **CONDITIONAL PASS**  
Independent ICLR significance assessment: **BORDERLINE**

## Executive assessment

I read the paper as a scoped minimax closure theorem for a bounded partially linear coefficient problem in which two represented nuisance classes and four exact approximation/stochastic budgets are public. Its sharp rate is

`n^{-1/2} + (a+s^2)(b+t^2) + (s∧t)^2 + t(a∧t) + s(b∧s)`.

The paper is not inventing the public-class formulation, the root-`n` term, the approximation product, the common-stochastic term, or the editing/calibration upper architecture. Those elements are already visible in Gu (2025), Gu–Yin–Cai–Fan (2026 v1), TAME (2026 v1), and standard empirical-process/orthogonal-learning tools. The strongest contribution that survives my audit is narrower and more credible: it supplies matching directional lower mechanisms for `t(a∧t)` and `s(b∧s)`, assembles the full field in one exact fixed-variance model, and separates empty, interior and saturated variance regimes.

I did not find an internal exchange of the crucial minimax quantifiers. I also did not find a variance witness that violates the advertised exact conditional-variance restriction. All three required citation families—BBM, Gu et al., and TAME—support the claims assigned to them. The manuscript's attribution of `ab` and `M` is appropriately restrained.

My reservation is significance rather than a demonstrated mathematical contradiction. The learner receives the represented class pair and exact budgets, may be tailored to that pair, and need not be computational. The variance is exactly homoskedastic. These conditions make the theorem coherent but substantially narrower than a general adaptive or practical PLM result. With the large overlap from the two 2026 papers removed, the O/P lower mechanisms and boundary analysis are a real theoretical increment, but I am not yet convinced they alone make the paper clearly above the ICLR bar.

## First-pass domain intuition

If I remove the paper's terminology, the core question is: given two public approximation classes for the outcome and treatment regressions, and given exact upper bounds on their misspecification and stochastic localization scales, what is the worst-case absolute-error cost of estimating the scalar coefficient when treatment-residual variance is constant?

The closest three literatures are:

1. the Gu structure-agnostic PLM/open-problem and SADE/TAME line;
2. double/debiased and orthogonal learning with product-rate nuisance remainders;
3. structure-agnostic semiparametric minimax lower bounds based on two-point, fuzzy-hypothesis, Assouad or constrained-risk arguments.

The contribution most likely to be valid is the directional O/P necessity: on the displayed rays those terms can dominate `q+AB+M`, so this is not a cosmetic expansion. The contribution most likely to be overread is the full theorem as a general black-box/adaptive PLM breakthrough: the public class, exact budgets, pair-specific rule and fixed variance provide substantial information. The most unnatural assumption for application is not boundedness by itself but the combination of exact public difficulty budgets with an information-theoretic Borel rule and no computational interface.

## Model reconstruction and correctness

M1 observes `2n` i.i.d. triples `Z=(X,T,Y)` on a standard Borel covariate space and real treatment/outcome coordinates. The law obeys

`T=pi_0(X)+u`,  `Y=beta_0 T+mu_0(X)+epsilon`,

with `E[u|X]=0`, `E[epsilon|X,T]=0`, and `E[u^2|X]=v` for one constant `v in [v_-,v_+]`. Variables, nuisances and residuals share the stated envelope; `beta_0 in [-3,3]`. The target is the statistical coefficient `beta_0`, not a causal effect. Positive conditional treatment-residual variation identifies it in the nonempty regimes.

The public object is a represented countable class pair `Gamma=(G_mu,G_pi)` plus `rho=(B0,v_-,v_+,c_rad)` and the four budgets `(a,s,b,t)`. The model cell requires approximation errors at most `a,b` and localized positive-radius Rademacher complexity controlled by `c_rad s,c_rad t`. The estimator is allowed the public representations and budgets but not the true nuisance functions, law, realized approximation errors, population best approximants or a hard-instance label.

Q1 is exactly

`sup_Gamma inf_{Borel delta_Gamma} sup_{P in P(Gamma)} E_P |delta_Gamma-beta(P)|`.

Thus Q1 aggregates fixed-pair M1 experiments; it is not an equivalence or lossless reduction between two different observation schemes. A pair may depend on `n` and the budget tuple, but it is fixed before the law and data. The learner is pair-specific. I found no use of `inf_delta sup_Gamma` and no step that chooses a rule after seeing the unknown law.

The empty/interior/saturation split is also logically appropriate. When `v_->B0^2`, boundedness makes the model empty and the paper declines to state a rate. For `0<v_-<B0^2`, constants may depend on fixed `rho` and can degenerate near the boundary. At `v_-=B0^2`, boundedness forces the treatment residual to its extremal two-point form and the nuisance treatment regression collapses; a separate root-`n` result is therefore appropriate.

I classify M1 and Q1 as **PASS/HIGH**. I classify the fixed-variance and public-information aspects as **CONDITIONAL PASS/HIGH**: they are clear and coherent, but all theorem and significance language must remain restricted to that exact field.

## Fixed variance and public information

The variance assumption is not without loss of generality. If `T*=T/c` with `Y` unchanged, then `pi*=pi/c`, `u*=u/c`, `v*=v/c^2`, while the coefficient becomes `beta*=c beta`; the envelope, nuisance budgets, target range and absolute loss are changed. An `x`-dependent scale would generally destroy a constant PLM coefficient. The paper does not make the invalid WLOG claim and its lower witnesses use exact `v=v_-`.

The information order is:

1. `rho,n` and the budget tuple are fixed;
2. the outer adversary fixes a represented pair `Gamma`;
3. the learner sees that public object and fixes one Borel rule;
4. nature chooses `P` in the resulting cell;
5. `2n` i.i.d. observations are generated;
6. the fixed rule outputs an estimate and its expected absolute error is evaluated;
7. the inner worst case and then the outer pair supremum are taken.

This is meaningful as public-class information-theoretic minimax theory. It is not unknown-budget adaptation, one universal estimator across pairs, or a computational guarantee. The manuscript mostly says this plainly. I would treat any broader presentation as a material overclaim.

## Literature and proof attribution

I initially suspected the rate might be a direct restatement of Gu–Yin–Cai–Fan. The theorem-field comparison changes that conclusion. Their Theorem A.1 already has `q+AB+M`, and TAME already has the two-branch editing/calibration upper construction. The manuscript correctly removes those ingredients from its novelty claim. In the checked versions, however, I did not find the same matching lower necessity for both directional terms under the exact Q1 information order.

BBM Theorem 2.1 maps to Lemma 4 with the displayed constants after symmetrizing the class and setting the source parameters; the probability is only weakened. The citation is exact enough to support the lemma.

The `ab` and `M` appendices are native certificates for the manuscript's exact theorem field, not new rate discoveries. I classify them as technical adaptations. The independently interesting lower constructions are the O/P mechanisms, subject to a separate line-by-line proof audit beyond this literature/novelty remit.

在我记录的检索范围和时间边界内，我没有找到直接 prior-work collision。 This does not prove absence. The strongest verified classification is two **STRONG OVERLAP** sources, followed by several partial or contextual neighbors.

## Strengths

- The minimax order, public information and measurable interface are unusually explicit.
- The paper draws a disciplined novelty boundary around Gu et al. and TAME instead of rebranding their results.
- The O/P terms can be first-order on explicit rays, giving the added lower mechanisms conceptual rather than merely constant-level content.
- Exact conditional variance is checked in the lower witnesses; the envelope/complexity rescaling closes an easy-to-miss membership gap.
- Empty, interior and saturated variance regimes are separated rather than hidden under a uniform constant.

## Weaknesses

- Exact public budgets and class representations are strong oracle information; practical adaptivity is not established.
- Pair-specific Borel rules and absence of optimization/runtime requirements limit algorithmic value.
- Homoskedastic conditional treatment-residual variance narrows applicability and cannot be normalized away without changing the problem.
- Most of the baseline rate and all upper-architecture ideas have very recent, very close antecedents; the residual novelty is concentrated in O/P lower necessity and exact closure.
- The manuscript's own earliest public date and actual submission timestamp are unavailable, so priority is conditional on the local 2026-08-24 artifact and recorded source dates.

## Fairness/reverse check

Before calling the contribution incremental, I checked the strongest differences in the paper's favor. The information order is genuinely tighter than an informal “black-box learner” description; the constant-variance witness is not automatic; and O/P can dominate inherited terms. These are real differences. Conversely, I tried to turn the closest papers into direct collisions, but their checked theorem fields either stop at `q+AB+M`, give an upper architecture without the matching directional lower theorem, or use point-nuisance error neighborhoods and different losses/noise assumptions. I therefore do not classify the paper as substantially repetitive.

## Verdicts by required item

| Item | Verdict | Severity if wrong | Confidence | Evidence |
|---|---|---|---|---|
| M1 definition and identification | PASS | CRITICAL | HIGH | PRIMARY VERIFIED |
| Q1 quantifier order | PASS | CRITICAL | HIGH | PRIMARY VERIFIED |
| M1/Q1 relationship | PASS | MAJOR | HIGH | PRIMARY VERIFIED |
| Fixed variance | CONDITIONAL PASS | MAJOR | HIGH | PRIMARY VERIFIED |
| Public class/information timeline | CONDITIONAL PASS | MAJOR | HIGH | PRIMARY VERIFIED |
| BBM citation | PASS | MINOR | HIGH | PRIMARY VERIFIED |
| Gu et al. citation | PASS | MAJOR | HIGH | PRIMARY VERIFIED |
| TAME citation | PASS | MAJOR | HIGH | PRIMARY VERIFIED |
| `ab`/`M` ownership | PASS | MAJOR | HIGH | PRIMARY VERIFIED |
| Direct-collision search | CONDITIONAL PASS | MAJOR | MEDIUM | PRIMARY VERIFIED for inspected candidates |
| Novelty | CONDITIONAL PASS | MAJOR | MEDIUM | Mixed primary evidence and proof dependence |
| ICLR significance | BORDERLINE | MAJOR | MEDIUM | Official criteria plus primary comparisons |

## ICLR significance recommendation

Using the ICLR 2027 public reviewer questions—is the problem well stated, motivated in its literature, supported, and significant—I find correctness/clarity relatively strong, novelty credible but concentrated, and broad significance unresolved. The work is relevant to theoretical ML through nuisance learning and orthogonal estimation. It may be especially suitable for a specialized theory/statistics audience. For ICLR, my independent conclusion is **BORDERLINE**, not “not relevant” and not a confident accept-level judgment.

The strongest fact that could improve my assessment would be an independently verified O/P proof together with either a heteroskedastic extension, a genuinely budget-adaptive theorem, or a computable procedure under a transparent oracle model. The fact most likely to worsen it would be an earlier theorem showing both O/P lower mechanisms under the same information structure.

## Required declarations

### Scope statement

This review covers model reconstruction, identification, minimax quantifiers, fixed-variance/public-information structure, primary-source citation verification, proof attribution at the theorem-field level, prior-work collision search, novelty and ICLR significance. It is a simulated expert audit produced by an AI model, not a claim of human academic credentials. A full line-by-line validation of every appendix proof is outside this Reviewer S assignment.

### Conflict statement

No conflict with an identified author, institution, funder or competing group was detected from the blind package. Author identity is unknown, so conflicts that require identity knowledge cannot be excluded. The reviewer has no personal or institutional interests. Prior topical exposure to a separate C1 audit in this session is disclosed; no C1 report or answer was opened or reused for this C2 review.

### Independence statement

I did not read an author internal audit, reference answer, completed audit table, Expert M report or other reviewer opinion. Package filenames and README guidance were used to avoid prohibited materials. Conclusions derive from this C2 manuscript, its supplied source pack and public primary sources.

### Search-limit statement

Searches covered the public web, arXiv, PMLR, DBLP-indexed and official ICLR pages available on 2026-08-24. Google Scholar was not available as a fully reproducible export; Semantic Scholar, OpenAlex and Crossref coverage for very recent 2026 preprints may lag. Paywalled or unindexed sources, private submissions and later versions may be missing. No search can establish nonexistence.

### Verifiable signature

Reviewer: Reviewer S — simulated independent expert review  
Model/version: Codex, underlying model identifier not exposed to this task  
Session/task ID: not provided  
Completed: 2026-08-24, Asia/Shanghai  
Output-file hashes: see `SHA256SUMS.txt` in the final package; archive hash is provided in the adjacent sidecar and handoff message  
Human-only gate: this simulated report does **not** satisfy the package's human-credentialed Reviewer S gate.
