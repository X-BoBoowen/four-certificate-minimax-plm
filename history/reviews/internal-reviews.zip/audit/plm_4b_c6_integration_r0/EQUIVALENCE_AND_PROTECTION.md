# C6 equivalence and protected-state verification

Audit date: 2026-08-26.

## Master/Candidate equivalence

- Compared scientific artifacts: 33.
- Byte mismatches: 0.
- Compared rendered pages: 37.
- Pixel-hash mismatches: 0.
- Candidate-only QA is administrative and excluded from scientific equality.

## Direct protected authorities

| Artifact | SHA-256 | Status |
|---|---|---|
| Master-R7 PDF | 63A542B2D91A4C65F98044A74CAA99716CC2C8B1584B80AE10142097732E82A2 | MATCH |
| Candidate-C5 PDF | D8DD7EB9F01038D0AA863F78C3972950AD98B6B6225E4A69D3CF7F92E45E2259 | MATCH |
| canonical bibliography | B2E428B79BC5E8C6F2984BFE747E7583DE0DDAA787A3C3C7B865097DF8CC0B37 | MATCH |
| K0 final decision | 66A0F6FC713844AFB3ADDEC2C8F1D8676A9C695640AE97E44CBF75C8DA77E3FD | MATCH |

The frozen pre-integration tree manifests recorded 39 Master-R7 files, 40
Candidate-C5 files, 10 K0 strategy files, 8 K0 theory files, and 6 K0
validation files. Independent compact-JSON tree digests used by the C6
validator remained:

- Master-R7:
  3F2AB6749CE2F843960C8685E3C2BC43860371E8F60F520B7EEC2CC74F566CF2;
- Candidate-C5:
  2528BBB314060725DA9E87600BA16010C3920D82F80444413F1D9435942C1284;
- K0 strategy:
  0B1FDEA423F7F5EC08EA2D87C441453D3224F6CF0EDB1D6931162931852ABAEA;
- K0 theory:
  EF9722B9435E6F736B5349BA3C2013B84E5A3DDEE2F18E7E947E2469680448BD;
- K0 validation:
  2BCF63F8E0F1CCC974135115BFAD56BE300DE6C8B716CB886D5CB8C1897A5E74.

These validator digests use a separately documented JSON-lines algorithm and
therefore are not substituted for the frozen PowerShell-manifest digests in
CONTROLLING_ARTIFACTS.md. Both before/after checks report unchanged content.

H2 materials were not listed, opened, extracted, released, or used. No
historical Candidate, Master, K0, proof, validation, or canonical bibliography
file was modified.

Disposition: MASTER/CANDIDATE EQUIVALENCE AND PROTECTED-ARTIFACT GATES PASS.
