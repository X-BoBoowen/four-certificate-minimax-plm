# C6 build and visual report

Audit date: 2026-08-26.

## Master-R8

- Compiler: Tectonic 0.17.0.
- Exit: 0.
- PDF: 37 US-Letter pages.
- Main text and disclosures end: page 9.
- References begin: page 10.
- Log counts: LaTeX errors 0; undefined citations/references 0; duplicate
  labels 0; overfull boxes 0; underfull boxes 0; LaTeX warnings 0; package
  warnings 0.
- PDF SHA-256:
  9B7EFF3546F43047E1CE5F366831C741C97DB4F3512469DEF49BA64893D9DC0A.

## Candidate-C6

- Compiler: Tectonic 0.17.0.
- Exit: 0.
- PDF: 37 US-Letter pages.
- Main text and disclosures end: page 9.
- References begin: page 10.
- Log defect counts: all zero under the same categories.
- PDF SHA-256:
  53ADA5994300F31A912E23CC1CE4107E4D349FAFF06329DD3161583FBF2AB9E3.

The PDF byte hashes differ only because independent builds carry volatile PDF
metadata. Both have generic TeX creator/producer fields and no title, author,
subject, or keywords. Their 37 page renders are pixel-hash-identical.

## Visual audit

All Master pages were rendered at 120 dpi and inspected in a 37-page contact
sheet. Pages 6, 9, and 34--37 were separately inspected at original detail:

- page 6: Proposition 3 and fixed-pair assembly;
- page 9: corrected source table, limitations, conclusion, and disclosures;
- page 34: proof index and Appendix L opening;
- pages 35--37: public classes, complexity chain, raw-law membership,
  arbitrary-rule reduction, splice, and scope boundary.

No clipping, overlap, blank page, unreadable table, broken display, displaced
heading, or page-limit spill was found. The analytic figure generator remains
at figures/+generate_theory_summary.py.

Disposition: BUILD, PAGE, METADATA, AND VISUAL GATES PASS.
