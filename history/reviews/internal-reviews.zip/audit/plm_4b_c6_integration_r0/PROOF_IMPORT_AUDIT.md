# C6 proof-import audit

Audit date: 2026-08-26.

Controlling proposition: Master-R8 main.tex, Proposition 3, label
prop:same-pair-lower. Controlling proof: Appendix L,
L_same_pair_lower.tex.

| Obligation | Locator | Disposition |
|---|---|---|
| O1 common Walsh group and four disjoint bands | Appendix L.1, lines 11--54 | CLOSED |
| O2 complete outcome/propensity classes | Appendix L.1, lines 83--110 | CLOSED |
| O3 union rather than span | Appendix L.1, lines 103--110 | CLOSED |
| O4 sequential-M1, measurable evaluation, envelope | Appendix L.2, lines 111--124 | CLOSED |
| O5 full class and cross-band difference counts | Appendix L.2, lines 125--158 | CLOSED |
| O6 Massart-to-budget constant chain | Appendix L.2, lines 139--168 | CLOSED |
| O7 exact zero-budget degeneration | Appendix L.2, lines 165--170 | CLOSED |
| O8 P/O/ab off-class distances under enlargement | Appendix L.3, lines 172--190 | CLOSED |
| O9 q/P/O/ab/M raw-law membership and constant variance | Appendix L.3, lines 191--227 | CLOSED |
| O10 arbitrary-Borel testing after full pair disclosure | Appendix L.4, lines 229--257 | CLOSED |
| O11 small-n, low-budget, equality, and zero-term splice | Appendix L.5, lines 259--269 | CLOSED |
| O12 fixed-pair maximum-to-sum | Appendix L.5, lines 270--289 | CLOSED |
| O13 S0-to-X final assembly | Appendix L.5, lines 279--289 and equation (9) | CLOSED |

Count: CLOSED 13, OPEN 0, KILLED 0.

The proof imports component raw laws only from Appendices C--F of the same
manuscript. It contains no dependency on a K0 certificate, project terminal, or
unavailable oracle. The strict-interior, constant-variance, fixed-infinite
ambient, known-budget, sequential-M1, and arbitrary-Borel assumptions are
identified at the point of use.

Disposition:

STANDALONE MANUSCRIPT PROOF IMPORT PASSES.
