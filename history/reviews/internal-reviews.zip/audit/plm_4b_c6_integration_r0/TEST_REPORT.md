# C6 regression and mutation report

Run date: 2026-08-26.

| Suite | Result |
|---|---:|
| C6 source, build, equivalence, protected, and nine hostile mutations | 119/119 |
| C5 protected integration and mutations | 64/64 |
| X1/R1 mathematical regression | 15/15 |
| PDF infinity extraction/mutation | 3/3 |
| positive-c_rad membership | 9/9 |
| scalar-q target cap and splice | 9/9 |
| joint empirical upper | 11/11 |
| C2-R1 validator | 12/12 |
| P raw-law identities | 7/7 |
| O raw-law identities | 9/9 |
| ab raw-law/falsifier | 16/16 |
| M raw-law/falsifier | 19/19 |
| K0 same-pair exact suite | 8/8 |
| Total registered checks | 301/301 |

The K4 exact-rational boundary diagnostic also completed over 768 grid points
and retained its analytic controller; it is auxiliary and is not included in
the 301 registered checks.

The nine C6 mutations independently detected:

1. observable support tag;
2. union changed to span;
3. ab dictionary inserted into a public class;
4. omitted cross-band difference accounting;
5. nonzero candidate under a zero stochastic budget;
6. swapped forall/exists quantifiers;
7. regression to component-specific public pairs;
8. Gu A.1 loss/variance field regression;
9. calibrated-DML year/version regression.

The first grouped pytest command was unavailable because the bundled Python
does not contain pytest. No test or dependency was modified: every authoritative
unittest file was then run through its native direct entry point. PDF extraction
used the existing Python 3.11 environment with PyMuPDF.

Disposition: ALL REGISTERED TESTS PASS.
