# C6 source-field verification report

Audit date: `2026-08-26`.

Scope: the three corrections authorized for C6 and the closest theorem ancestors needed to state the Level-2 same-public-pair result. Only official arXiv or PMLR records and their primary full text were used. A search non-hit supplies no novelty, priority, or collision-free credit.

## Gu--Yin--Cai--Fan

- Official record: Yihong Gu, Qishuo Yin, Tianxi Cai, and Jianqing Fan, *Optimally Taming Biases in Black-Box Models for Efficient Semiparametric Estimation*, arXiv:2606.06368, submitted 4 June 2026: <https://arxiv.org/abs/2606.06368>.
- Primary theorem checked: Appendix Theorem A.1 in the official PDF.
- Loss field: expected absolute loss, not squared loss.
- Variance field: exact constant conditional variance, written as `E[u^2|X] \equiv v` with a lower numerical restriction, not merely a variance lower bound.
- Lower-rate field: the theorem already contains the `q+AB+M` predecessor after translating its approximation and stochastic terms into the manuscript notation.
- Residual C6 differential: four separately declared public budgets under the sequential-M1/Q1 interface; the two additional directional necessities `O` and `P`; and the Level-2 consolidation of all five lower subfamilies inside one fixed public pair at each fixed `(rho,n,a,s,b,t)` cell. Expected-L1 loss and exact constant variance are not differences and must not be claimed as such.

## Calibrated DML

- Official record: Lars van der Laan, Alex Luedtke, and Marco Carone, *Doubly Robust Inference via Calibration*, arXiv:2411.02771: <https://arxiv.org/abs/2411.02771>.
- Version history checked on the official record: v1, 5 November 2024; v2, 27 June 2025; v3, 20 August 2026.
- Required local-derived BibTeX policy: `year = {2024}` and `note = {Version 3, revised 20 August 2026; first posted 5 November 2024}`.
- The C5 combination `year=2025` plus a v3/2026 note is rejected as internally inconsistent.

## Liu--Mukherjee--Robins

- Official record: Lin Liu, Rajarshi Mukherjee, and James M. Robins, *On the Asymptotic Inadmissibility of Double Machine Learning Estimators Under Structure-Agnostic Models*, arXiv:2606.22391: <https://arxiv.org/abs/2606.22391>.
- Primary full-text field: fixed-pilot structure-agnostic neighborhoods, asymptotic inadmissibility/minimax analysis, monotone bias classes, expected conditional covariance, and higher-order/quadratic-functional constructions.
- Relation: directly relevant context for why first-order/DML optimality is sensitive to the information model. It does not state the finite-sample four-public-budget PLM coefficient theorem, the `O/P` necessities, or the Level-2 one-public-pair construction.
- C6 use: contextual positioning only; no attribution of the C6 theorem and no non-collision inference from differing notation.

## Required manuscript consequences

1. Replace the Gu row's `squared loss` by `expected absolute loss`.
2. Replace the Gu row's `variance lower bound` by `exact constant conditional variance`.
3. Remove both fields from the claimed differential.
4. Correct the local derivative bibliography entry for arXiv:2411.02771 to the first-posted year 2024 while recording the exact v3 revision date.
5. Add Liu--Mukherjee--Robins as a bounded contextual neighbor, not as a four-budget collision.
6. Retain explicit ancestry for the inherited `q+AB+M` lower structure and the TAME upper architecture.

## Disposition

`MANDATORY SOURCE CORRECTIONS ARE FIELD-CERTIFIED; NO DIRECT COLLISION FOUND IN THE BOUNDED CHECK, WITH NO NOVELTY OR PRIORITY CREDIT FROM NON-HITS.`
