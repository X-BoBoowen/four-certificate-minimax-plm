# K2 assumption ledger

| Assumption or access | Used at | Frozen source role | New? |
|---|---|---|---|
| \(\beta_0,\widehat\beta_0\in[-3,3]\) | joint coefficient range \([-6,6]\) | public theorem/estimator | no |
| supplied countable representations | joint core and measurable approximate minima | public class interface | no |
| \(|T|,|Y|,\|\pi_0\|_\infty,\|\mu_0\|_\infty\le C(B_0)\) | envelopes and Bernstein constants | theorem envelope | no |
| \(E(u\mid X)=0\), \(v\ge v_->0\) | curvature, O/R normalization | PLM law | no |
| \(E(\varepsilon\mid X,T)=0\) | joint and O/R outcome multipliers | PLM law | no |
| public difference-class complexity at every radius above its declared budget | function part of joint localization and calibration; K2 first ensures the induced radius is at least that budget | theorem complexity field | no |
| fixed \(c_{\rm rad}>0\) | lemma normalization constant | K0 accepted theorem-field correction | no |
| three independent splits | conditioning and fitted-index legality | estimator architecture | no |
| deterministic clipping to \([-3,3]\) | tails beyond the certified \(z\) interval | estimator architecture | no |
| bounded approximation comparators | B9 and five-term/R decompositions | theorem approximation field | no |

No policy oracle, population minimizer, unknown nuisance, new joint complexity
budget, stronger variance condition, restricted \(n\), or smaller
\((a,s,b,t)\) field is introduced.
