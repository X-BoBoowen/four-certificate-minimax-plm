# PLM-4B-UPPER-EMPIRICAL-K2 final decision

## Incoming decision

ACCEPT PLM-4B-SCALAR-Q-K1 TERMINAL A — ROOT-n SCALAR WITNESS CERTIFIED AFTER TARGET CAP.

K1 closes S-002/RN-001 with unchanged rate and theorem domain and a changed
fixed positive lower constant only.

## Gate adjudication

| Frozen gate | Evidence | Result |
|---|---|---|
| protected artifacts unchanged | closeout hashes exactly match the K2 entry baseline | pass |
| joint class under original assumptions | J.1--J.5 and lemma-field audit | pass |
| corrected B.9 under same estimator | K2.1--K2.7 | pass |
| O all-\(z\) terms fully sourced | O.1--O.14 | pass |
| R independently reconstructed | R.1--R.16 | pass |
| termwise tail integration | T.1--T.6 | pass |
| conditioning and fitted-index order | sigma-field ledger | pass |
| fixed-\(\Gamma\)/outer minimax order | quantifier audit | pass |
| requested falsifiers | 11/11 exact tests plus continuous boundary proof | pass |
| stronger assumptions/domain change | assumption ledger | none |

## Required proof corrections

Any future paper correction must:

1. insert the joint-class definition and localized-complexity proof;
2. replace the unsupported B.9 invocation by the corrected basic-inequality
   chain;
3. replace B.12 by \(H_\mu(a_0)\le C_\rho(r^2+w_z^2)\);
4. replace B.14 by a bound exposing \((d/r)w_z\);
5. update B.15 and the five O termwise inequalities;
6. replace the prose after B.18 by the corrected source map;
7. present the independent R replay even though B.29* has the same final
   formula;
8. expand the termwise tail integration and quantifier order.

K2 does not authorize any of these edits.

## Single terminal

JOINT-CLASS AND ALL-z O/R UPPER CERTIFIED — RATE UNCHANGED; EXPLICIT PROOF CORRECTIONS REQUIRED

## State boundary

Formal progress remains exactly 82% — COMPLETE DRAFT EXISTS; HEADLINE PROOF
CORRECTION IN PROGRESS.

Candidate-C1-R1 remains MATHEMATICALLY CONTESTED CANDIDATE — NOT
PROOF-COMPLETE AND NOT SUBMISSION-READY.

M-002/M-003 and the directly identical Omega-T03/T04 proof obligations are
scientifically certified in K2 evidence but not yet incorporated into the
paper. S-001/M-001, M-004, S-003/S-004 general presentation, and
novelty/significance remain frozen and unresolved.

The only next PI decision requested is whether to authorize a separate unified
definition/presentation correction phase. No paper edit is automatic.
