# Independent hostile proof audit

## 1. Independent joint-class derivation

Define the linear map
\[
 A(\gamma,f)=(\sqrt v\,\gamma,\gamma\pi_0+f)
\]
from the scalar/function parameter pair to
\(\mathbb R\oplus L_2(P_X)\). Equation (J.1) states that
\(\|A(\gamma,f)\|^2=\|\gamma T+f\|_2^2\). The inverse on its image obeys
\[
 |\gamma|\le v_-^{-1/2}\|A(\gamma,f)\|,\qquad
 \|f\|_2\le(1+B_0v_-^{-1/2})\|A(\gamma,f)\|.
\]
Applying the Rademacher functional separately to the scalar \(T\) coordinate
and to the public \(f\) coordinate reproduces (J.4). This route does not use
the triangle/absorption steps of the corrected basic inequality and reaches
the same radius floor.

Reviewer attack: if the public assumption only starts at radius \(s\), can
the induced \(f\)-radius fall below it? No: the joint lemma is invoked only
for \(R\ge C_\rho(s\vee h_n)\), and the constant is chosen so the upper
radius \(C_\rho R\) is at least \(s\).

## 2. Independent O objective derivation

Discard the forward proof and retain only approximate optimality:
\[
 \lambda A^2+H(\widehat a)
 \le\lambda B^2+H(a_0)+\tau,
\]
where \(A=\|\widehat a-\widetilde a\|_n\) and
\(B=\|a_0-\widetilde a\|_n\). The uniform empirical process gives
\(H(a_0)\le C(r^2+w_z^2)\), while \(B\le C(d+w_z)\).
Since \(H(\widehat a)\ge0\),
\[
 A\le C\{d+w_z+r/\sqrt\lambda+w_z/\sqrt\lambda
                 +\sqrt{\tau/\lambda}\}.
\]
Substitution of \(\sqrt\lambda\asymp r/d\) independently forces
\((d/r)w_z\). Thus any derivation of the old B.14 without that term is
algebraically impossible unless it proves a new cancellation before objective
comparison. No such cancellation exists in the frozen objective.

## 3. Line-by-line vulnerability audit

| Step | Strongest attack | Disposition |
|---|---|---|
| countable joint core | irrational truth not in core | rational deterministic comparator and limit |
| joint curvature | \(f=-\gamma\pi_0\) | leaves \(v\gamma^2\) exactly |
| public complexity transfer | induced radius outside assumption field | radius floor chosen above \(s\) |
| B.9 basic inequality | empirical comparator cross term | retained and absorbed through empirical norm conversion |
| \(H_\mu(a_0)\) | omitted \(z/n\) | repaired to \(r^2+w_z^2\) |
| O objective | division by small \(\lambda\) | \((d/r)w_z\) exposed |
| O identity | hidden denominator term | exact normalization removes it |
| R inheritance | false mirror argument | independent two-sample replay |
| random fitted indices | pointwise event used after fitting | uniform countable events precede substitution |
| layer cake | nonnested \(\mathcal E_z\) | only pointwise tail probabilities used |
| \(d/r\) divergence | standalone rate loss | standalone term absent; surviving products absorb |

## 4. Assumption drift check

No stronger class, measurability, variance, access, or radius assumption was
used. The proof uses \(c_{\rm rad}>0\), already accepted by K0. It does not
repair or claim credit for the separate literal-zero-radius or general M-004
presentation issues.

## 5. Where a residual error would most likely remain

If this repair is still wrong, the most likely location is the O objective
comparison/calibration interface, specifically the passage between the
full-class supremum \(H_\mu\), its represented countable core, and the
finite-sample normalization hyperplane. Joint localization has an exact
orthogonal identity and two derivations; conditioning follows the split
sigma-fields; tail absorption reduces to deterministic inequalities. The
objective interface combines all three and is therefore the narrowest point
for a future line-by-line human audit.

Under the stated pointwise-dense bounded representation, finite-sample
functionals are continuous along the representation and the K2 passage is
valid. The risk designation reflects audit priority, not an unresolved K2
implication.

## Verdict

The active M-002/M-003 repair survives hostile audit. The existing Candidate
text does not: its B.12, B.14, O termwise map, and explanatory prose require
explicit correction before any proof-complete claim.

