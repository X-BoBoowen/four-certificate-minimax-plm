# Exact test report

## Test-first chronology

1. The test file was written before the checker. Its first execution failed
   with the expected missing-module error for the absent checker.
2. The first implementation run executed eight tests; seven passed and the
   source-map test failed because \((d/r)w_z^2\) was hidden inside
   \((1+d/r)w_z^2\).
3. The source map was split into its independent contributions. All eight
   tests then passed.
4. Boundary tests for O ties/all-zero budgets, large \(d/r\), the R strict
   branch, and small-\(n\) concentration windows were added. The final suite
   has eleven passing tests.

## Final result

Result: 11/11 PASS, exact standard-library arithmetic.

The main rational grid contains 576 O cells and 448 R cells. The maximum
term-to-target ratios are respectively \(1296/257\) and \(88/17\).
Separate \(q=1/256\) checks force \(d/r>100\) while retaining bounded final
ratios. No floating-point result is used.

## Interpretation boundary

The checker verifies deterministic algebra, finite budget cells, source-map
membership, and exact cancellation identities. It does not establish
empirical-process concentration, continuous-domain absorption, or minimax
quantifiers; those are proved in the mathematical certificates.

