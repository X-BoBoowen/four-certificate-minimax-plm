Reviewer C — Stage 1 独立 AI red-team 原始报告
Four-Certificate Minimax Rates over Public Class Pairs for Bounded Partially Linear Models

审查对象：01_Candidate_C14_Anonymous_Manuscript.pdf，46 页。以下页码同时是 PDF 页码与稿件印刷页码。本报告于 2026-09-07 独立形成，保存时尚未收到 Stage 2 材料。它是 AI 审查，不是人类同行评审或形式化证明认证。

**总体结论与评分**

我倾向弱接收（weak accept），评分 6.5/10。评分采用连续尺度：1 表示主要结论已被明确推翻，3 表示明显拒稿，5 表示接收边界，7 表示有实质理论贡献且基本支持接收，9–10 表示影响广泛的突出成果。我的正确性判断偏正面；分数没有更高，主要因为贡献是非常具体实验中的匹配下界补全，核心上界方法、两混合测试和若干下界结构已有直接先行工作，实际学习器与一般模型的适用面仍有限。

总体信心 4/5；对本次已重推的定理链条约 4/5，对文献贡献边界约 3/5。这里的信心不是“全文不可能还有错误”的概率。我通读全部 46 页，重点复推 Appendix B 的概率与可测性链条、C–F 的原始分布和混合距离、G/H 的组装与饱和边界、L 的同一类对兼容性。没有发现会改变 Theorem 1 速率、必要假设或主要量词的已确认错误。

有一处确定的局部错误：第 35 页 (E.11) 的最后一个严格小于号，在该页明确包括的边界上不成立。改为非严格不等号即可，后续 TV 界、下界常数和定理均不受影响。不能把它升级为主定理被推翻的证据。

最强接收理由是：本稿没有只把已有上界换一种多项式写法，而是给出在所声明公共四预算实验中合法的 O/P 必要性证据；它们使旧的下界在真实可用的预算射线上少一个幂次的问题得到解决。最强拒稿理由是重要性与增量：若会议要求新的普适方法、自然类的结果或可实施的算法，本稿主要是 TAME 上界之后的定理闭合，其工程化有限字典与冗长的审计式表述可能不足以达到该门槛。这是贡献评价，不是数学反例。

**我所理解、并实际审查的结论**

固定无限标准 Borel 协变量空间、固定包络与正的常数方差下界，给定公开且可逐点序列表示的两个候选类，以及事前上界证书 (a,s,b,t)。风险是

R_pair = sup_Gamma inf_{delta_Gamma Borel} sup_{P in P(Gamma)} E_P |delta_Gamma-beta(P)|,

不是同一学习规则同时适用于所有未编码类的风险，也不是给定两次实际训练误差的风险。样本量为 2n；q=n^{-1/2}。

在 0<v_-<B_0^2 的固定参数场内，速率为

q + (a+s^2)(b+t^2) + min(s,t)^2 + t min(a,t) + s min(b,s).

我按文中的 O=t min(a,t)、P=s min(b,s) 使用字母；“O 下界”与“O 上界分支”不是同一对象。上界的两个分支分别达到 q+a(b+t)+(a+s)^2 和 q+b(a+s)+(b+t)^2，再用公开选择与大半径回退组装。下界有 q、ab、M、O、P 五个分量；主风险的外层上确界足以组装它们。Proposition 3 额外给出每个 n/预算格子内一个工程化公开类对与同一协变量边缘分布，使五个不等式均成立。它没有断言一个单独的 law 同时支付五项。

当 v_-=B_0^2 时，共享包络迫使 propensity 为零，故 nuisance 速率不再出现。这个边界由单独的识别论证决定，不能继续套用 interior 常数。

以上限定条件在主文和附录相当明确。我没有把缺失的异方差、未知预算、自适应、计算效率、置信区间或因果结论当作作者已经声称的结果来反驳。

**已确认错误：只需局部修补**

定位：第 35 页，Appendix E.3，式 (E.11)，约行 1874–1877。

该式末端写为

exp{-(64-1/8) N S} < exp(-511),
S=a^2+b^2, N=2n.

取 n=16、a=b=1/(2 sqrt(2))，则 q=1/4、S=1/4、ab>0，因此满足 Appendix E 的“大分支”全部入口条件，并且 NS=8。于是

(64-1/8) NS = (511/8)*8 = 511,

所以显示中的最后一步实际是等号，不能是严格小于。这个反例不涉及极限、数值优化或抽取错误；我也对第 35 页做了视觉核对，PDF 的确印的是严格小于号。

严重性：低，确定的局部数学/排版错误。
影响：不改变原始分布、共同参考、观测距离的数量级、目标间隔、预算合法性、任何估计器或量词。用 “≤ exp(-511)” 已远强于后续 TV<1/4 所需。也可保留更紧的前一步余量，但没有必要。
最小修复：把这一处最后的 “<” 改成 “≤”。不需要重做 Theorem 1 或修改其常数。
这同时说明第 41–43 页自称的全面边界审计仍应作为待检查主张，而不是审稿证据本身。

没有其他已确认的实质错误。本报告余下的风险与改进意见不会冒充错误清单。

**上界审查：关键攻击点及结果**

1. 可测性与零预算（第 11–12、16、20、23、40 页，(A.1)、Lemma 8、(B.10)–(B.11)）。

逐点处处的表示序列，加上同一固定候选包络，确实通过 dominated convergence 保持总体 L2 近似下确界；在固定有限样本上，又保持这些连续经验目标的取值极限。对于校准的差分类，分别逼近 g 和 g' 即可。因此全文没有必要把未必可测的 full-class 局部上确界直接插入数据相关索引。

(A.1) 对 full class 用 outer expectation，上界只用其 countable core 的普通期望，并且只需要不等式支配。这条方向正确；我没有发现暗中把两者断言为相等的步骤。在 s=0 或 t=0 时，所有正半径的 core 复杂度被直接迫为零，后续使用正的 h_n floor，无须计算 0/0 或构造 star hull。

O 编辑的 H_mu 在 P_1(Ta)≠1 时确实为无穷，因为 f=0 而 gamma 可任意大；在该超平面上则成为 (B.10)。当 T 向量不为零，选一个非零坐标作 pivot、其余坐标用有理数列举，给出的 chart 是该真实超平面的稠密 Borel 参数化，即使 T_j 是无理数亦然。这比直接在 R^n 中使用有理格点来满足一个可能无有理解的等式要正确。由于差分类有共同有限包络，H 在有限样本上是有限 Lipschitz 函数；正二次惩罚带来 coercivity，first-within-tolerance 选择可测。R 编辑同理，其随机性只来自 D2 和 D1 协变量。

这些是信息论构造，不等于有限次查询可计算的算法；稿件对这一点有明确限制。

2. 局部经验过程与 joint fit（第 14–19 页，Lemmas 6–7、(B.2a)–(B.9b)）。

我查了 Bartlett–Bousquet–Mendelson 原文 Theorem 2.1。把对称类的 range 取 [-B,B]、alpha=1，得到 Rademacher 系数 4 与 range 系数 8B/3，符合 (B.2)。这是一个有效的外部定理调用，而非作者的“内部证书”。[Local Rademacher complexities, Theorem 2.1](https://arxiv.org/pdf/math/0508275)

Lemma 7 的 dyadic shells 使用真实类的正半径限制，没有把不属于类的缩放函数强行放入类。壳层数因共同包络与 h_n 而有限；z+2j+log 8 的失败概率可作几何求和，j/n 和 sqrt(j/n) 被 h_n^2、h_n 吸收。随机但有界的 multiplier 可在样本条件下 contraction；固定 multiplier 的 centered process 需要的额外均值项也在文中支付了。这一路可得到 stated orders。

joint class J_mu 的关键是
||gamma T+f||_2^2 = v gamma^2 + ||gamma pi_0+f||_2^2.
因此即便 f 接近 -gamma pi_0，gamma 方向仍支付 v gamma^2，不能发生隐藏的无曲率抵消。进一步
|gamma|≤R/sqrt(v_-),  ||f||_2≤(1+B_0/sqrt(v_-))R
给出文中的 joint localization。scalar direction 的 R/sqrt(n) 项被 C_J(s∨h_n) 支付；它并没有被假装成原 G_mu 的复杂度。七次 primitive calls 中为 joint class 单独列出这一调用是必要且有效的。

固定 comparator 的 Bernstein 事件可先带任意正 slack，所得 scalar tail bound 再让 slack 降到零；不需要也不能把所有 comparator 事件作无限交。本稿写出的路径可行。对于经验范数转移，利用 h=fit-comparator 属于 countable difference core，再为固定 comparator residual 加一条 scalar bound，是合法做法。

3. 条件独立性与校准分解（第 20–25 页，(B.12)–(B.29)）。

我特别检查了“编辑后的向量能否再乘 outcome/treatment noise”的问题。

O 权重由 D2、D1 的 X/T 决定，给定 F_T 后 D1 的 epsilon 仍独立且条件均值为零，故 weighted Hoeffding 可作用于 epsilon(a_hat-w)。r_mu(X)u 的控制改在 F_X 下进行，也有相应中心化。R 的 m_hat 只用 D2 的 Y 与 D1 的 X，给定 F_X 后 D1 treatments 未被固定，因此 r_m u 的条件中心化没有失效。不同 conditioning fields 的失败界先各自积分再作无条件有限 union bound，并不要求这些事件独立。

O 的归一化 P_1(T a_hat)=1 支持 (B.17) 五项恒等式；不能用未归一化的初始权重替代这一点。R 的 signed identity 也能直接重推：
Y-m_hat=beta_0 u+epsilon-r_m，T-pi_hat=u-e_pi，
减掉 beta_0 P_1(u-e_pi)^2 后，恰好留下
epsilon(u-e_pi)-r_m(u-e_pi)+beta_0(u e_pi-e_pi^2).
这与 (B.28) 相符，最后的 -beta_0 e_pi^2 未被漏掉。

R 分母给定 D2 后的中心为 v+||e_pi||_2^2，方差受 B_D^2 倍该中心控制，故 (B.27) 的经验下界不是从总体正性直接跳出的。O 的 true-weight 比较分母 D0=P_1(Tu) 也单独处理，零 treatment 向量有指数小概率回退。

4. 小正则化项与期望风险（第 21–25 页，(B.14)、(B.18)–(B.20)、(B.29)–(B.30)）。

最容易制造错误的是 objective comparison 后除以 lambda，把 sqrt(z/n) 放大 d/r；若只在固定置信水平代入，会隐藏不可积或漏项风险。本稿保留了
(d/r)sqrt(z/n)、(ad/r)sqrt(z/n)、(d/r)z/n
及 R 分支的对应项。这里 r≥C_rad h_n，且 d 有固定包络，因此
q/r ≤ const,
d/(nr) ≤ const/sqrt(n log(en)) ≤ const*q.
deterministic ad 由 ay+x^2+q 控制；其放大后的积分也只多一个 q/r。R 同理用 bd 与 bx+y^2。n^{-6} 与 n^{-12} 优化误差也被相同 floor 吸收。对每个 z 分别构造 tail event，然后 layer-cake 积分是足够的，不需要一个对所有 z 同时成立的事件。clipping 和有限 z 范围外的指数尾处理没有留下需要额外速率的角落。

我没有将每个未命名 C_rho 展开成最优数值常数，也没有形式化验证每个常数定义；但关键放大项与常数依赖的方向经检查成立。本文只承诺 fixed-rho constants，故并不需要我未找到的统一边界常数。

5. 公开方向选择与多项式等价（第 4、27–28、38 页，(8)、(B.31)–(B.33)、(G.2)）。

这里我没有只接受 “direct budget-cell checks”。可以独立验证如下：

令 S0=ab+M+O+P。由 at^2≤O、bs^2≤P、s^2t^2≤M，立即得
S0≤X≤2S0，
且无须除以任一预算。

对于 V=min{A,xy,T_mu,T_pi}：
X≤5A，因为 AB≤2A、M≤s^2、O≤a、P≤s^2；
X≤4xy，因为 AB、M、O、P 各≤xy；
X≤4T_mu，因为 AB≤ay+2s^2、O≤ay、M+P≤2s^2；
交换两侧得 X≤4T_pi。
从而 X/5≤V。
另一方面 W≤4A（T_mu≤2a+2a^2+2s^2≤4A），W≤2xy，且 W≤T_mu,T_pi，因此 W≤4V。

还可用六个弱序格子直接控制 W。按第 27 页表的顺序，所选分支可分别界为
3ab+2P+O，
3ab+2O+P，
5ab+O，
5ab+P，
ab+4O+M，
ab+4P+M。
每个都≤5S0≤5X，足以支持稿件较松的 V≤6X。端点相等不会改变这些弱不等式。若 x≤y，则 T_mu≤2xy≤2T_pi；反向同理，公开选择至多损失常数。

对于 unsafe cell：若 h_n>delta_rho，则 h_n^2≤2q 直接支付回退；否则 O 不安全意味着 s>delta_rho。若 t≥s/2，则 M≥s^2/4；若 t<s/2，x≤y 迫使 b>s/2，所以 P>s^2/2。镜像证明处理 R。不需要偷偷在大半径使用 branch oracle。Q1 上界是先证明一个固定 Gamma 的 uniform law bound，再取外层 supremum，顺序正确。

**下界审查：原始实验、预算与观测距离**

1. 三点 treatment channel 与所有 envelope（第 29–30 页，(C.5)–(C.13)；第 32–37 页）。

设 v=v_-，m_rho=min{1/64,v/(4B0),(B0-sqrt(v))/4}，L=sqrt(v)+2m_rho。
对 mean m，三点质量为
p_+(m)=(v+m^2+Lm)/(2L^2),
p_-(m)=(v+m^2-Lm)/(2L^2),
p_0(m)=1-(v+m^2)/L^2.
直接求和给出 ET=m、ET^2=v+m^2，因此 Var(T)=v。m_rho>0、Lm_rho≤v/4、L+m_rho<B0 给出侧点和零点正性，以及 T 与 u=T-m 的共同包络。二元 response Y=(B0/2)R 的概率按线性条件均值构造，所以 epsilon 的中心化不是只靠边缘 moment matching 猜出的。

因此这些是满足原模型的完整观测 law；没有把一个不合法的 signed measure 当成概率分布，也没有引入隐藏的 clean sample。v 可等于区间两端唯一值，故 singleton variance interval 不构成漏洞。

2. P 与 O 的共同参考（第 30–34 页，(C.10)–(C.19)、(D.1)–(D.12)）。

P 用 propensity ±z eta，outcome nuisance z gamma 与 z kappa，kappa=gamma+Delta eta，Delta v=2 eta gamma。
用 a_t 表示 sign-average treatment 质量、b_t=eta t/(2L^2)，sign average 相等所需的 identity 是
Delta a_t t = b_t(kappa+gamma).
在侧点它等价于
Delta(v+eta^2)=eta(kappa+gamma),
把前两条代入即为同一个等式；零点两边均零。
所以 Q(t,r)=(a_t+r b_t gamma/A)/2 的确在两标签间逐原子相同。
写 P_{ell,z}=Q+z C_ell，可直接复算出稿件 h_ell=C_ell/Q，而 E_Q h_ell=0。
这一步支持目标间隔 Delta~s min(b,s)，不是仅仅指出两个低阶矩相等。

O 使用同一 propensity z gamma，label 0 的 outcome nuisance 为 z eta、label 1 为零，Delta(v+gamma^2)=gamma eta。sign-average identity 变为
Delta a_t t=b_t eta。
这保证 label 1 的 outcome factor 可在 likelihood ratio 中完整约去，得到 h_1=b_t/a_t；如果省略这条逐原子 identity，约去是不合法的。稿件具备该 identity，并且
K_1=sum_t b_t^2/a_t=gamma^2/(v+gamma^2)
计算正确。其目标间隔具有 t min(a,t) 的阶。

P/ab 共享一种原始分布模板，O/M 共享另一种模板。因而“四个下界”不应被解读为四种新的通用下界技术；不过它们在不同公开预算分配中的成员资格是分开检查的，足够支持实际结论。

3. Walsh 正交与 finite mixtures（第 28、31–32、34–37 页，Lemma 11、(C.19)–(C.20)、(D.12)–(D.13)、(E.10)–(E.11)、(F.12)–(F.13)）。

对每个标签，likelihood 是 1+sigma phi_j(X)h_ell(T,R)，reference 的 (T,R) 部分与 X 独立。Walsh 的两两正交已足以使不同坐标的 one-observation Gram entry 为 1；并不需要所有 Walsh characters 联合独立。同坐标同号/反号给出 1±K_ell。N 个 iid observations 后，各 entry 才提升为 N 次方。对 2p 个 prior atoms 展开平方，得到

chi2(Pbar_ell^N,Q^N)
= {[(1+K_ell)^N+(1-K_ell)^N]/2-1}/p.

这和 (C.3) 相同。我另外显式枚举了一个 4 个 X 点、3 个 Walsh 方向、N=3 的有限实验，核查直接计算的联合 likelihood 二阶矩与此公式一致，详见后面的计算记录。巨大 p 在数学上仍是有限公开字典；测试界量化的是所有 Borel statistics，所以“学习器能遍历完整字典”本身不是反例。

在文中的有效分支里，log p 为 64Ns^2、64Nt^2 或相应量；K_ell 的上界常数远小于 64，所以混合距离非常小。两个参考相同的标签各自靠近 Q^N，通过 triangle inequality 得到跨标签 TV 界。给定每个 prior 标签内部 beta 相同，expected-loss testing 再给出所需目标间隔常数。

4. 公共复杂度与 approximation certificates（第 30–37 页，(C.14)、(D.6)–(D.7)、(E.2)、(E.5)、(F.4)–(F.7)）。

有限差分类采用全局 Massart bound，然后除以任一 r≥s 或 r≥t；这是一个上界证书，因此不需要 complexity 恰好等于 budget，亦不需要局部球中存在某种缩放函数。P 的 outcome difference envelope 为 2kappa、log cardinality≤258ns^2，给出 R_n≤46 kappa s≤(23lambda/64)s^2。除以 3r 并用 lambda≤192 c_rad/23 就满足 (A.1)。O/M 的两个 stochastic coordinates 也各自支付了自己的预算；不会因为只记了 min(s,t) 就遗漏另一边。

近似预算有直接成员/距离证据：P 的 outcome truth 在字典，propensity 对 {0} 的距离为 eta≤b；O 的 propensity 在字典，outcome 离 {0} 的距离≤a；ab 两边都是 off-class truth 相对 {0} 的距离；M 两边均在字典。lambda 同时缩放了与 BG 相关的 public candidates，不能把它从 target separation 常数中删掉，稿件没有删。

低 n、小 stochastic square 或零项的区域由 q 下界 splice，交互项≤常数*q。这是最大值比较，不是相加两份 Bayes risk。由此 all-n closure 成立，(E.11) 的局部严格号问题不改变这个事实。

5. 同一公开类对与共同协变量 law（第 43–46 页，Appendix L；第 6 页 Proposition 3）。

本稿在 L 中没有把各个原始字典直接取线性 span，而是有限 union。这个区别对包络和复杂度非常关键。G_mu^star 仅包含 P/M bands 和零；G_pi^star 仅包含 O/M bands 和零；ab band 只作为 off-class truth，避免其由 a^2+b^2 控制的巨大 cardinality 污染 s/t 证书。

完整 difference classes，包括跨频段差，分别满足
|G_mu^star|≤7p_s、|Delta G_mu^star|≤49p_s^2，
|G_pi^star|≤5p_t、|Delta G_pi^star|≤25p_t^2。
非平凡时 Ns^2 或 Nt^2≥8，额外固定 cardinality 因子被 log bound 的余量吸收；union 的 envelope 是最大 amplitude，而不是 amplitudes 的和。因此这一步没有丢失 cross-band complexity。

所有 characters 都在同一有限群上取值，P_X^star 是该群整个嵌入像的均匀 law。新增字典不改变任一原始标签混合的观测分布或 TV，且所披露的其它函数值是 X 的确定性后处理。对一个知道完整 pair 的任意 Borel rule，原测试不等式仍成立。component identity 没有作为一个额外坐标喂给学习器；即使某些 components 在其他观测特征上可区分，component 内部的下界仍有效，并不要求所有 components 互不可区分。

q 的共同 host 版本把 treatment 改为同一三点支持、但保留 ET^2=v；likelihood energy 4(d_star)^2 v/(nB0^2) 不变。零 nuisances 都在 enlarged pair 中。inactive components 可复用这个 q family。五个 testing inequalities 对同一 rule 成立后，先取最大值，再取 infimum，最后由 max-to-sum 和 S0≤X≤2S0 得到 Proposition 3。没有 sup/inf 交换。

6. 饱和与空实验（第 7–8、39 页，(H.1)–(H.6)）。

我独立重推得到：若 v_->B0^2，|u|≤B0 与 E(u^2|X)≥v_- 矛盾。若 v_-=B0^2，则 u^2=B0^2 a.s.；条件中心化迫使 u=±B0 条件等概率；再用 |T|=|pi_0+u|≤B0 得 pi_0=0。于是 beta=E(TY)/B0^2，bounded sample mean 的 expected absolute error≤1/sqrt(2n)。singleton class 的两点目标 theta=±3/(32sqrt(n)) 及二元 response 是合法 lower subexperiment；tensorized affinity 给 TV^2≤72/1024，足以推出所声称的 3/(128sqrt(n))。

该边界依赖 T 与 residual u 使用同一个 B0 包络，这是模型的实质限制。它本身是较短的 support/identification lemma；正确，但不应承担本稿主要新颖性。

**公开先行工作：定理层面的比较与可迁移障碍**

我实际打开了以下一手来源，而不是只依赖稿件 Table 4。以下比较仅针对列出的版本/定理，不是完整文献的优先性证明。

| 一手结果 | 实际对照 | 对本稿贡献的影响 |
| --- | --- | --- |
| Gu (2026), TAME Theorem 3.1、Corollary 3.2、(3.6)–(3.7) | 在本文符号中 leading upper 正是 min{a(b+t)+(a+s)^2, b(a+s)+(b+t)^2}；公开预算方向选择也已出现。其 corollary 有小误差渐近条件与 high-probability remainder。 | 不能把两分支、校准原理或该上界阶作为本稿新发现。本稿额外工作是这里特定 M1/Q1/all-budget expected-L1 闭合和必要下界。[原文](https://arxiv.org/html/2607.21541v1) |
| Gu–Yin–Cai–Fan (2026), Theorem A.1、(A.1)–(A.2) | 直接给四预算 lower q+(a+s^2)(b+t^2)+min(s,t)^2；框架为固定协变量 law 与 outer truth families，公开 learners 的表述和本稿的 represented public pair 不完全相同。 | O/P 确实不在这一公式中。不能只因模型相近就无证明地搬运全部常数/量词；本稿有自己的 native 实验，避免该问题。[原文](https://arxiv.org/html/2606.06368v1) |
| Jin–Mackey–Syrgkanis (2025), Theorem 3.1、Theorem B.1 | 二元 treatment、anchored nuisance errors；nuisances 为 (E[T|X],E[Y|X])，定理已有 squared-radius 与 mixed-product 障碍，源定理用 quantile loss。 | 一般的“平方项/方向性障碍”并非本稿首次。但把其 epsilon 直接命名为 a,s,b,t 不成立：这里 outcome nuisance 是 mu，而 E[Y|X]=beta*pi+mu；还须给出公开类复杂度与常数条件方差 embedding。未在该定理中发现直接蕴含本稿 O/P 的完整桥梁。[原文](https://proceedings.nips.cc/paper_files/paper/2025/file/f0156a82b6af6a4e838923ce9c124424-Paper-Conference.pdf) |
| Balakrishnan–Kennedy–Wasserman, Theorems 1–2, arXiv v2 | fixed pilots 的 L2 neighborhoods；ECC 的 MSE lower/upper 为 r_n s_n+1/n，r_n,s_n 是 squared L2 radii。 | 是结构无关估计的框架祖先，不是本文 coefficient/Q1/四预算匹配下界。尤其不能把 MSE lower 直接开平方当作 expected-L1 lower。[原文](https://arxiv.org/html/2305.04116v2) |
| Jin–Syrgkanis, arXiv 2512.17341v2, Theorem 7.5 | anchored binary PLM 中的 expected conditional covariance target，给 product lower。 | 本文若 v 已知，ECC=v*beta；但源定理的 law class 没有因此自动限制为这里的固定条件方差 public-certificate 子实验。对子类的 lower 仍需构造，不能靠目标名称转换完成。[原文](https://arxiv.org/html/2512.17341v2) |
| van der Laan–Luedtke–Carone, arXiv 2411.02771v3 | 已有校准、partial orthogonality 下的一侧 nuisance 足够好时的渐近推断与区间结果。 | 解释了 directional calibration 的概念邻近性；我只检查了摘要、相关主文/定理条目，没有审完其全部证明，不能由此声称全文不存在任何可迁移结果。[原文](https://arxiv.org/html/2411.02771v3) |

另外查了 [Gu 的 COLT 2025 open-problem 页面](https://proceedings.mlr.press/v291/gu25b.html)，确认该问题的历史来源；没有把摘要当作解决本稿全部量词问题的定理。

重要的正面证据是合法射线：取 a=t=r、b=s=0，旧 nuisance lower= r^3，新 O=r^2；镜像为 b=s=r、a=t=0。让 r=n^{-1/8}，则 q=n^{-1/2}=o(r^3)，所以差距不是被参数项淹没的形式游戏。若只看两份公开原文中显示的 upper 与旧 lower，确有尚缺的匹配项。

然而，这不是广义优先性证明。已知平方/混合 lower 技术与本稿非常接近；我的肯定判断是“核查过的定理并未直接覆盖这个完整字段，本稿自己的 constructions 支持闭合”，而不是“所有更早文献都不可能改造到这里”。若另有先行 theorem 已给出同样的 public class complexity allocation 与 exact-variance embedding，我会下调创新评分。

**尚未解决的风险、局部阐释需求与偏好——分开列明**

A. 文献范围风险（中等影响于创新性；不是已确认 correctness gap）。我没有做穷尽式优先性检索，也没有审查稿件所引全部 DML/orthogonal-learning/Robins/Liu 论文的每条 theorem。对 closest comparisons 的证据较强，对“全球最新、首个解决”的断言没有充分证据；好在稿件自身明确不作广泛 priority claim。若后续给出直接在相同 public-pair certifying experiment 上的先行 lower，我会改变总体分数。

B. 常数与全程序审计的剩余不确定性（低至中等；不是具体反例）。我检查了关键 constant dependencies、active predicates、零预算、sample splitting、两标签原子与测试距离，并复算了明示的 algebra；没有以 proof assistant 验证全部 46 页，也没有展开所有 K_i、C_rho 为机器可检验数字。本文 “complete proof / audit” 的文字本身不能消除这类剩余不确定性。我没有发现一个明确缺少的 leading-rate term。

C. 结果的重要性边界（影响接收强度，非错误）。exact constant conditional variance、已知四预算、固定 envelope、外层可随 n 更换的 finite public pair、任意 Borel computational rule 共同定义了一个刻意宽的统计对抗实验。它适合回答信息论 sharpness，但没有直接给出自然学习类上的速率下界，也没有提供现实可用的预算认证方法。作者已经承认这些限制，因此不能要求作者为未声称的算法性能负责；不过这些限制确实约束论文对一般 ML 读者的意义。

D. 同一类对加强的权重（创新性判断）。L 的 union/Walsh multiplexing 是有效而非显然错误的构造；它比单纯 outer-sup maximum 更强。但 pair 是逐格工程化的，且零项可复用 q family，不能读成一个自然类在各个样本规模同时具有五种不可分解困难。我会把它记为次要加强，与作者主张一致。

E. 行文与解释偏好（低，不影响定理）。主文第 7–8 页关于“保留方向性分解来选择 calibration orientation”的描述，可进一步区分方向选择与 tuning：真正的分支 indicator 只比较 x=a+s、y=b+t，而 lambda/floors 才需要单独的 stochastic certificates。不能把“只知道 x,y 就完全不能选择方向”当作本定理证明的事实。另一方面，同一 (x,y) 的确不足以确定最终 minimax rate；例如 x=r、y=1/2，(a,s,b,t)=(r,0,1/2,0) 的 nuisance order 是 r，而 (0,r,1/2,0) 的 order 是 r^2。这个更直接的例子比仅互换 O/P 两条等阶射线更能说明速率分解的价值。

F. 行文偏好（低）。第 41–43 页的 audit、boundary matrix 与 dependency index 对定位有用，但与前文重复较多；“corrected”“repaired”“independent raw route”等标签不能替代数学证明，也不宜让读者误以为重复同一个代数式就是独立外部验证。我已按原始公式而非这些标签评判。纯理论论文不需要为了形式完整而添加无关实验；我不把没有模拟结果作为缺点。

**实际计算记录与可复现支持**

计算全部用于复查公式，不构成统计实验、性能证据或对所有实数输入的证明。没有生成新的稿件版本、证据包或额外 review 文件。

(1) 预算代数搜索。
NumPy RNG seed=123；候选一维值集合是 linspace(0,1,41) 与 10**linspace(-12,-1,30) 的拼接。从该集合独立抽取 30 批、每批 50,000 个四元组，合计 1,500,000 格。按文中公式计算 A,B,M,O,P,X,T_mu,T_pi,W,V,S0，分母为零的纯零格单独跳过比值。观察到的最大比值为：

| 比值 | 最大观察值 | 稿件声称上限 |
| --- | --- | --- |
| W/V | 3.3706896552 | 4 |
| V/X | 1.5788203508 | 6 |
| X/V | 4.0 | 5 |
| X/S0 | 2.0000000000000004 | 2 |
| T_selected/X | 2.5894077388 | 48 |

X/S0 的 4e-16 超出为浮点舍入，解析式已另行证明上限 2。搜索不能证明这些不等式；前面给出的逐格推导才是正面证明支持。

(2) 原始分布扫描。
NumPy RNG seed=314159；5000 次固定参数抽样，每次 B0 从 {3,4,10,100} 抽取，v/B0^2 从 {10^-8,10^-5,.001,.1,.5,.99,.999999} 抽取；独立抽取四预算于 [0,1]，c_rad 和 BG 的对数在 [-6,1] 均匀抽取。每次按 C/D/E/F 原始公式生成四机制、两标签、两符号，合计 80,000 个六原子 law。

扫描计算质量和、ET、Var(T)、E(Y|T,X)、两标签 sign-average reference、同坐标反号 Gram，以及 residual envelope。最大 absolute mass error 为 3.33e-16；最大 relative variance error 为 4.44e-16；最大 conditional mean-Y error 为 1.18e-14；最大 reference discrepancy 为 8.33e-17；最大反号 Gram error 为 4.44e-16。扫描中的最小原子质量 2.49e-7；所检查 treatment/outcome residual 相对 B0 的最大包络比 0.9999997813。这些结果没有提供反例，并与解析核查吻合；我不据此声称任意 rho 的所有 envelope 已被数值穷尽。

(3) 显式联合分布的 Gram formula 检查。
取 v=.7、L=1、A=1.5、eta=.05、gamma=.07、p=3、N=3；四个协变量点上的 Walsh 行为
(1,1,1), (-1,1,-1), (1,-1,-1), (-1,-1,1)。
这些是检验 algebra identity 的自由小参数，未冒充文中 active lower 分支的预算格。对 P/O 的每一标签，先计算全部 24 个 (X,T,R) 原子，对 6 个 (j,sigma) 的三次 tensor product 作平均，再直接计算 sum(Pbar^2/Q^3)-1。结果：

| 模板/标签 | K | 直接 chi-square | 与闭式公式差 |
| --- | --- | --- | --- |
| P/0 | .0057210524093 | 3.27304406698e-5 | 0 |
| P/1 | .0057520532117 | 3.30861161504e-5 | 4.44e-16 |
| O/0 | .0080470888838 | 6.47556395048e-5 | 5.92e-16 |
| O/1 | .0069513406157 | 4.83211363553e-5 | 7.40e-17 |

可按如下短程序复现这个检查（NumPy；使用完整观察 law，而不是只输入作者的 K 值）：

~~~python
import itertools
import numpy as np
v,L,A,eta,gam = .7,1.,1.5,.05,.07
phi=np.array([[1,1,1],[-1,1,-1],[1,-1,-1],[-1,-1,1]])
p,N=3,3
for typ in ["P","O"]:
    delta=2*eta*gam/v if typ=="P" else eta*gam/(v+gam*gam)
    kappa=gam+delta*eta
    references=[]
    for ell in [0,1]:
        laws=[]
        for j,sg in itertools.product(range(p),[-1,1]):
            mass=[]
            for xi in range(4):
                z=sg*phi[xi,j]
                m=z*eta*(1 if ell==0 else -1) if typ=="P" else z*gam
                mu=z*(gam if ell==0 else kappa) if typ=="P" else (z*eta if ell==0 else 0)
                for t in [-L,0,L]:
                    pt=1-(v+m*m)/L**2 if t==0 else (v+m*m+t*m)/(2*L**2)
                    for r in [-1,1]:
                        mass.append(pt/8*(1+r*(ell*delta*t+mu)/A))
            laws.append(np.array(mass))
        laws=np.array(laws)
        Q=(laws[0]+laws[1])/2
        h=laws[1]/Q-1
        K=np.sum(Q*h*h)
        mix=sum(np.einsum("i,j,k->ijk",u,u,u) for u in laws)/(2*p)
        ref=np.einsum("i,j,k->ijk",Q,Q,Q)
        direct=np.sum(mix*mix/ref)-1
        formula=(((1+K)**N+(1-K)**N)/2-1)/p
        print(typ,ell,K,direct,abs(direct-formula))
        references.append(Q)
    print("reference difference",np.max(np.abs(references[0]-references[1])))
~~~

(4) 确认错误 (E.11) 的复现只需计算
(64-1/8)*32*(1/4) = 511.
这项是解析等式，与机器容差无关。

**哪些证据会改变我的判断**

会明显降低正确性评分的证据：某个合法 fixed Gamma/rho/budget cell 上有 Borel estimator 达到严格快于声称下界的阶；原始 hard family 的一项包络、公共 complexity 或 exact conditional variance 在合法边界被违反；发现 R 编辑实际使用了 D1 treatments，从而破坏所依赖的 conditional centering；或找到本稿 tail chain 中未被 q/branch target 支付的放大项。单纯声称 p 很大、pair 会随 n 变化或预算不是实际误差，都不是反例，因为这些已被风险定义允许。

会降低创新评分的证据：早于本稿的明确 theorem 已经对同一个 public-class approximation/stochastic allocation、pair-specific Borel quantifier 与 exact-variance model 给出 O/P，或有无需新的统计构造的完整定理级 reduction。只发现另一篇文章也有 epsilon_1 epsilon_2 或 epsilon_1^2 还不够。

会提高重要性评分的证据：这套闭合能明确落到一个广泛使用的自然类对、未知预算情况下仍有相应可验证选择原则，或者提供与现有 TAME 实践直接相关的可实施结论。它们不是当前定理正确性所必需，也不应被拿来拖延对当前理论结论的判断。

**实际材料、工具、会话与未审计项目**

唯一读取的项目材料：
D:\29722\Desktop\paper\PLM4B_C14_GPT56PRO_TWO_STAGE_REVIEW\STAGE1_UPLOAD_ONLY\01_Candidate_C14_Anonymous_Manuscript.pdf

完整读取其 46 页的文本；另外将第 31 页与第 35 页渲染作视觉核对，使用同一个临时 PNG 覆写。没有读取同目录之外的稿件源文件、历史审计、其他评审、封闭 H2 包或 Stage 2 文件。没有联系其他评审，也没有要求或接收他们的结论。没有自行创建下级审稿会话。

公开一手材料均已在上文链接。对于 Bartlett 使用的是 arXiv 2005 reprint Theorem 2.1；对于 BKW 是 arXiv v2，而非独立核验最终 Statistical Science 排版版本；TAME 与 Gu–Yin–Cai–Fan 是所列 v1；Jin–Syrgkanis 明确查看 v2；Calibrated DML 查看 v3 的有限相关部分。检索还返回了非一手索引页/ResearchGate/alphaXiv 等，但本报告定理比较没有依赖这些二手页面。Project Euclid 页面打开未返回可用正文，因此浓缩不等式的核验转用 arXiv 原文。

使用工具：functions.exec 编排的 PowerShell exec_command、Python 3.11.9、PyMuPDF 1.28.2、NumPy 2.4.6；view_image；web.run 的 search/open/click/find；clock.curr_time。Python 解释器是 C:\Users\29722\AppData\Local\Programs\Python\Python311\python.exe。首次文本输出因 Windows 默认编码失败后改成 UTF-8；没有因此修改 PDF。没有使用优化求解器、proof assistant、训练模型或经验性能模拟。

会话角色为独立 Reviewer C，调度指定模型/推理设置为 gpt-6-astra / ultra；此信息来自本次会话任务设置，未独立验证服务端模型实现。我不是人类专家审稿人。主调度仅提供匿名 PDF 的路径、权限边界、报告交付要求，并在中途确认继续自主保存；没有提供论文项目对话、先前审查发现或其他 reviewer 意见。

未审计事项：源树的图形脚本及第 10 页所给运行命令未执行；没有重建 LaTeX/PDF；没有核验 AI-use statement 所述作者实际过程；没有做完整文献优先性调查；没有逐项检查所有参考文献书目信息；没有形式化认证 46 页中的全部固定数值常数。图 1 的射线数量级按显示公式重算过，不能据此声称其源代码可复现性已被审计。

本报告的最终判断保持为：弱接收；主数学结论在上述独立攻击与复算范围内成立的证据较强，尚无实质推翻证据；一处 (E.11) 末端严格号应局部修正，贡献评价应主要落在 O/P matching necessity，而不是继承的校准架构。
