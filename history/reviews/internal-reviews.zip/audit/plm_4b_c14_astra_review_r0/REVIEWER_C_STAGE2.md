Reviewer C — Stage 2 独立 AI red-team 原始报告
Four-Certificate Minimax Rates over Public Class Pairs for Bounded Partially Linear Models

日期：2026-09-07。
本报告是在 Reviewer C 的同一独立会话中、保存 Stage 1 原始报告之后形成的更新。Stage 1 文件保持原文；以下明确记录本轮新增证据和判断修订。本报告是 AI 审查，不是人类同行评审，也不是形式化证明认证。

**当前结论**

我维持弱接收（weak accept），评分 6.5/10，未因新增源码自动加分或扣分。尺度与 Stage 1 相同：1 表示主要结论被明确推翻，3 表示明显拒稿，5 表示接收边界，7 表示有实质理论贡献且基本支持接收，9–10 表示影响广泛的突出成果。正确性判断的信心为 4/5，贡献／优先性判断的信心为 3/5。源码增强了我对两个初始拟合承重步骤的信心，但不是全文正确性的自动证书。

(B.6a)–(B.6e) 与 (B.8a)–(B.8e) 的新增展开是有效的。我逐步重推了基本不等式、固定比较函数的经验范数控制、二次项吸收、联合类的局部化、总体曲率和 slack 极限，没有发现新增的 oracle、隐藏的 joint-class 复杂度证书、凸性假设或不可数随机索引插入。它们闭合了此前压缩叙述中读者必须自行补全的关键推导；这不等于证明 C13 的定理原先为假。

本轮新确认一处低严重性证明错误：Lemma 7 平方过程的居中项控制，在内球覆盖全类时使用了不成立的半径／包络不等式。它可以原地修复，不改变引理、主定理、预算、估计器或速率。它不在 C13→C14 的 diff 改动中，属于本轮发现的既有问题，不是此次回归。

Stage 1 的 (E.11) 末端严格号问题仍然存在。新增六份材料没有 Appendix E 的修改，也没有提供该处已经修复的证据。

因此，我支持“完成两处局部修补后冻结当前科学结论”，不支持把当前文字原样视为已经无误的最终冻结版，也没有发现必须阻断主科学结论的证据。若冻结是指不再重开模型与速率设计，现有证据支持；若冻结是指逐字接受现有 PDF／源码，则应先修正下述两处。

最强接收理由仍是：在明确限定的公共类对、四项上界证书与常数条件方差实验中，O/P 必要性补足了已有上界与较弱下界之间的缺口，并处理了所有预算格子与同一类对的兼容性。最强拒稿理由仍是重要性和增量：核心校准上界、两混合测试和一般的平方／乘积障碍均有直接先行工作，主要贡献是相当专门实验中的匹配下界闭合；本稿未给自然函数类、未知预算适应或高效实现的新增结论。后者是贡献评价，不是正确性反例。

**本轮材料边界与 diff 的实际核对**

除第一阶段的 46 页匿名 PDF 外，我只读取了获准的六份新增材料：

1. STAGE2_UPLOAD_CORE\01_C13_TO_C14_Complete_Source_Diff.patch
2. STAGE2_UPLOAD_CORE\02_C14_main.tex
3. STAGE2_UPLOAD_CORE\03_C14_Appendix_A_Model_Quantifiers.tex
4. STAGE2_UPLOAD_CORE\04_C14_Appendix_B_Upper_Proof.tex
5. STAGE2_UPLOAD_CORE\05_C14_Appendix_C_QP_Lower.tex
6. STAGE2_UPLOAD_CORE\06_C14_References.bib

它们的共同目录为：
D:\29722\Desktop\paper\PLM4B_C14_GPT56PRO_TWO_STAGE_REVIEW\STAGE2_UPLOAD_CORE\

我完整读取 patch、main 509 行、Appendix A 209 行、Appendix B 1507 行、Appendix C 388 行。对 bib 解析了全部条目键，再检查本批 tex 实际使用的 13 个引用条目；没有声称对 592 个条目的全部内容进行了语义审计。

用内存中的 Python 解析核对 unified diff：四个文件共 10 个 hunk，旧侧／新侧行数均符合 hunk 声明，全部新侧内容与提供的对应 C14 文件逐行相符。按 old_start/new_start 记录，它们是：

- main：25/25、286/286、301/303、410/412、443/447；
- Appendix A：126/126；
- Appendix B：345/345、364/418、436/498；
- Appendix C：64/64。

这是“给定 patch 与给定新源码内部一致”的核对，不是对历史仓库、C13 原件或 diff 全仓完整性的独立认证。patch 中的旧／新路径标记不构成我读取或验证旧源树的授权。我没有读取旧源树，也没有据此重建一个替代工作目录。

B 源码中 50 个显式 \tag{} 未发现重复。六份材料不构成可编译的完整树，因此本轮没有 clean build、LaTeX 编译、图形脚本运行或所谓历史测试复现。正文引用的其他附录仍以 Stage 1 PDF 为审查材料。

**Stage 1 实质结论的逐项状态**

| Stage 1 项目 | Stage 2 状态及影响 |
| --- | --- |
| 第 35 页 (E.11) 最后一处严格小于号在合法边界不成立 | 保留，未修复证据。低严重性，改为非严格号即可。 |
| 初始 propensity 拟合、joint 拟合及 comparator slack 路径可成立 | 得到新增源码的直接支持；本轮详细重推见下文。没有新增假设。 |
| Lemma 7 的局部化链条可给出声称的量级 | 结论仍可成立，但我修订 Stage 1 对该段文字的无保留判断：本轮发现一个具体错误不等式，最小修复后链条成立。 |
| represented core、outer expectation 支配和 first-within-tolerance 选择可测 | 保留。A 的显式可测性补充与标准 Borel 模型相容；B 的有理数 joint 增量使用正确。 |
| O/R 两个校准分支的条件独立性、归一化和 signed identity | 保留。此次改动没有改变所用数据、权重或 conditioning fields。 |
| all-z 尾界及放大项可以积分为 stated expected-L1 rate | 保留。新增初始拟合证明输出的半径和失败概率形式与后续相同；未发现新残余项。 |
| 六个预算格子、公开方向选择和多项式等价 | 保留；本轮没有修改这些代数关系。此前独立推导与计算支持仍适用。 |
| q、ab、M、O、P 原始实验与共同参考分布合法 | 保留。C 的对称性注释是有效澄清，没有改变实验；D–F 仍按 PDF 审查。 |
| Proposition 3 的同一类对／同一边缘分布闭合 | 保留，主文量词现在更清楚；不是单个 law 同时支付五项，也不是一个类对对所有 n 均最困难。 |
| 饱和边界 v_-=B_0² 与严格 interior 分开处理 | 保留；未发现新增或删去的条件。 |
| 上界架构和一般平方／乘积障碍已存在；新意集中在 O/P 的公共四证书分配及 native lower 闭合 | 保留，归属措辞有所改善，见定理级比较。 |
| Stage 1 未执行源代码、图形脚本、编译或完整优先性调查 | 仍然未执行／未完成，不能被这六份文件消除。 |

我没有把表中“保留”描述成第二次逐页完整重做了所有未变化附录。Stage 1 已对整个 PDF 做过独立审查；本轮集中增加的是源码和 diff 所能支持的检查，同时重开了 Lemma 7。

**承重检查一：(B.6a)–(B.6e) 的 propensity 初始拟合**

定位：04_C14_Appendix_B_Upper_Proof.tex 第 345–419 行，特别是 (B.6a)–(B.6e)，第 362、368、376、385、399 行的式号；初始 basic inequality 为其前面的 (B.6)。

记固定比较函数为 g_pi，h=pi_hat-g_pi，r=g_pi-pi_0，u=T-pi_0。经验近似最小化的容差为 tau_n。因为

T-pi_hat = u-r-h，T-g_pi = u-r，

两平方损失之差准确地等于

h² - 2uh + 2rh。

故
P_2 h² ≤ 2 P_2(uh) - 2 P_2(rh) + tau_n。

交叉项的符号正确；随后绝对值与经验 Cauchy–Schwarz 不依赖这个项的符号。h 属于已表示的 countable difference core，P(uh)=0；统一过程事件在插入拟合索引之前已构造。因此，令 H=||h||_2、delta=delta_{pi,z}，可以同时使用

|P_2(uh)| ≤ C_rho(delta H+delta²)，
P_2h² ≥ H²-C_rho(delta H+delta²)。

这正是 (B.6a)，没有把“真误差属于公开差分类”当成假设。属于差分类的是 fit-comparator，而非 fit-truth。

固定比较残差的总体范数 r_pop≤b+epsilon。令 w=sqrt(z/n)，其包络为 B_pi。源码前述 Bernstein 界具有形式

R² ≤ r_pop² + sqrt(2) B_pi r_pop w + (2/3) B_pi² w²，
R=||r||_{2,n}。

实际上已有更清楚的直接界：
R ≤ r_pop+B_pi w，
因为右侧平方中的交叉项系数 2≥sqrt(2)，平方项系数 1≥2/3。这支持 (B.6b) 的较松 C_rho 写法，不会产生 sqrt(b) 一类新速率项。

过程平方项的另一侧给出

||h||_{2,n}² ≤ H²+C_rho(delta H+delta²)
             ≤ C_rho(H+delta)²，

因此 (B.6c) 正确。代回 basic inequality，

H² ≤ C_rho(delta H+delta²)+2R||h||_{2,n}+tau_n
   ≤ C_rho{(delta+R)H+(delta+R)²+tau_n}。

令 U=delta+R，对 CHU 应用 Young：

CHU ≤ H²/2 + C²U²/2。

这里重新用 C_rho 表示变大的固定常数是合法的；它无需保持原来的数值。吸收后得到

H ≤ C_rho(delta+R+sqrt(tau_n))。

用 sqrt(tau_n)=rho_n、delta≤bar t+w 和三角不等式，就得到 (B.6e) 及 (B.7) 之前的带 slack 显示式。源码把此前“+2 epsilon”的压缩表达改成“+C_rho epsilon”，避免把经过未知常数吸收的 slack 系数错误地固定为 2。这个改动是合适的。

最终去掉 epsilon 也正确。对每一个 epsilon>0，最终随机变量 L=||pi_hat-pi_0||_2 都是同一个估计器的误差，且

P{L>A+C_rho epsilon} ≤ K exp(-z)，

其中 A、K 与 epsilon 无关。取 epsilon_m↓0，事件 {L>A+C_rho epsilon_m} 递增到 {L>A}，概率连续性给出无 slack 尾界。比较函数本身和比较事件可以随 epsilon 改变，不需要把它们作可数或不可数交集。比较函数依赖真 law 仅用于证明；它不是学习器的输入。

审查结果：此段完整、有效；没有精确最小值存在性、凸性、star-shapedness 或 oracle 风险假设。它依赖 Lemma 7；下文的局部居中项修复应先落实，但不会改变这里的推导或输出形式。

**承重检查二：(B.8a)–(B.8e) 的 joint 初始拟合**

定位：B 源码第 421–577 行；(B.8) 位于第 427 行，(B.8a)–(B.8e) 的式号分别位于第 512、524、534、546、559 行。

这里必须区分三个不同对象：

- 公开 countable joint class 中的 j；
- 证明中固定的比较残差 e°；
- 未必属于该 countable class 的真实拟合误差 Gamma T+F。

源码现在正确维持了这个区分。取 beta°∈Q∩[-3,3]、g° 为 represented comparator，并定义

e°=(beta°-beta_0)T+(g°-mu_0)，
j=(beta_hat_0-beta°)T+(mu_hat-g°)。

beta_hat_0 和 beta° 都来自有理数搜索，二者之差属于 Q∩[-6,6]；mu_hat-g° 属于 represented difference core，因此 j∈J_mu。即使真实 beta_0 为无理数，也不影响这个结论。另一方面 e° 含有真值，但它是固定比较函数，不被当成公共类中的随机搜索索引。

平方损失的差准确地等于

(epsilon-e°-j)²-(epsilon-e°)²
= j²-2 epsilon j+2e°j。

因此
P_2 j² ≤ 2P_2(epsilon j)-2P_2(e°j)+tau_n。

取 J=||j||_2、E=||e°||_{2,n}，统一的 joint 过程事件与 P(epsilon j)=0 给出

|P_2(epsilon j)|+|(P_2-P)j²| ≤ C_rho(delta J+delta²)，
||j||_{2,n} ≤ C_rho(J+delta)。

这就是 (B.8a)。事件是在插入随机 j 之前构造的。

固定比较残差满足

||e°||_2 ≤ a+(1+B_0)epsilon_cmp，
|e°| ≤ 7B_0+B_G。

包络不随 slack 增大：两个系数均在 [-3,3]，所以系数差绝对值至多 6，另有 |mu_0|≤B_0 和 |g°|≤B_G。用同一平方残差 Bernstein 论证得到 (B.8b)。随后的 Cauchy–Schwarz 与 Young 恰好给出

J² ≤ C_rho{(delta+E)J+(delta+E)²+tau_n}，
J ≤ C_rho{a+(1+B_0)epsilon_cmp+bar s+w+rho_n}。

这支持 (B.8c)–(B.8d)。

还必须证明 J 小确实控制系数和 outcome nuisance 的分别误差。对任意实数 gamma 与平方可积 f，

||gamma T+f||_2²
= v gamma²+||gamma pi_0+f||_2²。

令 q_f=||gamma pi_0+f||_2，则

gamma²+||f||_2² ≤ (1+2B_0²)gamma²+2q_f²。

取 c=v_-/[2(1+B_0)²]，有 c(1+2B_0²)≤v_-≤v，且 2c<1。后者来自非空模型必有 v_-≤B_0²，不是新增条件。于是

||gamma T+f||_2² ≥ c{gamma²+||f||_2²}。

这是 (B.8) 的充分且合法常数。现在才令 Gamma=beta_hat_0-beta_0、F=mu_hat-mu_0，利用 Gamma T+F=e°+j，得到

|Gamma|+||F||_2
≤ 2(1+B_0)/sqrt(v_-) · ||Gamma T+F||_2
≤ C_rho{a+(1+B_0)epsilon_cmp+bar s+w+rho_n}。

这是 (B.8e)。总体曲率对所有实数 gamma 有效，因此此处真实误差系数无须有理；这个步骤没有再次调用随机过程。最后的 slack 极限与 propensity 部分相同。

joint-class 预算本身也没有被偷偷加入模型。若 j=gamma T+f 且 ||j||_2≤R，则同一正交恒等式给出

|gamma|≤R/sqrt(v_-)，
||f||_2≤C_f R，C_f=1+B_0/sqrt(v_-)。

故在 R≥C_J(s∨h_n) 的允许半径内，

R_n(R;J_mu)
≤ [B_0 h_n/sqrt(v_-)+3c_rad C_f s]R
≤ c_rad C_J(s∨h_n)R。

第一项是一个标量 treatment 方向的复杂度，明确由 h_n 支付；第二项来自公开 outcome difference-class 的预算。C_J 和 C_rad 在 law 之前固定，只依赖 rho。s=0 时仍有正的 h_n 半径；没有要求公开类对真实函数作缩放闭包。

审查结果：B.8 的新增展开成立，且把最容易混淆的“可数搜索增量”和“总体真实误差”分开得更清楚。这是有效的证明补全，不是新估计器或新统计假设。

**我专门检查而未确认的回归：后文的 +2 epsilon 是否已经失效**

定位：B 源码第 579–608 行，尤其第 595–604 行的两个经验初始拟合显示式。

前面的总体拟合证明改成了 C_rho epsilon，后面仍写 2 epsilon，表面上可能像是未同步修改。我没有把这个表面现象列成错误，因为这些经验显示式可以从已经去掉 slack 的 (B.7)、(B.9) 独立推出。

再取一个固定的 nuisance comparator g，令 f=fit-g、r=g-truth。对 fit 所在半样本，

||fit-truth||_n
≤ ||f||_n+||r||_n
≤ ||f||_2+c_sq Delta+||r||_2+B_pi w
≤ ||fit-truth||_2+2||r||_2+c_sq Delta+B_pi w。

新的比较残差满足 ||r||_2≤b+epsilon 或 a+epsilon，因此这里准确地给出额外 2 epsilon；它不是从前一段尚未取极限的 C_rho epsilon 硬改成 2。上述更明确的 Bernstein 平方配方也支持 B_pi w 的系数 1。L_pi=K_5+c_sq+B_pi+2、L_mu=K_6+c_sq+B_pi+2 足以吸收 2b 或 2a 等项。

需要支付的失败概率是已成立的总体拟合尾界、统一平方过程事件与这次固定 comparator 的有限合并；不必让上一段的所有 comparator 事件同时成立。这与正文统一增大固定失败常数的做法相容。

建议把这层推导读作从无 slack 的总体结论重新开始；文字上若再说明一句会更清楚，但这里没有已确认的数学回归。我不要求为了消除一个可以正确解释的记号表象而改变速率或估计器。

**本轮新增的确定局部问题：Lemma 7 的平方过程居中项**

定位：原 PDF 第 15 页，Lemma 7 证明中“For the square process”段；B 源码第 173–181 行，错误链位于第 179–180 行：

“Centering adds at most R_j²/sqrt(n) ≤ B h_n R_j.”

R_j 在第 164–165 行定义为 2^j delta_z，R_0=delta_z。壳层内函数的实际范数至多 min(R_j,B)，但 R_j 这个符号本身并没有被 B 截断。第 155–156 行还明确允许 delta_z≥B 时整个类都落入内球。因此上述第二个不等式并不总成立。

一个完全合法的引理级例子是：

n=1，z=1，h_1=1，c_rad=1，r_0=1；
X 只有一个取值；
H={0, f_+, f_-}，f_+(X)=0.1，f_-(X)=-0.1；
包络 B=0.1；可取独立的 ±1 对称乘子 xi。

H 可数、含零，乘子有界且 E(xi|X)=0。对每个 r≥r_0=1，
R_{1,P_X}(r;H)=0.1≤r=c_rad r_0 r，
所以 (B.2a) 成立。delta_z=K_1+1，R_0=K_1+1；对引理所用正的 K_1，

R_0²/sqrt(n)=(K_1+1)²
>0.1(K_1+1)=B h_1 R_0。

不需要知道 K_1 的具体数值，就已推翻显示中的第二步。为数值展示取 K_1=1 时，原比较是 4≤0.2，显然错误。这个数值只是展示；解析反例不以我自由选择最终 K_1 为前提。

真正需要界的是居中所新增的 Rademacher 项，而不是那个可能很松的 R_j² 上界。直接使用共同包络即可修复：

sup_{f∈H_j} P f² · E|n^{-1}Σ_i epsilon_i|
≤ min(R_j²,B²)/sqrt(n)
≤ B R_j/sqrt(n)
≤ B h_n R_j。

这是因为对正数 R_j，min(R_j²,B²)≤B R_j，同时 n^{-1/2}≤h_n。这个证明覆盖内球、最大壳层、n=1 和 delta_z≥B，且不要求修改原来的局部复杂度调用半径。

严重性：低，确定的局部证明错误；并非 Lemma 7 结论或 Theorem 1 的反例。
最小修复：在居中项的链中保留 min(R_j²,B²)；也可用同样有包络的直接界。
影响：不改变模型、量词、公开预算、随机过程阶、失败概率、初始拟合半径、估计器或最终 minimax rate。原先后续所需的 C_rho delta_z R_j 界原样恢复。

这处错误不在给定 patch 的 B 三个 hunks 中，因而按本轮材料它是既有文字，不是 C13→C14 新引入的回归。我明确修订 Stage 1 对这段逐字正确性的判断；Stage 1 的旧文字不会被覆写。它也说明论文所说“覆盖 whole-class inner ball”的自我核查描述不能替代证明本身。

**Stage 1 确认的问题仍未消除：(E.11)**

定位：原 PDF 第 35 页，Appendix E.3，式 (E.11)，约行 1874–1877。Stage 1 已视觉确认末端确为严格小于号。

该链末端写为
exp{-(64-1/8) N S}<exp(-511)，
S=a²+b²，N=2n。

取 n=16、a=b=1/(2sqrt(2))，则 q=1/4，S=1/4，ab>0，满足该“大分支”的入口条件。NS=8，所以

(64-1/8)NS=(511/8)·8=511。

末端这一步是等号。改为 ≤ 即可；后续 TV<1/4 的余量极大。前面真正的 chi-square 界还可能有严格余量，但这不能使所显示的两个相等指数之间变成严格不等式。

严重性仍为低；对实验、目标间隔、所有速率和量词无影响。六份新增材料既不包含 Appendix E 新源码，patch 也没有该处修改，故本轮只能报告“未见修复”，不能猜测未提供文件已经修好。

**其余 C13→C14 修改的科学效果**

主文摘要，第 25 行附近：显式加入 (a,s,b,t)∈[0,1]^4。这与已有主定理的预算场一致，改善可见性；并非此次才给上界偷偷增加的小误差假设。本文仍用大半径回退处理预算格子，不应读成所有预算都趋零。

Proposition 3，main 第 287–306 行：现在更明确地写出固定 strict-interior rho、每个 n≥1、每个预算格子后，存在工程化 Gamma_star 和 P_X,star；相应下标包含 rho。这是正确的量词顺序。类对和边缘分布可随 rho、n 和公开预算变化，不随采样结果或隐藏真 law 改变。它不能被宣传为“单个固定字典对所有样本规模实现全部最难率”，也没有这样断言。下界 law 可不同，风险取同一公开类对内的上确界；类是有限并集，不是免费增大的线性张成。

Appendix A 第 126–134 行附近：把 mu_0、pi_0 写成 A/B(R)-可测。在标准 Borel 的观测模型中，可由条件期望的可测版本获得 pi_0(X)=E[T|X] 与 mu_0(X)=E[Y-beta T|X]；所有分布约束和 L2 近似按 a.s. 意义处理。选择这样的版本不要求额外平滑性、学习可访问性或 pointwise 真值证书。我没有发现这会排除一个原先应当合法的分布实验。

B 的曲率段与两组展开：上文已给出独立 derivation。新段落是证明补全和对象区分，不是新 joint 证书。源码第 548 行把 Gamma 临时用作系数误差，而正文同字母用于公开类对，阅读上略有负担；作用域足够清楚，我只把它视为可选的记号偏好，不列成错误。

C 第 64–73 行附近：说明有限类复杂度应用发生在对称差分类上。对称性在 L2 局部半径限制后仍成立，因此
sup_h Σepsilon_i h(X_i)=sup_h |Σepsilon_i h(X_i)|
可以成立；h=0 也包含在内。于是使用 one-sided Massart bound 时不需要再凭空增加一倍类大小。这个注释正确澄清了原先的使用方式；没有改变有限字典、复杂度预算或下界构造。

main 第 415–421、450 行附近：更准确地归属 Jin–Mackey–Syrgkanis 的 aggregate anchored-error 障碍，并把概括表中的 “binary T,Y” 改为 “binary T; Y binary in B.1”。公开源 Theorem 3.1 的一般陈述限制 treatment 二元和 outcome 有界，Appendix B.1 才使用二元 outcome 子实验。这项修改纠正了旧摘要表对原定理范围过窄的概括。它提高归属准确性，不提供额外新颖性。

**定理级先行工作比较与当前贡献判断**

以下比较延续 Stage 1 查阅的公开一手文献；本轮又直接核对了两篇 Gu 预印本的相关原文。论文中写“direct bridge absent”本身不是我承认新颖性的理由；需要看 estimand、风险、law class、预算分配与量词是否真能匹配。

| 一手结果 | 已有内容与本文关系 | C14 后应保留的贡献边界 |
| --- | --- | --- |
| Gu, TAME，Theorem 3.1、Corollary 3.2、(3.6)–(3.7) | 本文记号下已有 leading upper min{a(b+t)+(a+s)², b(a+s)+(b+t)²}，也有按公开半径选择方向。其 corollary 有小误差条件和概率余项。 | 不能声称校准架构、两分支或这个 leading rate 是新发现。本文的工作是该公共实验中的 all-budget expected-L1／M1／Q1 闭合与匹配必要性。[原文](https://arxiv.org/html/2607.21541v1) |
| Gu–Yin–Cai–Fan，Theorem A.1、(A.1)–(A.2) | 四预算下界含 q+(a+s²)(b+t²)+min(s,t)²；实验以固定 P_X 与 outer truth families 表述。 | 本文 O/P 并未直接包含于该公式。不同实验表述不能自动互换；native lower 构造的公共类合法性是必须做的工作。[原文](https://arxiv.org/html/2606.06368v1) |
| Jin–Mackey–Syrgkanis，Theorem 3.1 与 Theorem B.1 | anchored nuisances 为 E[T|X]、E[Y|X]，已有 squared-radius 与 mixed-product 障碍；主结论使用 quantile risk。 | “存在平方项或方向性乘积”不是本稿的发现。本文 residual nuisance 为 mu_0，而 E[Y|X]=beta pi_0+mu_0，还要分配成四个 public certificates 并保持 exact conditional variance；源定理的两个 epsilon 不能直接改名为 a,s,b,t。[官方论文](https://proceedings.nips.cc/paper_files/paper/2025/file/f0156a82b6af6a4e838923ce9c124424-Paper-Conference.pdf) |
| Balakrishnan–Kennedy–Wasserman，arXiv v2，Theorems 1–2 | fixed-pilot L2 邻域下 ECC 的 MSE 率含 r_n s_n+1/n，r_n、s_n 是平方半径。 | 是框架先行工作；不能对 MSE 下界直接开平方，便得到本文 expected-L1 coefficient 下界，也不能自动获得四预算公共类实验。[原文](https://arxiv.org/html/2305.04116v2) |
| Jin–Syrgkanis，v2，Theorem 7.5 | anchored binary PLM 的 ECC target 与 product lower。 | 若 v 已知，ECC=v beta，但目标换算不自动把源 law class 限制到本稿常数条件方差子实验；仍须构造合法子族。[原文](https://arxiv.org/html/2512.17341v2) |
| van der Laan–Luedtke–Carone，v3 | 已有校准、partial orthogonality 与一侧 nuisance 足够好时的渐近推断。 | 方法方向已有明确先行工作；我仅检查了相关主文条目，没有声称排除了其全文所有可迁移结果。[原文](https://arxiv.org/html/2411.02771v3) |

源码对 JMS 的新措辞比旧措辞准确：应把 aggregate anchored-error 障碍归还先行工作，剩余工作是公开四证书的分配、mirrored P 与 O 的配对、常数条件方差 embedding，以及本文可测性／风险量词下的闭合。这个层级在 C14 中基本表述到位。

我未找到一个无需新统计构造就能从上述源定理得到完整 O/P、exact-variance 和 represented-public-pair 结论的桥梁；因此不支持“它只是已知定理换字母”的强否定。反过来，未找到桥梁并不能证明绝对原创性。尤其若某个早期结果已经包含同一四证书 allocation 的有限子实验，贡献评价应下调。

论文仍应把核心结果呈现为特定实验中的匹配必要性与整体闭合。把 primitive 两混合方法、一般校准思想、基本吸收法或平方／乘积障碍本身包装为新增方法，会超过我能支持的贡献层级。C14 的这轮改写朝正确方向前进，但分数没有因此提升：归属准确是必要条件，不会增加定理本身的影响范围。

**未发现回归的下游链与可复算的正面证据**

初始拟合输出没有新增数据依赖或不可吸收项，因此 Stage 1 对下游两分支的检查继续适用：

1. O 权重只使用 D2 与 D1 的 X/T；在 F_T 条件下，D1 outcome noise 的均值仍为零。R 编辑的 m_hat 使用 D2 outcome 与 D1 covariates；在 F_X 条件下保留对 D1 treatment noise 的中心化。此次 diff 未改变这些依赖关系。

2. R 分支的恒等式保留了 signed quadratic 项：
epsilon(u-e_pi)-r_m(u-e_pi)+beta_0(u e_pi-e_pi²)。
新增初始拟合段没有删去最后的负平方项，也没有把总体分母正性当成经验分母下界。

3. 需要积分的尾项仍包括 (d/r)w、(ad/r)w 和 (d/r)w² 及镜像项。r≥C_rad h_n 支付 q/r 与 d/(nr)；slack 经 scalar tail limit 消除，而不是作为未知 estimator tuning 留在风险里。

4. 预算多项式中，令 A=a+s²、B=b+t²、M=min(s,t)²、O=t min(a,t)、P=s min(b,s)，X=AB+M+O+P，S_0=ab+M+O+P。由 at²≤O、bs²≤P、s²t²≤M 得 S_0≤X≤2S_0，不涉及除零。六个格子的分支选择与 Stage 1 所给代数界继续支持公开选择与回退；此次没有更换目标多项式。

5. Stage 1 已直接检查 native 三点 treatment channel 的常数方差、P/O 的共同参考方程、Walsh 正交性和混合 chi-square 公式。本轮 C 注释只说明复杂度的对称性，未改变这些对象。Proposition 3 新量词与 Appendix L 的有限并集相容：同一类对和同一 P_X 可用于不同困难 laws，无须把它们当作同一个最难 law。

这些是维持正面判断的具体理由；不是借论文自身的“checked”“audit”或“reproducible”用语推断正确性。此前计算是辅助反例搜索，不能覆盖无限参数集；解析推导才是这些保留判断的依据。

**冻结条件、未决风险以及可改变判断的证据**

支持局部修补后冻结的证据：

- 两组指定承重展开可逐式重推，常数只依赖固定 rho，没有更换 estimand、风险、量词或 estimator。
- 已确认两处错误都有明确、立即可验证的本地修复；不需要增加假设、改变预算区间或弱化主率。
- 本轮没有发现 C13→C14 改动造成的下游回归。
- 归属说明更准确地承认已有方法与一般障碍，仍留下有实际数学内容的公共四证书匹配必要性问题。

目前不支持科学阻断。若把任何局部错误都等同于主定理失败，会混淆“显示的中间不等式为假”和“所需结论无法成立”。本轮两处属于前者，而且都有独立修复推导。

仍未决的事项：

- 没有完整源树，因此编译、交叉引用在最终排版中的整体状态、图形生成与命令可复现性没有被本轮确认。
- 没有把所有 C_rho 展开成数值常数；关键依赖方向和吸收项经检查，但没有形式化逐常数认证。
- 本轮不是完整重新审查 46 页每个未改变的证明，而是在 Stage 1 基础上核对源码、diff 和新的攻击点。
- 文献优先性调查是定向的，不是穷尽的。特别是常数方差 embedding 与公共证书分配能否从某篇未检查文献直接推出，仍可由明确 theorem/reduction 改变判断。
- 自然类适用性、未知预算、计算效率、置信区间以及异方差推广不是当前定理的结论。本稿影响范围有限，但这不等于其声明内的错误。

会降低正确性评分的证据，包括合法预算格子中的更快 Borel estimator 与 claimed lower 冲突；某个 hard family 无法满足公共 complexity 或 exact conditional variance；真实的 conditioning-field 违规；以及不能被 q 或选定分支支付的放大尾项。会降低新颖性评分的证据，是已有结果对同一 public-class 实验、同一风险与四证书 allocation 直接给出 O/P，或有完整且不需新统计构造的 reduction。仅指出另一篇文章有 epsilon_1² 或 epsilon_1 epsilon_2，不足以完成该反驳。

会提高重要性评分的证据，是清楚落地的自然类结果、可验证的未知预算选择、或对已有 TAME 实践有实质作用的实现结论。这些是提高贡献层级的证据，不是我在本轮额外添加的接收前置任务。

**实际工具、来源、会话信息与限制**

项目材料仅为本报告前列六份 Stage 2 文件，以及：
D:\29722\Desktop\paper\PLM4B_C14_GPT56PRO_TWO_STAGE_REVIEW\STAGE1_UPLOAD_ONLY\01_Candidate_C14_Anonymous_Manuscript.pdf

本轮没有读取内部台账、旧审计、其他 reviewer 报告、完整仓库历史、未授权 sibling 文件或封闭参考包，也没有向其他审稿者询问意见。主调度只提供了 Stage 2 的材料范围、检查目标和交付路径，没有提供其他审查结论。本会话没有自行创建下级审稿会话。

Stage 1 的完整原始报告已保存；本轮为核对原结论使用了本会话内存中的 Stage 1 原文，没有改写该文件。只新增此 REVIEWER_C_STAGE2.md；没有编辑论文，没有代写作者回复，没有制作档案、证据包、校验和清单或额外工作流文件。

实际工具为 functions.exec 编排的 PowerShell exec_command、Python 与网页工具。Python 解释器：
C:\Users\29722\AppData\Local\Programs\Python\Python311\python.exe
本会话使用 Python 3.11.9、PyMuPDF 1.28.2、NumPy 2.4.6；Stage 1 的数值反例搜索和有限分布计算使用 NumPy，相关完整复现代码保存在 Stage 1 报告中。本轮主要是文本／diff 解析和简单数值等式核对，没有重复运行所有 Stage 1 扫描。尝试导入 SymPy 时发现未安装，没有据此声称计算机代数验证。PDF 文本输出遇到 Windows 默认编码错误后改为 UTF-8 并成功读取；这没有修改 PDF。本轮再次读取第 15 页文字以核对 Lemma 7 的印刷位置；Stage 1 已视觉检查第 31、35 页，本轮没有另做全页视觉审计。

新增数值检查很小：对 Lemma 7 的展示参数得到原比较左侧 4、右侧 0.2，正确的包络居中上界为 0.01；对 (E.11) 计算得到指数恰为 511。二者的确认都来自上文解析等式／不等式，而不是浮点容差。

公开来源使用上文所列一手原文。Stage 2 成功再次打开 TAME arXiv 2607.21541v1 和 Gu–Yin–Cai–Fan arXiv 2606.06368v1；尝试重开 JMS 官方 PDF 时本轮工具返回访问错误，因此该比较使用的是同一会话 Stage 1 已成功取得的官方 PDF 原文及记录，没有伪称本轮重新下载成功。Bartlett–Bousquet–Mendelson Theorem 2.1 的原始 range／常数映射已在 Stage 1 查阅 [Local Rademacher complexities](https://arxiv.org/pdf/math/0508275)。其他文献的版本和有限阅读范围在比较表与 Stage 1 报告中注明。bib 中实际使用的 13 个 citation keys 全部存在，592 个 entry keys 未发现重复；这不等于所有书目内容、DOI 落地页或参考文献最终编译均已核验。

会话角色为独立 Reviewer C，任务指定模型／推理设置为 gpt-6-astra / ultra；信息来自任务调度，而非我独立核验的服务端实现。Stage 2 在同一 Stage 1 会话中继续，保留自己的先前推导；没有读取或接收别人的判断。这是 AI red-team 审查，不能被表述为人类专家签字或形式化正确性证明。

当前最终判断：弱接收，6.5/10；指定的两段承重展开闭合，贡献归属改善；无确认的科学阻断或新回归。Lemma 7 居中项与 (E.11) 严格号应局部修正后再冻结最终文字。
