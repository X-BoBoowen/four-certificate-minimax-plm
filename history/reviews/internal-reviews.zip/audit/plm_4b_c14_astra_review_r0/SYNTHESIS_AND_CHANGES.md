# C14 三路两阶段 AI 审稿与 C15 修订结论

日期：2026-09-07。当前稿件：Master-R17 / Candidate-C15。内部流程状态仍为 92%，不是正确性概率或录用概率。

本轮已完成三路两阶段审阅、六份原始报告的完整阅读、主代理证据核对、必要局部修订和新稿验证。当前没有已确认的主定理级阻断；本轮具体发现已修复。贡献大小与适用性上的保留意见仍成立。本记录不宣布 submission-ready，不保证以后不会发现有效问题。

## 审查执行及原始结果

三个主审均配置为 gpt-6-astra / ultra，以空继承上下文启动，未互读报告。第一阶段仅接收 C14 匿名 46 页 PDF，允许自主重推、计算、找反例、查一手文献；未预设通过或拒绝，也未要求必须找出错误。第二阶段沿用各自会话，读取既有六份定向源码材料，第一阶段原文保持不变。这是工具内的隔离会话，非替用户在外部 ChatGPT 网页创建的对话。

| 主审 | 第一阶段完整原文 | 第二阶段完整原文 | 最终个人判断 |
|---|---|---|---|
| A | [A Stage 1](REVIEWER_A_STAGE1.md) | [A Stage 2](REVIEWER_A_STAGE2.md) | 6/10，弱接收；建议局部修补 |
| B | [B Stage 1](REVIEWER_B_STAGE1.md) | [B Stage 2](REVIEWER_B_STAGE2.md) | 6/10，弱接收；建议局部修补 |
| C | [C Stage 1](REVIEWER_C_STAGE1.md) | [C Stage 2](REVIEWER_C_STAGE2.md) | 6.5/10，弱接收；建议局部修补 |

不合并分数；置信度与评分尺度以原始报告为准，均非概率。部分主审使用了角色默认模型进行有限算术或文献辅助，具体型号及范围在原文披露，不能声称所有辅助调用均为 astra ultra。最终主审意见由三位各自整合。

这些是 AI red-team，不是独立人工评审。用户既有作者审阅与责任声明继续保留，不能由此推导独立外部人工验证已完成。

第二阶段六份材料不是完整可编译树。三位没有据此声称 clean build 或历史测试复现。下述完整树构建由本地整合阶段另行执行。修补后仅向 A、C 作了局部解析核验，返回在本记录归纳；没有回写六份原始报告、改评分，或称其为新增独立全审。

## 证据取舍与修订

| 发现 | 核对结果 | C15 处理 |
|---|---|---|
| Lemma 7 平方过程中心化半径界错误 | 主代理独立发现并复推；A/B/C 第二阶段各自发现。名义壳层半径可超过包络 B | Appendix B 按实际二阶矩加入包络截断，保留原壳层与后续常数 |
| (E.11) 最后严格不等号错误 | C 第一阶段提出；主代理验证合法端点 NS=8，指数恰为 511 | 最后 < 改为 ≤；后续严格 TV<1/4 保持 |
| Proposition 3 / L.5 的 c* 同名不一致 | A/B 第一阶段提出；L 先定义分量最小值，最后所得是其十分之一 | L 复用 G 的 c_min,rho，明确最终 c*_rho=c_min,rho/10 |
| (G.1) 重复显示 | A 提出，B 亦记录；不是下界逻辑失效 | 合为一次带 G.1 编号的完整 risk≥R*≥max 链 |
| 聚合预算、方向选择和风险阶的解释不够准确 | C 提出；主代理复算同聚合、不同风险的例子 | 主文第 7–8 页加入精确例子，并区分方向、校准和风险 |

平方过程修复从实际中心化代价开始：
\[
\sup_{f\in\mathcal H_j}Pf^2\,
\mathbb E_\epsilon\left|\frac1n\sum_i\epsilon_i\right|
\le\frac{\min\{R_j^2,B^2\}}{\sqrt n}
\le\frac{BR_j}{\sqrt n}\le Bh_nR_j.
\]
函数同时满足局部化与包络约束，且 h_n≥n^{-1/2}。新式覆盖末壳层和整个内球超过包络的情况，恰好恢复原证明需要的界，无须增加 R_j≤B 或大样本假设。原错误是证明行错误，不是 Lemma 7 结论的反例。A 已回读新 B 源码确认关闭。

E.11 可取合法端点 n=16、a=3/10、b=2/5：S=1/4、N=32、NS=8，(64−1/8)NS=511。非严格指数界仍使两混合的总 TV≤e^{-511/2}<1/4。C 再次核验修复充分；概率律、振幅和检验常数不变。

G 的各非参数分量常数已包含大分支与 q-splice 常数的最小值，且 3d*_rho/32=c_q,rho/4。因此 G 的 c_min,rho 正是 L 所需的分量最小值。最大值转和及 S_0 转 X 分别支付 5、2，最终定义 c*_rho=c_min,rho/10。A 直接对照新 G/L 确认一致；主命题和量词不变。

新主文例子：对 0<r≤1/2，
\[
(a,s,b,t)=(r,0,1/2,0),\qquad(0,r,1/2,0)
\]
都满足 (x,y)=(r,1/2)，但 X 分别是 r/2、3r²/2。沿充分大整数 n 取 r=n^{-1/8}，q=r^4=o(r²)，完整风险分别为 Θ_rho(n^{-1/8}) 和 Θ_rho(n^{-1/4})。两格具有相同 O 方向比较；安全回退仍按既有条件执行，未声称任意有限 n 都实际调用 O 分支，也未声称估计器和调参完全相同。主代理与 C 分别复算。

相对 R16/C14，仅以下五份科学源码改变：

- [main.tex](../../paper/iclr2027_candidate_c15/main.tex)
- [Appendix B](../../paper/iclr2027_candidate_c15/appendices/B_upper_proof.tex)
- [Appendix E](../../paper/iclr2027_candidate_c15/appendices/E_ab_lower.tex)
- [Appendix G](../../paper/iclr2027_candidate_c15/appendices/G_lower_assembly_constants.tex)
- [Appendix L](../../paper/iclr2027_candidate_c15/appendices/L_same_pair_lower.tex)

标题、主定理、两条命题、速率、假设、Q1/M1 接口、学习输入、估计器、selector、下界概率构造、图、样式、bibliography 与既有 AI 声明未改。R16/C14 保留；C14 PDF 仍与本轮匿名审稿输入字节一致。

## 主代理判断及保留意见

三位认为 (B.6a)–(B.6e)、(B.8a)–(B.8e) 能在当前字段下闭合。我对比较函数、经验/总体范数转换、曲率回推、松弛消去和本轮失败行作了自己的核对。后续用不带松弛的 (B.7)/(B.9)，另取比较函数而出现 +2epsilon，不构成此前 +C_rho epsilon 修正的回归；不同松弛下比较函数可以不同，无须交无限多个事件。

我直接核对了 [Bartlett–Bousquet–Mendelson Theorem 2.1](https://www.stat.berkeley.edu/~bartlett/papers/bbm-lrc-05.pdf) 的参数映射。该来源支持稿件的集中不等式常数形式，不能替代稿件自身错误中心化行的修复。

[Jin–Mackey–Syrgkanis 正式会议版](https://proceedings.nips.cc/paper_files/paper/2025/file/f0156a82b6af6a4e838923ce9c124424-Paper-Conference.pdf) 的 Theorem 3.1 使用二元 treatment、有界 outcome，Theorem B.1 使用二者均二元。C14 已有区分正确，本轮保留。已有 anchored-error 平方与混合阻碍继续准确归属，不能靠未搜到完全相同公式宣称普遍优先权。

当前支持的是：在 bounded PLM、常条件残差方差、固定无限 standard Borel 宿主、sequential-M1、known pre-data upper certificates 与 pair-specific Borel 规则的实验中，O/P 匹配必要性可以改变风险阶，四预算率获得闭合。TAME 双分支上界架构与既有 q+AB+M 下界结构仍属继承部分。Same-public-pair 是 engineered、cell-dependent 的次要加强，不是全局外层下界组装的必要条件。

自然固定类别、自适应未知预算、一般异方差、计算效率、因果或经验性能扩展没有被列为本轮必做修补；它们需要新研究。贡献增量、方法可迁移性及较长 audit 文字的保留意见继续存在。未作穷尽式优先性证明或整篇形式化验证。没有依据为提高 AI 评分继续滚动版本；若出现新的有效具体问题仍应处理。

## 实际验证与构建

使用 Python 3.11 运行现有相关 unittest，四组均退出 0：

| 范围 | 结果 |
|---|---|
| upper_empirical_k2 经验范数/上界检查 | 11/11 |
| upper_r2 selector regression | 6/6 |
| ab_native_k9 exact identities | 11/11 |
| ab_native_k9 raw-law falsifier | 5/5 |

共 33 项相关回归通过，未冒充重跑全部历史 99 项。已有 exact_boundary_checks 失败数为 0；另在内存中对原半径反例、E 指数端点和预算例子作了精确分数诊断。

两树 live constant DAG 均通过，输出相同的 27 节点无环顺序。复用 C14 validator 的 validate_texts 与 run_mutations：两树结构检查零错误，各 11 个既有变异被拒绝，共 22 个。未将其锁定旧父稿范围或哈希的整树入口当作 C15 检查。另有 11 项修复文本断言，两树通过；这些只是文本回归检查。

直接字节比较确认：两树 34 份非构建文件一致；相对各自父稿恰好五份改变；1 个 theorem 与 2 个 proposition 环境均逐字节保持。图形 PDF 等源资产包含在比较中，没有把所有 PDF 一概排除。

两棵新树均不含继承的 main 构建产物，分别使用 Tectonic 0.17.0 和参数 --only-cached --keep-intermediates --keep-logs main.tex 构建。沿用 SOURCE_DATE_EPOCH=1788134400、FORCE_SOURCE_DATE=1。两次成功，PDF 字节一致，均为 398763 字节、46 页 US Letter。本轮是两个新稿树内的独立构建，不另称额外临时 clean-room 重现。

最终 TeX 日志无 fatal error、undefined citation/reference、重复标签或 overfull；BibTeX 无缺项。五个 underfull 提示仍在。启动时有非致命 Fontconfig 配置提示；正文字体可从 PDF 提取，图中的 Type3 字体具有内嵌 CharProcs，全部页面成功渲染，未见缺字。

46 页均渲染并作总览检查，修订页及相关 underfull 页放大检查，未见公式截断或文字重叠。Appendix J 保留较松的段间留白和跨页 boundary-matrix 提示，这是既有排版弱点；G 删去重复式后部分附录分页提前，本轮没有重写未改动的 audit 附录。Conclusion 完整结束于第 9 页，第 10 页开始 Reproducibility、AI use 和 references。临时渲染文件只用于检查，没有复制到项目或整理成证据包。清理目录的递归删除被工具自动审批策略拒绝，未给出更具体原因，因此检查图片仍位于 C:\Users\29722\AppData\Local\Temp\plm_c15_visual_8ope6prh；稿件与报告不受影响。

## 当前官方要求的核对范围

2026-09-07 核对 [ICLR 2027 Author Guidelines](https://iclr.cc/Conferences/2027/AuthorGuidelines)：初投稿正文至多 9 页；参考文献、其后附录、AI use 和可选 reproducibility 声明不计此限额。当前 PDF 符合已检查的位置与页数字段。官方模板压缩包仅在内存中读取，未保留归档；其 iclr2027_conference.sty、iclr2027_conference.bst、fancyhdr.sty、natbib.sty 与稿件现用文件均逐字节一致。

匿名署名、未启用 finalcopy、PDF 空 author/title 元数据和正文/链接未出现项目身份或本地路径，均已核对。PDF 无嵌入附件；对外链接仅为论文来源。现有公共 GitHub 仓库未更新或附作匿名投稿材料。

[ICLR 2027 AI Policy for Authors](https://iclr.cc/Conferences/2027/AIPolicyForAuthors) 要求论文及提交表单披露 AI 使用，作者承担内容责任。论文既有声明涵盖发现、文献、证明起草与审读、符号检查、图及编辑；提交表单未填写。已查官方规则没有将独立外部人工证明审计列为投稿硬条件；作者责任与独立审查仍分别陈述。

未访问作者 OpenReview 账号，未核验个人 profile、名额、互惠审稿资格、其他在投稿件或提交表单。未提交、上传、发布或 Git commit/push，未访问关闭的 H2 reference packages。稿件层面的核对不等于作者和提交端事项已完成。

## 当前文件

- [Candidate-C15 PDF](../../paper/iclr2027_candidate_c15/main.pdf)
- [Master-R17 PDF](../../paper/master_r17/main.pdf)
- 六份完整原始报告见本文件开头。

当前终态：MASTER-R17 AND CANDIDATE-C15 THREE-ASTRA TWO-STAGE REVIEW REPAIRS INTEGRATED AND VERIFIED。后续判断以 C15 实际源码与具体证据为准，不以旧评分、历史冻结措辞或模型名称代替科学核对。
