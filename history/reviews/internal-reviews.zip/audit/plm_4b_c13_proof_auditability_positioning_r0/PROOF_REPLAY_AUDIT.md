# Independent proof replay: Appendix B initial fits

## Treatment fit, (B.6) to (B.7)

Let `h = hat pi - g_pi` and `r_pi = g_pi - pi_0`.  The successor now exposes
the complete chain.

1. The already registered represented-core process call gives the centered
   multiplier bound for `P_2(uh)` and the two-sided square-process comparison
   for `P_2 h^2`; the common scale is
   `delta_{pi,z}=K_{1,*}(3t vee h_n)+sqrt(z/n)`.
2. For the one deterministic represented comparator selected for a fixed
   positive proof slack, scalar Bernstein applied to `r_pi^2` gives
   `||r_pi||_{2,n} <= C_rho(b+epsilon_cmp,pi+sqrt(z/n))`.
3. The upper square-process side gives
   `||h||_{2,n} <= C_rho(||h||_2+delta_{pi,z})` before the fitted index is
   inserted, because the process event is uniform over the countable
   difference core.
4. Substitution into the exact basic inequality, empirical
   Cauchy--Schwarz, and Young's inequality absorb one half of `||h||_2^2`.
5. The final triangle inequality adds the population comparator residual.
   The resulting scalar tail inequality has failure independent of the proof
   slack; scalar tail-probability continuity sends that slack to zero without
   intersecting infinitely many comparator events.

This yields exactly (B.7), with the pre-existing budget order and failure
multiplier.  No estimator input or tuning depends on comparator slack.

## Joint fit, (B.8) to (B.9)

For arbitrary measurable `f`, conditional centering gives

`P(gamma T+f)^2 = v gamma^2 + ||gamma pi_0+f||_2^2`.

Writing `q=||gamma pi_0+f||_2`,
`gamma^2+||f||_2^2 <= (1+2B_0^2)gamma^2+2q^2`.  With
`c=v_-/[2(1+B_0)^2]`, both
`c(1+2B_0^2)<=v_-<=v` and `2c<1`; hence the displayed curvature (B.8) is
valid.  This removes the former undefined `g_mu` notation and applies to the
total error used later.

For the fitted difference `j` and deterministic comparator residual
`e^circ`, the existing joint process call gives multiplier, square-process and
empirical/population norm conversion uniformly before fitted-index insertion.
The one fixed comparator event controls `||e^circ||_{2,n}`.  The exact joint
basic inequality then yields (B.8c); Young absorption yields (B.8d).  Finally,
with `Gamma=hat beta_0-beta_0`, `F=hat mu-mu_0` and
`Gamma T+F=e^circ+j`, the generic curvature and triangle inequality yield
(B.8e), hence (B.9) after the same scalar continuity argument.

## Event and assumption audit

- The joint class is the already supplied countable class `J_mu`; no new
  joint-complexity certificate is assumed.
- The zero outcome-stochastic-budget case retains the positive `C_J h_n`
  base radius and never evaluates a radius-zero quotient.
- Every comparator is deterministic for the corresponding positive slack;
  the failure bound is uniform in that scalar slack.
- Existing downstream event unions absorb only the same finite process and
  comparator failure multipliers.
- No convexity, exact minimizer, population oracle, extra learner input, or
  strengthened model assumption is used.

Disposition: **PASS**.  No unclosed proof obligation was found in the two
expanded bridges.
