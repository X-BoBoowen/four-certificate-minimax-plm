# Positioning and attribution audit

## Primary-source check

The retained full Jin--Mackey--Syrgkanis source, SHA-256
`3B458299F3437117AD59412AABD675EF47CEFF47AD8627028CEAAA616D181247`,
was checked at Definition/Theorem 3.1 and Appendix Theorem B.1.  Theorem 3.1
uses binary treatment and states the aggregate anchored-error squared-radius
and mixed-product obstruction.  Theorem B.1 additionally permits a binary
response construction.  The successor's prose and Table 4 now say exactly
this.

## Contribution boundary after revision

- Primary residual contribution: matching necessity of the directional
  `O=t(a wedge t)` and `P=s(b wedge s)` terms in the stated public
  four-certificate field.
- Explicitly inherited: TAME's two-branch upper architecture;
  Gu--Yin--Cai--Fan's `q+AB+M` lower structure; aggregate anchored-error
  squared-radius/mixed-product obstruction and fuzzy/product-testing ancestry.
- Scoped residual field: public four-certificate allocation, the mirrored P
  direction paired with O, exact-variance embedding, and matching
  sequential-M1/Q1 closure.
- Secondary: the engineered, cell-dependent same-public-pair coexistence
  construction.  It is stronger cellwise evidence but unnecessary for global
  Q1 assembly through the outer supremum and maximum-to-sum algebra.

The manuscript makes no priority, collision-free, non-reduction, universal
phase-diagram, natural-class, deployability, or generally new lower-bound
mechanism claim.  Proposition 3 and Appendix L mathematics are preserved.

Disposition: **PASS**.  The revised hierarchy is accurate and does not
repackage inherited material as original.
