# Six-report intake and evidence boundary

All reports were read in full before successor derivation. They are review evidence, not authority, proof, or votes.

| Reviewer stage | SHA-256 | Lines | Evidentiary use |
|---|---:|---:|---|
| R1 stage 1 | `5FA5286F52BFE47A7B6B2F7F68F7B1F7FA22FAB139E803C4570342E848A4BDE2` | 553 | issue leads only |
| R1 stage 2 | `0C3C80583DC5334A90510A85E8B26130E5B28F55F5C53461234181C12FFD1AEA` | 644 | issue leads only |
| R2 stage 1 | `556F397366E54A0CA21875D84C4B93C6AB300839EFEC01B24AFB42839F3F415D` | 591 | issue leads only |
| R2 stage 2 | `14640B46AD0A00C4DC7439743D35E7D1AB4CBB7159B1BB58CC2B526F7DF5C48B` | 684 | issue leads only |
| R3 stage 1 | `848254AF1CD7C23222356F5558EBE4CB935BB95170580B3F90114BF501E69079` | 569 | issue leads only |
| R3 stage 2 | `D035612707D6A05A7E6910147422074CDE76275C56F4C3D9A0083D4B1BDE79C1` | 655 | issue leads only |

The source comparison confirmed eight bounded issues: two compressed initial-fit derivations, one undefined curvature symbol, explicit nuisance measurability, a symmetry bridge after the finite-class lemma, Proposition 3 quantifier display, the abstract budget domain, and narrower Jin--Mackey--Syrgkanis/same-pair positioning. Previously closed outer-expectation, represented-core dominance, seven-radius mapping, endpoint, zero-budget, and Appendix-L mathematical issues remain closed and are not reopened.

The local full primary text for Jin--Mackey--Syrgkanis confirms that Theorem 3.1 is a binary-treatment lower bound and strengthened Theorem B.1 additionally takes the response binary. No novelty or priority credit is inferred from a literature non-hit.
