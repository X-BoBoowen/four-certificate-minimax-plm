# Candidate-C3 Figure 1 reproduction audit

## Claim and source

- Printed claim: PDF p. 10 Reproducibility Statement.
- Exact script: `paper/iclr2027_candidate_c3/figures/+generate_theory_summary.py`.
- Script SHA-256: `697B4851A34DD614E539F61011C3D47542F9CFAB2D865388215441097686BC33`.
- The path and file name printed by the manuscript are correct.

## Clean temporary execution

The script was copied without modification into `audit/plm_4b_c3_second_pass_synthesis_a0/figure_reproduction_temp/` and run there, so no protected figure, data, source, or code was overwritten.

Two environment-resolution attempts failed before scientific execution:

1. Windows `python` resolved to the Microsoft Store alias and exited `9009`.
2. The bundled workspace Python existed but lacked `matplotlib` and exited on import.

These are tool-environment failures, not script failures. The available project-compatible Python 3.11.9 environment with matplotlib 3.11.0 and NumPy 2.4.6 then executed successfully without installing packages or changing the script.

## Output comparison

| Output | Protected SHA-256 | Fresh SHA-256 | Result |
|---|---|---|---|
| `+rate_ray_data.csv` | `8424A385E5188AA79D143FE54445085980976AC72C97E4E96EDA1787B14CEBB9` | same | byte-identical; 240 rows; maximum numeric difference `0` |
| `+theory_summary.png` | `5B84AE2D6CD5707C5F3FC934971935C86D3BC3E7C234E7524916F9105B45172D` | same | byte-identical |
| `theory_summary.pdf` | `69F8B18B3DB4C43ED1D9D9F80CC08C9AC49E35D2C426F009AD31BF4621CC751A` | `04168F4218B88612BC0CC72700EF29A835B6AB159EF24B3E8E8CE143A8BE4717` | same byte length; exactly five differing bytes, all in `/CreationDate`; graphic payload unchanged |
| `+theory_summary.svg` | `484CA234E1AB79C72CBFB66EA7AB3B99F805F1DD1099BB74F9EA779700569055` | `58DA1BCE0C466225C3306AE49FECACEB1DFFDB11B78324812C5D62C3485BCC11` | same byte length; differences are generation time and nondeterministic internal SVG element IDs/references; the byte-identical PNG confirms rendered content |

## Verdict

`SCRIPT EXISTS AT THE CLAIMED PATH AND REPRODUCES FIGURE 1 IN A CLEAN TEMPORARY OUTPUT TREE.`

The script was absent from G's minimal blind packet because that role's whitelist contained the anonymous manuscript and review forms, not the project source tree. That absence is a package-scope observation, not a false manuscript path or missing project artifact. A final source/supplement release should include the script and run instruction.
