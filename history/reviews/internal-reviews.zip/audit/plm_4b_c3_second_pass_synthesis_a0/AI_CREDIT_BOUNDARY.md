# AI-credit boundary

## Controlling rule

M, S, and G are three external AI red-team returns. They supply technical evidence, objections, calculations, and source locators. They confer:

- independent-human-review credit: `0`;
- human proof-audit credit: `0`;
- human source-audit credit: `0`;
- submission-readiness credit: `0`;
- priority or novelty credit from search non-hits: `0`.

Reviewer labels, declarations, dates, and the Omega instance string are provenance metadata for AI sessions. M's and S's textual “signature” lines and G's reviewer-instance line are not human signatures or authentication.

## Permitted evidentiary use

The returns may identify proof nodes, scope boundaries, literature differentials, and falsification attempts. An issue is accepted only after direct manuscript/source checking or a reproducible calculation. Agreement among the three may raise audit coverage; it cannot replace a proof. A PASS means only that the stated reviewer did not confirm a failure within the work it actually performed.

## Conflict rule

Severity labels are normalized by claim impact, not averaged. S's “Major” labels on pair-specific access, known budgets, variance, and lower-pair interpretation are significance/scope judgments because S explicitly found the theorem's printed quantifiers mathematically legal. They are not converted into correctness defects by label counting. Conversely, M/G PASS cannot erase a source-supported limitation or an unchecked obligation.

## Remaining external requirement

A genuine independent human mathematical audit and a genuine independent human source/domain audit remain pending. No AI file may fill, sign, or release-gate a human form.
