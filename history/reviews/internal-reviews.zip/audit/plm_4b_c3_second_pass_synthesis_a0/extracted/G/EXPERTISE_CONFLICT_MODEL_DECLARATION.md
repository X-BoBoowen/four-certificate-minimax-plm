# Expertise, conflict, and model declaration

- Reviewer type (AI or human): AI
- Provider: OpenAI
- Model: Codex, GPT-5 family
- Version/build: Exact model build was not exposed to this review session.
- Review date: 2026-08-25 13:37:07 UTC+08:00 (Asia/Shanghai)
- Relevant expertise: General theory review spanning probability, theoretical statistics, semiparametric estimation, empirical processes, minimax lower bounds, measurable decision rules, machine-learning theory, reproducibility, and research positioning. This is a capability disclosure, not a human credential or biography.
- Context-isolation description: Fresh blind-review context. I used only the supplied ZIP, the anonymous manuscript inside it, and public primary sources independently retrieved for citation/novelty checking. I did not use project chats, prior reviews, correction summaries, specialist packets, internal audit materials, or another reviewer's output.
- Earlier-version exposure: None known; no earlier manuscript version was opened or supplied in this review context.
- Tools used: ZIP inventory and SHA-256 verification; pypdf text extraction; Poppler pdfinfo and full 33-page PNG rendering; visual page inspection; public web search and direct retrieval of primary-source PDFs; independent Python numerical checks of the finite lower constructions, common references, Gram-energy bounds, boundary/tie cases, and selector algebra.
- Other materials used: Public primary sources listed with exact locators in `NOVELTY_AND_CITATION_LOG.md` and `READ_MATERIALS_LOG.md`; no nonpublic source was used.
- Conflict or dependence disclosure: No personal, institutional, financial, or relational conflict can apply to this AI instance. I did not infer or seek the anonymous authors' identities. This is a simulated AI review and is not an independent-human audit. Conclusions depend on the supplied manuscript and the cited public sources.
- If human, authentication method: Not applicable.

Declaration that no other reviewer report was read: I did not read, receive, infer, aggregate, or consult any other reviewer report or completed review form.

Declaration that the returned files and raw output are unedited: The completed forms and `FULL_RAW_REVIEW_OUTPUT.md` are the direct output of this reviewer instance and were not summarized, polished, or rewritten by another AI or reviewer.
