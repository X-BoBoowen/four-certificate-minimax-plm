# Reviewer Ω independent blind first-pass report

## 1. Review setup

- **Input scope.** I reviewed the supplied ZIP as a fresh anonymous ICLR 2027 theory submission. I read the package README, general instructions, AI/human notice, blank declaration/form/logs, manifest and hashes, followed by the complete 33-page `manuscript/anonymous_manuscript.pdf`, including all appendices A-K.
- **Integrity check.** The manuscript SHA-256 is `342315A80B4B6CB9701CC6A58DEF728E407A84673F426CD6FB0D0311D2E162A1`, exactly matching `MANUSCRIPT_HASH.txt`. The input ZIP SHA-256 is `58D43AEFE018165D9C4DF682A7D32A1C4B79A526593CE2DE58A5E9469660B9FB`.
- **Assessment boundary.** I assessed correctness, minimax quantifiers, empirical-process logic, finite lower constructions, novelty, significance, clarity, reproducibility, assumption realism, and ICLR fit. I did not assess computational performance or empirical superiority because neither is claimed. I did not assign a causal interpretation because the paper explicitly excludes one.
- **Independence.** No other review, completed form, project conversation, correction summary, specialist packet, author identity information, or earlier manuscript version was read. No such prohibited file was present in the ZIP.
- **Public sources.** I independently checked the cited TAME and Gu-Yin-Cai-Fan preprints, the COLT open problem, the closest PLM lower-bound papers by Jin and coauthors, and the Bartlett-Bousquet-Mendelson concentration source. Exact locators are in `NOVELTY_AND_CITATION_LOG.md` and `READ_MATERIALS_LOG.md`.
- **Missing materials affecting confidence.** The figure-generation script named on PDF p. 10 was not in the packet. The manuscript states that it has not yet received complete independent human verification; no such human verification record was supplied. Neither absence prevents a mathematical first-pass review, but both remain relevant to final release readiness.

## 2. Overall judgment

The paper's real contribution is narrower and more interesting than a generic claim that the usual nuisance-product remainder is incomplete. It proves, for one carefully frozen bounded PLM experiment and one exact public-pair minimax order, that separating approximation from stochastic budgets creates two directional hard mechanisms:

`O = t(a∧t)` and `P = s(b∧s)`.

These terms are not a cosmetic refinement. On the legal O and P rays, they change the nuisance lower-bound order from `r^3` to `r^2`. The paper then closes the corresponding TAME-derived two-branch upper architecture under a measurable public interface, embeds the inherited `q`, `ab`, and `M` lower mechanisms, and proves an independent envelope-saturation identification theorem.

My initial reaction after the main text was skeptical for three reasons. First, the lower bound uses different public class pairs for different terms. Second, the P and O witnesses looked as though they might be two notational views of one product construction. Third, the exact saturation statement looked vulnerable to an illicit continuation of an interior constant. The appendices substantially changed that impression. Appendix G uses only a maximum of valid lower bounds on the same outer-supremum scalar; it does not add Bayes risks. The P and O raw laws have different common-reference cancellations and different public dictionaries. Appendix H proves saturation from support geometry and a direct moment identity. Those three attacks failed.

I did not find a confirmed FATAL or MAJOR correctness problem. The upper proof is long, but its most dangerous transitions are exposed rather than hidden: the joint-class localization precedes fitted substitution; the O branch enforces exact normalization; the R calibration uses two samples with the relevant sigma-fields separated; the amplified `d/r` terms survive into the all-`z` integration; and the fixed-pair rule is constructed before the law supremum.

The main reservation is significance/positioning, not correctness. The theorem assumes constant conditional treatment-residual variance, fixed shared envelopes, known declared budgets, countably represented public classes, and pair-specific arbitrary Borel decision rules. It makes no adaptive or computational claim. These are legitimate theoretical choices and are disclosed, but they limit immediate use and prevent me from reading the result as the full general answer to every version of the COLT open problem. In addition, the closest PLM-specific binary-treatment lower bounds deserve an explicit theorem-level comparison.

**Recommendation posture:** Weak Accept, corresponding to 6/10 on a conventional ICLR-style scale. This is a reviewer recommendation, not an editorial decision.

**Confidence:** 4/5.

## 3. Strongest contributions

1. **The directional lower mechanisms are substantive.** The O and P rays produce an unbounded separation from the inherited `AB+M` lower envelope. This is a rate-order result, not a constant-factor improvement (PDF p. 3, Figure 1 and Theorem 1; pp. 21-25, Appendices C-D).

2. **The quantifier discipline is unusually strong.** The paper explicitly separates public inputs, proof-only comparators, latent hard labels, and pair-specific rules. The lower assembly in Appendix G matches the printed `sup_Gamma inf_delta sup_P` order (PDF p. 2, equation (4); p. 29, (G.1)-(G.3)).

3. **The lower constructions are finite and auditable.** Each witness specifies raw atom masses, positivity, exact conditional residual variance, target separation, public approximation/stochastic budgets, a common reference, Gram entries, mixture distance, and small-`n` closure. I independently recomputed these properties; the checks passed.

4. **The upper proof closes access and measurability rather than assuming them.** Countable representations, first-within-tolerance empirical minimizers, a rational chart of the normalization hyperplane, and finite-dimensional Borel selections make the pair-specific decision rule legal under M1 (PDF pp. 11-19, Appendix B).

5. **The saturation boundary is a clean identification result.** At `v_-=B0^2`, boundedness forces `u=±B0` conditionally, which in turn forces `pi_0=0`; the target becomes the sample moment `E[TY]/B0^2` and the rate is parametric (PDF p. 30, (H.1)-(H.6)).

6. **Positioning honesty is above average.** The paper does not claim a new generic editor, a new TAME upper architecture, new `ab`/`M` ancestry, efficient computation, unknown-budget adaptation, empirical superiority, confidence intervals, or causality.

## 4. Major concerns

**None confirmed.**

I considered elevating the lower assembly, P/O model membership, upper fitted-index measurability, and saturation boundary to Major Concern. Each survived the targeted checks described below. I do not use this section to relabel scope or citation-comparison reservations as technical failures.

## 5. Detailed findings

### DF-01: Four-budget lower assembly — SURVIVED ATTACK

- **Locator:** PDF p. 2, equation (4); p. 29, Appendix G, equations (G.1)-(G.3).
- **Attack:** Different hard public pairs cannot generally have their Bayes risks added. If the proof had silently changed the minimax order or summed the component risks, Theorem 1 would fail.
- **First potential failure step:** The passage from five component lower bounds to a lower bound for their sum.
- **Resolution:** For each fixed component pair `Gamma_j`, the outer supremum dominates that pair's minimax risk. Therefore the common scalar risk dominates the maximum of the five component lower bounds. The proof then uses only deterministic `max >= sum/5` and `S0 <= X <= 2S0`. No samples, priors, or Bayes risks are added across pairs.
- **Impact:** The claimed lower assembly is valid for the printed Q1 order. It would not automatically transfer to a pair-independent `inf_delta sup_{Gamma,P}` order, and the paper says so.

### DF-02: P/O finite experiments — SURVIVED ATTACK

- **Locator:** P: PDF pp. 21-23, (C.10)-(C.21). O: pp. 23-25, (D.1)-(D.15).
- **Attack:** I tried to break the constructions through negative atom masses, a changed residual variance, a failed PLM conditional mean, a public class that leaked the latent label, an approximation/stochastic budget violation, nonmatching sign-averaged references, or a Gram-energy bound too weak for the exponential dictionary.
- **Resolution:** The three-point treatment channel preserves the declared conditional variance. In P, the propensity sign flip is compensated by `kappa=gamma+Delta eta`; in O, the propensity is common and `Delta(v_-+gamma^2)=gamma eta`. The sign-averaged references agree atomwise. Public dictionaries are fixed before the latent coordinate/sign/label. Amplitude rescaling by `lambda_rho` enforces both `B_G` and `c_rad` constraints.
- **Independent check:** 100,000 randomized mechanism/selector checks and 3,840 explicit zero/tie/boundary checks recomputed normalization, positivity, moments, common references, and the stated Gram-energy inequalities; all passed.
- **Impact:** I found no basis to remove O or P from the rate.

### DF-03: Upper measurable selector — SURVIVED ATTACK

- **Locator:** PDF pp. 11-19, Appendix B, especially (B.8)-(B.9), (B.10)-(B.20), (B.21)-(B.30), and (B.31)-(B.33).
- **Attack:** The high-risk possibilities were a random fitted index inserted into a pointwise concentration event, an O optimizer that failed exact normalization, R-branch leakage of D1 treatments into the calibration fit, an uncontrolled denominator, or loss of the amplified `d/r` terms during expectation integration.
- **Resolution:** The empirical-process events are uniform over countable difference classes before fitted substitution. The O functional is finite only on `P_1(Ta)=1`, and the rational chart lies exactly on that hyperplane. The R edit uses D2 outcomes and D1 covariates while D1 treatments remain centered after conditioning. The denominator is controlled empirically. Equations (B.18) and (B.29) retain the amplified terms, and the layer-cake calculation integrates each monomial separately.
- **Residual uncertainty:** I did not formalize the entire Appendix B in a proof assistant. I checked the dependency chain and recalculated the dangerous algebraic transitions; no counterexample or missing assumption was found.

### DF-04: Selector algebra and unsafe fallback — SURVIVED ATTACK

- **Locator:** PDF p. 19, (B.31)-(B.33).
- **Attack:** Search for a budget tuple in `[0,1]^4` violating `V<=W<=4V`, `X/5<=V<=6X`, or `T_selected<=48X`; separately test zero budgets and ties.
- **Resolution:** One million preliminary random tuples and the later 100,000/3,840 mechanism suites found no violation. The unsafe-cell implication also checks out: if the radius floor is not already absorbed by `q`, branch unsafety forces either `M`, O, or P above a fixed threshold.
- **Impact:** The public branch selection correctly converts the inherited branch minimum into the stated rate up to constants.

### DF-05: Empty/interior/saturation theorem — SURVIVED ATTACK

- **Locator:** PDF p. 3, Theorem 1; p. 30, Appendix H.
- **Attack:** Attempt to construct a saturation law with nonzero propensity or continue the interior lower family to equality.
- **Resolution:** `|u|<=B0` and `E[u^2|X]=B0^2` force `u^2=B0^2` almost surely. Conditional centering forces equal signs. Requiring both `pi_0(X)+B0` and `pi_0(X)-B0` to lie in `[-B0,B0]` forces `pi_0=0`. The lower-family slack `B0-sqrt(v_-)` genuinely vanishes at equality, so the boundary must be proved separately.
- **Impact:** The boundary phase change is correct in the stated shared-envelope model.

### ISSUE-NOV-01: Closest PLM lower-bound comparison is incomplete — MODERATE

- **Locator:** PDF p. 9, Table 5 and Section 11, especially the sentence citing Jin-Syrgkanis and Jin-Mackey-Syrgkanis as adjacent ancestors.
- **Evidence:** Jin et al. (2025), Theorem B.1, gives a PLM-coefficient lower bound under binary treatment and anchored nuisance neighborhoods. Jin-Syrgkanis (2026), Theorem 7.5, gives a PLM-restricted mixed-bias product lower bound for expected conditional covariance and explicitly points back to Jin et al. Theorem B.1.
- **Assessment:** These sources do not visibly contain the manuscript's four public budgets, constant fixed variance, M1/Q1 access, or both O/P terms. I therefore did not find a collision. However, the paper should explain this at theorem level rather than leave the reader to infer it from a generic adjacent-work sentence.
- **Effect:** Novelty confidence is qualified, not defeated.

### ISSUE-SCOPE-01: Strong theorem, restricted scientific reach — MODERATE

- **Locator:** PDF pp. 2-3, Section 2 and Theorem 1; p. 9, Section 11; pp. 30-31, Appendices I-J.
- **Evidence:** The rule knows `(a,s,b,t)` and the represented class pair, may be tailored to each pair, and need only be Borel. The law has constant conditional residual variance and shared bounded envelopes. No computational, adaptive, confidence-interval, pair-independent, heteroskedastic, or causal theorem is claimed.
- **Assessment:** This is not a hidden assumption or correctness defect; the paper is candid. It does limit immediate implications and means the result should not be advertised as a universal solution to black-box PLM estimation.
- **Effect:** This is the main reason for Weak Accept rather than a stronger score.

### ISSUE-DEF-01: Covariate law in Walsh constructions is implicit — MINOR

- **Locator:** PDF p. 21, Appendix C.4; p. 23, Appendix D; p. 25, Appendix E; p. 27, Appendix F.
- **Concern:** The appendices choose Walsh characters on a finite dyadic cube and immediately use mean zero, unit norm, and orthogonality, but they do not explicitly say that `P_X` is uniform/Haar on that cube or state the cube size.
- **Effect:** Local repair only. Declaring a sufficiently large finite dyadic group with uniform law makes the construction complete.

### ISSUE-REPRO-01: Figure script not supplied — MINOR / NOT ASSESSABLE

- **Locator:** PDF p. 10, Reproducibility Statement.
- **Concern:** `figures/+generate_theory_summary.py` was named but not included in the packet.
- **Effect:** No theorem impact. The rendered figure is visually correct relative to the displayed formulas, but exact source-level reproduction remains unverified.

## 6. Survived attacks

The dedicated list is returned in `SURVIVED_ATTACKS.md`. The most consequential survived attacks are:

- Q1 max-not-sum lower assembly;
- P and O raw-law legality, common-reference equality, public-budget certificates, and observation-distance control;
- `ab` and `M` independence from O/P;
- O exact normalization and R two-sample calibration;
- selector/fallback algebra at zero budgets, ties, and large-radius cells;
- saturation propensity identification;
- TAME and Gu-Yin-Cai-Fan ancestry claims;
- readability and rendering across all 33 pages.

I attempted these attacks specifically. They are not generic statements that the manuscript looked plausible.

## 7. Prior-work and novelty assessment

The public-source check supports the manuscript's central ancestry claims:

- TAME Corollary 3.2, equation (3.7), contains the two-branch upper remainder that maps to `T_mu∧T_pi`. The manuscript correctly declines novelty credit for that architecture.
- Gu-Yin-Cai-Fan Theorem A.1 contains the `q+AB+M` lower envelope. It does not display O/P.
- The COLT 2025 open problem asks for a matching four-budget law, but in a broader/different formulation. The present theorem answers a narrowed, carefully frozen version.
- Jin et al. (2025) and Jin-Syrgkanis (2026) are closer PLM lower-bound ancestors than the current prose makes clear, but their models and nuisance parameterizations do not visibly imply the submitted O/P certificates.

After removing inherited components, the new contribution that remains is: two native directional lower mechanisms, their matching assembly with the inherited upper envelope in one exact model, and the model-boundary identification result. That is a genuine theoretical increment. I cannot establish priority from a scoped search of very recent 2026 literature, and I do not treat search non-hit as proof of novelty.

## 8. Broader significance assessment

| Axis | Assessment | Reason |
|---|---|---|
| Correctness | High | No confirmed fatal/major failure after targeted proof and construction checks. |
| Originality | Medium-high | O/P necessity in this exact model appears new; upper architecture and `q+AB+M` ancestry are inherited. |
| Technical depth | High | Measurable upper closure, finite mixture lower certificates, all-budget closure, and explicit constants. |
| Scientific importance | Medium-high within theory | Resolves the rate geometry of a meaningful structure-agnostic PLM experiment. |
| Conceptual insight | High | Approximation direction and stochastic resolution cannot always be collapsed into one nuisance error per learner. |
| Broad relevance | Medium | Semiparametric and causal-ML theory communities will care; the exact interface is specialized. |
| Interdisciplinary interest | Medium-low | The theorem is primarily for theory readers; practical or scientific-domain consequences are not yet demonstrated. |
| Immediate implications | Medium-low | No adaptive, computable, or empirical procedure is established. |
| Long-term implications | Medium-high | The directional-budget viewpoint could guide sharper black-box functional-estimation theory beyond PLM. |
| Reproducibility | High for mathematics | Proofs are self-contained; figure script availability is unverified. |
| Readability | High for a technical proof paper | Dense but well indexed and visually clean. |
| Positioning honesty | High, with one gap | Inheritance and nonclaims are explicit; closest PLM lower bounds need a sharper comparison. |

Even if completely correct, the reason this work merits serious top-conference consideration is not the boundary theorem alone and not a new estimator architecture. It is the exact identification of two missing directional minimax mechanisms and the proof that they change rates by unbounded factors. The readers most likely to change their understanding are researchers working on semiparametric minimax theory, black-box nuisance learning, debiasing/calibration, and information-theoretic lower bounds. The broader audience will not yet change practice because the theorem does not solve unknown-budget adaptation or computation.

## 9. Minor issues

1. Explicitly declare the covariate marginal and group size for the Walsh dictionaries (`ISSUE-DEF-01`).
2. Include the named Figure 1 generation script in the final source/supplementary release (`ISSUE-REPRO-01`).

No other minor issue was material enough to report. I do not count stylistic preferences or the paper's dense proof-audit apparatus as defects.

## 10. Unresolved uncertainties

- Priority for O/P cannot be certified from search non-hit, especially for July-August 2026 work not yet well indexed.
- The long upper proof was not formalized in a proof assistant or checked by an independent human in this packet.
- Exact Figure 1 code reproduction was not assessable.
- The behavior of the result under heteroskedastic residual variance, unknown budgets, pair-independent estimators, efficient oracles, or confidence-interval loss remains outside the theorem.
- I cannot determine from the packet whether the manuscript's AI-assisted derivations have since received complete human verification.

None of these uncertainties is sufficient, on the evidence I have, to manufacture a Major Concern.

## 11. What would change my judgment

Evidence that would lower my assessment:

- a public theorem with the same four budgets, same fixed-variance M1/Q1 access, and the same O/P lower conclusion predating this work;
- a concrete violation of model membership, common-reference equality, Gram/TV control, or stochastic-budget certification in either directional witness;
- a counterexample to the fixed-pair upper bound showing that a fitted random index was inserted outside a uniform event or that the R calibration leaks D1 treatments;
- evidence that the outer minimax order was intended to be pair-independent, in which case the current lower assembly and upper access theorem address a different problem.

Evidence that would raise my assessment:

- an explicit theorem-level comparison resolving `ISSUE-NOV-01`;
- an extension to heteroskedastic treatment variance or to the broader original open-problem law field;
- a common computable rule with observable/unknown-budget adaptation;
- independent human verification or formal checking of the upper proof's empirical-process chain;
- a demonstration that the directional law changes the analysis of a broader class of functionals, not only this PLM experiment.

## 12. Completed forms and returned files

The returned package contains the unchanged anonymous manuscript and original instructions, plus:

- completed `EXPERTISE_CONFLICT_MODEL_DECLARATION.md`;
- completed `ICLR_STYLE_REVIEW_FORM.md`;
- completed `TECHNICAL_ISSUE_LOG.md`;
- completed `NOVELTY_AND_CITATION_LOG.md`;
- completed `RETURN_CHECKLIST.md`;
- this full raw review output;
- `ISSUES.md`;
- `SURVIVED_ATTACKS.md`;
- `UNRESOLVED_UNCERTAINTIES.md`;
- `READ_MATERIALS_LOG.md`;
- `CLAIM_DEPENDENCY_MAP.md`;
- a generated return manifest with file SHA-256 values.

The output ZIP and its SHA-256 are recorded after packaging in `OUTPUT_SHA256.txt`.

## 13. Independence statement and signature

I performed this review as one independent simulated reviewer instance. I did not read, infer, aggregate, or align with another reviewer's conclusions. I did not identify or attempt to identify the anonymous authors. I did not modify the manuscript. Uncertainty is stated where the available evidence does not justify a stronger claim.

Reviewer Ω — simulated independent top-tier expert review  
Reviewer instance ID: `OMEGA-C3-58D43AEFE018`  
Provider/model: OpenAI Codex, GPT-5 family; exact build not exposed  
Session ID: Not exposed to this review instance  
Date/time/timezone: 2026-08-25 13:37:07 UTC+08:00 (Asia/Shanghai)
