# Unresolved uncertainties

1. **Novelty priority.** The scoped public-source search found no direct four-budget O/P collision, but very recent 2026 work may be incompletely indexed. A search non-hit is not novelty evidence.
2. **Closest PLM lower bounds.** Jin et al. (2025), Theorem B.1, and Jin-Syrgkanis (2026), Theorem 7.5, are not mapped explicitly to the manuscript's nuisance coordinates and access model. I infer that they do not imply O/P here, but the authors should supply the exact differential.
3. **Upper-proof formal verification.** The 33-page manuscript was fully read and the high-risk transitions were checked, but Appendix B was not encoded in a proof assistant and no independent human proof audit was available.
4. **Figure code.** The script named on PDF p. 10 was absent, so exact code-level reproduction of Figure 1 was not assessable.
5. **Human verification.** The manuscript states that complete independent human verification has not yet occurred. The packet did not establish whether that status has changed.
6. **Out-of-scope regimes.** Heteroskedastic treatment variance, unknown budgets, one rule shared across public pairs, computational efficiency, confidence intervals, causal identification, and uniform interior-to-saturation constants remain open by design.

I do not have enough evidence to upgrade any of these uncertainties to a Major Concern.
