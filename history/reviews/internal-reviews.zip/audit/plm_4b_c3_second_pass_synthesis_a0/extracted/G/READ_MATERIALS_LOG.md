# Materials actually read

## Supplied package

Read in full before the manuscript:

- `README.md`
- `GENERAL_REVIEW_INSTRUCTIONS.md`
- `AI_OR_HUMAN_REVIEW_NOTICE.md`
- blank `EXPERTISE_CONFLICT_MODEL_DECLARATION.md`
- blank `ICLR_STYLE_REVIEW_FORM.md`
- blank `TECHNICAL_ISSUE_LOG.md`
- blank `NOVELTY_AND_CITATION_LOG.md`
- blank `RETURN_CHECKLIST.md`
- `MANUSCRIPT_HASH.txt`
- `PACKAGE_MANIFEST.tsv`

Then read in full:

- `manuscript/anonymous_manuscript.pdf`, PDF pages 1-33, including Appendices A-K.

The manuscript was also rendered to 33 PNG pages and every rendered page was visually inspected.

## Public primary sources independently consulted

- Gu (2026), *Optimal use of a black-box learner in semiparametric estimation*, arXiv:2607.21541v1. Read abstract/history and public PDF, with focused verification of PDF p. 16, Corollary 3.2, equation (3.7). https://arxiv.org/abs/2607.21541
- Gu, Yin, Cai & Fan (2026), *Optimally taming biases in black-box models for efficient semiparametric estimation*, arXiv:2606.06368v1. Read abstract/history and public PDF, with focused verification of PDF pp. 19-20, Theorem A.1. https://arxiv.org/abs/2606.06368
- Gu (2025), *Open Problem: Structure-Agnostic Minimax Risk for Partial Linear Model*, COLT/PMLR 291. Read the complete 5-page public PDF, especially p. 4, Theorem 1/equation (9). https://proceedings.mlr.press/v291/gu25b.html
- Jin, Mackey & Syrgkanis (2025), *It's Hard to Be Normal: The Impact of Noise on Structure-Agnostic Estimation*, arXiv:2507.02275v3 / NeurIPS 2025. Read abstract and PLM lower-bound sections, with focused verification of public PDF p. 26, Theorem B.1. https://arxiv.org/abs/2507.02275
- Jin & Syrgkanis (2026), *Sharp Structure-Agnostic Lower Bounds for General Linear Functional Estimation*, arXiv:2512.17341v2. Read abstract and relevant PLM sections, especially public PDF pp. 29-30, Theorem 7.5 and Remark 7.1, plus the cited proof region. https://arxiv.org/abs/2512.17341
- Bartlett, Bousquet & Mendelson (2005), *Local Rademacher Complexities*, Annals of Statistics 33(4). Read the primary-source statement around pp. 1503-1504, Theorem 2.1, used by manuscript Lemma 4. https://www.stat.berkeley.edu/~bartlett/papers/bbm-lrc-05.pdf
- Public abstracts/pages for adjacent structure-agnostic work were searched only to test for a direct collision; no search non-hit was treated as novelty proof.

## Materials deliberately not read

- No internal audit report, reference answer, other expert opinion, completed form, project chat, correction summary, specialist packet, author-identifying source, or earlier manuscript version.
- None of those prohibited materials appeared in the supplied ZIP.
