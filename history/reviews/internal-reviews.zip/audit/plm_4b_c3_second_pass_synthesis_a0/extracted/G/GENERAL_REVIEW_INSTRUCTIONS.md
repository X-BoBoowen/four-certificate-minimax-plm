# General review instructions

Provide an independent ICLR-style review based only on the anonymous manuscript and any public sources you independently consult. Separate theorem correctness, novelty, significance, clarity, reproducibility, and assumption realism. Do not infer author intent or a desired score. A search non-hit is not novelty evidence.

For every material criticism, give a PDF page and theorem/equation/section locator, explain the consequence, and distinguish fatal correctness issues from repairable exposition. Complete the declaration, review form, technical issue log, novelty/citation log, and return checklist.
