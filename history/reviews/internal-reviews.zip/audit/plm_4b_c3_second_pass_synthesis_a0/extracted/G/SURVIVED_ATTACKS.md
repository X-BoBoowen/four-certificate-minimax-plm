# Survived-attacks log

| Attack ID | Core claim attacked | PDF locator | Attack route | Result |
|---|---|---|---|---|
| SA-01 | Five lower mechanisms combine into the full nuisance lower rate | p. 29, (G.1)-(G.3) | Tested whether different public pairs were illegitimately added or whether `sup`/`inf` was exchanged | SURVIVED ATTACK: only a maximum on the same outer-supremum scalar is used, followed by deterministic max-to-sum algebra. |
| SA-02 | P is independently necessary | pp. 21-23, (C.10)-(C.21) | Recomputed raw masses, PLM moments, exact variance, common reference, public budgets, Gram energies, and TV exponent | SURVIVED ATTACK: no violation found; numerical and algebraic checks agree. |
| SA-03 | O is independently necessary | pp. 23-25, (D.1)-(D.15) | Tried to reduce O to a relabeled P witness and recomputed the common-propensity channel | SURVIVED ATTACK: O keeps propensity common and uses a different atomwise cancellation; all certificates passed. |
| SA-04 | `ab` is not inferred from O/P | pp. 25-26, (E.1)-(E.13) | Checked that singleton public classes can carry off-class truths while stochastic complexity is zero in every declared cell | SURVIVED ATTACK: public pair is fixed and the Walsh direction remains a latent law coordinate, not side information. |
| SA-05 | `M=(s∧t)^2` is separately necessary | pp. 27-28, (F.1)-(F.15) | Checked the two stochastic budgets separately rather than assuming symmetry | SURVIVED ATTACK: both finite dictionary complexity bounds use `w<=s` and `w<=t` in the required directions. |
| SA-06 | Selector algebra matches the target rate | p. 19, (B.31)-(B.33) | Random and boundary search over `[0,1]^4`, including zeros and ties | SURVIVED ATTACK: no counterexample in 100,000 randomized and 3,840 boundary/tie mechanism suites; preliminary selector-only search also found none. |
| SA-07 | O calibration is a legal public Borel operation | pp. 15-17, (B.10)-(B.20) | Tested normalization, rational hyperplane chart, proof-only comparator use, and fitted-index uniformity | SURVIVED ATTACK: finite objective forces exact normalization and every random substitution occurs after a uniform countable supremum. |
| SA-08 | R calibration does not leak D1 treatments | pp. 17-18, (B.21)-(B.30) | Tracked the D2 outcomes/D1 covariates construction and conditioning sigma-fields | SURVIVED ATTACK: D1 treatments remain centered when required; denominator control is empirical. |
| SA-09 | Saturation identifies the propensity | p. 30, (H.1)-(H.6) | Tried a nonzero propensity at `v_-=B0^2` | SURVIVED ATTACK: support intersection forces `pi_0=0`; the moment estimator and lower subexperiment are valid. |
| SA-10 | Claimed prior-work ancestry is honest | p. 9, Section 11 | Checked TAME Corollary 3.2 (3.7) and Gu-Yin-Cai-Fan Theorem A.1 | SURVIVED ATTACK: upper architecture and `q+AB+M` lower ancestry are correctly disclosed. |
| SA-11 | Manuscript is visually readable | all pp. 1-33 | Rendered and visually inspected every page | SURVIVED ATTACK: no clipping, overlap, broken table, black glyph, or unreadable figure was found. |

The fact that a claim survived these attacks is not a formal proof certificate; it records that the specific attempted failure modes did not materialize.
