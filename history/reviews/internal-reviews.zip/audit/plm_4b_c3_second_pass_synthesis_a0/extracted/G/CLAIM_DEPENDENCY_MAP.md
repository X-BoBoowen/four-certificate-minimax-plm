# Claim dependency map

## Core claim C0

**C0:** In the strict interior `0<v_-<B0^2`, the Q1/M1 public-pair minimax expected-L1 risk is `Theta_rho(q+X)`, where `X=AB+M+O+P`.

Dependencies:

- **U0: fixed-pair upper bound** for every legal represented public pair.
  - U1: bounded concentration and positive-radius localized process control (Appendix B.1).
  - U2: Borel initial propensity and joint outcome/coefficient fits with L2 error control (B.2, especially (B.7)-(B.9)).
  - U3: O branch exact normalization, adversarial calibration, tail bound, and expectation (B.3-B.4, (B.10)-(B.20)).
  - U4: R branch two-sample calibration, denominator control, tail bound, and expectation (B.5-B.6, (B.21)-(B.30)).
  - U5: public branch orientation and unsafe-cell fallback (B.7, (B.31)-(B.33)).
  - U6: one Borel rule is fixed before `sup_P`; uniformity then permits outer `sup_Gamma`.
- **L0: interior lower bound.**
  - Lq: scalar parametric subexperiment (C.3).
  - LP: propensity-approximation/outcome-resolution finite mixture (C.4-C.7).
  - LO: outcome-approximation/propensity-resolution finite mixture (Appendix D).
  - Lab: singleton-class off-class approximation-product mixture (Appendix E).
  - LM: two public stochastic dictionaries with zero approximation error (Appendix F).
  - LA: outer-pair maximum and deterministic equivalence `S0<=X<=2S0` (Appendix G).

If U3 failed, the O-safe upper cells would be unsupported. If U4 failed, the R-safe cells would be unsupported. If LP or LO failed, the corresponding directional term would have to be removed; another lower witness cannot replace it. If LA used a sum of Bayes risks rather than a maximum, C0 would fail for the stated proof.

## Boundary claims

- **CE:** If `v_->B0^2`, no legal law exists because `|u|<=B0` (Appendix H).
- **CS:** If `v_-=B0^2`, support saturation plus conditional centering forces `u=±B0` equiprobably and `pi_0=0`; then `beta_0=E[TY]/B0^2` and the rate is parametric (H.1-H.6).

CE and CS do not depend on U3/U4 or any Walsh lower family. The interior lower constants may vanish at saturation without contradicting CS.

## Novelty dependencies

- N1: TAME already supplies the two-branch upper remainder; no novelty claim for the generic architecture.
- N2: Gu-Yin-Cai-Fan Theorem A.1 already supplies `q+AB+M`; no novelty claim for those rate components.
- N3: novelty therefore rests primarily on LP/LO in this exact model, plus interface closure and the E/I/S theorem.
- N4: priority remains contingent on a complete comparison with the closest PLM lower-bound literature; search non-hit alone is insufficient.
