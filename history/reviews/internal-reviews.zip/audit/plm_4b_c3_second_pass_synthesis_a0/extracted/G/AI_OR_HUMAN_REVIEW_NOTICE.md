# AI or human review notice

This is a blind first-pass review package. Substantive review must be performed by the external reviewer or external AI instance receiving this archive.

If the reviewer is an AI system, the returned materials must disclose provider, model, version or build, review date, context-isolation conditions, exposure to any earlier manuscript version, and tools used. AI output may be recorded only as AI red-team evidence; it is not a human or independent-human audit.

Do not invent a personal name, institution, credential, signature, or human identity. Do not read another reviewer’s report. Do not use project conversations, prior reports, or non-package context. Return the completed files and the full raw output without summarization, polishing, or rewriting by another AI.

The package creator has not completed any substantive review field.
