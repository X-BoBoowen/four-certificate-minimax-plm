# Issue list

No FATAL or MAJOR issue was confirmed.

| Issue ID | Status | Severity | PDF locator | Decision relevance |
|---|---|---|---|---|
| ISSUE-NOV-01 | PLAUSIBLE ALTERNATIVE / positioning gap | MODERATE | p. 9, Table 5 and Section 11 | Closest PLM lower-bound ancestry is under-compared; no direct O/P collision was found. |
| ISSUE-SCOPE-01 | CONFIRMED LIMITATION | MODERATE | pp. 2-3; p. 9; pp. 30-31 | Restricts broad significance and immediate applicability, but not correctness. |
| ISSUE-DEF-01 | CONFIRMED LOCAL OMISSION | MINOR | pp. 21, 23, 25, 27, Appendices C-F | Uniform `P_X` on the finite dyadic cube should be explicit. |
| ISSUE-REPRO-01 | NOT ASSESSABLE | MINOR | p. 10, Reproducibility Statement | Named figure script was not in the packet; no theorem effect. |

Full evidence, consequences, and repair criteria are in `TECHNICAL_ISSUE_LOG.md` and Sections 5, 7, and 8 of `FULL_RAW_REVIEW_OUTPUT.md`.
