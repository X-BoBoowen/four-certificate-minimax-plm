# Independent general ICLR first pass

Review `manuscript/anonymous_manuscript.pdf` as a fresh, self-contained ICLR submission. Assess correctness at the level available to a general theory reviewer, novelty, significance, clarity, reproducibility, assumptions, and venue fit. Record precise PDF locators for every material issue.

Read `AI_OR_HUMAN_REVIEW_NOTICE.md` first and complete all blank files in this archive. Use a new isolated conversation and do not provide project chats, prior reviews, correction summaries, specialist packets, or another reviewer’s output. Do not use the same conversation for mathematical or source/domain roles. Preserve the provider/model declaration and return the completed files and full raw output unchanged.
