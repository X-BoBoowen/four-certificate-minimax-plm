# `ab` 与 `M` 证明归属表

## 符号含义

- `a`：outcome class 对 `mu0` 的 L2 approximation upper budget。
- `b`：propensity class 对 `pi0` 的 L2 approximation upper budget。
- `s`：outcome difference class 的 localized Rademacher stochastic budget。
- `t`：propensity difference class 的 mirror stochastic budget。
- `ab`：两个 off-class approximation budgets 的乘积，不是 `A*B` 的缩写。
- `M=(s∧t)^2`：两个 class 的共同 stochastic bottleneck。
- `A=a+s²`, `B=b+t²`；故 `AB` 展开含 `ab`，但两者不是同一个符号。

## 归属矩阵

| 组件 | 首次出现/既有来源 | 本文出现与证明位置 | 本文内部依赖 | 外部依赖 | 原创部分 | 归属分类 | verdict |
|---|---|---|---|---|---|---|---|
| `ab` rate | Gu et al. (2026) Theorem A.1 的 `AB` 已蕴含 `ab`；Balakrishnan et al. (2023/2025 v2) 为更早 product/fuzzy-mixture 技术祖先 | 主文 rate algebra §6；完整 native certificate Appendix E, PDF pp.25–27 | raw-law/model/budget membership；common-reference Gram/mixture calculation；testing reduction；all-n cap | Le Cam/fuzzy testing 与 product lower 技术；不需 BBM/TAME upper | 在 M1 bounded fixed-variance shared-envelope 中给显式 singleton public pair、统一常数和 all-n embedding | **技术性适配 + 标准方法实例化**；rate 非原创 | **PASS**；稿件明确不声称新 rate |
| `M=(s∧t)^2` rate | Gu et al. Theorem A.1 原文直接写出 `[delta_mu^stoc∧delta_pi^stoc]^2` | 主文 §6；完整 native certificate Appendix F, PDF pp.27–29 | one public M1 pair；两套 finite dictionaries 的 complexity certificates；two Gram calculations；testing/all-n closure | finite-class Rademacher bound、fuzzy testing | 保持 approximation zero、fixed variance、candidate bound 与两个独立 stochastic budgets 的本地构造 | **技术性适配**；rate 直接继承 | **PASS** |
| `q` | classical parametric lower | Appendix C/H | two-point testing/Hellinger | Le Cam | bounded fixed-variance witness | 标准方法实例化 | PASS |
| `O=t(a∧t)` | 未找到同信息结构先行 lower；TAME 有对应 upper branch | §5；Appendix D, PDF pp.23–25 | finite Walsh family；outcome off-class perturbation；propensity resolution；mixture distance | 标准 testing calculus | target-preserving directional hard family | **实质原创（检索范围内）** | CONDITIONAL PASS |
| `P=s(b∧s)` | 未找到同信息结构先行 lower；TAME 有 mirror upper | §5；Appendix C, PDF pp.19–23 | propensity sign perturbation、outcome compensation、finite class budgets、mixture distance | 标准 testing calculus | mirror directional hard family | **实质原创（检索范围内）** | CONDITIONAL PASS |
| 总 lower `q+X` | Gu lower 三项 + 本文 O/P | §6；Appendix G | `R_pair≥max_j c_j term_j`；max-to-sum；`ab+M+O+P≍AB+M+O+P` | 无新 external theorem | 在 Q1 outer scalar 中闭合 | **已有结果组合 + 标准装配**；创新来自 O/P | PASS |

## 关键判断

我没有因为 Appendix E/F 篇幅长就把 `ab/M` 判为原创。Gu et al. Theorem A.1 是直接 theorem-field 先行来源，不能只称为“灵感”。反过来，我也没有因为 O/P 使用已知 Walsh mixtures 与 testing calculus 就否定它们：新颖性在于构造了新的 hard directions，并证明它们在完整 M1 constraints 下产生旧 lower envelope 捕捉不到的 target separation。

稿件当前的归属语言经受住了核查：Introduction 和 §11 明确写明 `ab/M` rate 不新，TAME upper 不新。建议只做一个小幅加强：在 Appendix E/F 标题或第一段明确标为 “native re-proof of inherited component”，让读者不会把证明长度误认为 priority claim。

---

Reviewer S — simulated independent expert review  
Date: 2026-08-25 · Asia/Shanghai (UTC+08:00)
