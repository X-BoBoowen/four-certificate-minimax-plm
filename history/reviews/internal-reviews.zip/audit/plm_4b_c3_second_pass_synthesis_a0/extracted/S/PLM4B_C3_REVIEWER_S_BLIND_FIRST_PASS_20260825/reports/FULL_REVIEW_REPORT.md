# Reviewer S 第一次独立盲审报告

## 结论先行

我没有在这篇稿件中找到一个可直接判定主定理为假的模型矛盾、量词交换或先行工作直接碰撞。论文最可信的新贡献，是在作者明确规定的 M1/Q1 信息结构内，为四预算 partially linear model 补上两个方向性下界

`O=t(a∧t)`，`P=s(b∧s)`，

从而把 Gu–Yin–Cai–Fan 已有的 `q+AB+M` lower envelope 与 TAME 已有的 two-branch upper architecture 闭合为 `q+AB+M+O+P`。这两项在作者给出的不平衡预算射线上相对旧 lower envelope 改变阶数，因此不是常数级修饰，也不是把旧 theorem 简单换符号。

不过，论文的适用范围比标题式口号窄。估计器得到完整 public class representations 和四个数值 budget；每个 class pair 可拥有不同 decision rule；outer adversary 的 pair 可随 `n` 和 budget cell 改变；五个 lower components 也可由不同 pair 分别见证。固定条件方差与共享 `B0` envelope 又使 E/I/S 边界高度模型特定。因此我的判断是：

- 数学正确性：**CONDITIONAL PASS**，置信度 0.76；
- 文献归属：**PASS**，置信度 0.90；
- `O/P` 新颖性：**CONDITIONAL PASS**，置信度 0.82；
- ICLR 意义：**BORDERLINE**，置信度 0.74；
- 综合建议：**BORDERLINE，偏 Weak Reject / major positioning revision**。

这里的保留不是“我发现了一个反例”，而是：真实但较窄的 theorem increment，是否已经建立了足够广泛的机器学习意义。

## 我理解的论文核心

去掉作者自造的符号，核心问题是：在一个 bounded PLM 中，若 outcome regression 和 treatment regression 各自只有一个公开候选类，并分别给出“离类多远”和“类内多难学”的两个上界，那么估计低维系数 `beta0` 的最坏 expected absolute error 到底由哪几个交互项控制？

标准 DML 把每个 nuisance 压成一个 aggregate error，给出两个 aggregate errors 的乘积。Gu et al. 已说明 lower side 至少有 `AB+M`。TAME 则说明用 oriented calibration/editing 可以取得两条 remainder branches 的较小者。本文真正完成的工作，是证明当两个 learner 的 approximation 与 stochastic difficulty 不平衡时，还存在两种不可省略的交叉障碍：一边的 off-class bias 会被另一边的 stochastic resolution 截断。这就是 `O` 与 `P`。

## 第一遍阅读形成的领域直觉

1. **文献谱系位置。** 这不是一篇重新发明 orthogonality 或 DML 的论文。它位于 structure-agnostic semiparametric minimax 这条很新的支线上：Balakrishnan–Kennedy–Wasserman 的 fixed-pilot lower-bound formalization，Jin–Syrgkanis 系列对 treatment effects/linear functionals/noise structure 的 lower bounds，Gu et al. 对 approximation/stochastic budgets 的分解，以及 TAME 对 black-box nuisance bias 的定向编辑。

2. **作者声称跨越的障碍。** 障碍不是“怎样做一个更好的 PLM estimator”本身，而是“two-learner TAME upper 中的方向性项，是否真是 minimax 必要，且能否在同一精确 public-class experiment 里全局闭合”。

3. **最可能成立的贡献。** `O/P` finite Walsh-mixture certificates。它们确实针对既有 `AB+M` 不足的预算射线，且构造必须同时保持 fixed variance、boundedness、M1 membership 与观测混合难分。

4. **最可能被重新包装的部分。** TAME 的 O/R branch、按 aggregate radii 选向以及 minimum-of-two remainder；`ab`、`M` 的 rate；BBM concentration；五项由 max-to-sum 的装配。稿件对这些归属总体诚实。

5. **最不自然的设定。** 四个预算和完整 public class 都在真实分布前公开，且 risk 允许 class-pair-specific estimator。这个设定数学上清楚，但它把最关键的方向信息直接给了 selector。其次，E/I/S boundary 依赖同一 `B0` 同时界住 `T` 与 `u`，不像一般 overlap phase transition。

6. **最接近的三类工作。** （i）Gu et al. 的 four-budget PLM lower；（ii）TAME 的 two-learner upper；（iii）Balakrishnan/Jin 系列的 fixed-pilot structure-agnostic product lower 与 noise-dependent PLM lower。

7. **初始怀疑的反向检查。** 我最初认为主 rate 可能只是把 TAME Corollary 3.2 与 Gu et al. Theorem A.1 并列后做代数。但逐项比较后发现，前者只给上界，后者只给 `AB+M` lower；在 `a=t=r,b=s=0` 或镜像射线上，缺失项是 `r^2` 而旧 lower 只有 `r^3`。因此新 lower 不是从两篇原文直接推出。

## 模型、识别与量词

数据是两个独立的 `n`-sample halves，总计 `2n` 个 iid `Z=(X,T,Y)`。模型为

`T=pi0(X)+u`, `Y=beta0*T+mu0(X)+epsilon`,

并要求 `E[u|X]=0`、`E[epsilon|X,T]=0`、`E[u^2|X]=v`，其中 law-specific 的未知常数 `v∈[v_-,v_+]`。由于 `v_->0`，`beta0` 在统计 PLM 内可识别。论文没有把它误写成因果效应；若要因果解释还需额外条件。

M1 的 public instance `Gamma=(G_mu,G_pi)` 不含真实 nuisance、best approximant 或 hard label。它含完整候选类、bounded countable pointwise-dense measurable representations，以及已知 `(a,s,b,t)`。`a,b` 是 population L2 approximation upper bounds；`s,t` 是 localized Rademacher upper budgets，不是实际拟合误差，也不要求达到等号。

Q1 的量词是

`sup_{Gamma} inf_{delta_Gamma Borel} sup_{P∈P(Gamma)} E_P |delta_Gamma-beta(P)|`。

我特别核对了上下界是否偷换成 `inf_delta sup_Gamma,P`：没有。upper 先对每个 fixed legal `Gamma` 构造同一 `delta_Gamma` 并对所有 `P` 一致控制，再取 outer supremum；lower 对每一项选择一个 fixed public pair，随后对看见该 pair 的任意 estimator 做 testing lower，再由 outer supremum 合并。hard pair 不依赖 realized data 或 latent label。

这个量词的代价是：它不要求一个共同算法跨所有 class pairs；也不要求同一个 pair 跨所有 `n`/budget cells。数学定理因此成立在一个“最坏 pair 的 pair-specific minimax value”上，而不是某个固定 learner family 的完整风险曲面。作者已在文中披露，但我认为摘要与意义讨论仍应更醒目。

## 正确性审查

### 模型非空与边界

当 `0<v_-<B0^2` 时，零 nuisance/singleton class 与对称有界 residual 已足以给出 legal instances；lower constructions 通过小振幅常数把 truth、candidate、`T,Y,u,epsilon` 全部留在 envelope 内。当 `v_->B0^2` 时，`|u|≤B0` 与 `E[u^2|X]≥v_-` 冲突，所以 experiment 为空。当 `v_-=B0^2` 时，所有 compatible laws 都必须有 `|u|=B0` a.s. 且条件均值为零，从而条件上 `u=±B0` 各半；再结合 `|T|≤B0` 迫使 `pi0=0`。于是 `beta0=E[TY]/B0^2`，parametric `q` rate 合理。

这里不能说 fixed variance “WLOG”。若缩放 `T` 或 `Y`，会同时改变 `beta`、loss、`B0/BG` 与 approximation budgets。论文没有做这个错误主张。需要提醒的是，作者所谓 interior 是 `v_-` 留有 slack，而不是模型中的每一个 law 都严格低于 saturation；当 `v_+≥B0^2` 时，I stratum 仍可含 saturated laws。

### upper bound

upper 核心与 TAME 一致：在 outcome aggregate radius 较小时用 O branch 编辑 treatment-side weights，镜像时用 R branch。本文额外处理了：

- countable representations 下的 Borel approximate ERM；
- calibration hyperplane 的可测 selector；
- small-radius certificates 失败时输出有界 fallback；
- all `n` 与全部 budget boundaries；
- high-probability oracle remainder 到 expected L1；
- fixed-pair uniformity到 Q1 outer supremum。

我核对 BBM transfer、localized multiplier/square process 的使用、初始 nuisance error 的 radius bookkeeping、branch denominator normalization，以及 `W=min(T_mu,T_pi)` 与 `X` 的确定性比较，没有找到明显断裂。一个容易误读的地方是 manuscript 的 global theorem 不能直接由 TAME Corollary 3.2 引用得到，因为 TAME 需要 `delta_mu+delta_pi=o(1)` 并只给 high-probability asymptotic remainder；这里的 global fallback 与 Borel closure 必须靠本文自己的 Appendix B。稿件确实这样做了。

### lower bound

parametric witness、`ab`、`M`、`O`、`P` 五项均在本地模型中单独检查了：truth/candidate envelope、fixed variance、approximation distance、finite-class Rademacher budget、target gap 与 mixture distance。`P` construction 通过 propensity sign perturbation 与 outcome compensation 隐藏 target shift；`O` 保持 propensity side common 并将 shift 隐入 outcome off-class direction。Walsh dimension 可随 `n`/budget cell 变大，但这被 Q1 允许，且 pair 在 data 前固定。

我没有复算每个 Appendix 常数到最后一位，也没有形式化 proof assistant 证书。因此我不会把数学正确性写成无条件 PASS。就 referee-level reading 而言，没有发现 fatal gap；最值得第二位独立审稿人再算的是 O/P mixture affinity 与 all-n cap 的数值拼接，而不是主量词或 rate algebra。

## 指定文献核验

### BBM

Bartlett–Bousquet–Mendelson (2005) Theorem 2.1 的确给出 bounded class 的 one-sided localized Rademacher concentration。对中心类加入负函数、令 `alpha=1`，range 取 `[-B,B]`，可得到本文 Lemma 4 的 `4 R_n`、variance square-root 和 `8Bz/(3n)` 常数。本文写成 `2e^{-z}` 是保守合并，不是扩大 source theorem。结论：**PASS**。

### Gu et al.

arXiv:2606.06368v1 Appendix A.1 的模型与本文极接近：bounded PLM、fixed conditional variance、两个 classes、四个 approximation/stochastic budgets、`2n` data、expected L1 和 outer-class minimax。Theorem A.1 下界原文就是

`q + (a+s^2)(b+t^2) + (s∧t)^2`。

所以 `ab` 与 `M` rate 已有；本文对此归属准确。原文没有 `O/P`，上界也不 matching。结论：引用 **PASS**，先行重叠 **STRONG OVERLAP**，不构成直接 collision。

### TAME

arXiv:2607.21541v1 Algorithm 1、TAME-2 (3.6) 与 Corollary 3.2 (3.7) 已给本文两条 branch remainder 的原型。本文称其 “TAME-derived” 是准确的；如果作者声称 branch 本身为新会是错误，但当前没有这样做。本文新增的是 global expected-risk/interface closure 与 matching lower。结论：引用 **PASS**，upper 机制归属为**直接继承 + 非平凡技术适配**。

## `ab` 与 `M` 的归属

`ab` 是 outcome/propensity approximation budgets 的乘积；`M=(s∧t)^2` 是共同 stochastic bottleneck。二者都由 Gu et al. Theorem A.1 直接蕴含/写出，且 product lower 的更早技术祖先可追到 Balakrishnan et al. 与相关 fuzzy-testing 文献。

本文 Appendix E 对 `ab` 的 singleton/off-class construction，以及 Appendix F 对 `M` 的 two finite dictionaries，价值是把旧 rate 原生嵌入 M1、fixed variance、shared envelope、all-n constant bookkeeping。我的归类分别是：

- `ab`：**技术性适配 / 标准方法实例化**；
- `M`：**技术性适配**；
- 与 `q,O,P` 的装配：**已有结果组合 + 标准 reduction**；
- `O/P` certificates：**在检索范围内实质原创**。

证明长不等于贡献原创；反过来，使用 Walsh mixtures 和 Le Cam 也不使 `O/P` 自动失去价值，因为它们解决的是旧 lower 未覆盖的新方向。

## prior-work collision 判断

我从模型、target、rate、proof method、black-box access、critical radius、fixed pilot、treatment noise 与 directional calibration 多条路线检索。最接近三项是 Gu et al. Theorem A.1、TAME Corollary 3.2、Jin–Mackey–Syrgkanis 的 PLM noise lower bounds。

前两项共同把本文包围得很紧，但仍没有任何一项同时给出同一 Q1/M1 下的 `O/P` matching lower；第三项的 fixed-pilot access、binary/Gaussian noise 与 quantile risk 均不同。Balakrishnan et al. 的 ECC product lower 是技术祖先，不是同 target/input theorem。

因此我的正式结论是：**在我记录的检索范围和时间边界内，我没有找到直接 prior-work collision。** 这不是优先权证明。两篇最关键 preprints 都在 2026 年 6–7 月首次出现，审稿日为 2026-08-25，forward-citation 网络尚未成熟；匿名材料也没有可独立验证的 submission timestamp。

## 创新性与意义分项

| 维度 | 评价 | 理由 |
|---|---|---|
| 问题创新 | CONDITIONAL PASS | four-budget PLM gap 已由 Gu COLT/Gu et al. 提出；本文完成而非首提 |
| 模型创新 | BORDERLINE | M1 measurable interface 与 shared-envelope strata 新且精确，但有较强人为设计 |
| 理论创新 | PASS | `O/P` matching necessity 改变不平衡射线的 minimax 阶 |
| 技术创新 | CONDITIONAL PASS | hard perturbations 非平凡；基础 tools 和 upper architecture 继承较多 |
| 概念创新 | CONDITIONAL PASS | “approximation on one side × stochastic resolution on the other” 是清晰新解释 |
| 方法价值 | BORDERLINE | 没有新算法架构；主要是 TAME 的 rigorous global closure |
| 对 ML 社区意义 | BORDERLINE | 对 black-box learner imbalance 有启发；尚未跨出单一 PLM/Q1 interface |
| 对统计/因果社区意义 | CONDITIONAL PASS | 精确 lower bound 有价值；无新 causal identification/inference guarantee |

## 主要优点

1. 作者没有把 `ab/M`、TAME branch 或通用 testing technology 冒充为新贡献。
2. 模型、public information、Borel measurability、预算含义和 quantifier order 写得少见地清楚。
3. `O/P` 不只是符号项；有显式预算射线展示它们相对旧 lower envelope 的无界阶差。
4. upper/lower 都保持 fixed variance 和 bounded native PLM，没有用不在模型内的 Gaussian shortcut。
5. E/I/S 把 shared-envelope saturation 的识别变化单独处理，没有把 interior formula 生硬延拓到边界。

## 主要保留与作者应优先修改之处

1. **把 pair-specific quantifier 前置。** 摘要第一次写 minimax law 时就应说明它是 outer worst public-pair value，而不是每个 pair 的 matching lower。
2. **解释 public budgets 的现实来源。** 给出至少一个常用 learner family 如何验证 `(a,s,b,t)` 与 M1 representation；否则 selector 的最关键方向信息像 oracle 输入。
3. **更明确拆分 TAME inheritance。** 建议主文放一张逐项表：TAME 已有 branch/objective/remainder；本文新增 all-n expected L1、fallback、Borel、uniform fixed-pair lift。
4. **不要过度推广 boundary。** E/I/S 是 shared `B0` + fixed conditional variance 的几何，不是一般 overlap theorem。
5. **若可能，强化意义。** 最有说服力的是在同一自然 pair 上同时 lower，或 unknown-budget adaptation，或把方向性 barrier 推广到一类 orthogonal moments。

## 规定项目 verdict 总表

| 项目 | 结论 | 严重程度 | 置信度 |
|---|---|---|---|
| M1 定义域/值域/非空性 | PASS | 无 | 高 |
| PLM estimand 统计识别 | PASS | 无 | 高 |
| nuisance、independence、conditional moments | PASS | 无 | 高 |
| Q1 量词与 upper/lower 一致性 | PASS | 无技术错误；范围限制 Major | 高 |
| hard instance 是否依赖数据/label | PASS | 无 | 高 |
| model 随 `n`/budget 变化的披露 | PASS | 解释限制 Major | 高 |
| fixed variance 模型内部一致性 | PASS | 适用范围 Major | 高 |
| fixed variance 是否 WLOG | PASS（论文未作 WLOG 主张） | 无 | 高 |
| public class 信息对称性 | PASS | oracle-like limitation Major | 高 |
| public class unknown-budget adaptivity | CONDITIONAL PASS（明确不声称） | Major | 高 |
| BBM 引用 | PASS | 无 | 高 |
| Gu et al. 引用与 theorem field | PASS | 无 | 高 |
| TAME 引用与 upper 归属 | PASS | 无；需继续突出继承 | 高 |
| `ab` 归属 | PASS | 无 | 高 |
| `M` 归属 | PASS | 无 | 高 |
| `O/P` prior collision | CONDITIONAL PASS | 新文献时间窗限制 Major | 中高 |
| upper proof | CONDITIONAL PASS | 残余 proof-audit risk Major | 中高 |
| lower proof | CONDITIONAL PASS | O/P 常数需第二次独立复算 Major | 中等 |
| E/I/S boundary | PASS within model | 外推限制 Major | 高 |
| 因果/计算/实践 claims | PASS（均未越界声称） | 无 | 高 |
| ICLR significance | BORDERLINE | Major | 中高 |

没有一项被我判为已证实的技术性 FAIL。个人偏好没有升级成 FAIL。

## 最终建议

如果把这篇稿件当作一个精确的理论统计结果，我认为它有真实贡献，特别是 `O/P` necessity，而不是仅仅 theorem transfer。若只问“是否比 Gu et al. + TAME 多了数学内容”，答案是肯定的。

如果问“当前版本是否已经无疑达到 ICLR 所需的广泛意义”，我的答案是 **BORDERLINE**。它很可能更自然地落在专业理论统计/机器学习理论场域；要跨过 ICLR 门槛，作者需要把 public-budget/pair-specific experiment 与实际 learner 选择之间的联系讲得更有说服力，或给出超出单一 PLM 的方向性 barrier。

---

Reviewer S — simulated independent expert review  
Provider: OpenAI  
Model: Codex（基于 GPT-5；精确 serving variant 未暴露）  
Version/build: 未向会话暴露  
Session ID: 未向会话暴露  
Date: 2026-08-25  
Timezone: Asia/Shanghai (UTC+08:00)  
Manuscript SHA-256: `342315A80B4B6CB9701CC6A58DEF728E407A84673F426CD6FB0D0311D2E162A1`  
Input ZIP SHA-256: `F91A9F96686C445A24A5C7915C9AB04FD5F237A51D1AFB1F40587385A6E455A3`
