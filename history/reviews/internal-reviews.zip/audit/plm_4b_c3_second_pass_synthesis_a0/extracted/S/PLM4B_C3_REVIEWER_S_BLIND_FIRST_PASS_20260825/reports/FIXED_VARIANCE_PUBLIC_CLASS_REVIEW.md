# Fixed-variance / public-class 专项意见

## Fixed variance

| 检查项 | 事实重建 | 结论 |
|---|---|---|
| 已知还是未知 | estimator 知道区间 `[v_-,v_+]`，不知道 law-specific 常数 `v` | **PASS**；应称 unknown homoskedastic variance within known bounds |
| 同方差还是异方差 | `E[u²\|X]=v` a.s.，是 conditional homoskedasticity | **PASS** on definition；外推限制 Major |
| 能否 WLOG 标准化 | 不能在不改变 `beta`、loss、`B0/BG`、nuisance amplitudes 与 budget cell 的情况下简单归一化 | **PASS**；论文没有错误声称 WLOG |
| upper 用到什么 | 主要用 `v≥v_-` 控制 residualized design/denominator；固定相等比单纯 overlap 更强 | **CONDITIONAL PASS**；upper 可能可推广，但本文未证明 |
| lower 是否满足约束 | parametric、`ab`、`M`、`O/P` witnesses 均在本地 PLM 中把 conditional residual variance 固定为允许值（通常 `v_-`） | **PASS**；没有借用模型外 Gaussian law |
| upper/lower 是否同模型 | 是；二者共享 bounded PLM 与 fixed variance。TAME/Gu 只作为工具/祖先，主 lower 没有从更宽模型直接移植 | **PASS** |
| E stratum | `v_->B0²` 与 `\|u\|≤B0` 矛盾 | **PASS** |
| S stratum | `v_-=B0²` 迫使 `v=B0²`, `\|u\|=B0`；条件均值零使两点等概率；`\|T\|≤B0` 再迫使 `pi0=0` | **PASS**；rate `q` 合理 |
| 是否显著降低难度 | 是。固定 variance 排除 heteroskedastic design；S 更把 propensity 完全识别。这是 theorem domain，不是无害正规化 | **Major limitation** |
| “strict interior” | 指 lower endpoint 有 slack；不表示每个 law 都 `v<B0²` | **Minor wording issue** |

我的判断：fixed variance 不是数学漏洞，但它是结果意义的第一层边界。尤其 E/I/S 不能被宣传为一般 overlap phase transition；它来自 shared envelope geometry。

## Public class

| 检查项 | 信息时间线结论 | verdict |
|---|---|---|
| 谁选择 | Q1 outer adversary 在固定 `n,rho,budgets` 后选 legal `Gamma` | PASS |
| 何时确定 | data、inner law、latent label 之前 | PASS |
| 能否依赖真实 nuisance/P | 不能依赖事后已实现的 `P`；但 `Gamma` 定义了随后允许的 truth family | PASS |
| 能否依赖 sample | 不能 | PASS |
| 能否随 `n`/budget 变 | 能，而且 lower dictionaries 实际这样做 | PASS as disclosed；Major interpretive limitation |
| estimator 获得什么 | 完整 classes、countable representations、`rho`、四个 numerical upper budgets | PASS；oracle-like public information |
| estimator 未获得什么 | truth、best approximant、realized fit error、law、hard label | PASS |
| upper/lower 信息是否对称 | 是；lower 的任意 estimator 也看见 hard public pair 与 budgets | PASS |
| adaptivity 来源 | branch orientation 直接使用 known `a+s` 与 `b+t`；不是 unknown-difficulty adaptation | CONDITIONAL PASS；论文已 disclaimer，仍应前置 |
| 是否需要同一 rule 跨 pairs | 不需要，`delta_Gamma` 可 pair-specific | PASS for Q1；Major scope limitation |
| 是否单一 pair 同时 hard | 不要求；五个 component 可跨 pairs 合并 | PASS for Q1；不应过度解释 |
| measurable access | pointwise-dense countable representations 与 first-within-tolerance 使 ERM/calibration Borel | PASS；这是本文实在的 interface closure |
| computational access | 没有 polynomial-time 或 finite-oracle 保证 | PASS as scoped |

## 关键反事实解释

如果把 quantifier 改为 `inf_delta sup_Gamma sup_P`，则必须定义一个跨抽象 class representations 的共同 measurable algorithm；本文没有证明该风险与 Q1 相等。如果要求 fixed `Gamma` 对所有 `n` 和所有 budget cells 同时服务，lower 的 dimension/dictionary construction 也不能直接沿用。如果预算未知，当前 selector 的 branch 和 tuning 不能直接实施。

所以我认为这里的问题不是模型错误，而是作者对适用范围必须保持克制。当前正文的技术表述大体克制；标题、摘要与 venue-significance 叙事仍可更明确地把 “public-budget, pair-specific” 放到前台。

---

Reviewer S — simulated independent expert review  
Date: 2026-08-25 · Asia/Shanghai (UTC+08:00)
