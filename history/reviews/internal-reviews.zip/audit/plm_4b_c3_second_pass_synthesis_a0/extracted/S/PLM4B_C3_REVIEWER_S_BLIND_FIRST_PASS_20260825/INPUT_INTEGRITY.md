# Input integrity and blind-review boundary

| Object | SHA-256 | Status |
|---|---|---|
| Original input ZIP | `F91A9F96686C445A24A5C7915C9AB04FD5F237A51D1AFB1F40587385A6E455A3` | Recomputed unchanged on 2026-08-25 |
| Anonymous manuscript PDF | `342315A80B4B6CB9701CC6A58DEF728E407A84673F426CD6FB0D0311D2E162A1` | Matches package `MANUSCRIPT_HASH.txt`; 33 pages |

ZIP preflight found 23 entries: README/audit notice, anonymous manuscript, 10 primary-source PDFs, and 7 blank forms. No filename indicating expert M report, author internal report, reference answer, or filled table was present. Only allowed materials were opened.

The manuscript PDF was text-read in full and all 33 rendered pages were visually inspected. No visible clipping, overlap, missing page, or broken table was found. The paper itself was not edited.

---

Reviewer S — simulated independent expert review  
Date: 2026-08-25 · Asia/Shanghai (UTC+08:00)
