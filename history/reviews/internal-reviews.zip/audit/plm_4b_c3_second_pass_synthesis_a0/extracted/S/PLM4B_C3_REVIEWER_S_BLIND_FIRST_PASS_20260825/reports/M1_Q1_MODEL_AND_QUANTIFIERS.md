# M1/Q1 模型与量词重建表

## 独立重建

| 层次 | 对象 | 精确定义/量词 | 审稿判断 |
|---|---|---|---|
| 可观测空间 | `Z=(X,T,Y)∈𝒳×R×R`，`𝒳` standard Borel | 两个独立 halves，各 `n` iid；总样本量 `2n` | PASS；标准 Borel 足以支持普通条件期望与 Borel rule |
| 潜变量 | `u=T-pi0(X)`，`epsilon=Y-beta0*T-mu0(X)` | 不可观测；只通过 conditional moments 约束 | PASS |
| DGP | `T=pi0(X)+u`, `Y=beta0*T+mu0(X)+epsilon` | `E[u\|X]=0`, `E[epsilon\|X,T]=0`, `E[u²\|X]=v` a.s. | PASS；是 conditional-mean PLM，不是潜在结果模型 |
| estimand | `beta(P)=beta0` | 对每个 compatible `P` 唯一；`v_->0` 排除无变异 treatment residual | PASS；统计识别成立 |
| nuisance | `mu0:𝒳→R`, `pi0:𝒳→R` | law-specific unknown measurable functions | PASS |
| fixed regularity tuple | `rho=(B0,BG,v_-,v_+,c_rad)` | 在 theorem 外先固定；常数可依赖 `rho` | PASS；不是 uniform-in-rho theorem |
| bounded parameter space | 变量、target、nuisance、residual 均由 `B0` 界；public candidates 由 `BG` 界 | 同一 `B0` 同时界 `T` 与 `u` | CONDITIONAL PASS；内部一致，但使 variance boundary 模型特定 |
| M1 public instance | `Gamma=(G_mu,G_pi)` 加两套 countable pointwise-dense measurable representations | `Gamma` 在 data 与 `P` 之前公开；representation 可用于 Borel selection | PASS；是 Gu/TAME class access 的 measurable refinement，不是与其形式上等价的 theorem |
| approximation budgets | `inf_{g∈G_mu}\|\|g-mu0\|\|_{L2(PX)}≤a`；mirror `≤b` | 对 compatible `P` 的 truth 约束；`a,b` 是公开 upper bounds | PASS；不要求等号，不提供 best approximant |
| stochastic budgets | 对 difference class，在所有 `r≥s`（mirror `r≥t`）满足 localized population Rademacher upper inequality | `s,t` 是公开 class-complexity upper bounds；不是 realized ERM error | PASS；`c_rad>0` 是实质参数 |
| compatible law family | `P(Gamma)` | 在同一 law 内同时满足 PLM、moments、fixed variance、boundedness 与 approximation conditions | PASS；lower constructions逐项给 membership |
| legal public-pair envelope | `G_{rho,n}(a,s,b,t)` | 先固定 `n,rho,budgets`，再纳入所有 legal/nonempty `Gamma`；可随 `n` 与 cell 改变 | PASS mathematically；scope limitation |
| rule | `delta_Gamma:Z^{2n}→R` Borel | rule 可使用 data、`Gamma,rho,a,s,b,t`；不可使用 `P`、truth、best approximant、hard label | PASS |
| loss/risk | `E_P\|delta_Gamma-beta(P)\|` | expected L1；不是 squared loss、high-probability radius 或 CI coverage | PASS |
| Q1 | `R_pair=sup_Gamma inf_{delta_Gamma} sup_{P∈P(Gamma)} E_P\|delta_Gamma-beta(P)\|` | `Gamma` 先于 rule 的 `inf`，但 rule 有下标 `Gamma`；`P` 最后 adversarial | PASS；最关键解释是 pair-specific minimax value |
| upper | `∀Gamma ∃explicit delta_Gamma ∀P∈P(Gamma)` | constant uniform in fixed legal `Gamma`；再取 `sup_Gamma` | PASS；无 quantifier exchange |
| lower | 对每个 component `j`，`∃Gamma_j` 使 `inf_delta sup_{P∈P(Gamma_j)}` 大 | `Gamma_j` 可因 component、`n`、budget cell 不同；每个都在 estimator/data 前固定 | PASS for Q1；不是 single-pair joint lower |
| public class 与 truth 时间关系 | `Gamma` 先，`P` 后 | 不能说 class “依赖已实现的真实 P”；但 outer adversary 可先选一个 class，再在它允许的 truth family 内选 `P` | PASS；class 本身仍提供结构信息 |
| model 随 `n` | covariate dimension、finite dictionaries、class pair 可随 `n` | theorem 的对象是每个 `(n,budget cell)` 的最坏 legal pair | PASS as disclosed；不应外推为 fixed learner sequence 的自动结论 |

## 信息时间线

| 时间 | 由谁决定 | 已知给 estimator | 仍未知 |
|---|---|---|---|
| 0 | theorem 固定 | `n,rho=(B0,BG,v_-,v_+,c_rad)`、budget cell `(a,s,b,t)` | public pair、truth、law、sample |
| 1 | outer adversary 选 legal `Gamma` | 完整 `G_mu,G_pi` 及 representations；所有前述 public inputs | `P,mu0,pi0,beta0,v`、sample、hard label |
| 2 | decision problem 允许为该 `Gamma` 选 Borel `delta_Gamma` | 可把 `Gamma` 作为代码/规则的一部分 | 真实 `P` 与 nuisance |
| 3 | inner adversary 选 `P∈P(Gamma)` | estimator 不获知选择 | truth、law parameters |
| 4 | 从 `P` 采样 `Z_1,…,Z_{2n}` | observed sample | latent residuals/label |
| 5 | estimator 输出并计 expected L1 | data + public inputs | 不能事后改变 class/rule |

## 与相近模型的关系

| 比较对象 | 关系 | 是否保持 loss/risk/量词 | 结论 |
|---|---|---|---|
| Gu et al. Appendix A.1 | M1/Q1 是其 four-budget class minimax 的**收紧与 measurable lift**：bounded/fixed-variance/eL1/outer-class order 高度一致，但本文显式 regularity tuple、standard Borel representation、legal-pair envelope 与 all-n interface 更强 | 抽象量词近同；covariate域、candidate bound、measurability 细节不完全相同，因此不能写成严格等价 | STRONG OVERLAP，不是形式等价 |
| TAME-2 | 本文 upper 是 TAME branch 的**技术性 transfer + global closure** | TAME 只给小误差 high-probability remainder，不给 Q1 minimax/lower；risk 与量词不保持 | 不能把 TAME Cor. 3.2 直接当作 Theorem 1 |
| fixed-pilot black-box models | M1 是“公开 candidate class + class complexity/approximation budgets”；fixed-pilot 模型是“公开一个 pilot + truth 邻域” | estimator access、parameter space 和通常的 quantile/squared loss均不同 | analogy/partial overlap，不是 reduction |
| saturated S stratum | I 的子极限不是 S theorem 的 risk-preserving reduction | interior constants 可退化；S 通过 envelope equality 识别 `pi0=0` | 必须分开证明，论文处理正确 |

## 总体 verdict

- 定义域、值域、非空性：**PASS**（高置信度）。
- estimand 统计识别：**PASS**（高置信度）。
- upper/lower 量词合法性：**PASS**（高置信度）。
- 与 Gu/TAME 的“等价”主张：论文没有作这种过强主张，**PASS**。
- public-pair-specific risk 的自然性：**CONDITIONAL PASS**（Major scope concern，高置信度）。
- 模型随 `n`/budget cell 变化：**PASS as disclosed**；外推需限制。

---

Reviewer S — simulated independent expert review  
Date: 2026-08-25 · Asia/Shanghai (UTC+08:00)
