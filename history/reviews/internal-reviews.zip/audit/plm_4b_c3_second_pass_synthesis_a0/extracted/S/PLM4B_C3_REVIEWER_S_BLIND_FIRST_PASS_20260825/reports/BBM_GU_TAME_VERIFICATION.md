# BBM、Gu et al.、TAME 原文核验表

| 项目 | BBM | Gu et al. | TAME |
|---|---|---|---|
| 准确来源 | Peter L. Bartlett, Olivier Bousquet, Shahar Mendelson, *Local Rademacher Complexities* | Yihong Gu, Qishuo Yin, Tianxi Cai, Jianqing Fan, *Optimally taming biases in black-box models for efficient semiparametric estimation* | Yihong Gu, *Optimal use of a black-box learner in semiparametric estimation* |
| 年份/版本 | Annals of Statistics 33(4), 2005；包内 author version 2004-05-14 | arXiv:2606.06368v1, 2026-06-04 | arXiv:2607.21541v1, 2026-07-23 |
| 正式链接 | [DOI 10.1214/009053605000000282](https://doi.org/10.1214/009053605000000282)；[arXiv](https://arxiv.org/abs/math/0508275) | [arXiv v1](https://arxiv.org/abs/2606.06368v1)；[DataCite DOI](https://doi.org/10.48550/arXiv.2606.06368) | [arXiv v1](https://arxiv.org/abs/2607.21541v1)；[DataCite DOI](https://doi.org/10.48550/arXiv.2607.21541) |
| 被引用版本是否匹配 | 是 | 是；审稿日只有 v1 | 是；审稿日只有 v1 |
| 核心 locator | Theorem 2.1, journal pp.1503–1504；proof pp.1528–1530 | Appendix A.1, (A.1)–(A.2), Theorem A.1, PDF pp.19–20 | Algorithm 1；TAME-2 (3.6)；Corollary 3.2 (3.7), PDF p.16；Theorem 3.1 |
| 原文 input/access | bounded function class and Rademacher average | two public/tailored ML classes, four budgets, 2n data, estimator knows budgets | initial black-box estimates, reference class, public aggregate error bounds, two data halves |
| 原文 assumptions | range/variance bounds and measurable supremum | bounded PLM；`X` uniform cube；fixed `E[u²\|X]≡v≥1/3`；class approximation + localized complexity | bounded PLM；treatment residual nondegenerate；Cor. 3.2 requires aggregate nuisance errors `o(1)` |
| 原文 loss/quantifier | high-probability supremum inequality | expected L1；`sup_{F_mu,F_pi} inf_est sup_P` | high-probability estimator expansion/remainder；不是完整 minimax lower |
| 原文实际结论 | one-sided empirical-process concentration with tunable `alpha` | upper 为 one-sided method 与 DML 较小；lower 为 `q+AB+M` | one-learner matching `q+a_mu a_pi+s²`；TAME-2 upper 为两条 directional branches 的 minimum |
| 本文声称 | Lemma 4 是 BBM Theorem 2.1 的 exact transfer | `q+AB+M`、故 `ab/M` 已有 | editing/calibration、O/R branches 与 upper architecture 是 TAME-derived |
| 是否省略原文条件 | 否；本文中心化、并负类、取 `alpha=1`，概率写法更保守 | 未发现影响对比的省略；本文 M1 更形式化，covariate/envelope 常数不同 | 没有把 Cor. 3.2 的 asymptotic scope 偷换成 source theorem；而是自行证明 global extension |
| 归属分类 | 标准工具的准确 transfer | `q+AB+M` 是直接先行结果；本文 native proof 为技术性适配 | 核心 upper mechanism 直接继承；global measurable Q1 closure 为非平凡技术适配 |
| 最终 verdict | **PASS，高置信度** | **PASS，高置信度** | **PASS，高置信度** |

## 逐项说明

### BBM 常数核对

BBM Theorem 2.1 对 `f∈[a,b]` 给 `2(1+alpha) E R_n(F)`、variance square-root 和 `(b-a)(1/3+1/alpha)z/n`。本文对中心类加入其负类，取 `alpha=1`，并令 range 为 `[-B,B]`，恰得 Rademacher 系数 4 和 range 系数 `2B*(4/3)=8B/3`。绝对 supremum 的两侧合并给保守 `2e^{-z}`。这里没有把 expectation 换成 empirical complexity，也没有遗失 variance field。

### Gu et al. theorem-field 核对

这篇原文是本文最接近的 lower-bound predecessor，不应只作为一般 related work。其 Appendix A.1 已经同时具有：bounded PLM、fixed conditional variance、两个 function classes、两套 approximation/stochastic budgets、2n iid data、expected L1 和 outer class minimax。差异在于本文加入 standard-Borel/countable representation interface、fixed regularity tuple、native all-n constructions 与两个新 directional terms。

我认为 manuscript 对 Gu et al. 的引用是准确的，没有把 `q+AB+M` 说成自己的发现。原 PDF 的 (A.1) residual condition 抽取为 `E[epsilon Y|X,T]=0`，从模型上下文明显像排版或文本抽取异常；本文采用标准 `E[epsilon|X,T]=0`。这不改变 Theorem A.1 rate 对比，但建议作者引用时不要依赖该异常字符串。

### TAME theorem-field 核对

TAME-2 的初始 fit 和 branch selection 与本文高度同构。原文 (3.7) 在 `delta_mu≤delta_pi` 时给 `delta_mu^appr*delta_pi+delta_mu²`，镜像时给另一 branch，再取 minimum。这正是 manuscript `T_mu/T_pi` 的来源。

实质差异是：TAME Corollary 3.2 只在 aggregate nuisance errors `o(1)` 时给 high-probability remainder 加 `o(q)`；manuscript 则对任意 `[0,1]^4` budgets、所有 `n`、expected L1、unsafe cells 与 Borel interface 给统一固定-pair上界。因此我不会把 manuscript upper 称为“直接 corollary”；更准确的归属是“机制直接继承，定理接口非平凡扩展”。

---

Reviewer S — simulated independent expert review  
Verification date: 2026-08-25 · Asia/Shanghai (UTC+08:00)
