# Prior-work collision 矩阵

| Candidate | 时间状态（相对 2026-08-25） | 相同模型 | 相同 estimand | 相同 loss | 相同 input/access | 相同 variance/bounds | 相同 budget decomposition | 相同 quantifiers | 相同结论 | 分类与排除/命中理由 |
|---|---|---|---|---|---|---|---|---|---|---|
| Gu, Yin, Cai & Fan (2026), Theorem A.1 | 早于审稿日且被稿件引用；相对匿名投稿时点无法独立确认 | 高 | 是，PLM coefficient | 是，expected L1 | 高：two public/tailored classes + known budgets；M1 representation 细节较少 | 高：bounded + fixed conditional variance | 是，`a,s,b,t` | 高：outer classes, inner estimator/law | 否：lower 仅 `q+AB+M`，upper 不 matching | **STRONG OVERLAP**；是最接近 lower predecessor，但缺 `O/P` |
| Gu (2026), TAME Cor. 3.2 | 早于审稿日且被引用；投稿时点不明 | 高 | 是 | high-probability remainder，不是 expected minimax loss | 高于一般 DML，但无完整 Q1/M1 | bounded + nondegenerate；不要求本文 fixed equality | two approximation/stochastic components enter aggregate errors | 否；estimator theorem，不是 outer-pair minimax | 上界 branch 相同；无 matching lower | **STRONG OVERLAP / DIRECT UPPER ANCESTRY**；不碰撞主 theorem |
| Gu (2025), COLT open problem | 早于审稿日 | 高 | 是 | 压缩稿记法需谨慎 | 高度接近 black-box class interface | bounded，variance 条件较弱/不同 | 是 | outer minimax 精神相同 | 只给 gap/open problem 与 old lower | **STRONG OVERLAP / PROBLEM PRECURSOR** |
| Jin, Mackey & Syrgkanis (2025) | 早于审稿日 | PLM 是 | 是 | quantile risk | 否：fixed pilots + L2 neighborhoods | binary or Gaussian treatment noise；与 bounded fixed equality 不同 | 否；pilot errors，不拆 class approximation/stochastic complexity | fixed-pilot minimax | product/square noise-dependent lower；无 O/P | **PARTIAL OVERLAP** |
| Jin & Syrgkanis (2026) | 早于审稿日 | 部分；general functional 与 ECC/PLM sections | 主实例多为 ECC/linear functional；非同 `beta` | quantile risk | fixed pilots/anchored neighborhoods | problem-specific | 否 | 不同 | general product lower | **PARTIAL OVERLAP**；Remark 指回 Jin et al. 2025 |
| Balakrishnan, Kennedy & Wasserman (2023/2025) | 早于审稿日 | 否 | ECC/quadratic functionals | squared risk | fixed pilots | binary/ECC setup | 只有 pilot L2 radii | `inf sup` around pilots | product lower | **CONTEXTUAL / METHOD ANCESTRY** |
| Chernozhukov et al. (2018) DML | 早于审稿日 | 是（PLR example） | 是 | asymptotic estimation/inference | estimated nuisances, cross-fitting | general regularity | nuisance total errors，不拆四预算 | estimator theorem | product upper/orthogonality | **CONTEXTUAL**；benchmark，不是 minimax collision |
| Foster & Syrgkanis (2023) orthogonal learning | 早于审稿日 | general orthogonal loss | low-dimensional target/general | excess risk | nuisance learner + critical radius | general | approximation/stochastic learning theory | estimator/oracle theorem | higher-order nuisance impact | **CONTEXTUAL** |
| Robins et al. higher-order/fuzzy-testing line | 早于审稿日 | 否 | nonlinear causal/functionals | varies | smoothness/function-space specific | varies | 非本文四预算 | varies | product/higher-order lower technology | **CONTEXTUAL / METHOD ANCESTRY** |
| BBM (2005) | 早于审稿日 | 否 | 否 | concentration inequality | function class only | bounded functions | localized radius | high-probability process theorem | 仅支撑 Lemma 4 | **FALSE LEAD AS COLLISION / EXACT TOOL SOURCE** |

## 结论

没有候选满足“相同 PLM coefficient + expected L1 + bounded fixed conditional variance + four public approximation/stochastic class budgets + pair-specific `sup_Gamma inf_delta_Gamma sup_P` + `q+AB+M+O+P` matching lower/upper”全部字段。

正式表述：**在我记录的检索范围和时间边界内，我没有找到直接 prior-work collision。**

这不等价于“全球不存在”。核心来源均很新，且匿名稿没有独立 submission timestamp；故 `O/P` priority verdict 为 **CONDITIONAL PASS**，不是绝对认证。

---

Reviewer S — simulated independent expert review  
Search cutoff: 2026-08-25 · Asia/Shanghai (UTC+08:00)
