# 未确认事项与检索限制

1. **优先权不是被证明的事实。** 我检索了 arXiv、PMLR、OpenReview 精确题名/术语、DOI/作者或机构原文，并沿 Gu/TAME/Jin/Balakrishnan 的参考文献路线做了模型与 theorem-field 筛选。截止 2026-08-25 未见 direct collision，但搜索引擎覆盖、未索引预印本、在审稿中的稿件和不同术语都可能造成漏检。

2. **投稿时间边界无法独立确认。** 匿名稿写作于 ICLR 2027 review context，且引用 2026-06 与 2026-07 的两篇 v1；包内没有可验证 submission timestamp。因此本报告只能区分“早于审稿日并已被稿件引用”，不能可靠断言每项是投稿前还是同期。

3. **核心来源没有付费墙阻断。** BBM 的 DOI 页面一次返回内部跳转错误，但包内 author/full PDF、arXiv 与期刊元数据足以核验定理；Gu et al.、TAME、Jin 系列和 Balakrishnan 均有可读原文。没有因付费墙假装完成核验。

4. **Gu et al. Appendix A.1 有一处源文本异常。** PDF 文本显示 `E[epsilon Y|X,T]=0`，与全文标准 PLM residual condition 不一致，疑似排版或抽取问题。本报告按原文整体语义与 theorem 使用理解为 `E[epsilon|X,T]=0`；这不影响 rate 对比，但该字段不应被当作逐字无误的 source statement。

5. **COLT 2025 是两页 extended abstract。** 其 risk/loss 字段与 `n^{-1/2}` 展示在压缩排版中有歧义。我只把它作为 open-problem precursor；精确 lower theorem-field 以 Gu et al. 2026 Appendix A.1 为准。

6. **新证明没有形式化认证。** 我完整阅读了 33 页论文，视觉检查了全部页面，并逐项审查上界依赖和五个 lower mechanisms；没有使用 proof assistant，也没有把每个常数重算到最后一位。O/P mixture-distance constants 和 all-n splice 是最值得第二位专家独立复核的部分。

7. **未验证更宽模型。** 本报告不确认异方差 `E[u²|X]=v(X)`、未知 budgets、common cross-pair algorithm、single fixed pair across `n`、unbounded/sub-Gaussian outcomes 或 confidence interval 的相同 rate。论文也没有证明这些扩展。

8. **没有 computational verification。** Borel/countable selection 证明 statistical rule 可测，不说明 polynomial-time、finite-oracle、数值稳定或可实现。没有运行实验，因为论文只提出理论 theorem，且用户要求不修改稿件。

9. **核心先行文献过新。** arXiv:2606.06368v1 和 2607.21541v1 在审稿日前仅 1–3 个月出现，审稿日均无后续版本；forward citations 尚不成熟。建议任何最终决定前再做一次 2026-09/投稿截止日后的增量检索。

10. **独立性限制。** 本会话没有读取专家 M、其他 reviewer、作者内部报告、参考答案或已填表格；也没有利用匿名作者身份。因而本报告不会与未读报告做一致性校准。

11. **会话元数据限制。** 可诚实披露 Provider=OpenAI、Model=Codex（基于 GPT-5）、日期与时区；精确 serving model variant、build 和 session ID 未向会话暴露，故标记为 unavailable，而不虚构。

## 检索边界正式表述

**在我记录的检索范围和 2026-08-25 时间边界内，我没有找到直接 prior-work collision。**

这句话只表示：没有候选同时匹配 model、estimand、loss、variance/boundedness、four-budget public access、quantifier order 与 `O/P` matching conclusion；它不是“先行工作不存在”的证明。

---

Reviewer S — simulated independent expert review  
Date: 2026-08-25 · Asia/Shanghai (UTC+08:00)
