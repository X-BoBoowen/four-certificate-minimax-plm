# 经受住审查的主张清单

以下是我在模型重建、原始文献核验、证明路线抽查与反向 prior search 后仍认为站得住的主张。`CONDITIONAL PASS` 表示没有找到反例，但存在明确的范围或检索限制。

| 主张 | 状态 | 经受住审查的理由 | 边界 |
|---|---|---|---|
| bounded PLM 中 `beta0` 在 `v_->0` 下可作为统计系数识别 | PASS | residualized treatment 有正二阶矩，conditional mean restrictions 明确 | 不是自动的 causal effect |
| M1/Q1 的 public access 与量词被完整定义 | PASS | pair、rule、law、sample 的先后顺序可展开，无暗中 `P`-dependent estimator | risk 是 pair-specific，不是 common-rule minimax |
| interior Q1 upper 可由 public four-cell rule 达到 `q+X` | CONDITIONAL PASS | TAME branch、global fallback、Borel selector、expected-L1 integration 与 uniform fixed-pair lift逻辑闭合 | 长证明未形式化验证所有常数 |
| `O=t(a∧t)` 是必要 lower term | CONDITIONAL PASS | native fixed-variance Walsh-mixture witness 与不平衡射线 separation 成立；未找到同字段先行 theorem | priority 受 2026 新文献检索窗口限制 |
| `P=s(b∧s)` 是必要 mirror term | CONDITIONAL PASS | mirror construction 保持 class budgets/variance/mixture difficulty | 同上 |
| `O/P` 可相对 `AB+M` 改变阶 | PASS | 在 `(a,t)=(r,r), b=s=0` 或 mirror，old lower 为 `r^3`，missing term 为 `r^2` | 抑制 parametric `q` 后看 nuisance-dominated regime |
| Gu et al. 已给 `q+AB+M` lower | PASS | 原文 Theorem A.1 直接写出 | 不是 matching four-budget theorem |
| `ab` 与 `M` rate 不属于本文首创 | PASS | `AB` 展开含 `ab`，且 Gu 原文直接含 `M` | 本文 native embeddings 仍有技术价值 |
| TAME 已给 two-branch upper architecture | PASS | 原文 Algorithm 1、(3.6)、Cor. 3.2 (3.7) 可逐式映射 | 原文仅 asymptotic/high probability，不给本文 global Q1 theorem |
| BBM Lemma transfer 的常数与条件准确 | PASS | 负类扩张、中心化、`alpha=1` 后常数匹配 | 只是工具归属 |
| 五项 lower 可在 Q1 outer supremum 下合并 | PASS | 每项给某个 legal pair；outer scalar ≥各项；max-to-sum 合法 | 不证明同一 pair 同时 hard |
| `v_->B0²` 时 experiment 为空 | PASS | bounded `u` 的二阶矩上界直接矛盾 | 特定 shared envelope |
| `v_-=B0²` 时 propensity 被迫为零且 rate 为 `q` | PASS | equality case 迫使 `u=±B0` 条件等概率，`\|T\|≤B0` 迫使 `pi0=0` | model-specific，不是一般 overlap boundary |
| upper/lower 在同一 fixed-variance bounded model 内 | PASS | lower 没有偷偷用 unbounded Gaussian witness；upper 对同一 compatible laws | constants 非 uniform near saturation/c_rad=0 |
| 论文没有声称 unknown-budget adaptation、causal effect、CI、polynomial time 或 practical superiority | PASS | scope disclaimers 清楚 | 后续传播应保持同样克制 |
| 未发现直接 prior-work collision | CONDITIONAL PASS | exact formula、historical terms、backward/forward routes均只回到 strong/partial overlap | “未找到”不是“不存在”的证明 |

## 一句话总结

论文最重要、也最经得住审查的 residual claim 是：**当两个 black-box nuisance learners 的 approximation 与 stochastic difficulties 分开公开且高度不平衡时，TAME two-branch upper 中的两个 directional cross terms 在 Q1 worst-public-pair minimax risk 下确实是必要的。**

---

Reviewer S — simulated independent expert review  
Date: 2026-08-25 · Asia/Shanghai (UTC+08:00)
