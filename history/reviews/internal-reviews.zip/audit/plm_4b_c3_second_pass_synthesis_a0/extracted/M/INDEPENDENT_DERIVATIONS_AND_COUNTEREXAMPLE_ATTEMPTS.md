# Independent derivations and counterexample attempts

Reviewer: Reviewer M -- simulated independent expert review  
Manuscript: *Four-Budget Minimax Rates for Bounded Partially Linear Models*  
Date/time zone: 2026-08-25, Asia/Shanghai (UTC+08:00)

I started from the definitions and raw laws, not from the displayed target formula. This file records the calculations that carried the most downstream weight.

## 1. BBM Theorem 2.1 transfer

The supplied source is the May 14, 2004 manuscript of Bartlett, Bousquet, and Mendelson. I independently checked the published 2005 Annals of Statistics electronic reprint (vol. 33, no. 4, pp. 1497--1537, DOI 10.1214/009053605000000282). Published Theorem 2.1 is the cited result; its statement matches the supplied manuscript. The journal-page locator spans the discussion on p. 1503 and the theorem on p. 1504.

The source's first inequality is, for a class `F` mapping into `[a,b]`, with `Var(f(X_i))<=r`,

`sup_f (P f-P_n f) <= 2(1+alpha) E R_n(F) + sqrt(2 r x/n) + (b-a)(1/3+1/alpha)x/n`

with probability at least `1-exp(-x)`. It also holds with the empirical-process direction reversed.

The manuscript applies this only as follows:

| BBM object | Manuscript object |
|---|---|
| `F` | the countable centered class `W` enlarged by `-W` |
| `[a,b]` | `[-B,B]` |
| variance bound `r` | `sigma^2` |
| confidence `x` | `z` |
| `alpha` | `1` |
| `E R_n(F)` | `R_n(W)=E_{data,epsilon} sup_w |n^{-1}sum epsilon_i W_i(w)|` |
| one-sided supremum | the absolute supremum `Z`, because the class is symmetric |
| source probability | `1-exp(-z)`; the manuscript's `1-2exp(-z)` is weaker |

Substitution gives

`Z <= 4 R_n(W)+sqrt(2 sigma^2 z/n)+8Bz/(3n)`,

which is exactly (B.2). The transfer does not use a localization fixed point, star-shapedness, Bernstein class condition, or an empirical Rademacher estimate. Countability supplies the measurability condition that BBM states separately. I therefore classify the transfer as PASS.

## 2. Finite-shell calculation

Let `delta_z=K_1(r_0 max h_n)+sqrt(z/n)`, with the manuscript's notation `r_0 max h_n` meaning `r_0 vee h_n`. The shells are

- `H_0={f:||f||_2<=delta_z}`;
- `H_j={f:2^{j-1}delta_z<||f||_2<=min(2^j delta_z,B)}`;
- `J=ceil(log_2(B/delta_z))_+`.

The envelope covers the whole class, including the case `delta_z>=B`, when `J=0`. Put `R_j=2^j delta_z` for `j>=1` and `R_0=delta_z`. Since every `R_j>=r_0`, the assumed all-positive-radius complexity bound applies directly; no member of the class is scaled.

For a bounded centered multiplier `xi`, contraction gives a shell Rademacher mean `O((r_0+h_n)R_j)=O(delta_z R_j)`, variance `O(R_j^2)`, and centered range `O(1)`. For the square process, contraction of `u -> u^2` gives the same mean order, while `Var(f^2)<=B^2R_j^2`.

With `x_j=z+2j+log 8`, both processes and all shells have failure sum

`4 sum_{j=0}^J exp(-x_j) <= (1/2)exp(-z) sum_{j>=0}exp(-2j)<exp(-z)`.

The variance term is

`R_j sqrt(x_j/n) <= C R_j(sqrt(z/n)+sqrt(j/n)+n^{-1/2}) <= C delta_z R_j`,

and the range term is

`C x_j/n <= C(z/n+j/n+1/n) <= C delta_z^2`.

On `j>=1`, `R_j<2||f||_2`; on the inner ball, `R_0=delta_z`. This yields (B.3)--(B.4), including the maximal shell, zero declared stochastic budgets, and `n=1`.

## 3. Joint-class localization

For `j=gamma T+f(X)`, conditional centering of `u=T-pi_0(X)` gives

`||j||_2^2=v gamma^2+||gamma pi_0+f||_2^2`.

If `||j||_2<=R`, then

`|gamma|<=R/sqrt(v_-)`,

and

`||f||_2<=||gamma pi_0+f||_2+B_0|gamma|<=C_rho R`.

The scalar Rademacher direction is `O(R/sqrt(n))`, absorbed by the positive floor `C_rho h_n R`; the public difference direction is evaluated at the actual radius `C_rho R>=s`. This verifies the joint radius used before (B.9). The attempted cancellation `f=-gamma pi_0` cannot eliminate `v gamma^2`.

## 4. Independent expansion of (B.18)

Write `r=bar s`, `d=d_pi`, `u_z=sqrt(z/n)`, and `ell=sqrt(tau_n/lambda_O)`. From (B.13)--(B.14),

`||a_hat-w||_n <= C[d+u_z+(d/r)u_z+ell]`.

Starting from the five exact terms in (B.17):

1. `P_1(epsilon w)` contributes `u_z`.
2. `P_1(epsilon(a_hat-w))` contributes `d u_z+u_z^2+(d/r)u_z^2+ell u_z`.
3. `P_1((mu_0-g_mu)w)` contributes `a u_z+u_z^2`.
4. `P_1((mu_0-g_mu)(a_hat-w))` contributes
   `ad+(a+d)u_z+(ad/r)u_z+u_z^2+(d/r)u_z^2+a ell+ell u_z`.
5. Calibration of `P_1((g_mu-mu_hat)a_hat)` contributes, after expanding its conservative envelope,
   `x^2+r^2+lambda_O d^2+tau_n+C(1+x+r+d)u_z+C u_z^2`.

Collecting and padding only with nonnegative terms produces precisely the structure in (B.18):

`ad+x^2+r^2+lambda_O d^2+tau_n+ell(a+r)`

plus

`(1+a+d+x+r)u_z+(ad/r)u_z+(1+d/r)u_z^2+u_z^3+ell u_z`.

The important negative check is that there is no standalone `(d/r)u_z`, no `(d/r)u_z^3`, and no `lambda_O^{-1}u_z^2`. I first suspected such a missing term, but the independent multiplication shows that the manuscript's list is conservative and complete.

## 5. Tail integration and (B.20)

For every fixed `z` in `[1,c_2n]`, the tail statement has the form `Pr{L>K G(z)}<=K'exp(-z)`, where `G` is nondecreasing and is a linear combination of `z^{p/2}n^{-p/2}`, `p=0,1,2,3`. Nested events are unnecessary for layer cake.

- The interval below `z=1` is covered by `G(1)`.
- Each power integrates with `int_1^infinity z^{p/2}exp(-z)dz<=Gamma(1+p/2)`.
- The region above `c_2n` contributes at most `6K'exp(-c_2n)` after target clipping.
- If `c_2n<1`, then `q=n^{-1/2}>sqrt(c_2)`, so the deterministic loss bound six is absorbed into a fixed-`rho` multiple of `q`.

Thus the stochastic monomials integrate at scales

`q, (ad/r)q, q^2, d/(nr), q^3, ell q`.

Using `r>=C h_n`, `h_n^2<=2q`, `d<=K(y+r+rho_n)`, and `ell=K rho_n d/r`, each is `O_rho(q+ay+x^2)`. This gives (B.20).

## 6. Independent expansion of (B.29) and (B.30)

Let `e_pi=pi_hat-pi_0`, `r_m=m_hat-m_0`, and `D=P_1(u-e_pi)^2`. Direct substitution into the R ratio gives

`D(beta_R^raw-beta_0)=P_1[epsilon(u-e_pi)]-P_1[r_m(u-e_pi)]+beta_0[P_1(ue_pi)-P_1e_pi^2]`,

which is (B.28) and contains no O-specific object.

With `r=bar t`, `d=d_all`, `u_z=sqrt(z/n)`, and `ell=sqrt(tau_n/lambda_R)`, the norm bound is

`||r_m||_n<=C[d+r+u_z+(d/r)u_z+ell]`.

Expanding the four terms in (B.28), and decomposing `e_pi=(pi_hat-g_pi)+(g_pi-pi_0)`, yields the base

`bd+y^2+r^2+lambda_Rd^2+tau_n+ell(b+r)`

and the stochastic envelope

`(1+b+d+y+r)u_z+(bd/r)u_z+(1+d/r)u_z^2+u_z^3+ell u_z`,

exactly (B.29). The same layer-cake argument integrates these at `q,(bd/r)q,q^2,d/(nr),q^3,ell q`. The inequalities `r>=C h_n`, `d<=K(x+y+r+rho_n)`, and the R-safe order `y<x` absorb all terms into `O_rho(q+bx+y^2)`, proving (B.30).

## 7. Selector, fallback, and Q1 lift

Let

`A=a+s^2`, `B=b+t^2`, `M=(s min t)^2`, `O=t(a min t)`, `P=s(b min s)`, `X=AB+M+O+P`,

and `x=a+s`, `y=b+t`, `T_mu=ay+x^2`, `T_pi=bx+y^2`.

If `x<=y`, then `T_mu<=2xy<=2T_pi`; hence `T_selected<=2 min(T_mu,T_pi)`. The mirror holds for `y<x`. I independently verified the manuscript's auxiliary comparison

`V=min(A,xy,T_mu,T_pi)`, `V<=W<=4V`, `X/5<=V<=6X`,

both analytically and by boundary-grid/random search. Thus `T_selected<=48X`.

For an unsafe O cell with the empirical floor below its fixed threshold, `s` exceeds a fixed positive delta. If `t>=s/2`, then `M>=s^2/4`; otherwise `x<=y` forces `b>s/2`, so `P>s^2/2`. The R case is the mirror. Zero fallback therefore loses at most a fixed multiple of `q+X`.

The rule is constructed for a fixed public pair before the inner law supremum. Only after proving a constant uniform in the pair is the outer pair supremum taken. This is the correct Q1 order.

## 8. Lower-bound calculations

### 8.1 Scalar `q`

With `T=+/-sqrt(v_0)`, target labels `theta=+/-d_rho^*/sqrt(n)`, and binary response probability `1/2+theta t/B_0`, all envelopes and exact variance hold. Relative to the uniform reference, the likelihood ratio is `1+/-h`, with

`K_q=E_Q h^2=4(d_rho^*)^2v_0/(nB_0^2)<=1/(64n)`.

For `N=2n`, `(1+K_q)^N-1<1/31`, so each label is within `1/(2sqrt(31))` of the reference in TV and the cross-label TV is below `1/4`. Expected-loss testing gives the stated positive multiple of `q`.

### 8.2 Directional `P=s(b min s)`

The two labels are

`(beta,pi,mu)=(0,z eta,z gamma)` and `(Delta,-z eta,z kappa)`,

where `kappa=gamma+Delta eta` and `Delta v_0=2 eta gamma`. These identities imply simultaneously

`E_0(Y|X)=E_1(Y|X)=z gamma`,

and

`E_0(TY|X)=E_1(TY|X)=eta gamma`.

The propensity class is the singleton zero class; the outcome class publishes both amplitudes for every Walsh direction/sign, before the latent choice. The common-reference condition is

`Delta a_t t=b_t(kappa+gamma)`,

which reduces to `Delta(v_0+eta^2)=eta(kappa+gamma)` and follows from the two defining identities. The Gram energies satisfy `K_0<=s^2/225`, `K_1<=s^2/196`. With `p=ceil(exp(64Ns^2))`, the mixture chi-square is exponentially small. The target gap is

`Delta=lambda_rho m_rho s(b min s)/(512v_0)`.

The scalar splice covers `s^2<q`, `n<16`, and zero faces.

### 8.3 Directional `O=t(a min t)`

Both labels share the public propensity `z gamma`; the outcome/target pairs are `(0,z eta)` and `(Delta,0)`, with

`Delta(v_0+gamma^2)=gamma eta`.

This identity equates the two conditional `TY` moments and yields the atomwise common reference (D.8). The target gap is

`Delta=lambda_rho m_rho t(a min t)/[1024(v_0+gamma^2)]`,

bounded below by the displayed fixed-`rho` constant. The Gram bounds `K_0<t^2/9`, `K_1<t^2/256`, the exponential public dictionary, and the scalar splice give (D.15). This construction is not a variable renaming of P: it does not flip the propensity.

### 8.4 Approximation product `ab`

Both public classes are `{0}`. Walsh functions index off-class truths only. The two labels use the same algebra as the P channel with `eta=m_rho b/4`, `gamma=a/512`, producing target gap `m_rho ab/(1024v_0)`. Approximation errors are at most `b` and `a`; both stochastic complexities are identically zero. The mixture exponent uses `S=a^2+b^2`, and the scalar experiment covers `S<q` and small `n`.

### 8.5 Common stochastic `M=(s min t)^2`

Let `w=s min t`. Both truths lie in one fixed pair of public Walsh dictionaries. The outcome complexity calculation uses `w<=s`; the propensity calculation separately uses `w<=t` and `m_rho<=1/64`. Hence both declared budgets hold, not just a single budget `w`. The target gap is

`lambda_rho^2m_rho w^2/[1024(v_0+gamma^2)]`,

and the same common-reference/Gram calculation gives (F.15).

### 8.6 Maximum to sum

Each component pair is inserted separately into

`R_pair=sup_Gamma inf_delta_Gamma sup_{P in P(Gamma)} E_P|delta_Gamma-beta(P)|`.

Therefore `R_pair` is at least the maximum of the five component lower bounds. With `S_0=ab+M+O+P`,

`AB=ab+at^2+bs^2+s^2t^2`,

and, on `[0,1]^4`,

`at^2<=O`, `bs^2<=P`, `s^2t^2<=M`.

Thus `S_0<=X<=2S_0`, and `max(q,ab,M,O,P)>=(q+S_0)/5`. No incompatible priors or samples are added.

## 9. Saturation

At `v_-=B_0^2`, boundedness gives `u^2=B_0^2` conditionally almost surely. Conditional mean zero forces equal mass at `+B_0` and `-B_0`. Since both `pi_0(X)+B_0` and `pi_0(X)-B_0` must lie in `[-B_0,B_0]`, their feasible intervals intersect only at `pi_0(X)=0`.

Consequently `beta_0=E(TY)/B_0^2`. The projected empirical moment based on `2n` observations has expected absolute error at most `1/sqrt(2n)`. The binary response subexperiment with target labels `+/-3/(32sqrt(n))` has product TV below `1/2` and gives `3/(128sqrt(n))`. This is a separate endpoint proof.

## 10. Counterexample and boundary searches

I tried the following analytical boundary cases:

- all four budgets zero;
- exactly one positive budget;
- `a=t`, `b=s`, `x=y`, `s=t`;
- `n=1`, `n=15`, `n=16`;
- `s^2=q` and `t^2=q`;
- singleton public classes and exponentially large finite dictionaries;
- `v_-` approaching zero and approaching `B_0^2` from below;
- `B_G` and `c_rad` approaching zero while remaining fixed positive;
- O ray `(a,t)=(r,r), b=s=0` and P mirror ray.

The assumptions excluded the attempted falsifiers where appropriate; for example, exact saturation removes the variance slack used by the directional priors, while fixed positive `c_rad` is necessary for the public stochastic dictionaries.

As screening, I also evaluated the selector/rate inequalities on all 625 points of the grid `{0,10^-12,0.1,0.5,1}^4` and on 1,000,000 independent uniform budget points. There were no violations of (B.31)--(B.32) or (G.2). On the O/P rays, the ratio of the full nuisance rate to the inherited `AB+M` rate equals `1+r^{-1}`, numerically confirming the unbounded separation. These computations were not treated as proofs; the proofs are the analytic inequalities above.

## Verdict on the independently derived items

All required derivations above are PASS. I found no confirmed formula error, probability-direction error, illegal parameter regime, or minimax-quantifier exchange.
