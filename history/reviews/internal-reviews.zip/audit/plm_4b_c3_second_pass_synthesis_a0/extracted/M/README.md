# Independent mathematical first pass

Open `manuscript/anonymous_manuscript.pdf` and perform a fresh mathematical-correctness review using only this archive. Start from the model and theorem statements, independently follow every required implication, and record the first unsupported step whenever a chain fails.

Read `AI_OR_HUMAN_REVIEW_NOTICE.md` first. Complete all files in `forms/`. The files in `packets/` are neutral locators, not conclusions or answer keys. The included primary source is supplied only for direct verification of the cited empirical-process transfer.

Use a new isolated conversation. Do not provide project chats, prior reviews, correction summaries, or another reviewer’s output. Do not use the same conversation for a source/domain or general-review role. Preserve the provider/model declaration and return all completed files plus the full raw review output unchanged.
