# Unconfirmed items

These items are not confirmed mathematical failures and were not entered as issues.

1. **Broader novelty and citation-completeness outside the BBM transfer.** I did not independently reproduce a literature-wide priority search for the claimed novelty of the directional `O/P` terms, nor did I verify every attribution to TAME, Gu--Yin--Cai--Fan, Robins et al., or the adjacent lower-bound literature. Those claims do not serve as proof premises in the self-contained theorem argument reviewed here. Status: unconfirmed, non-mathematical-first-pass scope.

2. **A simultaneous numerical instantiation of all generic upper-proof constants.** The proof uses finitely many constants `K_i`, a small safe radius `eta`, and confidence endpoints `c_2,c_3`, all allowed to depend on fixed `rho`. I checked the direction and compatibility of the required choices and found no circular dependence, but I did not produce a single numerical tuple for them. The existence argument is sufficient for the stated up-to-constant theorem. Status: expository follow-up, not a theorem failure.

3. **Exact deployment build and session ID.** The interface did not expose these values. Status: unavailable metadata; disclosed as such.

Everything else required by the mathematical audit instructions was resolved to PASS in this first pass.
