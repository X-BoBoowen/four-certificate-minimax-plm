# M05 — Outcome-oriented upper branch

Trace the outcome-oriented branch from its data-defined rule through the empirical-process event to the deterministic error bound. Check every use of the public-class envelope, all tuning/fallback cases, and the claim for every allowed confidence parameter and sample size.
