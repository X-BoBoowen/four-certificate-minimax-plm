# M04 — Joint-class localization

Verify the construction, envelope, variance proxy, and stochastic radius of every joint class used by the upper proof. Check that localization is valid for the declared represented public classes and that no supremum silently changes its index set or quantifier order.
