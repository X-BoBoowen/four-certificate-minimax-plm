# M03 — Finite shells

Reconstruct the localized finite-shell argument: inner radius, shell index set, maximal shell, failure-probability allocation, multiplier and squared-process bounds, absorption steps, and boundary cases. Check for hidden logarithms, radius factors, star-shapedness, or unproved scaling.
