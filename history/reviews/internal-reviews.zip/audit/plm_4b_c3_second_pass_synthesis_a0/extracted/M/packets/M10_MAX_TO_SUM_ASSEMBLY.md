# M10 — Maximum-to-sum assembly

Audit the deterministic conversion from individual lower terms to the stated aggregate rate. Check whether public-pair selection, constants, regime partitions, and sample-size splices support the exact minimax quantifiers without adding incompatible experiments or allowing learner-dependent choices.
