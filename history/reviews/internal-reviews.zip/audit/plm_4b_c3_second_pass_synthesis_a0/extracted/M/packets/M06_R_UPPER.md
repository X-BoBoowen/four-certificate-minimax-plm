# M06 — Residual/propensity-oriented upper branch

Trace the second upper branch from its data-defined rule through localization, calibration, and deterministic assembly. Check every all-parameter and all-sample case, including ties and fallback behavior, and compare its quantifiers with the theorem statement.
