# M09 — Product and mixed lower families

For each product or mixed construction, verify model membership, simultaneous stochastic budgets, envelope and variance constraints, likelihood distance, and target separation. Check every regime splice and the dependence of constants on the fixed regularity tuple only.
