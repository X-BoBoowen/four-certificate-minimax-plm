# M12 — All-sample, zero-budget, and measurability boundaries

Check every `n`-dependent branch, equality splice, all-zero budget, zero-radius convention, pair-specific decision-rule measurability claim, and target/envelope boundary. Verify that small-sample witnesses and upper fallbacks preserve the same theorem field and constants.
