# M02 — Conditional independence

Locate the conditional moment-generating-function lemma and every call site. Check that independence, centering, range, and variance are all conditional on the same sigma-field wherever products of conditional expectations are used. Construct a minimal falsifier for any weaker premise that appears to be substituted.
