# M08 — Outcome-directional lower family

Check that the two hypotheses share all learner-visible inputs required by the model, satisfy the exact public budgets, have valid atom probabilities and envelopes, and yield the stated directional target gap at the claimed information distance. Verify that the construction is not a relabeling that exposes a hidden sign.
