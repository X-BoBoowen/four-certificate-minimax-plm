# M07 — Scalar and public-class lower families

Re-derive the raw probability laws, model membership, target separation, observation distance, and expected-loss reduction for the scalar and public-class hard families. Audit target range, envelopes, variances, exact budgets, all-sample splices, and strict positivity of constants.
