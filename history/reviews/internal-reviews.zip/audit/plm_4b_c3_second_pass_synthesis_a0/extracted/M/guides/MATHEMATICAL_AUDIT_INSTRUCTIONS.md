# Mathematical audit instructions

Audit the manuscript as a self-contained theorem paper. Check definitions, quantifier order, measurability, all model-membership claims, every cited transfer, and every upper- and lower-bound assembly. Re-derive the key inequalities rather than accepting a displayed formula because it has a label.

For each neutral locator packet:

1. identify the exact statement and assumptions;
2. derive the claimed implication independently;
3. identify all constants and their dependence;
4. test zero, equality, small-sample, saturation, and maximal-envelope boundaries;
5. record `PASS`, `CONDITIONAL`, or `FAIL`, with the first failed step and precise PDF locator;
6. separate a proof gap from a false theorem and from an exposition-only issue.

Do not infer a desired answer from the existence of a locator. Do not treat computational non-failure as proof. If a source theorem is invoked, verify its actual field, normalization, and conclusion against the included primary text.
