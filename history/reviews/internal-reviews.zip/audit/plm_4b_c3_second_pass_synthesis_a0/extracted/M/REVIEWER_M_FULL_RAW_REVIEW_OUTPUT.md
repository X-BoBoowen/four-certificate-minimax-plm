# Reviewer M first independent blind review

**Manuscript:** *Four-Budget Minimax Rates for Bounded Partially Linear Models*  
**Reviewer:** Reviewer M -- simulated independent expert review  
**Date/time zone:** 2026-08-25, Asia/Shanghai (UTC+08:00)  
**Review type:** AI mathematical red-team evidence; not an independent-human audit

## Overall assessment

I read the 33-page manuscript and appendices in full before deciding where to concentrate. My overall mathematical verdict is **PASS**. I did not confirm a critical, major, or minor mathematical error. In particular, I found no failure that changes Theorem 1, Proposition 2, the minimax rate, the model class, or the Q1/M1 information structure.

This is not a conclusion I reached from the manuscript's own end-to-end audit. I rebuilt the argument from the model and theorem statements, returned to the original Bartlett--Bousquet--Mendelson theorem, expanded the two upper branches independently, and recomputed each lower experiment from its raw probability masses. Several steps initially looked vulnerable--especially the random fitted substitutions in the O/R calibrations, the amplified `d/r` terms in (B.18) and (B.29), and the use of different public pairs in the lower assembly--but those attacks failed under the stated assumptions.

My confidence is **HIGH** for the model/quantifier structure, BBM transfer, selector, saturation, and the five lower mechanisms, and **MEDIUM-HIGH** for the upper-branch constant bookkeeping. The latter proof is compressed and uses generic constants, but I found its choice dependencies consistent and its monomial accounting complete.

## What I think the paper actually proves

The paper studies expected absolute error for the scalar coefficient in a bounded partially linear model when the learner is given two fixed-envelope public nuisance classes and four deterministic upper budgets: approximation/stochastic budgets `(a,s)` for the outcome class and `(b,t)` for the propensity class. Under the native order

`sup_Gamma inf_delta_Gamma sup_{P in P(Gamma)} E_P|delta_Gamma-beta(P)|`,

the strict-interior minimax rate is

`q+(a+s^2)(b+t^2)+(s min t)^2+t(a min t)+s(b min s)`, `q=n^{-1/2}`.

The mathematically distinctive part is the necessity of the two oriented terms `O=t(a min t)` and `P=s(b min s)` in the same public-pair experiment in which a two-branch calibrated selector attains the upper bound. The paper also proves a genuine boundary phase change: above the residual envelope the experiment is empty, while exact saturation identifies the propensity and leaves a parametric problem.

The main result is therefore not a generic new orthogonal estimator and not merely a product-remainder theorem. It is a carefully frozen four-budget minimax statement with pair-specific Borel rules, fixed public envelopes, expected loss, and no adaptation or computational claim.

## First-pass judgment before targeted recalculation

The most important result is Theorem 1(I), because it asserts a matching global, all-budget, all-sample characterization and carries the claimed directional separation.

The proof chain that initially looked most fragile was the upper bound, not the lower bound. Its vulnerable points were:

1. whether BBM Theorem 2.1 really yields the exact centered supremum bound used in the finite-shell argument;
2. whether the calibration events are uniform before the data-dependent fitted indices are inserted, with the correct conditional sigma-fields;
3. whether the all-`z` tail envelopes integrate without losing an unrecorded amplified term.

The lower bound looked more convincing on first reading because the paper supplies finite raw laws, exact variance, common references, and explicit all-`n` splices. My main lower-bound concern was instead logical: whether different public pairs were being illegitimately added. Reconstructing the Q1 scalar showed that the proof takes a maximum first and only then uses deterministic max-to-sum algebra, which is valid.

If I could have checked only three places, I would have chosen Lemmas 4--5, equations (B.18)--(B.30), and the C--G lower chain. Those are the earliest nodes carrying the largest number of downstream conclusions.

## Dependency structure

The upper and lower halves share only the model and the rate algebra.

- M1 representation and the positive-radius public complexity assumption feed Lemmas 4--5.
- Lemma 5 feeds the initial fits and the countable joint localization.
- Initial fits feed two independent calibration branches.
- Branch tails feed the public selector and unsafe-cell fallback.
- A fixed-pair uniform inequality then feeds the Q1 upper bound.
- Separately, finite testing tools and the exact three-point channel feed the `q`, `P`, `O`, `ab`, and `M` experiments.
- Their five scalar lower bounds feed a maximum, then deterministic equivalence, then the interior lower bound.
- The envelope equality argument feeds the saturation theorem independently.

This separation matters. A failure of one directional prior would delete its lower term; it could not be repaired by another pair or by the saturation proof.

## Detailed mathematical assessment

### 1. Model field, M1 access, and Q1 order -- PASS

**Locator:** PDF/manuscript pp. 2--4 and 11--12; equations (2)--(5), (A.0)--(A.1).

The model fixes a standard Borel covariate space, bounded observations/truths/residuals, a fixed candidate envelope `B_G`, a positive residual variance lower bound, and countably represented public classes. Approximation budgets are population `L_2(P_X)` upper bounds, while stochastic budgets control the public difference classes at every positive radius above the declared budget.

The order of play is explicit: for each public pair, a Borel decision rule may depend on the pair, the fixed tuple, and the four budgets, but not on the law or a proof-only comparator. The rule is chosen before the inner law supremum. The upper proof respects this order. Every lower family publishes one fixed pair before the label, coordinate, or sign. I found no hidden `sup/inf` exchange.

The pointwise-dense bounded representation is enough for the uses made of it. It preserves finite-sample objectives pointwise and population infima by dominated convergence; first-within-tolerance selection over countable enumerations is Borel. The theorem deliberately excludes arbitrary uncoded nonseparable classes.

### 2. BBM transfer -- PASS, confidence HIGH

**Locator:** PDF/manuscript pp. 12--13, Lemma 4 and (B.2); source Theorem 2.1.

I verified the published article, theorem number, statement, probability, range factor, and measurability convention. The archive contains the May 2004 manuscript, while the cited publication is the 2005 Annals version; the theorem statement is the same.

The mapping is exact: symmetrize the countable centered class by adjoining its negatives, set the source range to `[-B,B]`, variance to `sigma^2`, confidence to `z`, and `alpha=1`. The source gives `4R_n`, the square-root variance term, and range term `8Bz/(3n)`. The manuscript weakens `1-exp(-z)` to `1-2exp(-z)`, which is harmless. No expectation result is promoted to high probability, and no fixed-point, star-shaped, or Bernstein-class condition is silently imported.

### 3. Localized finite shells -- PASS, confidence HIGH

**Locator:** PDF/manuscript p. 13, Lemma 5 and (B.2a)--(B.4).

I reconstructed the inner ball, dyadic shells, largest shell, confidence allocation, multiplier process, square process, and boundary cases. The envelope terminates the shells, including the case in which the inner ball is already the whole class. The base floor is positive even when the declared stochastic budget is zero, so no quotient at radius zero is evaluated.

The confidence allocation `z+2j+log 8` pays for both processes and every shell with a geometric failure sum. The shellwise variance term is `O(delta_z R_j)` and the range term is `O(delta_z^2)`. For `j>=1`, `R_j<2||f||_2`; the inner ball contributes the additive `delta_z^2`. No function is scaled and no star-shapedness is needed.

I specifically tried to break the argument at the maximal shell and at `n=1`; the envelope and clipping of the shell radius close both cases.

### 4. Joint localization and initial fits -- PASS

**Locator:** PDF/manuscript pp. 14--15, (B.6)--(B.9).

The key curvature identity is

`||gamma T+f||_2^2=v gamma^2+||gamma pi_0+f||_2^2`.

Thus cancellation in the public direction cannot remove the scalar curvature. From a joint radius `R`, one obtains `|gamma|<=R/sqrt(v_-)` and `||f||_2<=C_rho R`; this controls the scalar and public Rademacher directions at a positive radius. The initial fitted index is inserted only after a countable uniform event has been constructed.

The approximate empirical minimizers and population near-best functions play different roles correctly: the former are public Borel data functions; the latter are deterministic proof witnesses whose slack is sent to zero only after the uniform inequality.

### 5. Conditional independence and random-index substitutions -- PASS

**Locator:** PDF/manuscript pp. 12, 14, 16--18; (B.1a), (B.5), (B.17), (B.21), (B.25), (B.28).

I checked every nontrivial call against the nested sigma-fields `F_2`, `F_X`, and `F_T`.

- In O, the edit is a function of D2 and D1 `(X,T)` but not D1 outcomes. Given `F_T`, the D1 outcome residuals remain conditionally independent and centered.
- The term involving `(mu_0-g_mu)u` is treated given D1 covariates, where treatment residuals are conditionally independent and centered.
- In R, the edit uses D2 outcomes and D1 covariates but not D1 treatments. Given `F_X`, the D1 treatment residuals remain conditionally independent and centered.
- Calibration inequalities are uniform over the represented difference class before `pi_hat-g_pi` or `g_mu-mu_hat` is inserted.

A minimal falsifier would arise if the R edit used D1 treatments before the `P_1(r_mu u)` bound, or if the O edit used D1 outcomes before the weighted epsilon bound. Neither occurs.

### 6. O branch, (B.18), and (B.20) -- PASS

**Locator:** PDF/manuscript pp. 15--17, (B.10)--(B.20).

The exact normalization is implemented on a Borel dense chart of `P_1(Ta)=1`. If the treatment vector is zero, the branch returns zero; that event is exponentially small because `E T^2>=v_-` and `|T|<=B_0`.

The proof comparator `a_0=u/P_1(Tu)` is feasible on the denominator event. The localized multiplier and square inequalities give the benchmark (B.12). Projection of the fitted denominator is one-Lipschitz and leaves the comparator denominator fixed, giving (B.13). Approximate objective comparison gives both the norm bound (B.14) and the calibration value (B.15); exact normalization then gives (B.16) uniformly.

I expanded all five terms in (B.17). The amplified `(d/r)w_z` in the fitted norm is multiplied by `a` and by `w_z`, producing `(ad/r)w_z` and `(d/r)w_z^2`. This is exactly what (B.18) retains. My initial suspicion of a missing standalone amplified term was not borne out.

The tail integration is also sound. It uses pointwise tail probabilities, so the confidence events need not be nested in `z`. The lower interval is covered by the `z=1` threshold, every power integrates by a Gamma moment, and clipping controls the endpoint remainder. The resulting scales are absorbed into `q+ay+x^2`, yielding (B.20).

### 7. R branch, (B.29), and (B.30) -- PASS

**Locator:** PDF/manuscript pp. 17--18, (B.21)--(B.30).

I did not infer R by symmetry. The two-sample functional compares D2 response moments with D1 covariate moments. Its event is uniform over the public difference class, and the fitted vector is Borel because the positive quadratic makes the rationally enumerated objective coercive.

The denominator identity (B.26) and a fixed confidence endpoint give `D>=v_-/2`. Direct substitution into the ratio gives the signed identity (B.28). Expanding its four terms produces the base and stochastic monomials in (B.29), including the only two amplified terms `(bd/r)w_z` and `(d/r)w_z^2`. The same independent layer-cake calculation yields (B.30).

The potentially dangerous conditioning at (B.25) is legal: D1 treatments have not been frozen by an edit using only D1 covariates and D2 data.

### 8. Selector, fallback, and Q1 lift -- PASS

**Locator:** PDF/manuscript p. 19, (B.31)--(B.33).

The selector uses only declared budgets and fixed public radii. Ties `x=y` go to O. The safe/unsafe cells are disjoint and exhaustive.

I verified the deterministic comparison `T_selected<=48X` analytically and attacked it numerically on all zero/equality boundary grid points and one million random budget points; no violation occurred. The unsafe-cell fallback is justified by a clean dichotomy: if O is oriented but unsafe, either `M` or `P` is bounded below by a fixed positive constant; R is the mirror. If the empirical floor itself is too large, `q` already pays for clipping.

Because the safe-branch constants are uniform over a fixed pair and all compatible laws, the rule is a legal competitor inside the pair-specific infimum. The outer public-pair supremum is taken only afterwards.

### 9. Scalar and P lower bounds -- PASS

**Locator:** PDF/manuscript pp. 19--23, Lemmas 6--7 and (C.5)--(C.21).

For the scalar experiment I checked the target range, response probabilities, residual envelope, exact variance, likelihood ratios, product second moment, TV conversion, and expected-loss testing constant. The singleton public pair is legal for every budget cell.

For P, the two labels flip an off-class propensity and compensate the outcome truth. I recomputed the conditional response and treatment-response moments, the atomwise common-reference identity, likelihood coefficients, Gram energies, and the finite-class complexity bound. Both labels use the same published outcome dictionary; no sign or label is learner-visible. With `p` exponential in `Ns^2`, the mixture chi-square is exponentially small and the target gap is a fixed-`rho` multiple of `s(b min s)`. The scalar splice covers the remaining sample/radius regimes.

### 10. O directional lower -- PASS

**Locator:** PDF/manuscript pp. 23--25, (D.1)--(D.15).

O uses a different channel: both labels share the same public propensity, while the outcome perturbation is removed under the shifted target. The identity `Delta(v_0+gamma^2)=gamma eta` aligns the observable `TY` moment and creates the common reference.

I checked raw atom positivity, normalization, exact variance, all envelopes, both budget types, Gram entries by both likelihood and raw-mass multiplication, mixture TV, target separation, and the all-`n` splice. The construction is not a relabeling of P inside the fixed experiment.

### 11. `ab` and `M` lower bounds -- PASS

**Locator:** PDF/manuscript pp. 25--28, (E.1)--(E.13), (F.1)--(F.15).

The `ab` witness uses singleton public classes; its Walsh functions index off-class truths only. Approximation radii are within `a,b`, and stochastic complexity is zero for all declared upper budgets. The common-reference and mixture calculations yield a target gap proportional to `ab`.

The `M` witness has both truths inside one public pair of finite dictionaries. I checked the two stochastic budgets separately. The outcome calculation uses `w<=s`; the propensity calculation uses `w<=t` and the additional fixed amplitude bound. Public knowledge of the entire dictionary does not defeat the mixture lower bound, which already takes the infimum over every Borel rule tailored to that pair.

### 12. Lower assembly -- PASS

**Locator:** PDF/manuscript p. 29, (G.1)--(G.3).

The five public pairs may differ because each independently lower-bounds the same outer-supremum scalar. The proof takes their maximum, not a sum of Bayes risks. Only after that does it use

`S_0=ab+M+O+P <= X <= 2S_0`

and `max>=sum/5`. I checked the three component inequalities `at^2<=O`, `bs^2<=P`, and `s^2t^2<=M` on the entire unit cube, including zeros and ties. The factor ten is correct.

### 13. Empty and saturation strata -- PASS

**Locator:** PDF/manuscript pp. 29--30, (H.1)--(H.6).

Above `B_0^2`, bounded residuals make the model empty. At equality, conditional second-moment equality forces `u=+/-B_0` with equal mass. Both treatment support points must remain in `[-B_0,B_0]`, forcing `pi_0=0`. The target becomes `E(TY)/B_0^2`.

I recomputed the upper moment variance and the lower Hellinger affinity. The bounds `3/(128sqrt(n))` and `1/sqrt(2n)` are correct. The proof is pairwise for the upper and needs only one legal pair for the outer lower, exactly as stated.

### 14. All-sample, zero-budget, equality, and measurability boundaries -- PASS

**Locator:** PDF/manuscript pp. 11--19, 21--30, and 31--33.

I checked `n=1`, the `n=16` splice, equalities `s^2=q` and `t^2=q`, all four zero budgets, selector ties, zero difference classes, positive-radius quotients, singleton classes, fixed-envelope rescaling, and target clipping. Every empirical optimization has an explicit Borel first-within-tolerance implementation over a countable or rational enumeration. No lower family requires a label-dependent public class.

## Required-item verdict table

The user's H1--H12 language corresponds to the package's M01--M12 locators.

| Item | Verdict | Severity | Confidence | Independent derivation | Counterexample attempted | Attack survived |
|---|---|---|---|---|---|---|
| H1/M01 model field and uniformity | PASS | N/A | HIGH | Yes | Yes | Yes |
| H2/M02 conditional independence | PASS | N/A | HIGH | Yes | Yes | Yes |
| H3/M03 finite shells | PASS | N/A | HIGH | Yes | Yes | Yes |
| H4/M04 joint localization | PASS | N/A | HIGH | Yes | Yes | Yes |
| H5/M05 O upper | PASS | N/A | MEDIUM-HIGH | Yes | Yes | Yes |
| H6/M06 R upper | PASS | N/A | MEDIUM-HIGH | Yes | Yes | Yes |
| H7/M07 q and P lower | PASS | N/A | HIGH | Yes | Yes | Yes |
| H8/M08 directional lower families | PASS | N/A | HIGH | Yes | Yes | Yes |
| H9/M09 `ab` and `M` lower | PASS | N/A | HIGH | Yes | Yes | Yes |
| H10/M10 maximum-to-sum | PASS | N/A | HIGH | Yes | Yes | Yes |
| H11/M11 saturation | PASS | N/A | HIGH | Yes | Yes | Yes |
| H12/M12 all-`n`/zero/measurability | PASS | N/A | MEDIUM-HIGH | Yes | Yes | Yes |
| BBM transfer | PASS | N/A | HIGH | Yes | Yes | Yes |
| (B.18) | PASS | N/A | MEDIUM-HIGH | Yes | Yes | Yes |
| (B.20) | PASS | N/A | MEDIUM-HIGH | Yes | Yes | Yes |
| (B.29) | PASS | N/A | MEDIUM-HIGH | Yes | Yes | Yes |
| (B.30) | PASS | N/A | MEDIUM-HIGH | Yes | Yes | Yes |
| selector | PASS | N/A | HIGH | Yes | Yes | Yes |
| tail integration | PASS | N/A | MEDIUM-HIGH | Yes | Yes | Yes |
| Q1 lift | PASS | N/A | HIGH | Yes | Yes | Yes |
| q/P/O/ab/M lower bounds | PASS | N/A | HIGH | Yes | Yes | Yes |

## Confirmed issue list

No confirmed mathematical issue. The completed issue ledger contains no fabricated concern. I considered whether the 2004-vs-2005 BBM source version and the absence of explicit numerical values for all generic `K_i` should be issues; after fairness review, I regard the first as bibliographic provenance and the second as exposition for an up-to-constants theorem, not mathematical failures.

## Fairness review

Before settling on PASS, I returned to every serious suspicion and checked four possibilities.

First, I checked whether an assumption or definition had been overlooked. The fixed candidate envelope, positive `c_rad`, standard-Borel/counted representation, known budgets, and pair-specific decision rule are all genuinely in the theorem field. Several attacks fail only because these assumptions are explicit; I have not silently generalized the theorem beyond them.

Second, I checked for symbol misreadings. In particular, `w_z=sqrt(z/n)` is distinct from the lower-bound amplitude `w`, and the manuscript's `r` in the shell proof is a squared `L_2` variance proxy only in the BBM source, not in the later branch notation. Correcting those potential misreadings removed no problem.

Third, I asked whether any missing line would require a new lemma. The tail integration and raw-mass Gram calculations are concise, but the already stated layer-cake, Gamma-moment, finite-class, and chi-square identities suffice. I do not see a need for a new substantive lemma.

Fourth, I checked whether a local repair would change a rate or parameter range. The only useful edits I would suggest are expository: identify the supplied BBM file explicitly as the 2004 manuscript while citing the final 2005 pagination, and optionally gather the finite constant-choice order in one paragraph. Neither alters a theorem, rate, model, or constant-dependence claim.

## Scientific significance and readability

The paper will primarily interest researchers in semiparametric statistics, nonparametric minimax theory, and theoretical machine learning who study structure-agnostic or black-box nuisance learning. The oriented lower mechanisms are the clearest scientific contribution: the O/P rays demonstrate an order-level failure of an aggregate product summary, not merely a constant improvement.

The paper is technically self-contained and unusually explicit about information structure, measurable access, and negative claims. The cost is density. A nonspecialist reader will understand the phase diagram and directional message from the main text, but the exact M1/Q1 distinction and the two calibration objectives require substantial empirical-process maturity. I do not treat that as a correctness defect.

I have not performed a literature-wide novelty audit. The manuscript's claims of priority beyond the mathematical result remain outside the confirmed scope of this first pass.

## Final recommendation posture

On mathematical correctness, I am supportive: the paper has survived the specified first-pass attacks, including the exact external-theorem transfer and the high-risk upper/lower nodes. I recommend an independent human line review before submission, with particular attention to the generic-constant choice order in Appendix B, because this AI review is red-team evidence rather than human certification. On the evidence available here, however, I would not request a theorem, rate, or model correction.

## Disclosure and signature

Provider: OpenAI  
Model: Codex, GPT-5-family model; exact version/build not exposed  
Session ID: not available  
Earlier-version exposure: none known  
Other reviewer reports read: none  
Output ZIP SHA-256: calculated after packaging and supplied in the companion `.sha256.txt` file and delivery message  

**Reviewer M -- simulated independent expert review**
