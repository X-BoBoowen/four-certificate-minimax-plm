# PLM-4B-C3 A0 return provenance ledger

## Controlling identities

- Candidate-C3: `paper/iclr2027_candidate_c3/main.pdf`, SHA-256 `342315A80B4B6CB9701CC6A58DEF728E407A84673F426CD6FB0D0311D2E162A1`.
- Master-R5: `paper/master_r5/main.pdf`, SHA-256 `1AF33CDF00B2A6605C0AF339A923B18E2D3799848345E785915A63DB23025FEB`.
- Frozen synthesis protocol: `strategy/plm_4b_c3_second_pass_synthesis_a0/SYNTHESIS_PROTOCOL.md`, SHA-256 `79A017156A440F09D79A45DDAA16130C7B28A1287BBEC4AF90D0411E68FCC25D`.

The external ZIPs were hashed before listing. Each byte-identical copy was placed at `intake/<role>/original_return.zip`; each copy was then extracted once into a fresh role-specific directory. External originals were not changed or deleted.

## M chain

`D0CB...6DB2` (external ZIP) -> byte-identical intake copy -> 29 safe relative entries -> `REVIEW_OUTPUT_MANIFEST.tsv` verifies 28 non-manifest members -> embedded `manuscript/anonymous_manuscript.pdf` hashes to Candidate-C3. The 28 substantive return members also byte-match the supplied raw directory. Raw temporary renderings and working scripts were not admitted to the return archive. The return manifest was generated at packaging and therefore has no raw-directory counterpart.

## S chain

`851CEC...A9E` (external ZIP) -> byte-identical intake copy -> 18 safe relative entries -> `SHA256_MANIFEST.tsv` verifies 17 non-manifest members -> `INPUT_INTEGRITY.md` identifies H3 input ZIP `F91A9F...455A3` and Candidate `342315...62A1`. The protected H3 input ZIP at `audit/handoff_c3/PLM4B_C3_AUDITOR_S_BLIND_FIRST_PASS.zip` independently hashes to `F91A9F...455A3`, and its previously authenticated extracted manuscript hashes to Candidate-C3. The S output deliberately omits a manuscript copy; identity is therefore established by this complete input-return hash chain rather than by an embedded PDF. All 18 return members byte-match the raw `deliverable` tree.

## G chain

`124EE...11AA` (external ZIP) -> byte-identical intake copy -> 18 safe relative entries -> `RETURN_PACKAGE_MANIFEST.tsv` verifies 17 non-manifest members -> embedded `manuscript/anonymous_manuscript.pdf` hashes to Candidate-C3. All 18 return members byte-match the raw `completed_package` tree. The raw review records H3 input `58D43A...B9FB` and instance `OMEGA-C3-58D43AEFE018`.

## Independence declarations and limitations

- M declares a fresh blind AI session, no earlier version or other review, OpenAI Codex GPT-5 family; exact build and session ID unavailable.
- S declares a fresh isolated AI session, no earlier version or other review, OpenAI Codex based on GPT-5; exact serving variant, build, and session ID unavailable.
- G declares a fresh blind AI session, no earlier version or other review, OpenAI Codex GPT-5 family; exact build/session unavailable; instance `OMEGA-C3-58D43AEFE018` is explicitly recorded.
- These are reviewer self-declarations plus cryptographic package evidence. They do not authenticate a human identity and do not prove semantic independence beyond the disclosed process.

## Protected-reference boundary

The two H2 closed reference ZIPs were not listed, opened, extracted, read, copied, or used. The local primary PDFs used for F3 came from the already authenticated H3 S source bundle, not an H2 reference stage.

## Immutability boundary

No Candidate-C3, Master-R5, bibliography, figure, proof, source, code, review return, or external raw directory was modified. The only script execution used a copied figure script in a new audit-temporary directory and did not overwrite any scientific artifact.
