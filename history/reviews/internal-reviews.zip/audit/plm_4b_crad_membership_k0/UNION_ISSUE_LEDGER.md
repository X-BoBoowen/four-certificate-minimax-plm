# Union Issue Ledger

Phase: `PLM-4B-CRAD-MEMBERSHIP-K0`

Only `Ω-T01` and `Ω-T02` are active. Every other entry is registered evidence outside K0 scope and must not be repaired, adjudicated away, or silently merged into this phase.

| Canonical entry | Source entries | Exact issue | Evidence status at intake | K0 status | Authorized action |
|---|---|---|---|---|---|
| Ω-T01 | Ω-T01 | P/O/M stochastic-budget certificates omit the multiplicative `c_rad` requirement; the submitted pairs are not certified for sufficiently small positive `c_rad`. | verified proof defect | **ACTIVE** | adjudicate P/O/M membership only |
| Ω-T02 | Ω-T02 | The theorem fixes `c_rad` without stating `c_rad>0`; zero may make stochastic headline terms incompatible with the model. | strong potentially fatal concern | **ACTIVE** | adjudicate the exact domain only |
| ZR-001 | S-001, M-001 | At zero stochastic budget, the displayed radius set includes `r=0`, so `R_n(r)/(3r)` contains `0/0`. | major endpoint-definition defect | registered, inactive | no repair in K0 |
| RN-001 | S-002 | The root-`n` witness can leave `[-3,3]`, e.g. `B_0=64`, `v_0=1`, `n=1`. | major verified defect | registered, inactive | no repair in K0 |
| EP-001 | M-002 | The initial-fit proof invokes a joint scalar/function localized class without printing its required certificate. | major proof gap, reportedly repairable | registered, inactive | no repair in K0 |
| EP-002 | M-003 | (B.12)/(B.14) omit the high-probability `z/n` and `(d/r)sqrt(z/n)` terms. | major verified derivation defect | registered, inactive | no repair in K0 |
| HEL-001 | M-004 | The Hellinger/Bhattacharyya prose gives the square where the coefficient needs a square root. | minor verified notation defect | registered, inactive | no repair in K0 |
| NOV-001 | Ω-V01, Ω novelty/significance assessment, S-013, S-016 | O/P novelty remains conditional and overall significance is borderline/model-local; no direct collision was established in the bounded search. | reject-level positioning risk; non-hit gives no novelty credit | registered, inactive | no literature refresh or claim edit in K0 |

Dependency note: Ω-T01 occurs at hard-pair model membership, before Gram, mixture, TV, and testing calculations. Ω-T02 occurs at the theorem's fixed-parameter domain. Success on K0 cannot erase or downgrade any inactive issue.

