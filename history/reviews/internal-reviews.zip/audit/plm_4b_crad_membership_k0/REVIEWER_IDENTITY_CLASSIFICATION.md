# Reviewer Identity Classification

Phase: `PLM-4B-CRAD-MEMBERSHIP-K0`

| Label | Permitted description | Explicitly forbidden description | Genuine human identity/credential | Human verdict/signature credit |
|---|---|---|---:|---:|
| Reviewer Ω | AI-assisted general red team | independent human audit; external human verification; human reviewer signature | 0 | 0 |
| Expert S | AI-assisted source/model audit | human expert opinion; independent human source audit; human signature | 0 | 0 |
| Expert M | AI-assisted mathematical audit | human proof audit; external human verification; human signature | 0 | 0 |

The self-descriptions inside all three returns explicitly identify AI assistance or AI execution. A typed AI label, task identity, archive token, completion date, or file hash authenticates an artifact only; it does not establish a human identity, qualification, independence, opinion, or signature.

No genuine human first-pass input has been received. No reference-stage release gate is open. No external expert has been selected, contacted, retained, or simulated in this phase.

