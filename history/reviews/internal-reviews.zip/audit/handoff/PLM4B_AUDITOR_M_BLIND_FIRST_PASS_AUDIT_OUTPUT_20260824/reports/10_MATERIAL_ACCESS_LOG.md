# 实际读取材料清单

输入 ZIP：`PLM4B_AUDITOR_M_BLIND_FIRST_PASS.zip`。

## 1. 包内实际读取文件

### 顶层/ledger

- `README.md`
- `MANIFEST.tsv`
- `PROVENANCE.tsv`
- `REPLACEMENTS.tsv`

### 指南

- `guides/AUDIT_INSTRUCTIONS.md`
- `guides/DEFINITIONS_AND_SYMBOLS.md`

### 原始空白表格

- `forms/AUDITOR_CREDENTIAL_SCOPE.md`
- `forms/AUDITOR_M_FORM.md`
- `forms/INDEPENDENCE_AND_CONFLICT_FORM.md`

### H1-H12 packets

- `packets/H1_MODEL_M1_Q1_MAIN.md`
- `packets/H2_BBM_TRANSFER.md`
- `packets/H3_O_UPPER.md`
- `packets/H4_R_UPPER.md`
- `packets/H5_SELECTOR_TAIL_Q1.md`
- `packets/H6_Q_LOWER.md`
- `packets/H7_P_LOWER.md`
- `packets/H8_O_LOWER.md`
- `packets/H9_AB_LOWER.md`
- `packets/H10_M_LOWER.md`
- `packets/H11_ASSEMBLY_BOUNDARY.md`
- `packets/H12_END_TO_END.md`

### 论文与正式 proof source

- `manuscript/anonymous_manuscript.pdf`（28/28 PDF 页已渲染；全文逐页文本用于检索，关键公式回到原始页面视觉核查）
- `sources/bartlett_bousquet_mendelson_author_version.pdf`（重点核查 PDF pp. 3, 6-7；Theorem 2.1 原始 statement）
- `sources/crossref_bartlett_2005.json`

### reproduction 说明

- `reproduction/ENVIRONMENT_PORTABLE.md`
- `reproduction/REPRODUCE.md`
- `reproduction/EXPECTED_ARTIFACTS.md`
- `reproduction/TEST_INTERPRETATION_LIMITS.md`

### 允许的辅助检查脚本

- `checks/P_verify_exact_identities.py`
- `checks/O_verify_exact_identities.py`
- `checks/AB_verify_exact_identities.py`
- `checks/AB_falsifier_raw_laws.py`
- `checks/M_verify_exact_identities.py`
- `checks/M_falsifier_raw_laws.py`
- `checks/source_integrity.py`
- `checks/test_source_integrity_gate.py`

## 2. 公开 primary-source web spot checks

- [Gu, Optimal use of a black-box learner in semiparametric estimation, arXiv:2607.21541v1](https://arxiv.org/abs/2607.21541) - title, date, version and abstract scope.
- [Gu, Yin, Cai and Fan, Optimally taming biases in black-box models for efficient semiparametric estimation, arXiv:2606.06368v1](https://arxiv.org/html/2606.06368) - Theorem A.1 displayed upper/lower formulas and minimax order.
- [Jin and Syrgkanis, arXiv:2512.17341](https://arxiv.org/abs/2512.17341) - bibliographic existence/metadata only.
- [Jin, Mackey and Syrgkanis, arXiv:2507.02275](https://arxiv.org/abs/2507.02275) - bibliographic existence/metadata only.

## 3. 明确未读取/未使用

- 任何作者内部审计报告或 dependency ledger。
- 任何参考答案、solution、reference report。
- 任何已完成的 Auditor M/S 表格。
- 任何其他审稿人的意见。
- 任何历史 terminal、内部 verdict 或 reference-stage dossier。

## 4. 访问原则

先按文件名和 README 判断材料性质；未通过目录边界去“打开确认”疑似禁止材料。辅助脚本只在完成相应独立推导后作为旁证运行。
