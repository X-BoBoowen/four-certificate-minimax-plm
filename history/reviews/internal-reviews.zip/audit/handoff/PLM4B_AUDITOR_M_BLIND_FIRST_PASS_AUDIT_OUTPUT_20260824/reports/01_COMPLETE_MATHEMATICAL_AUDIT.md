# 独立数学证明审计报告

Reviewer：Expert M（AI-assisted independent mathematical audit）  
审计日期：2026-08-24（Asia/Shanghai, UTC+08:00）  
审计对象：`manuscript/anonymous_manuscript.pdf`（28 个 PDF 实际页）  
总体判定：**CONDITIONAL PASS**  
总体置信度：**HIGH**

## 1. 结论先行

论文的严格内点主 rate

\[
n^{-1/2}+(a+s^2)(b+t^2)+(s\wedge t)^2+t(a\wedge t)+s(b\wedge s)
\]

在完成两处局部上界修复和两处端点/记号修正后，得到材料中的假设与独立推导支持。没有找到要求删除 q、P、O、ab、M 任一项、改变 rate、缩小严格内点区间或更换 lower-bound 策略的反例。

不能给出无条件 PASS，原因是：

1. 随机复杂度预算在 `s=0` 或 `t=0` 时把 `r=0` 纳入 `R(r)/(3r)`，字面上出现 `0/0`（M-001）。
2. (B.9) 把 Lemma 5 用于联合标量/函数类，但未证明该联合类满足所需 localized-Rademacher 条件（M-002）。该条件可由曲率恒等式 (B.8)、`v_- > 0`、公共差分类预算和一维参数的 `n^{-1/2}` 复杂度推出，rate 不变。
3. O 分支 (B.12) 在 `E_z` 上把 offset supremum 误写成仅有 `\bar s^2`，遗漏 `z/n`；因此 (B.14) 也遗漏 `(d_\pi/\bar s)\sqrt{z/n}`（M-003）。(B.18) 已经保留的两个 amplification 项正好吸收该修正，故 (B.18)-(B.20) 可按原 rate 重证。
4. 饱和下界把单观测 Bernoulli Bhattacharyya coefficient 写成 `1-4\delta_n^2`，实际 coefficient 为其平方根；后续 TV 计算使用的是平方 coefficient，数值结论不变（M-004）。

## 2. 审查边界与材料隔离

先枚举 ZIP 条目，再读取 README 与审计说明。包内没有出现文件名含 `solution`、`answer`、`internal audit`、`reference report`、已完成审计表或其他审稿意见的材料。实际读取范围包括匿名论文、BBM 作者版原文、空白表格、H1-H12 packets、定义/复现说明、字节清单和允许的辅助检查脚本。未读取任何内部审计、参考答案、历史依赖台账或其他审稿意见。

packets 被当作最低检查范围和定位索引，不被当作正确性证据。所有实质判定均回到论文 PDF、BBM 原始定理或独立计算。

## 3. 模型、量词与主定理

风险顺序是

\[
R_{n,\rho}^{\mathrm{pair}}(a,s,b,t)
=\sup_{\Gamma}\inf_{\delta_\Gamma\;\mathrm{Borel}}
\sup_{P\in\mathcal P(\Gamma)}E_P|\delta_\Gamma-\beta(P)|.
\]

上界确实为每个固定合法 `Gamma` 构造一个可依赖 `Gamma`、`rho` 和公开 budgets 的规则，再在该固定 pair 内取得一致 `sup_P` 界，最后取 `sup_Gamma`。下界的五个 hard pair 可以不同，因为每个 pair 分别放入同一外层 `sup_Gamma`；论文仅取五个有效标量下界的 maximum，没有把不同 prior 的 Bayes risks 相加。

计数表示、first-within-tolerance、有限维有理稠密参数化、有限算术和 clipping 足以使公布的初始拟合、O/R edit、四格 selector 和 fallback 为 Borel。未发现 estimator 依赖 `P`、真实 nuisance、population best approximant 或 realized learner error。

唯一端点定义问题是 Appendix A 的半径比在零半径处未定义。最小修复为

\[
\sup_{r\ge s,\;r>0}\frac{\mathfrak R_n(r;\Delta\mathcal G)}{3r}\le c_{\rm rad}s,
\]

或明确约定零类在 `r=0` 的 quotient 为 0。该修复使论文反复声称的 all-zero-budget cells 成为良定义对象。

## 4. BBM theorem transfer

正式引用是 Bartlett, Bousquet and Mendelson, *Local Rademacher Complexities*, author version dated 14 May 2004；期刊版本为 *Annals of Statistics* 33(4), 1497-1537 (2005), DOI `10.1214/009053605000000282`。被移植的是 Theorem 2.1，作者版 PDF p. 6（续接 p. 7 的讨论）/ journal pp. 1503-1504。

取源类 `F=W union (-W)`、`[a,b]=[-B,B]`、variance `r=sigma^2`、confidence `x=z`、`alpha=1`。对称扩类使源定理的 one-sided supremum 等于本文绝对 supremum；源 `E R_n F` 等于本文对 data 和 Rademacher signs 同时取期望的 `R`。系数逐项成为

\[
2(1+\alpha)R=4R,\qquad
\sqrt{2\sigma^2z/n},\qquad
(2B)(1/3+1)z/n=8Bz/(3n).
\]

源失败概率为 `e^{-z}`，本文写成 `2e^{-z}` 是保守放宽。countability 满足可测 supremum 要求。`sigma=0` 时类内每个 centered 函数几乎处处为零（countable union），结论平凡。H2 判定 PASS。

## 5. 经验过程与初始拟合

Lemma 5 的固定公共差分类版本可由 ghost sample、symmetrization、bounded contraction、population-radius peeling 和 BBM concentration 得到。它不需要 star-shapedness，因为小于 `r_0` 的部分直接包含在 `r_0` ball 中，没有对函数作缩放。

但 (B.9) 所需类不是单纯 `Delta G_mu`。令

\[
\mathcal J=\{\gamma T+f(X):\gamma\in[-6,6]\cap\mathbb Q,
f\in\Delta\mathcal G_\mu\}.
\]

论文没有验证 `J` 的 localized complexity。修补方式如下。由 (B.8)，

\[
\|\gamma T+f\|_2^2=v\gamma^2+\|\gamma\pi_0+f\|_2^2.
\]

在 `||gamma T+f||_2<=r` 上，`|gamma|<=r/sqrt(v_-)`，且

\[
\|f\|_2\le \|\gamma\pi_0+f\|_2+B_0|\gamma|\le C_\rho r.
\]

因此对 `r>=C_\rho(s vee h_n)`，差分类部分贡献 `C_\rho s r`，一维 `gamma` 部分贡献 `C_\rho r/sqrt(n)`；故

\[
\mathfrak R_n(r;\mathcal J)\le C_\rho(s\vee h_n)r.
\]

把这一引理显式插入后，(B.9) 的 rate 不变。该缺口影响 H3/H4 的上游，但不是反例。

## 6. O/R 尾界与 expectation

O 的精确五项恒等式 (B.17) 和 R 的 signed identity (B.28) 均由原始 ratio 直接展开得到，符号正确。sigma-field 顺序也正确：O 的 fitted weight 不使用 D1 outcomes；R 的 `m_hat` 使用 D2 outcomes 和 D1 covariates但不使用 D1 treatments。所有随机拟合索引均在 uniform event 之后代入。

O 分支真正可推出的是

\[
H_\mu(a_0)\le C(r^2+w_z^2),\quad
\|\widehat a-\widetilde a\|_n
\le C\{d+(d/r)w_z+\ell\},
\]

而不是 (B.12)-(B.14) 写出的无 `w_z^2`/无 `(d/r)w_z` 版本。把修正项放回五项分解后，得到的额外量正是

\[
\frac{ad}{r}w_z,\qquad \frac d r w_z^2,
\]

二者已经显式存在于 (B.18)。故 (B.18) 本身在修补后成立；正文第 720-723 行声称这些项“并非用于补遗漏项”则不成立。

R 分支从 (B.22) 起已经保留 `delta_z=K(r+w_z)`，(B.24) 显式包含 `delta_z/sqrt(lambda_R)`，所以 (B.29) 没有 O 分支同样的遗漏。

层蛋糕转换按递增 envelope `f(z)` 写为

\[
E E\le f(1)+\int_1^{c n}K e^{-z}f'(z)\,dz+6K e^{-cn}.
\]

对 `w_z^p=(z/n)^{p/2}`，积分贡献为常数倍 `n^{-p/2}`；`z<1` 由 `f(1)` 覆盖，`z>cn` 由 clipping 和 `e^{-cn}<=C q` 覆盖，`cn<1` 时有 `q>=sqrt(c)` 并可直接吸收 bounded loss。结合 (B.19) 的 `d/(rn)<=Cq` 及 `ad/(r sqrt n)`、`bd/(r sqrt n)` 两分支吸收，(B.20)/(B.30) 的 expected bounds 保持原 rate。

## 7. selector、fallback 与 Q1 lift

四个 cells 由 `x<=y`/`y<x` 与相应 safe/unsafe 条件组成，弱等号归 O，安全等号仍为 safe，因此 disjoint 且 exhaustive。全部输入是公开 budgets、固定 `rho` 和公开类；selector 不读样本 realized error 或 denominator quality。

(B.31)-(B.32) 的六个弱序单元经独立代数与 1,000,000 个随机 budget 压力点未发现反例；数值搜索只是旁证，证明仍来自六单元代数。unsafe implication (B.33) 在 `h_n<=delta` 时由 `s>delta` 或 `t>delta` 分别强迫 `M/P` 或 `M/O` 为常数量级；`h_n>delta` 时 `h_n^2<=2q`。clipped-zero loss 至多 3。

固定 pair 的规则先进入该 pair 的 `inf_delta`，随后才取外层 pair supremum；没有 `sup/inf` 交换。H5 自身的 selector/Q1 逻辑通过，但其 expected-risk 输入继承 M-002/M-003 的局部修补，故总表标为 CONDITIONAL PASS。

## 8. q/P/O/ab/M lower bounds

五个 component 均使用固定于 latent label/sign/coordinate 之前的公共 pair。三点 treatment channel 的概率为正、和为 1、均值为指定 `m`、二阶矩为 `v_0+m^2`，故 residual variance 精确等于 `v_0=v_-`。binary response channels 直接给出 PLM conditional mean，而不仅是矩匹配。

- q：四原子 likelihood 为 `1 plus/minus h`，`K_q=4 delta_n^2 v_0/B_0^2<=1/(64n)`；`N=2n` 后 chi-square 小于 `1/16`，target gap 为 `2d_rho/sqrt(n)`，得到 `3d_rho/(8sqrt n)`。
- P：propensity 在 labels 间翻号，outcome nuisance 补偿；共同参考条件是 `Delta a_t t=b_t(kappa+gamma)`。两 Gram energies 不超过 `s^2/225`、`s^2/196`，gap 为 `m_rho s(b wedge s)/(512v_0)`。
- O：propensity common，outcome perturbation 删除；`Delta=gamma eta/(v_0+gamma^2)` 使 `Delta a_u u=b_u eta`。Gram energies 不超过 `t^2/9`、`t^2/256`。
- ab：公共类均为 singleton zero，truths 在类外但满足 `a,b` approximation budgets；两 stochastic complexities 精确为零。gap 为 `m_rho ab/(1024v_0)`，TV 小于 `1/4` 给出 (E.12) 的 `3/16384` 系数。
- M：两 truths 均属于同一个 finite public pair；outcome 和 propensity budgets 分别用 `w<=s`、`w<=t` 验证，不能仅由 `w=s wedge t` 口头推出。两 mixture energies 和 target gap 推出 (F.15)。

ceil dictionary size 保证 `p>=exp(64N r^2)`；各 nonparametric branch 有 `Nr^2>=8`，字典非空且可放入有限 dyadic cube。zero/small-n/small-budget branches 只把 component lower 与 q lower 取 maximum，没有跨 pair 相加。H6-H10 均判 PASS。

## 9. assembly 与边界

对每个 component，外层 pair supremum 给出同一标量风险的有效 lower bound，因此 (G.1) 的 maximum 合法。令 `S0=ab+M+O+P`，有

\[
S_0\le X\le 2S_0,
\]

因为 `at^2<=O`、`bs^2<=P`、`s^2t^2<=M`。五项 maximum-to-sum 给 `1/5`，再由 `X<=2S0` 给 `1/2`，合成 (G.3) 的 `1/10`。

`v_->B_0^2` 时由 `|u|<=B_0` 得实验为空。`v_-=B_0^2` 时 `u=plus/minus B_0` 条件等概率，`|T|<=B_0` 强迫 `pi_0=0`，于是 `beta_0=E(TY)/B_0^2`。上界 `1/sqrt(2n)` 正确。下界的 Hellinger prose 少一个平方根，但 `TV^2<=1-(1-4delta_n^2)^N<=4Ndelta_n^2` 与最终 `3/(128sqrt n)` 正确。

## 10. H1-H12 与总体建议

H2、H6-H10 为 PASS；H1、H3-H5、H11-H12 为 CONDITIONAL PASS。没有 H 项被判 FAIL。提交前必须至少完成 M-001 至 M-004 的文本/证明修正；其中 M-002/M-003 应由作者给出完整引理和逐项推导，不能只改一句“standard”。修复不改变主定理、rate 或预算区间。

## 11. 声明

本报告末尾的资历范围、利益冲突、独立性与可验证署名单独收录于 `reports/11_DECLARATIONS_AND_SIGNATURE.md`；完整材料访问记录见 `reports/10_MATERIAL_ACCESS_LOG.md`。
