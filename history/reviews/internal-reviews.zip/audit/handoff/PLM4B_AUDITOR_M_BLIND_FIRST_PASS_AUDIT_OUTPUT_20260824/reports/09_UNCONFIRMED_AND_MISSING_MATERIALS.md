# 未确认事项及缺失材料清单

## 1. 不影响数学主结论的未确认事项

1. **文献穷尽性/novelty priority**：核对了 BBM 原始定理、Gu et al. arXiv v1 Theorem A.1 的显示 lower formula，以及 Gu 2026 v1 的元数据/abstract。没有对整个相关文献宇宙做系统检索，因此不认证“closest”或“novel”是穷尽性结论。
2. **attribution-only references 的逐定理复核**：Robinson、DML、Robins et al.、Foster-Syrgkanis、Jin 系列等在本文中作为背景/ancestry，不是当前证明的 formal leaf。ZIP 未提供它们的全文，本审计没有重证明这些论文。
3. **generic K constants 的数值最优性**：确认可统一选择并只依赖 fixed rho；没有优化其最小数值。
4. **形式化证明助理验证**：未使用 Lean/Coq/Isabelle；所有推导是人工式符号审计加有限脚本旁证。
5. **运行时/可计算性**：论文明确不主张 polynomial-time 或 finite-oracle implementation，本审计不评估实际计算成本。

## 2. 材料缺失及影响

- 包内没有 manuscript TeX source 或 reproduction `run_all.ps1`，只有保护 PDF 与若干检查脚本。因此无法按 README 所述重编译两套 28 页 source trees；但 PDF 可读性和 28 页布局已直接渲染检查，数学审计不依赖重编译。
- 包内只提供 BBM 全文与其 Crossref JSON。其他 bibliography items 没有随包全文。由于 BBM 是唯一外部 proof-transfer leaf，核心正确性审查未因此阻断。
- 没有可用会话/任务 ID 暴露给 reviewer；署名中如实标为“未提供”。
- 精确模型 build/version 未暴露；只可声明 OpenAI Codex / GPT-5 family，exact build 未提供。

## 3. 禁止材料

未发现、未打开且未使用作者内部审计报告、参考答案、已完成审计表、其他审稿人意见、solution/answer/internal audit/reference report 类文件。

## 4. 影响判定

上述未确认/缺失项不构成对主数学结论的 FAIL。总体 CONDITIONAL PASS 的原因是 M-001-M-004，而不是“时间不足”或缺少 attribution-only 文献。
