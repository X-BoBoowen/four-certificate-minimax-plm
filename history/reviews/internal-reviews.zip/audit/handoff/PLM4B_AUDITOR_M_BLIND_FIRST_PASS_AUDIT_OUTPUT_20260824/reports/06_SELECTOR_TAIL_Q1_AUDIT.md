# Selector、尾积分与 Q1 lift 专项核查

## 1. selector 定义域和值域

- 输入：固定 `rho`、公开 pair `Gamma`、公开 budgets `(a,s,b,t)` 和 `2n` 样本。
- 公开派生量：`x=a+s`、`y=b+t`、`bar s`、`bar t`、固定 threshold `eta`。
- 分支：`x<=y` 时只可能选 O；`y<x` 时只可能选 R。各自 safe predicate 不成立则返回 0。
- 输出：pre-clipped scalar，经 projection 后在 `[-3,3]`。
- 未使用：`P`、`mu_0`、`pi_0`、population best approximants、realized errors、真实 denominator quality。

## 2. argmin、tie-breaking 与 Borel 性

- Initial fits：给定 countable representation，经验目标是 countable Borel family；选第一个在 infimum 加 `tau_n` 内的 index。infimum 定义保证 qualifying index 存在，无需 attainment。
- O edit：若 `T_{1:n} !=0`，取第一个最大绝对值坐标，其他坐标取有理稠密枚举，最后一个坐标由 hyperplane equation 精确确定。该 chart 对 irrational `T_j` 仍稠密且 Borel。objective 在 hyperplane 上 Lipschitz/continuous 且由正 quadratic coercive。
- R edit：在 `R^n` 的有理枚举上选 first-within-tolerance；正 quadratic coercive。
- selector ties：`x=y` 归 O；`bar s=eta`、`bar t=eta` 均视为 safe。无随机 tie-breaking。

判定：selector 是 exact public orientation 加 approximate deterministic optimizers，不是随机 selector；Borel 性 PASS。

## 3. 四格 partition

四格为

1. `x<=y, bar s<=eta`：O-safe；
2. `x<=y, bar s>eta`：O-unsafe；
3. `y<x, bar t<=eta`：R-safe；
4. `y<x, bar t>eta`：R-unsafe。

弱/严格不等号使其 disjoint 且 exhaustive，包括全部 zeros/ties。

## 4. selector algebra

令

\[
T_\mu=ay+x^2,\qquad T_\pi=bx+y^2,\qquad W=T_\mu\wedge T_\pi,
\]

\[
V=\min\{A,xy,T_\mu,T_\pi\},\quad X=AB+M+O+P.
\]

在 `x<=y`，`T_mu<=2xy<=2T_pi`；mirror case 同理。因此选中分支 `T_selected<=2W`。对 `(a versus t,b versus s)` 的六个弱序 cells 逐项展开，可得

\[
V\le W\le4V,\qquad X/5\le V\le6X,
\]

从而 `T_selected<=48X`。零除法未出现。

压力测试：对 `[0,1]^4` 进行 1,000,000 个独立随机点搜索，没有发现违反 `V<=W<=4V` 或 `X/5<=V<=6X` 的点；此搜索不代替上述分 cell 证明。

## 5. unsafe fallback

令 `delta=eta/C_rad`。

- 若 `h_n>delta`，则 `delta^2<h_n^2<=2q`，bounded loss 被 `q` 吸收。
- O-unsafe 且 `h_n<=delta` 时，`bar s>eta` 强迫 `s>delta`。若 `t>=s/2`，`M>=s^2/4`；否则由 `x<=y` 得 `b>s/2`，故 `P>s^2/2`。
- R-unsafe 是镜像：由 `t>delta` 得 `M` 或 `O` 为常数量级。

因此 clipped-zero loss `<=3` 被固定常数倍 `q+X` 吸收。PASS。

## 6. tail integration

对递增 tail envelope `F(z)`，正确 layer-cake 形式是

\[
E E\le F(1)+\int_1^{cn}P(E>F(z))F'(z)dz+6P(E>F(cn)).
\]

`z<1` 不把大偏差界非法积分到零，而由 `F(1)` 覆盖；`z>cn` 用 clipping；`cn<1` 用 `q>=sqrt c`。Jacobian 来自 `w_z=(z/n)^{1/2}`，所以 `w_z^p` 的导数为 `(p/2)n^{-p/2}z^{p/2-1}`。所有 Gamma integrals 有限。

O integration 继承 M-003 的 corrected tail；R integration 继承 M-002 的 initial-fit lemma。积分步骤本身 PASS。

## 7. Q1 lift

对每个固定合法 `Gamma`，构造规则 `delta_Gamma` 并证明

\[
\sup_{P\in\mathcal P(\Gamma)}E_P|\delta_\Gamma-\beta(P)|\le C_\rho(q+X),
\]

其中 `C_rho` 不依赖 `Gamma,n,budgets,P`。故

\[
\inf_{\delta\;\mathrm{Borel}}\sup_{P\in\mathcal P(\Gamma)}E_P|\delta-\beta(P)|
\le C_\rho(q+X),
\]

再取 `sup_Gamma`。没有把 `sup_Gamma` 与 `inf_delta` 交换，也没有要求跨 pair 的 common rule。Q1 lift PASS。

## 8. 专项判定

Selector/Borel/fallback/Q1：PASS。Tail-to-expectation：PASS conditional on corrected O tail。H5 总判定因继承 M-002/M-003 为 **CONDITIONAL PASS / HIGH confidence**。
