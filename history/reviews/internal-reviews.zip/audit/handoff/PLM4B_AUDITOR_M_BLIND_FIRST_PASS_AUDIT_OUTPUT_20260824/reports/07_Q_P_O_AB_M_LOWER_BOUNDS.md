# q/P/O/ab/M lower bounds 逐项审计

共同记号：`N=2n`，`v_0=v_-`，三点 treatment support 为 `{-L,0,L}`，

\[
m_\rho=\min\{1/64,v_0/(4B_0),(B_0-\sqrt{v_0})/4\},\quad L=\sqrt{v_0}+2m_\rho.
\]

对任意 `|m|<=m_rho`，(C.6) 的三质量和为 1、均值为 `m`、二阶矩为 `v_0+m^2`、variance 为 `v_0`；较小 side numerator 至少 `3v_0/4`，middle mass 由 `v_0+m_rho^2<L^2` 为正。`|T|`、`|T-m|<B_0`。

## H6：q lower

### 构造与 membership

`X` 常数，公开 pair `G_mu=G_pi={0}`，`T=plus/minus sqrt(v_0)`。labels `theta=plus/minus delta_n`，`delta_n=d_rho/sqrt n`，`Y=(B_0/2)R`，

\[
P_\theta(R=1|T=t)=1/2+\theta t/B_0.
\]

于是 `E(Y|T)=theta T`，nuisances 为零，outcome residual 条件中心化；由 `d_rho` 定义 probabilities 在 `[7/16,9/16]`，全部 envelopes 合法。

### observation distance

相对均匀四原子 `Q`，likelihood 为 `1 plus/minus h`，

\[
h=2r\delta_n t/B_0,\quad K_q=E_Qh^2=4\delta_n^2v_0/B_0^2\le1/(64n).
\]

`N=2n` 时 `chi^2(P^N,Q^N)=(1+K_q)^N-1<1/16`。每 label 到 Q 的 TV `<1/8`，cross-label TV `<1/4`。target gap `2delta_n`，expected-L1 testing 给 `3delta_n/8`。

### 量词与边界

同一 singleton pair 对所有 declared budgets 合法；pair 在 label 前固定。`n=1`、singleton variance interval 均覆盖。

**判定：PASS / HIGH。**

## H7：P lower

### 构造

nonparametric branch：`n>=16`、`s^2>=q`、`s(b wedge s)>0`。令 `w=b wedge s`，

\[
\eta=m_\rho w/4,\quad \gamma=s/256,\quad
\Delta=2\eta\gamma/v_0,\quad \kappa=\gamma+\Delta\eta,
\]

`p=ceil(exp(64Ns^2))`。对 Walsh `z=sigma phi_j`：

\[
(\beta_0,\pi_0,\mu_0)=(0,z\eta,z\gamma),\quad
(\beta_1,\pi_1,\mu_1)=(\Delta,-z\eta,z\kappa).
\]

binary response channel 直接给 `E(Y|X,T)=beta T+mu(X)`；两 treatment channels variance 都是 `v_0`。

### 公共 pair 与 budgets

在 label/coordinate/sign 前公布

\[
G_\pi=\{0\},\quad
G_\mu=\{z_j\gamma,z_j\kappa:j\le p,\sigma=plus/minus1\}.
\]

propensity approximation `eta<=b`，outcome truths 在 class 内。`Delta G_mu` cardinality `<16p^2`、envelope `2kappa`，Massart bound 在每个 `r>=s` 给 normalized ratio `<s`。finite listing 是 M1。

### common reference/Gram

atomwise equality条件为

\[
\Delta a_t t=b_t(\kappa+\gamma),
\]

side atoms 化为 `Delta(v_0+eta^2)=eta(kappa+gamma)`，由参数定义成立；zero atom 两侧为 0。likelihood coefficients centered，

\[
K_0\le s^2/225,\qquad K_1\le s^2/196.
\]

Walsh orthogonality给 same/opposite/different entries `1+K,1-K,1`。ceil dictionary 与 exact mixture formula 给每 label 到共同 `Q^N` 的 chi-square 极小，cross TV `<1/2`。

### gap、testing、all-n

gap `Delta=m_rho s(b wedge s)/(512v_0)`，testing 给 `m_rho P/(4096v_0)`。若 `s^2<q`，则 `P<q`；若 `n<16`，`P<=1<=4q`；zero branches trivial。只与 q lower 取 maximum。

**判定：PASS / HIGH。**

## H8：O lower

### 构造与 membership

branch：`n>=16`、`t^2>=q`、`t(a wedge t)>0`。令

\[
\gamma=m_\rho t/4,\quad \eta=(a\wedge t)/256,\quad
\Delta=\gamma\eta/(v_0+\gamma^2),
\]

`p=ceil(exp(64Nt^2))`。两 labels 共用 `pi=z gamma`：

\[
(\beta_0,\mu_0)=(0,z\eta),\quad(\beta_1,\mu_1)=(\Delta,0).
\]

label 0 outcome mean为 `z eta`，label 1 为 `Delta T`，均是 exact PLM；treatment residual variance为 `v_0`。

### 公共 pair/budgets

`G_mu={0}`，`G_pi={z_j gamma}`。label 0 outcome approximation `eta<=a`，label 1 为 0；两 propensities 在 class 内。`Delta G_pi` finite Massart ratio `<t`。

### reference/Gram/testing

common-reference equality

\[
\Delta a_u u=b_u\eta
\]

在 side atoms 等价于 `Delta(v_0+gamma^2)=gamma eta`。label-1 outcome tilt 在 likelihood ratio numerator/reference 中精确抵消，

\[
K_0\le t^2/9,\qquad K_1=\gamma^2/(v_0+\gamma^2)\le t^2/256.
\]

cross TV `<1/2`，gap 下界为

\[
\Delta\ge \frac{m_\rho}{1024(v_0+m_\rho^2/16)}t(a\wedge t).
\]

one-eighth testing 与 q splice 给 (D.15)。

**判定：PASS / HIGH。**

## H9：ab lower

### 构造与公共接口

branch：`n>=16`、`S=a^2+b^2>=q`、`ab>0`。公共 pair 在 latent choices 前固定为

\[
G_\mu=G_\pi=\{0\}.
\]

令 `eta=m_rho b/4`、`gamma=a/512`、`Delta=2eta gamma/v_0`、`kappa=gamma+Delta eta`。两 labels 与 P family 同型，但所有 Walsh truths 都在 public classes 外。

`eta<=b`、`gamma,kappa<=a`；difference classes 为 singleton zero，正半径 localized complexities 为 0。这里零半径 quotient 需 M-001 的 convention，但不影响构造本身。

### distance 与常数

common reference equality为 `Delta alpha_t t=xi_t(kappa+gamma)`。两 Gram energies `K_0<=S/32`、`K_1<=S/8`；`NS>=8`，mixture chi-square 小。cross TV `<1/4`。gap

\[
\Delta=m_\rho ab/(1024v_0).
\]

C.1 给 `3Delta/16=3m_rho ab/(16384v_0)`，确认 (E.12) 的 `1/16384`。small branches 由 `ab<=1<=4q` 或 `ab<=S/2<q/2` 与 q lower 取 maximum。

**判定：PASS / HIGH**（需统一采用 M-001 的定义修正）。

## H10：M lower

### 构造

`w=s wedge t`，branch `n>=16`、`w>0`、`w^2>=q`。令

\[
\gamma=m_\rho w/4,\quad \eta=w/256,\quad
\Delta=\gamma\eta/(v_0+\gamma^2),\quad
p=\lceil e^{64Nw^2}\rceil.
\]

两 labels 共用 `pi=z gamma`，outcome/target 为 `(0,z eta)` 和 `(Delta,0)`。

### 一个公共 pair 与两个 budget certificates

\[
G_\pi=\{z_j\gamma\},\qquad G_\mu=\{0\}\cup\{z_j\eta\}.
\]

truths 均在 pair 内，approximation zero。outcome finite-class bound除以 `3r`、`r>=s` 后用 `w<=s` 得 `<s`；propensity bound在 `r>=t` 后用 `w<=t` 得 `<t`。两者独立验证，未把 `w=min(s,t)` 当作未经计算的结论。

### distance/gap/all-n

common-reference equality `Delta alpha_u u=xi_u eta`；Gram energies `<w^2/9` 和 `<w^2/256`。gap

\[
\Delta\ge m_\rho w^2/[1024(v_0+m_\rho^2/16)].
\]

testing 保守取 one-eighth。`w=0` trivial；`n<16` 时 `w^2<=1<=4q`；`n>=16,w^2<q` 用 q lower。

**判定：PASS / HIGH**（零 face 定义按 M-001 修正）。

## 组合

五个 hard pairs 可不同，但每个分别 lower-bound 同一 `sup_Gamma inf_delta sup_P` 标量。只取 maximum。`S_0=ab+M+O+P` 与 `X` 满足 `S_0<=X<=2S_0`，故 maximum-to-sum factor `5` 与 equivalence factor `2` 给总 factor `10`。PASS。
