# 完整问题清单

## Issue M-001

- Issue ID：M-001
- 所属审计项：H1（模型、M1/Q1、主定理量词）；影响 H9/H10 的零预算表述
- 判定：CONDITIONAL PASS
- 严重程度：MAJOR
- 置信度：HIGH
- PDF 页码：PDF p. 10 / manuscript p. 10
- 章节/公式：Appendix A，lines 512-516，localized Rademacher budget display
- 第一个可能失败的步骤：把 `s=0` 或 `t=0` 代入 `sup_{r>=s} R_n(r)/(3r)`；集合包含 `r=0`，quotient 为 `0/0`。
- 作者使用的论证：声明条件覆盖 `[0,1]^4` 全部 budgets，并在后文把 singleton zero difference class 的零半径复杂度视为 0。
- 独立重算或核查：对 `Delta G={0}`，`R_n(0)=0`，但显示式本身是 `0/(3*0)`，在未给 convention 时不定义；“numerator 为 0”不能自动定义 quotient。
- 反例/边界例子尝试：取 `a=s=b=t=0`、`G_mu=G_pi={0}`。该 pair 本应是 q witness 使用的合法 pair，但字面定义无法判断它是否属于 `G(0,0,0,0)`。
- 问题为何影响结论：主定理显式量化所有 budget boundaries；零预算 cells 的参数集合在当前文本下未良定义。
- 最小修复建议：把 supremum 写成 `sup_{r>=s,r>0}`；或在定义处明确 `Delta G={0}`、`r=0` 时 quotient 取 0，并说明一般 `s=0` 仍只检查正半径。
- 修复后是否改变主定理/rate/参数范围：否。
- 尚未确认事项：若作者另有未显示的全局 convention，需在论文内显式交叉引用；本包未见该 convention。

## Issue M-002

- Issue ID：M-002
- 所属审计项：H3/H4；经验过程与局部复杂度
- 判定：CONDITIONAL PASS
- 严重程度：MAJOR
- 置信度：HIGH
- PDF 页码：PDF p. 11（Lemma 5）与 PDF p. 12（(B.8)-(B.9)）
- 章节/公式：Appendix B.1-B.2，Lemma 5、(B.8)、(B.9)
- 第一个可能失败的步骤：line 638 的“Applying (B.3)-(B.4) to the joint scalar/function class”没有先验证该联合类满足 Lemma 5 的 (B.2a)。
- 作者使用的论证：公共 budget 只直接控制 `Delta G_mu`；随后把同一过程界用于 `(gamma,f)` 联合索引。
- 独立重算或核查：令 `J={gamma T+f(X)}`。由 (B.8)，局部球内 `|gamma|<=r/sqrt(v_-)` 且 `||f||_2<=C_rho r`。因此差分类贡献 `C_rho s r`，一维 gamma 贡献 `C_rho r/sqrt(n)`，在 `r>=C_rho(s vee h_n)` 上得 `R_n(r;J)<=C_rho(s vee h_n)r`。这证明所需结果，但该证明不在正文中。
- 反例/边界例子尝试：尝试令 `f approx -gamma pi_0` 造成联合函数 cancellation。单独用 `||gamma pi_0+f||` 的确不能控制 `||f||`；必须同时使用 (B.8) 对 gamma 的控制和 `|pi_0|<=B_0`。这说明缺失步骤不是纯符号替换。
- 问题为何影响结论：(B.9) 是 O/R 两个上界的共同初始拟合输入；不补该 lemma 时，上界链缺少经验过程前提。
- 最小修复建议：在 (B.9) 前加入联合类 localized-complexity lemma，明确 metric、envelope、radii threshold、countability 与一维参数项。
- 修复后是否改变主定理/rate/参数范围：否；只扩大固定 `rho` 常数并保留 `bar s=C_rad(s vee h_n)`。
- 尚未确认事项：所有 K 常数的最小数值未优化；只确认存在依赖 fixed rho 的统一常数。

## Issue M-003

- Issue ID：M-003
- 所属审计项：H3；(B.18)/(B.20)；tail integration
- 判定：CONDITIONAL PASS
- 严重程度：MAJOR
- 置信度：HIGH
- PDF 页码：PDF p. 13 / manuscript p. 13，(B.12)-(B.15)；PDF p. 14，(B.18)-(B.20)
- 章节/公式：Appendix B.3-B.4
- 第一个可能失败的步骤：(B.12) 从 Lemma 5 的 `delta_z=K(r_0 vee h_n)+sqrt(z/n)` 界推出 `H_mu(a_0)<=K bar s^2`，遗漏 `z/n`。
- 作者使用的论证：在 `E_z` 上最大化 `K bar s ||f||-||f||^2/2`，随后 (B.14) 得到无 `(d/r)w_z` 的 norm bound，并声称 (B.18) 中 amplification 项不是为遗漏项准备。
- 独立重算或核查：正确最大化给 `H_mu(a_0)<=K(r^2+w_z^2)`。目标比较给 `||hat a-tilde a||_n<=K{d+(d/r)w_z+ell}`。五项恒等式 (B.17) 因而增加 `(ad/r)w_z` 和 `(d/r)w_z^2`；这两项已经出现在 (B.18) 右端，所以 (B.18) 可保持不变重证，(B.20) 的 layer-cake rate 也保持不变。
- 反例/边界例子尝试：取 `T=u=plus/minus sqrt(v)`、`pi_0=0`，令 `Delta G_mu` 含有稠密有理常函数。则 `H_mu(a_0)` 等于样本均值平方的常数倍。其超过 `K bar s^2` 的概率一般为 polynomial-in-n，而不可能对所有 `z` 达到 `e^{-z}`；取 `z=c n` 即暴露 (B.12) 的 all-z 错误。
- 问题为何影响结论：论文给出的 (B.18) 推导链含一个真实错误的高置信度步骤；不能以“额外项非必要”带过。
- 最小修复建议：把 (B.12)-(B.15) 改成含 `w_z^2`、`(d/r)w_z` 的版本，并重新列出五项 bound；随后指出 (B.18) 已包含全部 correction terms。
- 修复后是否改变主定理/rate/参数范围：否；不改变 (B.18) 的已显示 RHS、(B.20) rate 或 safe cell。
- 尚未确认事项：无；给定该修复，所需吸收和积分已独立完成。

## Issue M-004

- Issue ID：M-004
- 所属审计项：H11（saturation lower）；H12
- 判定：CONDITIONAL PASS
- 严重程度：MINOR
- 置信度：HIGH
- PDF 页码：PDF p. 27 / manuscript p. 27
- 章节/公式：Appendix H，lines 1404-1408，(H.5)-(H.6)
- 第一个可能失败的步骤：把单观测 Bernoulli cross-label Hellinger/Bhattacharyya coefficient 写成 `1-4 delta_n^2`。
- 作者使用的论证：称该 quantity 为 affinity，tensorize 后用 Cauchy-Schwarz 得 TV bound。
- 独立重算或核查：对 Bernoulli `1/2 plus/minus delta_n`，coefficient 是 `sqrt(1-4delta_n^2)`，其平方才是 `1-4delta_n^2`。N 样本 squared coefficient 为 `(1-4delta_n^2)^N`，故 `TV^2<=1-(1-4delta_n^2)^N<=4Ndelta_n^2=72/1024<1/4`；后续 gap/testing constant 正确。
- 反例/边界例子尝试：`delta_n=0.1` 时 coefficient 约为 `0.9799`，不是 `0.96`，直接说明 prose 等式错误；平方为 `0.96`。
- 问题为何影响结论：术语/平方遗漏可能误导 tensorization，但没有改变实际 TV 数值链。
- 最小修复建议：把“affinity is”改为“squared Bhattacharyya coefficient is”，或在 `1-4delta_n^2` 外加平方根并相应写 N-fold square。
- 修复后是否改变主定理/rate/参数范围：否。
- 尚未确认事项：无。
