# (B.18)、(B.20)、(B.29)、(B.30) 独立重算记录

记

\[
h_n=\sqrt{\log(en)/n},\quad w_z=\sqrt{z/n},\quad
r=\bar s\ \text{(O)}\ \text{或}\ r=\bar t\ \text{(R)},
\]

并保留论文的 `d`、`lambda`、`tau_n=n^{-12}` 及 `ell=sqrt(tau_n/lambda)`。

## 1. (B.18)：O tail

### 1.1 从 raw observations 推导恒等式

`P_1(T hat a)=1`，`Y=beta_0 T+mu_0+epsilon`。任取 represented near-best `g_mu`，令 `w=u/v`。则

\[
\widehat\beta_O^{raw}-\beta_0
=P_1(\epsilon w)+P_1\{\epsilon(\widehat a-w)\}
+P_1\{(\mu_0-g_\mu)w\}
+P_1\{(\mu_0-g_\mu)(\widehat a-w)\}
+P_1\{(g_\mu-\widehat\mu)\widehat a\}.
\]

这就是 (B.17)，无遗漏 covariance/denominator term。

### 1.2 正确的 calibration tail

Lemma 5 在 confidence `z` 下给 multiplier envelope `K(r||f||+w_z||f||+r^2+w_z^2)`。最大化 offset quadratic 后只能得到

\[
H_\mu(a_0)\le K(r^2+w_z^2),
\]

而不是 (B.12) 的 `K r^2`。由 `lambda=K(r/d)^2`、`d>=K r` 和 objective comparison，

\[
\|\widehat a-\widetilde a\|_n
\le K\{d+(d/r)w_z+\ell\},
\]

进而同一 bound 控制 `||hat a-w||_n`（`||a_0-w||_n=O(w_z)` 被 `d/r>=c` 吸收）。

### 1.3 五项逐项 bound

在相应 sigma-fields 下：

\[
|P_1(\epsilon w)|\le Kw_z,
\]

\[
|P_1\{\epsilon(\widehat a-w)\}|
\le K\{d+(d/r)w_z+\ell\}w_z,
\]

\[
|P_1\{(\mu_0-g_\mu)w\}|\le K(aw_z+w_z^2),
\]

\[
|P_1\{(\mu_0-g_\mu)(\widehat a-w)\}|
\le K(a+w_z)\{d+(d/r)w_z+\ell\},
\]

而 calibration term 由 corrected objective bound 与 initial-fit square bound 给

\[
|P_1\{(g_\mu-\widehat\mu)\widehat a\}|
\le K\{(x+r+w_z)^2+r^2+r w_z+w_z^2+\tau_n\}.
\]

展开并把所有量用共同非负 envelope 支配，得到

\[
\begin{aligned}
|\widehat\beta_O-\beta_0|\le K[&ad+x^2+r^2+\lambda d^2+\tau_n+\ell(a+r)\\
&+(1+a+d+x+r)w_z+(ad/r)w_z+r w_z\\
&+(1+d/r)w_z^2+w_z^3+\ell w_z],
\end{aligned}
\]

与 (B.18) 的显示 RHS 一致。结论：**(B.18) CONDITIONAL PASS**；公式本身可重证，但论文给出的 (B.12)-(B.15) 必须按 M-003 修正。

## 2. (B.20)：O expectation

### 2.1 deterministic absorption

`lambda d^2=K r^2`，`r<=C(s+h_n)`，`d<=K(y+r+rho_n)`，O-safe 有 `a<=x<=y`、`s<=x`。

- `ad<=K(ay+a r+a rho_n)`；若 `h_n<=y`，`ar<=K(ay+x^2)`；若 `y<h_n`，`a<=x<=y<h_n`，故 `ar<=h_n^2<=2q`。
- `r^2<=K(s^2+h_n^2)<=K(x^2+q)`。
- `ad/(r sqrt n)<=K(ay+x^2+q)`，用 `r>=C h_n` 与同一 `h_n<=y`/`y<h_n` 分支。
- `d/(rn)<=B_pi/(C sqrt{n log(en)})<=Kq`。
- `tau_n`、`ell(a+r)`、`ell/sqrt n` 均为 `O(q)`。

### 2.2 layer cake

令 `F(z)` 为 (B.18) 的递增 RHS，误差已 clip，故 `E<=6`。对 `1<=z<=c_2n`，

\[
P\{E>F(z)\}\le K e^{-z}.
\]

于是

\[
E E\le F(1)+\int_1^{c_2n}K e^{-z}F'(z)dz+6Ke^{-c_2n}.
\]

每个 `(z/n)^{p/2}` 的贡献为常数倍 `n^{-p/2}`；`e^{-c_2n}<=Cq`。若 `c_2n<1`，由 `n>=1` 可直接用 `q>=sqrt(c_2)` 吸收 bounded loss。故

\[
\sup_{P\in\mathcal P(\Gamma)}E_P|\widehat\beta_O-\beta(P)|
\le C_O(q+ay+x^2).
\]

结论：**(B.20) CONDITIONAL PASS**，仅继承 M-003；积分本身 PASS。

## 3. (B.29)：R tail

### 3.1 denominator 与 signed identity

令 `e_pi=hat pi-pi_0`、`r_m=hat m-m_0`，

\[
D=P_1(T-\widehat\pi)^2=P_1(u-e_\pi)^2.
\]

展开得 (B.26)。在 uniform event 上 `D>=v_-/2`。又

\[
Y-m_0=\beta_0u+\epsilon,
\]

所以 numerator 减 `beta_0D` 后

\[
D(\widehat\beta_R^{raw}-\beta_0)
=P_1\{\epsilon(u-e_\pi)\}-P_1\{r_m(u-e_\pi)\}
+\beta_0\{P_1(ue_\pi)-P_1e_\pi^2\},
\]

即 (B.28)，符号正确。

### 3.2 termwise bounds

(B.22) 已含 `delta_z=K(r+w_z)`，因此 objective comparison 合法给

\[
\|r_m\|_n\le K\{d+r+w_z+(d/r)w_z+\ell\}.
\]

在 `F_T` 下 outcome noise centered；在 `F_X` 下 `P_1(r_mu)` centered；propensity calibration event 在 fitted index 代入前 uniform。分解 `e_pi=(hat pi-g_pi)+(g_pi-pi_0)` 后，四个 displayed term 合并并除以 `D>=v_-/2`，得到

\[
\begin{aligned}
|\widehat\beta_R-\beta_0|\le K[&bd+y^2+r^2+\lambda_Rd^2+\tau_n+\ell(b+r)\\
&+(1+b+d+y+r)w_z+(bd/r)w_z+r w_z\\
&+(1+d/r)w_z^2+w_z^3+\ell w_z],
\end{aligned}
\]

即 (B.29)。未发现遗漏 sign、covariance 或 denominator amplification。

结论：**(B.29) CONDITIONAL PASS**，公式及 sigma-field 顺序 PASS，但共同上游 (B.9) 需 M-002 的联合类 lemma。

## 4. (B.30)：R expectation

R-safe 有 `y<x`、`b<=y<x`，`r<=C(t+h_n)`，`d<=K(x+y+r+rho_n)`。

- `bd<=K(bx+y^2+q)`。
- `bd/(r sqrt n)<=K(bx+y^2+q)`：若 `h_n<=x`，`b h_n<=bx`；若 `x<h_n`，`b<=y<x<h_n`，故 `b h_n<=h_n^2<=2q`。
- `d/(rn)<=Kq`，其余 powers 与 O 分支相同。

用同一 layer-cake identity 得

\[
\sup_{P\in\mathcal P(\Gamma)}E_P|\widehat\beta_R-\beta(P)|
\le C_R(q+bx+y^2).
\]

结论：**(B.30) CONDITIONAL PASS**，只继承 M-002；积分和 endpoint 处理 PASS。
