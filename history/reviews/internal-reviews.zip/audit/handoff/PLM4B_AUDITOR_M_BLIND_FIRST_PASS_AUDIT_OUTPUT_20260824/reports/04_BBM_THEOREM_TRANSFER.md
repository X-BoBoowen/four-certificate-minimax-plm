# BBM Theorem 2.1 transfer：原始定理、符号与假设映射

## 1. 原始来源

- Peter L. Bartlett, Olivier Bousquet, Shahar Mendelson, *Local Rademacher Complexities*.
- 随包版本：author version，封面日期 14 May 2004，36 个 PDF 页。
- 期刊版本：*The Annals of Statistics* 33(4), 1497-1537 (2005).
- DOI：`10.1214/009053605000000282`。
- 被移植定理：Theorem 2.1。
- 定位：随包作者版 PDF p. 6；journal pp. 1503-1504。作者版 PDF p. 7 是后续讨论/Corollary 2.2，不是新增 transfer 假设。
- 随包源文件 SHA-256：`43D23EF69350F3B9B42D79D9D123267EE89F6AAE83C813B9880B556F1AD0A787`。

## 2. 源定理所用记号

源定义

\[
P_nf=n^{-1}\sum_{i=1}^n f(X_i),\qquad Pf=E f(X),\qquad
R_nf=n^{-1}\sum_{i=1}^n\sigma_i f(X_i),
\]

以及 `R_n F=sup_{f in F}R_n f`。`E_sigma R_n F` 是给定 data 后对 signs 的 conditional Rademacher average，`E R_n F` 再对 data 取期望。

Theorem 2.1 第一部分：若 `F` 中函数取值于 `[a,b]`，且存在 `r>0` 使 `Var(f(X))<=r` 对所有 `f` 成立，则每个 `x>0`，以至少 `1-e^{-x}` 概率，

\[
\sup_{f\in F}(Pf-P_nf)
\le \inf_{\alpha>0}\left[2(1+\alpha)E R_nF
+\sqrt{2rx/n}
+(b-a)(1/3+1/\alpha)x/n\right].
\]

同一结论也适用于 `sup(P_n f-Pf)`。第二个、更复杂的 empirical-Rademacher bound 未被本文使用。

## 3. 逐项映射表

| 源定理字段 | 本文对象 | 核查 |
|---|---|---|
| `F` | `W^pm := W union (-W)` | 对称扩类后 one-sided supremum 等于 absolute supremum |
| observation `X_i` | 本文 iid observation `Z_i` | 仅改名 |
| source `[a,b]` | `[-B,B]` | range length 为 `2B` |
| source variance `r` | `sigma^2` | `Var(W)<=E W^2<=sigma^2`，因 centered |
| source confidence `x` | `z` | 二者范围均为正实数 |
| source tuning `alpha` | `1` | 合法固定值；不需取得 infimum |
| `sup(Pf-P_nf)` | `sup_W abs(P_nW)` | `PW=0` 且类对称 |
| `E R_n F` | 本文 `R` | 对称类的 sign supremum等于 absolute sign supremum；normalization 均为 `1/n` |
| measurability | countable `W` | countable supremum可测；负扩类仍 countable |
| source failure | `e^{-z}` | 本文写 `2e^{-z}`，是保守放宽 |

## 4. 常数重算

设 `alpha=1`：

\[
2(1+\alpha)R=4R.
\]

variance term：

\[
\sqrt{2rz/n}=\sqrt{2\sigma^2 z/n}.
\]

range term：

\[
(b-a)(1/3+1/\alpha)z/n
=(2B)(1/3+1)z/n
=8Bz/(3n).
\]

所以源定理直接给出更强的

\[
P\left\{Z>4R+\sqrt{2\sigma^2z/n}+8Bz/(3n)\right\}\le e^{-z}.
\]

本文 (B.2) 的 RHS `2e^{-z}` 因而成立。

## 5. 边界与隐藏条件

- `B=0`：所有函数值为 0，`Z=R=0`，结论平凡。
- `sigma=0`：每个 centered 函数方差为 0，故逐函数几乎处处为 0；countability 允许取共同 full-measure event，结论平凡。也可用正 variance upper bound 取极限。
- singleton class：负扩类至多两函数，映射仍成立。
- 未引入 clipping、conditioning、fixed point、critical radius、star-shapedness 或 data-dependent class。
- 本 transfer 只给 Lemma 4；Lemma 5 的 localization/peeling 是本文自己的后续论证，不属于 BBM transfer。

## 6. 判定

**PASS / HIGH confidence.** 未发现 theorem number、版本、量词、方向、normalization、probability 或常数移植错误。
