# 独立推导与反例尝试日志

| ID | 对象 | 压力测试/独立计算 | 结果 | 作用 |
|---|---|---|---|---|
| L-01 | Appendix A zero budgets | `a=s=b=t=0`, singleton zero classes | `R(0)/(3*0)=0/0`，命中 M-001 | 真实端点缺口 |
| L-02 | BBM transfer | singleton centered Rademacher class；再对称扩类 | 常数 4、sqrt term、8B/3 与源定理一致 | 支持 H2 PASS |
| L-03 | BBM sigma=0 | centered variance-zero countable class | 公共同概率一事件上全类为 0 | 边界通过 |
| L-04 | Lemma 5 localization | 最小 radius、退化零类、无需 rescaling 的 inner ball | 固定差分类可闭合；无需 star-shapedness | 支持 Lemma 5 固定类版本 |
| L-05 | Joint initial class | 令 `f approx -gamma pi_0` 尝试 cancellation | 仅 combined norm 不足；必须用 (B.8) 同时控制 gamma，命中 M-002 | 说明缺失 lemma 非机械调用 |
| L-06 | O calibration all-z | Rademacher treatment + countable dense constant difference class | offset supremum有 polynomial tail，不能被 `K bar s^2` 以 `e^{-cn}` 控制 | 反驳 (B.12) all-z 形式，M-003 |
| L-07 | Corrected O tail | 将 `w_z^2`、`(d/r)w_z` 放回五项恒等式 | 额外项正好是 (B.18) 已显示的 `ad w_z/r`、`d w_z^2/r` | 主 tail 可修复 |
| L-08 | Tail integration | 从 `z=1` 开始，显式导数/Jacobian；clipped remainder | 得 `n^{-p/2}` moments，未把大偏差 bound 积到 0 | B.20/B.30 积分通过 |
| L-09 | Selector algebra | 1,000,000 个随机 budget 点 + 零/tie faces | 无 (B.31) 违反点；随机搜索仅作旁证 | 支持 H5 |
| L-10 | Unsafe O cell | `t<s/2` 极端 | `x<=y` 强迫 `b>s/2`，故 P term 足够 | fallback 通过 |
| L-11 | Unsafe R cell | `s<t/2` 极端 | `y<x` 强迫 `a>t/2`，故 O term 足够 | fallback 通过 |
| L-12 | q lower | `n=1`、`v_0` 接近 0 或 `B_0^2` | probabilities、K_q、TV、gap 仍合法；常数可随 rho 缩小 | H6 通过 |
| L-13 | P raw law | 手工核查 conditional `E(Y given X)`、`E(TY given X)` 与 common-reference equality | PLM、共同参考与 target gap 一致 | H7 通过 |
| L-14 | O raw law | 将 Delta 偏离 `gamma eta/(v_0+gamma^2)` | common-reference/observable moment 同时失败；正确 Delta 通过 | 构造识别充分 |
| L-15 | ab public leak | 尝试把 Walsh dictionary 误放进 singleton public pair | 会改变机制；论文实际 pair 未泄漏 | H9 通过 |
| L-16 | M imbalance | `s<<t` 与 `t<<s` | 分别用 `w<=s`、`w<=t` 后两个 budget 都成立 | H10 通过 |
| L-17 | Dictionary integer | `p=ceil(exp(64Nr^2))`，branch `Nr^2>=8` | p 正整数且有限 dyadic cube 可容纳 p 个非平凡 Walsh characters | floor/empty 风险排除 |
| L-18 | max-to-sum | 全零、`a=t`、`b=s`、`s=0`、`t=0` | 无除法；`S0<=X<=2S0` | H11 assembly 通过 |
| L-19 | saturation support | 条件支持 `u=plus/minus B_0` 与 `T in [-B_0,B_0]` | intersection 只允许 `pi_0=0` | saturation identification 通过 |
| L-20 | Hellinger | `delta=0.1` Bernoulli pair | coefficient 是 `sqrt(0.96)` 而非 `0.96`；平方为 0.96 | 命中 M-004，TV chain仍正确 |

## 随包自动检查

下列脚本均以 exit code 0 结束：

- `P_verify_exact_identities.py`
- `O_verify_exact_identities.py`
- `AB_verify_exact_identities.py`
- `AB_falsifier_raw_laws.py`
- `M_verify_exact_identities.py`
- `M_falsifier_raw_laws.py`

这些结果只支持有限原子恒等式、已编码 fixtures 和 mutation detection；没有被用于证明渐近/非渐近量词、measurability、minimax placement 或全参数不等式。
