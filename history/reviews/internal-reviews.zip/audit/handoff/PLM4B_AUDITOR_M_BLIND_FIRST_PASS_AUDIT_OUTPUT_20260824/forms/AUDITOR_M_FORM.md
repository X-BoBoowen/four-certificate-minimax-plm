# Auditor M — mathematical correctness form

Name: Expert M (AI-assisted independent mathematical audit)  
Institution/affiliation: N/A—AI system; no human affiliation claimed  
Relevant expertise: theoretical statistics/ML, empirical processes, localized Rademacher complexity, concentration, minimax testing, Le Cam/chi-square/TV mixture arguments, measurability and minimax quantifiers  
Date audit began: 2026-08-24  
Date audit completed: 2026-08-24  

## Scope covered

- [x] H1
- [x] H2
- [x] H3
- [x] H4
- [x] H5
- [x] H6
- [x] H7
- [x] H8
- [x] H9
- [x] H10
- [x] H11
- [x] H12

## Overall determination

- [ ] PASS
- [ ] FAIL
- [x] NEEDS CLARIFICATION

Commission-schema mapping: **CONDITIONAL PASS**.

Material findings and exact locators:

M-001, PDF p. 10, Appendix A, localized-complexity display: zero budgets include the undefined quotient at radius zero. M-002, PDF pp. 11-12, Lemma 5 and (B.8)-(B.9): the joint scalar/function localized-complexity certificate is invoked but not proved. M-003, PDF pp. 13-14, (B.12)-(B.18): the all-z O-calibration step omits the required z/n term; (B.18) can be recovered because its displayed amplification terms already dominate the correction. M-004, PDF p. 27, lines 1404-1408: the Bernoulli Bhattacharyya coefficient is missing a square root in prose, although the ensuing TV bound uses the squared coefficient correctly.


Unresolved questions:

No unresolved issue presently changes the headline rate. Novelty/exhaustiveness relative to all literature was not certified. Exact implementation constants hidden in generic K_j constants were checked only for existence/dependence, not numerically optimized.


Limits of this review:

AI-assisted audit, not a human professional opinion. No claim of formal proof-assistant verification. Attribution-only references not supplied in the ZIP were not all re-proved. Automated scripts were treated only as falsification aids.


Typed name: Expert M (AI-assisted independent mathematical audit)  
Signature: Expert M—AI-assisted independent mathematical audit (verifiable by output SHA-256 ledger; not a human handwritten signature)  
Date: 2026-08-24  
