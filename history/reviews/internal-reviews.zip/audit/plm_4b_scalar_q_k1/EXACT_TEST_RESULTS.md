# Exact K1 Validation Results

## Test discipline

The test module was created before the checker. Its first run failed with ModuleNotFoundError for scalar_q_checker, establishing a red test before implementation. After the minimal squared-domain checker was added, all tests passed. A later exact sweep initially failed only because its asserted accounting total was entered as 618 while the generated set contained 642 cases; the expected accounting value was corrected to the independently countable set size, and the mathematical predicates were unchanged.

## Arithmetic model

- Parameters and every reported comparison use Python Fraction rational arithmetic.
- Quantities involving square roots are compared through nonnegative squares.
- The continuous-domain result is proved symbolically in the proof certificate.
- The 642-point sweep is explicitly a falsifier search, not an exact proof of the continuous domain.
- No floating-point result is used as a certificate.

## Final command result

9 tests, 9 PASS, 0 FAIL, 0 ERROR.

The tests cover:

1. exact reproduction of \(B_0=64,v_0=1,n=1\) under the old definition;
2. exact target-cap repair of that point;
3. strict activation of each of the three cap branches;
4. \(n=1,2,15,16\) across small, near-saturation, minimum-\(B_0\), and large-\(B_0\) cases;
5. target equality and atom-probability equality;
6. exhaustive/unique splice allocation at \(n=16\) and strict budget boundaries;
7. positivity and budget-independence of the revised scalar and consumer constants;
8. rejection of illegal \(B_0,v_0,n\) inputs;
9. 642 exact-rational falsifier cases over six \(B_0\) values, rational variances from near zero to near \(B_0^2\), and six sample sizes from 1 to \(10^6\).

## Certified threshold chain

For every checked legal point, the checker verifies

\[
\beta^2\le9,\quad
\eta_n^2\le\frac1{256n},\quad
h^2=K_q\le\frac1{64n},\quad
\chi^2_{2n}<\frac1{31}<\frac1{16},\quad
\operatorname{TV}_{\rm cross}<\frac3{16}<\frac14.
\]

Validation files:

- validation/sanity_checks/plm_4b_scalar_q_k1/test_scalar_q_k1.py
- validation/sanity_checks/plm_4b_scalar_q_k1/scalar_q_checker.py

Verdict: exact validation supports, but does not replace, the symbolic all-\(\rho\) certificate.
