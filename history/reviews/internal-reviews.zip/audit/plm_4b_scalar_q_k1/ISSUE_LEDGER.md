# K1 Issue Ledger

| Issue | Entry state | K1 action | Exit state |
|---|---|---|---|
| Ω-T01 | K0 closed for fixed \(c_{\rm rad}>0\) | authority carried forward | closed; no new credit |
| Ω-T02 | missing \(c_{\rm rad}>0\) theorem field confirmed | PI decision recorded; no paper edit | correction required in future theorem field |
| S-002 / RN-001 | sole active verified defect | raw-law cap, distance, envelope, and splice audit | locally certified in proof assets |
| S-001 / M-001 | registered inactive | no repair | open unchanged |
| M-002 | registered inactive | no repair | open unchanged |
| M-003 | registered inactive | no repair | open unchanged |
| M-004 | registered inactive | no repair | open unchanged |
| Measurability/triangular-array presentation | registered inactive | no repair | open unchanged |
| Novelty/significance borderline | registered inactive | no review | open unchanged |

Candidate status remains mathematically contested and the formal percentage remains 82%.
