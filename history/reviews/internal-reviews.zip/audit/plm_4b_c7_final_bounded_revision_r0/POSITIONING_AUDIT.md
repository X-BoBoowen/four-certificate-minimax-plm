# Bounded positioning audit

## Verdict

PASS. The revision changes contribution hierarchy and explanatory precision only.

## Adopted hierarchy

Primary contribution:

- matching necessity of `O=t(a wedge t)` and `P=s(b wedge s)`;
- unbounded order separation from the inherited lower envelope on legal rays;
- matching finite-sample characterization in the stated theorem field.

Explicitly inherited:

- TAME's two-branch upper architecture;
- Gu--Yin--Cai--Fan's `q+AB+M` lower structure;
- structure-agnostic/fixed-pilot framing and fuzzy/product-testing ancestry.

Secondary structural strengthening:

- Proposition 3 and Appendix L put the five hard subfamilies inside the compatible-law family induced by one pre-data finite public pair for a fixed sample size and budget cell;
- the scalar global Q1 lower does not require this common pair, because the outer supremum already dominates component-specific pair bounds before maximum-to-sum algebra;
- the Walsh pair is called engineered and cell-dependent, not natural, universal, or deployable.

## Scope checks

- Title, theorem statements, proposition statements, model, assumptions, quantifiers, and bibliography are unchanged.
- The abstract now defines the two directional terms before calling them O/P and assigns laws to a compatible-law family, not to a public pair.
- No priority, collision-free, natural-class, practical-superiority, common-rule, adaptation, or computational claim was introduced.

Final `main.tex` SHA-256: `6328C60D9D5AE8ACC4EE4FF510FA216A07F96A29231DB57501D925E42653CFAA`.
