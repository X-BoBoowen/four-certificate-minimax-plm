# Build and visual audit

## Build result

- Engine: Tectonic 0.17.0, SHA-256 `99FFCFDBF1EBF8BDDA9E791942E3D06AEDB12463FDDC33F07DE6F5211C8BF08D`.
- Master-R10: 42 pages, 371,704 bytes, SHA-256 `02A2E29B82CEE800CC235BE03A72F59A19678E927BE07FE59C6D3D8C679DD3FD`.
- Candidate-C8: 42 pages, 371,704 bytes, SHA-256 `5A6A0952BEE0EFEFC01A95B6F24763D190414ED36950C03440C99CF381651330`.
- LaTeX errors, undefined references/citations, duplicate labels, overfull boxes, underfull boxes, and unresolved TeX/package warnings: 0 in both logs.
- The console's Fontconfig default-config notice did not enter either TeX log and did not affect font resolution or rendering.

## Layout boundaries

- Main text conclusion: page 9.
- References begin: page 10.
- Appendix A begins: page 11.
- Appendix B begins: page 12.
- Proof-event ledger begins: page 23.

## Anonymity and format

- Official ICLR 2027 review template marker is present.
- Metadata contains only generic LaTeX creator/producer fields and a creation timestamp; author, title, subject, and keyword metadata are absent.
- No account name, local absolute path, project identity, OpenAI/ChatGPT identifier, or user number was found in extracted PDF text.

## Equivalence and visual inspection

- R10 and C8 non-build scientific source trees are byte-identical.
- The PDFs differ at the binary level only consistently with their two-second `CreationDate` difference.
- Extracted page text is identical; 42/42 Poppler-rendered page PNG SHA-256 values are identical.
- Five contact sheets covering all pages and focused pages 9--12, 16, 20--25, and 41--42 were visually inspected.
- No clipping, overlap, blank page, corrupted equation, bad page break, or stranded heading was found. The additional terminal whitespace on page 42 is the natural end of Appendix L, not missing content.
