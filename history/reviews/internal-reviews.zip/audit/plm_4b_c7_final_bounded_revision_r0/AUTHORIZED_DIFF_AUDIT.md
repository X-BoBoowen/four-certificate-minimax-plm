# PLM-4B-C7 final bounded revision: authorized-diff audit

Audit time: `2026-08-27T23:03:49.4833560+08:00`.

## Result

PASS. Relative to both controlling parents, the only changed scientific source files are:

- `main.tex`: 30 inserted lines and 20 deleted lines, confined to nine positioning opcodes at parent line intervals `[33,33]`, `[50,50]`, `[279,279]`, `[282,282]`, `[314,316]`, `[385,388]`, `[419,419]`, `[440,442]`, and `[454,459]` (one-based presentation).
- `appendices/B_upper_proof.tex`: 399 inserted lines and 65 deleted lines, all within the authorized proof-bookkeeping file.

Every other non-build file in each derived tree is byte-identical to its parent. The R10 and C8 scientific source trees are byte-identical to each other.

## Protected semantics

- Paper title: unchanged.
- Theorem 1 statement and rate: byte-identical.
- Proposition 2 and Proposition 3 statements: byte-identical.
- Q1/M1 quantifiers, fixed infinite standard-Borel space, model, assumptions, learner information, lower constructions, Appendix L mathematics, figures, and bibliography: unchanged.
- No new theorem, experiment, lower construction, scientific lift, or H2 source was introduced.

## Final source hashes

- `paper/master_r10/main.tex` and `paper/iclr2027_candidate_c8/main.tex`: `6328C60D9D5AE8ACC4EE4FF510FA216A07F96A29231DB57501D925E42653CFAA`.
- `paper/master_r10/appendices/B_upper_proof.tex` and its C8 counterpart: `568BD9EDE2087EEEEF8982826A80BB8CB013B19DF6B8C6CF6F0B7B6F85AE8E11`.
