# Proof replay audit

## Verdict

PASS. The proof-bookkeeping repair closes the reported event-attribution gap without changing Theorem 1, its rate, the model, or learner information.

## Initial fits and process events

- Exactly seven countable-core Lemma B.3/B.4 calls are formed before fitted-index substitution.
- All seven use the same admissible confidence parameter `z`; the finite union is absorbed into `K_4 exp(-z)`. There is no invalid `z+log 64` endpoint.
- Treatment and joint comparators have explicit scalar residual-square Bernstein events. The basic inequalities use empirical Cauchy--Schwarz.
- The two comparator slacks are proof-only. Each scalar tail inequality has a slack-independent failure bound and is passed to zero by tail-probability continuity; no infinite event intersection is formed.
- The empirical-radius conversions for the treatment and joint fits are explicit and uniform before insertion of the fitted index.

## D0 certificate

For `D0=P1(Tu)`, `E(Tu)=v`, `Var(Tu)<=B0^2 v`, and `|Tu-v|<=2B0^2`. Bernstein gives

`|D0-v| <= B0 sqrt(2 v z/n) + 4 B0^2 z/(3n)`.

With `c0=v_-/(32B0^2)`, the two deviations are at most `v/4` and `v/24`; hence `D0>=17v/24>=v_-/2`. This is attributed to `E_D0,z`, not to the process event.

## O replay

- O calibration (B.12)--(B.16) uses the process, D0, and exact treatment-fit events.
- The fixed outcome comparator has its own empirical-norm event.
- The three weighted terms condition on the correct fields: two on `F_T`, one on `F_X`. Each conditional bound is integrated before the unconditional union bound.
- `E_O,z` is exactly a six-event finite intersection and has failure `K_O,0 exp(-z)` on `1<=z<=c2 n`, with `c2<=c0`.
- (B.18) is first proved for the raw O output; projection nonexpansiveness transfers it to the clipped output. The zero-treatment branch is separately absorbed.

## Direct R denominator

Conditioning on `F_2` fixes `e_pi`. Then

`W_i=(u_i-e_pi(X_i))^2`, `m_pi=v+||e_pi||_2^2`, `0<=W_i<=B_D^2`, `|W_i-m_pi|<=B_D^2`, and `Var(W_i|F_2)<=B_D^2 m_pi`.

Conditional Bernstein therefore uses `B=B_D^2` and `sigma^2=B_D^2 m_pi`. With `c_den=v_-/(32B_D^2)`, its deviations are at most `m_pi/4` and `m_pi/48`, so `D>=m_pi/2>=v_-/2`; the deterministic upper bound is `K_den=B_D^2`. No localized-process event is used to handwave the denominator.

## R replay and selector

- R calibration and the empirical norm of `m_tilde-m0` use the exact fit events.
- The fixed propensity comparator and three fitted weighted inequalities have separate events and correct conditioning.
- `E_R,z` is exactly a six-event finite intersection and has failure `K_R,0 exp(-z)` on `1<=z<=c3 n`, with `c3<=c_den`.
- (B.29) is first proved for the raw R output and then transferred to its clipped version by projection.
- The six weak-order selector cells are explicitly enumerated; a boundary-heavy grid of 14,641 points passed every (B.31)--(B.32) inequality.
- Unsafe cells, all-zero budgets, finite `n`, ties, cap equality, and the fixed-Gamma Q1 competitor order remain covered.

## Constant direction

`C_rad`, `K_lambda=1`, `K_d=8`, `vartheta_rho=B_pi/8`, and `delta_rho=vartheta_rho/C_rad` are fixed upstream. Downstream constants depend only forward on this tuning. The parsed constant DAG is acyclic and passed on both derived sources.
