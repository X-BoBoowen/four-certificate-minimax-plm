# Test report

Final run date: `2026-08-27` (Asia/Shanghai).

## Results

| Suite | Result |
|---|---:|
| Historical authoritative regression, 13 native entry points | 301/301 |
| R10/C8 source, event-ledger, claim-boundary, and mutation gates | 141/141 |
| R9/C7 selector-integration regression | 82/82 |
| Constant-DAG parser tests | 3/3 |
| Live R10 constant DAG | PASS |
| Exact cap/selector/fallback/clipping/zero-treatment checks | failures=0 |
| Final PDF/build/render verification | 23/23 |

All executed processes returned exit code zero. The historical PDF-infinity test was run with the installed Python 3.11/PyMuPDF environment; this avoids treating a missing optional module in the bundled Python as a mathematical failure.

## Required hostile mutations

The round-specific suite rejects deletion or corruption of:

- D0 attribution;
- treatment or outcome comparator events;
- the O or R final intersection;
- the direct conditional R Bernstein step;
- the explicit event ledger;
- empirical-norm transfers in O or R;
- raw/clipped projection justification;
- comparator tail-continuity and the no-infinite-intersection rule;
- the missing `+` in the three-term outcome radius;
- the common admissible `z` in the seven process calls;
- downstream retuning of `K_d`, `K_lambda`, `vartheta_rho`, or `C_rad`;
- O/P-primary, TAME/Gu-inherited, same-pair-secondary, engineered/cell-dependent, law-family, and outer-supremum positioning boundaries.

## Validation sources

- `validation/plm_4b_c7_final_bounded_revision_r0/test_revision.py`: `FD616D7E879461D56144C201D233BFAE7C82EED6503A73528328E56B07E5505A`.
- `validation/plm_4b_c7_final_bounded_revision_r0/verify_build.py`: `EAACDB72A25B1C7D34A9A7377027EC2F7DBF1A662502BCC6FEE787A8213B0150`.

Tests are regression evidence and do not replace the proof replay recorded separately.
