# Primary-source index

Audit cutoff: `2026-08-24 (Asia/Shanghai)`. Hashes identify local snapshots. Search non-hit has no novelty value. `Primary record` may be an author/final PDF, an official proceedings PDF, an arXiv full text, or—where full text is access-restricted—an official DOI metadata record.

## Works actually cited in the candidate

| Work | Local primary record and SHA-256 | Version / official locator | Candidate location | Claim carried |
|---|---|---|---|---|
| Bartlett, Bousquet, Mendelson (2005), *Local Rademacher Complexities* | `primary/bartlett_bousquet_mendelson_author_version.pdf` — `43D23EF69350F3B9B42D79D9D123267EE89F6AAE83C813B9880B556F1AD0A787`; Crossref record `C5F969...3AB6` | author version dated 2004; Annals of Statistics 33(4), 1497–1537, DOI `10.1214/009053605000000282` | Appendix B, Lemma 4 | sole external proof leaf: Theorem 2.1 concentration transfer |
| Robinson (1988), *Root-N-Consistent Semiparametric Regression* | `primary/crossref_robinson_1988.json` — `4C28F35A6F1BFA2ACFA3AD64F84B0E251F0ADB3D3862288F73F244A3544B6FA5` | Econometrica 56(4), 931–954, DOI `10.2307/1912705`; publisher full text is access-restricted | §11 | classical PLM context only |
| Chernozhukov et al. (2018), *Double/Debiased Machine Learning...* | author PDF `1D51DFFAD897599EA63C6049BB935477C8EDA521FC7A3CC48F00EF4EA86AD00E`; Crossref `AC34E4...39F` | Econometrics Journal 21(1), C1–C68, DOI `10.1111/ectj.12097` | §11 | orthogonal/DML context only |
| Foster & Syrgkanis (2023), *Orthogonal Statistical Learning* | arXiv PDF `1C3CA25BD8A208C75CE2DB090B74271FDD229529031701E64BED14DF22962344`; Crossref `A77418...945` | Annals of Statistics 51(3), 879–908, DOI `10.1214/23-AOS2258` | §11 | orthogonal-learning context only |
| Robins, Tchetgen Tchetgen, Li, van der Vaart (2009), *Semiparametric Minimax Rates* | Crossref `6C51C208C5A5A1F483E3997AFC48EE3211223A16FC20D8B710877C0763ADBBDE`; OA-status manifest retained | EJS 3, 1305–1321, DOI `10.1214/09-EJS479` | §11 | fuzzy/product-lower ancestry, not a proof import |
| Gu (2025), *Open Problem: Structure-Agnostic Minimax Risk for Partial Linear Model* | `primary/gu_colt_2025.pdf` — `72A96E3352B728F6696F00260082097C441B4CD012327DBAA022E207BCE17E0B` | PMLR 291, 6220–6224 | §11 | native four-budget question |
| Gu, Yin, Cai, Fan (2026), *Optimally Taming Biases...* | `primary/gu_yin_cai_fan_2606.06368.pdf` — `AAE23C43852FD85CA2CBCDF218B36844A2FFAB1819F187E16A0DA62F875B99AD` | arXiv:2606.06368v1 | §11, Table 5 | closest four-budget theorem field; upper/calibration ancestry |
| Gu (2026), *Optimal Use of a Black-Box Learner...* | `primary/gu_blackbox_2607.21541.pdf` — `82D53DBB082D831FC89377EF26E1D84A5AC6DDBEB782D2CA4DCB58E21756A446` | arXiv:2607.21541v1 | §11, Table 5 | TAME editing/two-branch upper and adjacent lower result |
| Jin & Syrgkanis (2026), *Sharp Structure-Agnostic Lower Bounds...* | `primary/jin_syrgkanis_2512.17341.pdf` — `0C7328D1C7D8CB462CB6ED05D3C347C3209244D4BC90D45EC5366FF07FA9197C` | arXiv:2512.17341v2 | §11 | general fuzzy/invariant lower ancestor |
| Jin, Mackey, Syrgkanis (2025), *It's Hard to Be Normal...* | `primary/jin_mackey_syrgkanis_2507.02275.pdf` — `3B458299F3437117AD59412AABD675EF47CEFF47AD8627028CEAAA616D181247` | arXiv:2507.02275v3 / NeurIPS 2025 | §11 | treatment-noise lower ancestor |

## Additional closest-work full texts used only for collision/attribution audit

- Jin–Syrgkanis ATE/ATT ancestor: `jin_syrgkanis_2402.14264.pdf`, `F26E9D98452C1E67F12661125D88B9ECE69FCB99E726816A968CA3B55659623E`.
- Balakrishnan–Kennedy–Wasserman fuzzy-testing ancestor: `balakrishnan_kennedy_wasserman_2305.04116.pdf`, `57BE5566AE48FA193771C7E0F9DC586617D95D5213BEC94316755CB90559C400`.

## Acquisition limitation

The file `robins_et_al_2009_project_euclid_download_response.html` is a retained failed publisher-download response, not a PDF and not evidence. Robinson full text is paywalled. Their candidate uses are contextual, not proof dependencies; official DOI metadata and independent bibliographic records were used for field verification. Human Auditor S should obtain institutionally accessible full texts if deeper content verification is desired.
