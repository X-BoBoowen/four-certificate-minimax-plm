# BBM transfer field matrix

| Source field | Source statement | Paper field | Transfer argument | Status | Auditor comment |
|---|---|---|---|---|---|
| Sample | `n` iid observations | `n` iid observations | identity |  |  |
| Function class | measurable `F` | countable centered `W` | use `F=W union -W`; countability gives measurability |  |  |
| Range | values in `[a,b]` | `|W|<=B` | set `[a,b]=[-B,B]`; width `2B` |  |  |
| Variance | `Var f<=r` | `E W^2<=sigma^2`, centered | set `r=sigma^2`; same for negatives |  |  |
| Supremum | one-sided `sup(P-P_n)` | `sup |P_nW|` | centering plus negative closure |  |  |
| Rademacher term | `E R_n F` | `R_n(W)` | symmetric closure and paper absolute supremum coincide |  |  |
| Tuning | `inf_{alpha>0}` | fixed coefficient 4 | choose legal `alpha=1` |  |  |
| Confidence | every `x>0`, failure `e^{-x}` | `z`, failure `2e^{-z}` | `x=z`; candidate is conservative |  |  |
| Mean coefficient | `2(1+alpha)` | `4` | `alpha=1` |  |  |
| Variance coefficient | `sqrt(2rx/n)` | `sqrt(2sigma^2z/n)` | direct substitution |  |  |
| Range coefficient | `(b-a)(1/3+1/alpha)x/n` | `8Bz/(3n)` | `(2B)(4/3)=8B/3` |  |  |
| Measurability | measurable suprema | countable class | countable supremum of measurable functions |  |  |
| Clipping | none | none in Lemma 4 | no transfer |  |  |
| Conditioning | unconditional iid theorem | unconditional iid Lemma 4 | no hidden conditional application |  |  |
| Fixed point | none in Theorem 2.1 | none in Lemma 4 | not required |  |  |
| Extra lemma | none beyond theorem and symmetry | none claimed | verify no later step is folded into Lemma 4 |  |  |
