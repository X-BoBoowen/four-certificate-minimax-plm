# Reference-field verification

Method: compare the candidate bibliography against at least two available identity sources among primary PDF title page, official proceedings/journal record, Crossref, and arXiv record. This verifies bibliographic fields; it does not verify novelty.

| Key | Author order | Title | Year/version | Venue/pages/DOI | Result of preparatory check | Human comment |
|---|---|---|---|---|---|---|
| `bartlett2005local` | matches PDF/Crossref | matches | 2005 | AoS 33(4), 1497–1537; DOI matches | no field conflict identified |  |
| `robinson1988root` | matches Crossref/official record | matches | 1988 | Econometrica 56(4), 931–954; DOI matches | no field conflict identified |  |
| `chernozhukov2018doubledebiased` | matches author PDF/Crossref | matches journal title | 2018 | Econ. Journal 21(1), C1–C68; DOI matches | no field conflict identified |  |
| `foster2023orthogonal` | matches arXiv/Crossref | matches | 2023 | AoS 51(3), 879–908; DOI matches | no field conflict identified |  |
| `robins2009semiparametric` | matches article record (Robins first) | matches | 2009 | EJS 3, 1305–1321; DOI matches | display-order differences on institutional pages do not change article author order |  |
| `gu2025structureagnosticplm` | matches official PMLR PDF | matches | 2025 | PMLR 291, 6220–6224 | no field conflict identified |  |
| `gu2026tamingbiases` | matches arXiv PDF/API record | matches | v1, 2026-06-04 | arXiv:2606.06368 | no field conflict identified |  |
| `gu2026optimalblackbox` | matches arXiv PDF/API record | matches | v1, 2026-07-23 | arXiv:2607.21541 | no field conflict identified |  |
| `jin2026sharpstructureagnostic` | matches arXiv PDF/API record | matches | v2, 2026-01-05 | arXiv:2512.17341 | no field conflict identified |  |
| `jin2025hardnormal` | matches arXiv PDF/API record | matches | v3, 2025-11-07 | arXiv:2507.02275; NeurIPS 2025 | no field conflict identified |  |

Preparatory status is not a human source-audit verdict. Auditor S must confirm every row and record discrepancies.
