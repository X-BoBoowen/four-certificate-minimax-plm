# BBM Theorem 2.1 transfer dossier

## Source identity

- Peter L. Bartlett, Olivier Bousquet, Shahar Mendelson, *Local Rademacher Complexities*, Annals of Statistics 33(4), 1497–1537 (2005), DOI `10.1214/009053605000000282`.
- Local author-version PDF: `primary/bartlett_bousquet_mendelson_author_version.pdf`.
- PDF SHA-256: `43D23EF69350F3B9B42D79D9D123267EE89F6AAE83C813B9880B556F1AD0A787`.
- Source locator: Theorem 2.1, author-version PDF pp. 6–7; published pagination pp. 1503–1504.
- Candidate locator: Appendix B, p. 11, Lemma 4, equation (B.2).

## Source theorem transcribed for mapping

For a class `F` of measurable functions taking values in `[a,b]`, with `Var[f(X)]<=r` for every `f`, and iid sample size `n`, Theorem 2.1 bounds the one-sided supremum `sup_f(Pf-P_n f)`. For each `x>0`, with probability at least `1-exp(-x)`, it is at most

`inf_{alpha>0} { 2(1+alpha) E R_n F + sqrt(2rx/n) + (b-a)(1/3+1/alpha)x/n }`.

The source states the corresponding reverse one-sided bound as well. The dossier relies on the PDF, not a secondary quotation.

## Candidate transfer

Let `F=W union (-W)`, `[a,b]=[-B,B]`, `r=sigma^2`, `x=z`, and `alpha=1`. Centering gives `Pf=0`. Symmetry gives

`sup_{f in F}(Pf-P_n f)=sup_{w in W}|P_n W(w)|=Z`.

The symmetric Rademacher supremum has expectation exactly the paper's `R_n(W)`. Substitution gives `2(1+1)=4`, the variance term `sqrt(2 sigma^2 z/n)`, and range term `(2B)(1/3+1)z/n=8Bz/(3n)`. The source failure probability is `exp(-z)`; the paper's `2exp(-z)` is a weaker bound.

## Hidden-condition screen

- Measurability: the source requires measurable suprema; candidate countability supplies it.
- Separability: no additional uncountable-class separability argument is needed after countable representation.
- Clipping: none is used in the transfer.
- Conditioning: none is used in Lemma 4; later conditional arguments invoke different elementary inequalities.
- Fixed point / critical radius: none is required by Theorem 2.1 as used here.
- Centering: explicitly assumed by Lemma 4 and used to turn `Pf-P_nf` into `-P_nf`.
- Range transformation: source width is `b-a=2B`, not `B`.
- One-/two-sided: achieved by physical enlargement by negatives before invoking the source.

## Preparatory conclusion

The field-by-field substitution reproduces (B.2), with the candidate using a conservative failure factor. No extra hidden lemma was identified in this transfer. This is a preparatory source audit, not an independent human verdict; Auditor M/S must complete the blank status column in `BBM_FIELD_MATRIX.md`.
