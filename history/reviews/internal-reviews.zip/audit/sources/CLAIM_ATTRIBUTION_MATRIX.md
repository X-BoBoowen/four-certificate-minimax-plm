# Claim-attribution matrix

| Candidate statement | Candidate locator | Source responsibility | Required restraint | Human status |
|---|---|---|---|---|
| Classical PLM and orthogonal learning establish root-n behavior under sufficient nuisance control | §11 | Robinson 1988; Chernozhukov et al. 2018; Foster–Syrgkanis 2023 | contextual, not exact present theorem |  |
| Product lower bounds and fuzzy-testing methodology are established ancestry | §11 | Robins et al. 2009 and adjacent full texts | method ancestry only |  |
| COLT problem isolates the four-budget PLM interface | §11 | Gu 2025 | open problem, not solution |  |
| Closest four-budget lower displays `q+AB+M` rather than separate O/P necessity | §11/Table 5 | Gu–Yin–Cai–Fan Theorem A.1, PDF pp. 19–20 | statement-field comparison; no priority claim |  |
| Editing objectives and two-branch architecture are inherited | §§4,11 | Gu 2026 TAME; Gu et al. 2026 | present upper is not called a new generic editor |  |
| General linear-functional and treatment-noise results are adjacent lower ancestors | §11 | Jin–Syrgkanis; Jin–Mackey–Syrgkanis | different access/loss/model fields |  |
| Lemma 4 concentration bound | Appendix B, p. 11 | BBM Theorem 2.1 | exact theorem transfer; see field dossier |  |
| `ab` lower certificate | Appendix E | native proof in current manuscript | must not be described as inherited proof |  |
| `M` lower certificate | Appendix F | native proof in current manuscript | must not be described as inherited proof |  |

No row establishes novelty by search non-hit.
