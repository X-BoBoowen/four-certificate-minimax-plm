# Closest-work theorem-field matrix

| Field | Candidate | Gu et al. A.1 | Gu TAME | Other lower ancestors | Collision question for Auditor S |
|---|---|---|---|---|---|
| Target/model | bounded real-valued PLM coefficient, constant residual variance | four-budget PLM | semiparametric black-box learner | ATE/ATT/general functionals/noise models vary | Is there a direct specialization to exactly this bounded experiment? |
| Access | represented public pair, known four upper budgets | analogous public classes | learner/calibration interface | anchored neighborhoods or other oracles often differ | Is every inclusion direction stated correctly? |
| Quantifiers/loss | `sup_Gamma inf_delta_Gamma sup_P`, expected L1, all n | closest analogue | upper algorithm statements | quantile/MSE/local fields vary | Does any source have the same native operator order? |
| Upper | matching `q+AB+M+O+P`, Borel selector | nonmatching displayed upper | two-branch ancestor | not applicable | Is the present closure a corollary once M1/Q1 is imposed? |
| Lower | five native mechanisms | displayed `q+AB+M` | shared-class adjacent lower | fuzzy/product/invariant mechanisms | Does any primary theorem directly yield both O and P? |
| Boundary | E/I/S envelope stratification | not displayed | not displayed | noise-law regimes differ | Is saturation identification already a theorem in the same model? |
| Computation | arbitrary Borel, no efficiency claim | access varies | algorithmic | varies | Is candidate wording consistent with this limitation? |

Preparatory full-text comparison found no direct theorem-field identity among the inspected works. This is not a novelty finding; Auditor S must independently check the strongest specialization/collision route.
