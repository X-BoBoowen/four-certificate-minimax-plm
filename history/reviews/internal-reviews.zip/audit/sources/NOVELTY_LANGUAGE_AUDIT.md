# Novelty and significance language audit

## Candidate language retained for human review

- “Our contribution is the combination of …” is scoped to the assembled theorem field.
- “closest inherited lower envelope” and “closest four-budget statement” are comparative and must be tied to an explicit source/table.
- “the exact residual difference” is described as a matching law in one frozen native model, not as a universal method.
- TAME receives explicit credit for editing/calibration and the two-branch architecture.
- Fuzzy testing, product lower mechanisms, and general lower ancestors receive explicit credit.
- The manuscript states that theorem-level novelty remains a judgment and that search non-hit is not evidence.

## Forbidden or unsupported language

- `first`, `the first`, priority claims, or universal absence claims;
- “new generic editor,” “new general calibration principle,” or an inherited-proof claim for `ab`/`M`;
- a polynomial-time, adaptive, practical-superiority, confidence-interval, or uniform-to-saturation claim;
- a claim that Gu et al. proved the present O/P lower certificates or full E/I/S result.

## Gu et al. Theorem A.1 source caveat

The public arXiv PDF inspected at `gu_yin_cai_fan_2606.06368.pdf`, pp. 19–20, contains Appendix A.1 and the displayed Theorem A.1 statement. No separately posted public supplement containing an independent proof artifact was identified in the frozen source set as of the cutoff. This is a historical source-availability fact, not evidence that the theorem is wrong and not novelty credit for the candidate. Auditor S should record any subsequently located public supplement.

## Human task

For every comparative adjective, identify the exact primary theorem field and attempt the strongest direct-specialization argument. A non-hit must be reported only as a bounded search outcome.
