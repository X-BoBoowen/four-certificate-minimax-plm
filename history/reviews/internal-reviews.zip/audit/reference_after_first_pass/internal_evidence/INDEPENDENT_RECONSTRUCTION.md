# Independent reconstruction

The final appendix was reconstructed against the frozen theorem statement and native Q1/M1 interface, not by treating K3-R1 or K5--K11 conclusions as black-box proof citations.

The upper branch was replayed from concentration through the two calibrated edits and the public selector.  The reconstruction exposed and repaired two source-level weaknesses: the weighted conditional inequality is now stated explicitly, and the localized supremum is now an exact published-theorem transfer rather than an unnamed standard claim.

The lower branch was replayed from raw atom probabilities.  Each family now contains a separate model certificate, public-class/budget certificate, common-reference likelihood, direct Gram computation, product-mixture distance, testing reduction, and all-n/boundary closure.  The independent replay detected a factor-two error in the ab Le Cam constant; E.12--E.13 and the assembly now use 16384.

The boundary branch was not inferred from the interior construction.  Appendix H separately derives the empty stratum, the saturation identification identity, a uniform moment upper, and a singleton Hellinger lower.

Outcome: the PDF plus the single exact Type-B citation is sufficient to replay the theorem without opening an internal strategy or validation file.  Independent human verification remains pending by policy.
