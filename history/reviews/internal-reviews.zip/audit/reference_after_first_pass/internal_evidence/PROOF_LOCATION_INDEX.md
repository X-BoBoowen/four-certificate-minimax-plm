# Proof-location index

This index applies identically to Master-R3 and Candidate-C1-R1.

| Result | Main locator | Complete proof locator |
|---|---|---|
| Native model, M1 access, minimax order | Sections 2--3 | Appendix A |
| Three-stratum theorem | Theorem 1 | B.7, G, H |
| Global fixed-pair upper | Proposition 2, Section 4 | Appendix B, especially (B.1)--(B.33) |
| q lower | Section 6 | C.1--C.3, (C.1)--(C.9) |
| P lower | Section 5 | C.4--C.7, (C.10)--(C.21) |
| O lower | Section 5 | Appendix D, (D.1)--(D.15) |
| ab lower | Section 6 | Appendix E, (E.1)--(E.13) |
| M lower | Section 6 | Appendix F, (F.1)--(F.15) |
| Lower assembly and constants | Sections 5--6 | Appendix G, (G.1)--(G.3) |
| Empty and saturation strata | Sections 3 and 8 | Appendix H, (H.1)--(H.6) |
| Measurability and nonclaims | Sections 2 and 9 | Appendix I |
| Independent reconstruction and hostile audit | Section 9 | Appendix J |
| In-PDF dependency graph | none | Appendix K |

All 66 obligation rows have a concrete locator in PROOF_OBLIGATION_MATRIX.md.
