# Hostile falsifier

The audit tried to falsify the complete theorem through the following routes.

1. Quantifier swap: rejected by the explicit Q1 order and the fixed-pair-to-outer lift in B.7.
2. Nonmeasurable optimizer: rejected by countable first-within-tolerance selection in B.1 and I.
3. Conditioning leak: O and R terms are now bounded under their stated sigma-fields; weighted concentration is explicit.
4. Hidden star-shapedness: Lemma 5 works shell by shell and states that no star-shaped class is assumed.
5. Random-index amplification: the R calibration is uniform over the represented countable index set before substitution.
6. Denominator optimism: O and R denominators receive separate lower certificates; unsafe cells use the public zero fallback.
7. Bayes-risk addition: Appendix G takes a maximum of lower bounds on one scalar minimax risk, then applies a deterministic equivalence.
8. Incompatible lower witnesses: each witness uses the same native Q1/M1 input model and expected-L1 risk, though the outer public pair may differ as allowed by the supremum.
9. Common-reference zeros: every lower appendix proves strict positivity before defining likelihood ratios.
10. Gram circularity: P, O, ab, and M print direct raw-law Gram calculations in addition to kernel formulas.
11. Small-n/zero-budget escape: q and explicit branch closures cover these faces.
12. Saturation extrapolation: Appendix H uses a separate identification and Hellinger argument.
13. Source corruption: the protected R0 five-defect fingerprint remains reproducible; both new trees have zero scanner defects.
14. Citation black box: only Lemma 4 is Type B, and its published theorem fields are mapped explicitly.

No certified falsifier survived.  Search or random-grid non-hits are not used as proof.  The strongest remaining Reviewer-2 request is an independent human replay of the constant absorption in the O/R expectation bounds.
