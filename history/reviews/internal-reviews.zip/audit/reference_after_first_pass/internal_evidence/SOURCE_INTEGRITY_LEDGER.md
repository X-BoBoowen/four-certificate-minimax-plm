# Source-integrity ledger

## Frozen defect target

The protected Candidate-C1-R0 tree was never edited.  The preregistered scanner reports exactly five defects there: one lone carriage return in B_upper_proof.tex and four lost-backslash qquad tokens across C_q_p_lower.tex, D_o_lower.tex, and E_ab_lower.tex.

## R1 repair result

Both new trees pass the same scanner with zero defects.  The scan covers TeX, BibTeX, style, class, bibliography-style, Markdown, Python, CSV, SVG, and generated TeX sidecars.  It checks lone CR, C0 controls, replacement and zero-width characters, Unicode math in TeX, suspicious lost-slash math tokens, brace/environment balance, duplicate labels, and undefined references/citations.  Compilation separately closes undefined commands.

| Tree | Defects | Result |
|---|---:|---|
| paper/iclr2027_candidate_c1 (protected R0) | 5 | Expected historical RED; unchanged |
| paper/iclr2027_candidate_c1_r1 | 0 | PASS |
| paper/master_r3 | 0 | PASS |

The canonical bibliography and both local R1 copies are byte-identical with SHA-256 B2E428B79BC5E8C6F2984BFE747E7583DE0DDAA787A3C3C7B865097DF8CC0B37.  The R1 source introduces no new bibliography entry: the exact Type-B source was already present as bartlett2005local.

Verdict: source-integrity fatal gate passes without modifying any protected source.
