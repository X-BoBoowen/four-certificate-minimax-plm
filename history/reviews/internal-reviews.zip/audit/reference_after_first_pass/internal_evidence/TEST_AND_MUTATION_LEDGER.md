# Test and mutation ledger

## Test-first source-integrity gate

- Test written before any R1 source repair:
  `validation/plm_4b_proof_complete_r1/tests/test_source_integrity_gate.py`.
- First system invocation did not execute the test because the Windows Python
  alias was unavailable.  A second invocation found the bundled Python but no
  optional `pytest` package.  Neither event is a source-integrity result.
- The unchanged test function was then executed through the Python standard
  library against the protected `paper/iclr2027_candidate_c1/` tree.
- Expected RED result: exit code 1.
- Certified historical hits: lone CR in `appendices/B_upper_proof.tex` line 44;
  literal lost-backslash `qquad` tokens in `appendices/C_q_p_lower.tex` line
  15, `appendices/D_o_lower.tex` line 6, and
  `appendices/E_ab_lower.tex` line 6.
- The initial deliberately broad token heuristic also flagged ordinary prose
  uses of the English word `text`.  Before any repair, the production scanner
  narrowed that class to TeX mathematical contexts.  This is a test-precision
  correction, not relaxation of the frozen source-integrity rule.

No R1 manuscript source had been created or repaired when this RED result was
observed.

## Final GREEN and mathematical checks

- The unchanged protected R0 target still produces exactly the five frozen defects.
- Candidate-C1-R1: zero source-integrity defects.
- Master-R3: zero source-integrity defects.
- Exact rational validation scripts for the P, O, ab, and M lower families were rerun and passed their registered identities and boundary fixtures.
- Registered corruption tests for the finite lower families were rerun and rejected the altered laws/identities.
- A one-million-point random selector grid found no violation of the deterministic B.31--B.33 inequalities.  This is recorded only as heuristic sanity evidence; the manuscript's cell proof is controlling.
- Both manuscripts compile without errors or undefined items.  Scanner failure, compilation failure, solver failure, or a search non-hit was never interpreted as a mathematical conclusion.

Final disposition: GREEN.  The source gate distinguishes the protected historical defects from the repaired, newly created trees exactly as preregistered.
