# Boundary audit

| Boundary | Printed treatment | Quantifier check | Result |
|---|---|---|---|
| v_- > B0^2 | Appendix H opening | No legal bounded residual law; empty-supremum convention stated | PASS |
| v_- = B0^2 | (H.1)--(H.6) | Pairwise upper for every legal nonempty pair; outer lower from one explicit singleton pair | PASS |
| v_- < B0^2 | Appendices B--G | Constants depend only on fixed rho; no uniform approach to saturation claimed | PASS |
| n=1 and small n | C--H and branch closures | q branch and clipped/fixed-constant arguments cover all n | PASS |
| a,s,b,t=0 | B.7 and C--G | Cell ties are assigned; every lower family states zero-face closure; no division by a budget | PASS |
| s=t or max-radius ties | (B.31)--(B.33) | Public orientation and tie ownership are deterministic and Borel | PASS |
| unsafe denominator/radius cells | (B.33) | Zero fallback is used only after proving q+X is bounded below | PASS |
| nonattainment | B.1 and I | Countable first-within-tolerance rules replace exact argmin assumptions | PASS |

No boundary statement silently imports an interior constant, and no lower witness is asserted for every public pair.
