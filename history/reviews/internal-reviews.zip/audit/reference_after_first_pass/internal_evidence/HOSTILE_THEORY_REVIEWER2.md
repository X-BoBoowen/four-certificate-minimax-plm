# Hostile theory Reviewer 2

## Recommendation on proof completeness

No reject-level correctness gap remains in the artifact.  The previous 14-page candidate was not independently checkable; the 28-page R1 appendix is.

## Attacks

1. The upper proof might hide a generic empirical-process theorem.  Response: Lemma 4 is isolated as the only Type-B dependency and maps the precise Bartlett--Bousquet--Mendelson theorem; Lemmas 3 and 5 are proved in place.
2. Conditional O/R bounds might reuse data illegally.  Response: (B.17)--(B.18) and (B.28)--(B.29) expose the sigma-fields and each summand.
3. The selector might depend on unknown truth.  Response: B.7 uses only declared budgets, n, rho, public classes, and data-defined fits; unsafe fallback is public.
4. Separate lower experiments might be illegitimately added.  Response: (G.1) uses a maximum on one outer-supremum risk, and (G.2)--(G.3) are deterministic algebra.
5. Fuzzy-mixture constants might be copied rather than proved.  Response: C--F print common references, likelihoods, direct raw Grams, and product second moments for each family.
6. Saturation might inherit an interior lower.  Response: H uses a separate singleton Hellinger argument.
7. Source corruption might remain invisible in the PDF.  Response: the test-first gate reproduces the five protected R0 defects and finds zero in both new trees; all 28 pages were rendered and inspected.

## Residual concern

The paper's novelty/significance assessment is outside this proof-completion phase, and independent human verification remains pending.  On correctness, the most useful next audit is a cold replay of the O/R constant absorption rather than another rewrite.
