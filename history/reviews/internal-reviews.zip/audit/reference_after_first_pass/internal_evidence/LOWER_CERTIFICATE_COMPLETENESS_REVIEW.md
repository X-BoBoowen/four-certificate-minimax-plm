# Lower-certificate completeness review

## Verdict

PASS.  Every lower component has a finite, native Q1/M1 certificate in Appendices C--F; Appendix G performs only a legal maximum-to-sum assembly; Appendix H separately closes the boundary.

## Certificate checks

- q/P: C.1--C.7, especially (C.1)--(C.21), state the testing lemma, common reference, likelihood kernels, direct raw Gram, distance bound, and all-n closure.
- O: (D.1)--(D.15) separately establish raw-law legality, public budgets, common reference, two Gram routes, mixture distance, and testing.
- ab: (E.1)--(E.13) contain the singleton-public-class certificate and corrected Le Cam constant 16384.
- M: (F.1)--(F.15) contain one common public pair, separate s/t budget bounds, common reference, two Gram routes, and all-n closure.
- Assembly: (G.1)--(G.3) takes the maximum of lower bounds on the same outer minimax scalar; it never adds Bayes risks from different priors.
- Boundary: (H.1)--(H.6) gives identification, a pairwise moment upper, and one explicit outer-lower witness using an independent Hellinger calculation.

Exact rational programs reproduce the finite identities, but the printed algebra, not program success, is the proof authority.
