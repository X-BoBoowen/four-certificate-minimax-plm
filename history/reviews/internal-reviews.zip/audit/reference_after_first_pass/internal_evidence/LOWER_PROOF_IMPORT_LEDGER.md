# Lower-proof import ledger

Historical K5--K11 files identify the intended finite experiments but discharge no manuscript obligation.  Appendices C--H give the raw laws, public classes, budgets, likelihoods, Gram calculations, testing distances, constants, and boundary closures.

| Component | Final locator | Required certificates | Status |
|---|---|---|---|
| Testing calculus | Lemma 6, (C.1)--(C.3) | Expected-L1 testing, TV/chi-square, finite-mixture Gram tensorization | CLOSED-A |
| Complexity budgets | Lemma 7, (C.4) | Finite-class all-radii bound with the manuscript sample convention | CLOSED-A |
| Shared channel | C.2, (C.5)--(C.7) | Positivity, normalization, exact mean, exact residual variance, envelope | CLOSED-A |
| q | C.3, (C.8)--(C.9) | Native singleton pair, common reference, product distance, all-budget legality | CLOSED-A |
| P | C.4--C.7, (C.10)--(C.21) | Raw six-atom laws, common exact variance, public pair, budget, common reference, likelihood kernels, independent raw Gram, mixture TV, all-n closure | CLOSED-A |
| O | Appendix D, (D.1)--(D.15) | Raw laws, exact variance, public pair, both budgets, common reference, two Gram routes, mixture TV, all-n closure | CLOSED-A |
| ab | Appendix E, (E.1)--(E.13) | Equal-variance laws, singleton public classes, common reference, two Gram routes, mixture TV, corrected Le Cam factor, all-n closure | CLOSED-A |
| M | Appendix F, (F.1)--(F.15) | Common finite public pair, separate stochastic budgets, common reference, two Gram routes, mixture TV, all-n closure | CLOSED-A |
| Assembly | Appendix G, (G.1)--(G.3) | Maximum over five witnesses, not addition of Bayes risks; deterministic maximum-to-sum equivalence | CLOSED-A |
| Empty/saturation | Appendix H, (H.1)--(H.6) | Empty-class convention; identification at equality; moment upper; independent Hellinger lower | CLOSED-A |

Exact checks were rerun for the P, O, ab, and M finite families.  They verify stated rational identities and corruption rejection; they are supporting checks, not replacements for the printed derivations.  The ab testing constant is corrected to the denominator 16384 throughout E.12--E.13 and the assembled constant.

Verdict: all lower leaves are Type A and independently verifiable from the appendix.
