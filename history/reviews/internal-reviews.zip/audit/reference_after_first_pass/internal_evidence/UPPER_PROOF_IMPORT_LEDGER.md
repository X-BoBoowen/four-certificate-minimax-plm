# Upper-proof import ledger

Final target: Proposition 2 and Theorem 1 on the strict-interior stratum, under the exact Q1/M1 minimax order in Appendix A.  Historical K3-R1 files are provenance only; every manuscript-level step is reconstructed in Appendix B.

| Block | Final locator | Imported idea | Manuscript reconstruction | Status |
|---|---|---|---|---|
| Countable optimization | B.1 and Appendix I | Public approximate minimizers | Explicit first-within-tolerance rule over declared countable dense subsets | CLOSED-A |
| Scalar concentration | Lemma 3, (B.1), and weighted form (B.1a) | Bounded Bernstein/Hoeffding tools | Statements and proofs, including conditioning and deterministic weights | CLOSED-A |
| Localized supremum | Lemma 4, (B.2) | Variance-sensitive concentration | Exact Type-B transfer from Bartlett--Bousquet--Mendelson (2005), Theorem 2.1, pp. 1503--1504; signed-class, range, variance, countability, and parameter map printed | CLOSED-B |
| Localized processes | Lemma 5, (B.2a)--(B.5) | Multiplier and square-process bounds | Shell decomposition, contraction, variance control, and geometric failure sum printed | CLOSED-A |
| Initial fits | B.2, (B.6)--(B.9) | Treatment and joint least squares | Basic inequalities, curvature, approximation tolerance, and all-z radii printed | CLOSED-A |
| O edit | B.3--B.4, (B.10)--(B.20) | Outcome-oriented calibration | Borel domain, oracle comparator, five-term identity, conditional termwise bounds, tail integration, and endpoint absorption printed | CLOSED-A |
| R edit | B.5--B.6, (B.21)--(B.30) | Two-sample residual calibration | Comparator, random-index calibration, denominator control, six-term identity, conditional termwise bounds, and tail integration printed | CLOSED-A |
| Selector | B.7, (B.31)--(B.33) | Oriented four-cell rule | Exact public cells, safe-branch inequality, unsafe-cell fallback, tie ownership, Borel composition, and Q1 lift printed | CLOSED-A |

Quantifier audit: the estimator is public and pair-dependent exactly inside the infimum of the frozen Q1 order.  No common estimator across class pairs, efficiency, unknown-budget adaptation, or uniformity in rho is claimed.

Strongest remaining human check: independently replay the constant absorption in (B.18), (B.20), (B.29), and (B.30).  The terms and sigma-fields are now explicit, so this is a finite verification task rather than an open proof obligation.

Verdict: complete manuscript-level upper proof; one and only one Type-B leaf.
