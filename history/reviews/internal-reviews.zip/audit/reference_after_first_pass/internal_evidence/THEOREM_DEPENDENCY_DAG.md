# Theorem dependency DAG

Root assumptions: bounded PLM, fixed rho, known budgets, countable public M1 classes, N=2n, and expected absolute loss.

```text
Root assumptions
├── Upper branch
│   ├── Lemma 3: scalar and weighted concentration
│   ├── Lemma 4: localized-supremum transfer [only Type B leaf]
│   └── Lemma 5: localized multiplier/square events
│       ├── initial fits
│       ├── O edit -> O identity -> O expectation
│       └── R edit -> R identity -> R expectation
│           └── four-cell selector + unsafe fallback
│               └── Proposition 2 -> strict-interior upper
├── Lower branch
│   ├── Lemma 6: testing/TV/Gram calculus
│   ├── Lemma 7: finite-class budgets
│   └── exact three-point channel
│       ├── q certificate
│       ├── P certificate
│       ├── O certificate
│       ├── ab certificate
│       └── M certificate
│           └── maximum-to-sum assembly -> strict-interior lower
└── Boundary branch
    ├── v_- > B0^2 -> empty class
    └── v_- = B0^2 -> identification + moment upper + singleton lower
        └── saturation theorem

upper + lower + boundary -> Theorem 1
```

No cyclic dependency occurs.  Historical kernel files are provenance, not nodes.  The only external theorem node is Lemma 4; its field-by-field transfer is printed in the proof.
