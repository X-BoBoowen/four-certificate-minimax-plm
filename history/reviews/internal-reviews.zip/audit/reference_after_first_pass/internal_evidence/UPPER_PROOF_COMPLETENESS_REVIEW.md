# Upper-proof completeness review

## Verdict

PASS.  Proposition 2 can be checked from Appendix B plus the exact citation used in Lemma 4.  No internal K-file is required.

## Review trace

- Lemma 3, (B.1) and (B.1a): bounded scalar and weighted conditional concentration are stated and derived.
- Lemma 4, (B.2): the proof identifies the published theorem, pages, range, variance, signed-class, countability, and parameter substitutions.  This is the only Type-B leaf.
- Lemma 5, (B.2a)--(B.5): shelling, contraction, variance, and failure summation are explicit; star-shapedness is not assumed.
- B.2, (B.6)--(B.9): both approximate least-squares radii include optimization tolerance and curvature.
- B.3--B.4, (B.10)--(B.20): O normalization, comparator, five-term identity, sigma-fields, termwise bounds, and tail integration are printed.
- B.5--B.6, (B.21)--(B.30): R two-sample comparator, random-index calibration, denominator, six-term identity, termwise bounds, and expectation are printed.
- B.7, (B.31)--(B.33): the four cells, ties, unsafe fallback, Borel composition, and exact Q1 quantifier lift are printed.

Strongest objection: constants in the common amplification envelope and expectation absorption are not optimized.  This does not alter the stated rho-dependent rate, but a human verifier should replay (B.18), (B.20), (B.29), and (B.30) term by term.
