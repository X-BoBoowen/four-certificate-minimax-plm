# Items that survived targeted attacks

1. **Zero budgets and zero radius.** I checked `s=0` and `t=0`; (A.1) only uses positive radii, and the `h_n` floor prevents an upper-proof division by zero.

2. **Joint scalar/nuisance cancellation.** I tried `f=-gamma pi_0`. The residual term `gamma u` preserves curvature, so the joint class cannot hide the scalar direction.

3. **BBM direction and constants.** I signed the source class and substituted all fields. Lemma 4 is a conservative exact corollary of BBM Theorem 2.1.

4. **Random fitted-index insertion.** The relevant empirical-process events are uniform over countable public cores before fitted indices are inserted.

5. **Amplified O/R terms.** I tracked every term created by `1/sqrt(lambda)` through (B.17)/(B.28). The required `(ad/r)w_z`, `(bd/r)w_z`, and `(d/r)w_z^2` terms are present and integrable.

6. **Tail bound used outside its range.** The manuscript does not integrate the all-`z` inequality down to zero or beyond `c n`; it uses the `z=1` threshold and clipping.

7. **Selector ties and unsafe cells.** Ties go to O, safe equalities stay safe, and unsafe selected cells use a deterministic zero fallback whose risk is absorbed by `q+X`.

8. **Q1 quantifier order.** A pair-specific Borel rule is fixed before `sup_P`; only then is the outer `sup_Gamma` taken. No `sup/inf` exchange was found.

9. **P lower bound.** I checked the sign flip, compensating `kappa`, exact variance, public outcome dictionary, local complexity, common reference, and all-n splice. The witness survived.

10. **O lower bound.** I checked that the common propensity and deleted outcome perturbation define a different channel from P. The target gap and mixture TV survived.

11. **ab lower bound.** The public classes are singletons; Walsh truths remain off class and hidden. Approximation budgets, envelopes, and testing distance survived.

12. **M lower bound.** I separately verified both stochastic budget inequalities rather than relying only on `w=s∧t`. Public access to the full dictionary is already covered by the TV inequality.

13. **Maximum-to-sum assembly.** Different hard pairs are used only to lower-bound the same outer scalar; the proof takes a maximum, not a sum of Bayes risks.

14. **Saturation support argument.** I attempted a nonzero propensity at `v_-=B0^2`; it necessarily violates the treatment envelope at one residual support point.

15. **Lemma 7 false-alarm check.** Text extraction initially made the display look absolute-valued. The original PDF shows the ordinary signed supremum, and applications use symmetric difference classes. I withdrew this concern.

These PASS conclusions reflect checks actually performed, not unchecked remainder.

