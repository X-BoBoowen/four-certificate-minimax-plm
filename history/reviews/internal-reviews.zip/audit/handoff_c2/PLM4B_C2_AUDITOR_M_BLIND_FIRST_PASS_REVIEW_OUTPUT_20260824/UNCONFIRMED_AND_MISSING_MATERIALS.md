# Unconfirmed matters and missing-material record

## No proof-critical missing material

The anonymous manuscript, all appendices, blank forms, H01–H12 routing packets, and the BBM primary-source copy were present. The upper and lower proofs are written as self-contained except for BBM Theorem 2.1. I therefore did not need an internal proof package or reference-stage response.

## Unconfirmed matters

1. **Intended public-class envelope.** The phrase “bounded nuisance classes” may intend a common `B0` envelope, but Appendix A does not say so. This is the condition in Issue M-C2-01.

2. **Non-BBM prior-work claims.** The packet supplied only BBM as a proof dependency. I did not independently verify novelty, priority, or the exact theorem fields of TAME, Gu–Yin–Cai–Fan, Jin–Syrgkanis, or the other cited works. This limits attribution assessment, not the self-contained mathematical derivations audited here.

3. **Explicit numerical upper constants.** Appendix B uses existential fixed constants `K_i(rho)` and says to take a finite maximum. I checked the scaling and absorption logic but did not produce a globally optimized numerical value of `C_rho`. The theorem claims only existence and fixed-field dependence.

4. **Human authentication.** No human reviewer identity, signature, or independent-human verification is available. This output must be treated as AI-assisted red-team material, consistent with `HUMAN_ONLY_REVIEW_NOTICE.md`.

5. **Session/task identifier.** The execution environment did not expose a stable session or task ID.

## Materials deliberately not accessed

No reference answer, solution, internal audit, completed form, reference-after-first-pass package, Expert S report, other reviewer report, or prior output file was opened. The C2 archive did not list any such file.

