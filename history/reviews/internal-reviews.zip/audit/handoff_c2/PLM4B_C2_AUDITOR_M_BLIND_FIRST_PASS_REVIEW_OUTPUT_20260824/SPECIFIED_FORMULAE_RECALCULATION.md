# Independent recalculation of (B.18), (B.20), (B.29), and (B.30)

Throughout, `w_z=sqrt(z/n)`, `q=n^{-1/2}`, and the analysis is on the branch’s certified cell. I used only definitions and earlier established inequalities, not the target displays.

## (B.18): O-branch all-tail inequality

Locator: PDF p. 15 / manuscript p. 15, Appendix B.4.

Set `r=s_bar`, `d=d_pi`, and `ell=sqrt(tau_n/lambda_O)`. From the exact identity (B.17),

`beta_O^raw-beta_0`

is the sum of five terms:

1. `P_1(epsilon w)`;
2. `P_1{epsilon(a_hat-w)}`;
3. `P_1{(mu_0-g_mu)w}`;
4. `P_1{(mu_0-g_mu)(a_hat-w)}`;
5. `P_1{(g_mu-mu_hat)a_hat}`.

Earlier steps give

`||a_hat-w||_n <= K[d+w_z+(d/r)w_z+ell]`,

`||mu_0-g_mu||_n <= K(a+w_z)`,

and, by the calibrated objective,

`|P_1{(g_mu-mu_hat)a_hat}|`

`<=K[(x+r+w_z)^2+r^2+w_z^2+lambda_O(d+w_z)^2+tau_n]`.

The correct conditional weighted inequalities yield, term by term,

`|1| <= K w_z`,

`|2| <= K[d+w_z+(d/r)w_z+ell]w_z`,

`|3| <= K(aw_z+w_z^2)`,

`|4| <= K(a+w_z)[d+w_z+(d/r)w_z+ell]`.

Expanding only nonnegative terms and collecting gives

`|beta_O-beta_0| <= K_10[ad+x^2+r^2+lambda_O d^2+tau_n+ell(a+r)`

` +(1+a+d+x+r)w_z+(ad/r)w_z+(1+d/r)w_z^2+w_z^3+ell w_z]`,

which is (B.18). The two amplified terms have identifiable origins:

- `(ad/r)w_z` comes from `a*(d/r)w_z` in term 4;
- `(d/r)w_z^2` comes from `w_z*(d/r)w_z` in terms 2/4.

I found no missing standalone `(d/r)w_z`, `(d/r)w_z^3`, or `lambda_O^{-1}w_z^2` term.

Verdict: **PASS, HIGH confidence**, conditional on the explicit public-class envelope in M-C2-01.

## (B.20): O-branch expectation

Locator: PDF p. 16 / manuscript p. 16, Appendix B.4.

The deterministic relations are

`h_n^2<=2q`, `r>=C_rad h_n`, `d<=B_pi`,

`d<=K_d(y+r+rho_n)`, and `lambda_Od^2=K_lambda r^2`.

They imply the deterministic base in (B.18) is `O(q+ay+x^2)`. The only nontrivial amplified absorptions are

`(ad/r)q <= K(q+ay+x^2)`

by splitting `h_n<=y` versus `y<h_n`, and

`(d/r)q^2=d/(nr)<=B_pi/[C_rad sqrt(n log(en))]<=Kq`.

For `p=1,2,3`, layer cake gives the scale

`integral_0^infty (z/n)^{p/2} e^{-z} dz = n^{-p/2} Gamma(1+p/2)`.

Thus linear `w_z` terms integrate at `q`, quadratic terms at `q^2`, and the cubic term at `q^3`. The `(ad/r)w_z`, `(d/r)w_z^2`, and `ell w_z` pieces integrate at the separately absorbed scales above. The interval below `z=1` is controlled by the `z=1` threshold; for `z>c_2n`, clipping bounds the residual integral by `6K_11e^{-c_2n}`. If `c_2n<1`, `q>=sqrt(c_2)` absorbs the deterministic clipping loss.

Pointwise tail bounds for each `z` suffice; nested events are not required for layer cake. This yields

`sup_{P in P(Gamma)} E_P|beta_O-beta(P)| <= C_O(q+ay+x^2)`,

which is (B.20).

Verdict: **PASS, HIGH confidence**, conditional on M-C2-01.

## (B.29): R-branch all-tail inequality

Locator: PDF p. 17 / manuscript p. 17, Appendix B.6.

Set `r=t_bar`, `d=d_all`, and `ell=sqrt(tau_n/lambda_R)`. Direct substitution into the ratio, after the denominator event, gives (B.28):

`D(beta_R^raw-beta_0)=P_1{epsilon(u-e_pi)}-P_1{r_m(u-e_pi)}`

` + beta_0[P_1(ue_pi)-P_1e_pi^2]`.

The earlier bounds are

`||e_pi||_n<=K(y+r+w_z)`,

`||r_m||_n<=K[d+r+w_z+(d/r)w_z+ell]`,

plus (B.25) for the random represented difference `pi_hat-g_pi`. Conditional on `F_T`, outcome noise is centered; conditional on `F_X`, treatment residuals are centered. Decomposing `e_pi=(pi_hat-g_pi)+(g_pi-pi_0)` and using the uniform calibration event produces the four displays immediately preceding (B.29). Expanding them and using `D>=v_-/2` yields

`|beta_R-beta_0| <= K_12[bd+y^2+r^2+lambda_Rd^2+tau_n+ell(b+r)`

` +(1+b+d+y+r)w_z+(bd/r)w_z+(1+d/r)w_z^2+w_z^3+ell w_z]`,

which is (B.29).

The first genuinely R-specific step is (B.25): it compares `P_2(Yf)` and `P_1(mf)` while retaining D1 treatment centering. I found the conditioning legal because the uniform event precedes the random fitted difference insertion.

Verdict: **PASS, HIGH confidence**, conditional on M-C2-01.

## (B.30): R-branch expectation

Locator: PDF p. 18 / manuscript p. 18, Appendix B.6.

The deterministic relations give

`bd<=K(bx+y^2+q)`,

`bd/(r sqrt(n))<=K(bx+y^2+q)`,

and

`d/(nr)<=B_all/[C_rad sqrt(n log(en))]<=Kq`.

The split is `h_n<=x` versus `x<h_n`; on the second cell `b<=y<x<h_n`, so `b h_n<=h_n^2<=2q`. The layer-cake calculation is then the same polynomial integration as above, but it uses the independently derived R threshold. The low- and high-`z` truncations are again handled by the `z=1` threshold and clipping. Hence

`sup_{P in P(Gamma)} E_P|beta_R-beta(P)| <= C_R(q+bx+y^2)`,

which is (B.30).

Verdict: **PASS, HIGH confidence**, conditional on M-C2-01.

## First failed step across the four formulas

No algebraic or integration step among (B.18), (B.20), (B.29), and (B.30) failed. The earliest unresolved dependency is upstream: the public-class envelope used by Lemma 5 and the joint class must be uniformly controlled by the fixed theorem field (Issue M-C2-01).
