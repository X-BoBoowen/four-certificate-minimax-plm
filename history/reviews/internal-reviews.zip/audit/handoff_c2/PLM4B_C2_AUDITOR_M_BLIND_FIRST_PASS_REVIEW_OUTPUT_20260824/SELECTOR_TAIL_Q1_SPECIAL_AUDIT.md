# Selector, tail integration, and Q1-lift audit

## Selector definition and observability

Locator: PDF p. 18 / manuscript p. 18, Appendix B.7.

The public quantities are

`x=a+s`, `y=b+t`, `T_mu=ay+x^2`, `T_pi=bx+y^2`,

`I_O=1{x<=y, s_bar<=eta}`, `I_R=1{y<x, t_bar<=eta}`.

The pre-clipped rule is `I_Obeta_O+I_Rbeta_R` and returns zero when both indicators vanish. It is then projected to `[-3,3]`.

- Domain: the full `2n`-sample observation space together with the fixed public pair, budgets, and `rho`.
- Codomain: `[-3,3]` after clipping.
- Tie breaking: `x=y` goes to O.
- Totality: safe O, safe R, unsafe O, and unsafe R are disjoint and exhaustive.
- Unavailable objects: no nuisance truth, best population approximant, realized error, denominator quality, hard coordinate/sign/label, or law is queried.
- Exact versus approximate selections: nuisance fits and edit programs are first-within-`tau_n` approximate minimizers; branch selection itself is exact and deterministic.

## Existence and measurability

Initial empirical minimizers range over supplied countable representations and rational scalar coefficients. Countable infima are Borel, and the first index within tolerance exists by the definition of an infimum.

For O, when the treatment vector is nonzero, choosing the first largest-magnitude coordinate and rationally enumerating the other coordinates gives a countable dense chart of the exact hyperplane `P_1(Ta)=1`. The eliminated coordinate is a Borel rational function of the data on this event. The objective is finite, Lipschitz in `a` on the hyperplane for the bounded difference class, and coercive after adding the positive quadratic. If the treatment vector is zero, the branch returns zero.

For R, the rational enumeration of `R^n`, positive quadratic, and countable supremum yield a Borel approximate minimizer. The uniform process event is established before inserting the fitted difference `pi_hat-g_pi`.

The only qualification is Issue M-C2-01: the class envelope must be a fixed field constant. With that condition, I find the selector Borel.

## Deterministic orientation and fallback

Let `W=T_mu∧T_pi` and `V=min{a+s^2,xy,T_mu,T_pi}`. The manuscript claims

`V<=W<=4V`, `X/5<=V<=6X`.

I checked the six weak-order cells described after (B.31) and additionally tested 300,000 independent random budget quadruples. No violation occurred; the numerical extremes observed were `V/X` between about `0.253` and `1.544`, and `W/V` between `1` and `3.381`, within the analytic constants. On `x<=y`, `T_mu<=2xy<=2T_pi`; the mirror holds on `y<x`, yielding `T_selected<=2W<=48X`.

For fallback, set `delta=eta/C_rad`. If `h_n>delta`, then `delta^2<h_n^2<=2q`. Otherwise O-unsafe implies `s>delta`; if `t>=s/2`, then `M>=s^2/4`, and if `t<s/2`, orientation `x<=y` forces `b>s/2`, hence `P>s^2/2`. The R mirror uses `t`, `a`, and `O`. Clipped zero therefore costs at most a fixed multiple of `q+X`.

## Tail integration

The O and R tail bounds hold for each fixed `z` in `[1,c n]`; they need not be nested. Each threshold is increasing in `z` and is a finite polynomial in `w_z=sqrt(z/n)` with nonnegative coefficients. Layer cake can therefore be applied through the generalized inverse, or equivalently by integrating each monotone monomial against `e^{-z}`.

- `w_z` integrates at scale `q`.
- `w_z^2` integrates at `q^2`.
- `w_z^3` integrates at `q^3`.
- `(d/r)w_z^2` integrates at `d/(nr)`.
- `(ad/r)w_z` and `(bd/r)w_z` integrate at `(ad/r)q` and `(bd/r)q`.
- `ell w_z` integrates at `ell q`.

The tail bound is not extended below its validity range: `z<1` is covered by the `z=1` threshold. It is not extended past `c n`: clipping caps the residual contribution. This directly addresses the risk of integrating a large-deviation formula down to zero.

## Q1 lift

For every fixed legal `Gamma`, the manuscript constructs one Borel rule `delta_Gamma` before the inner law supremum and proves

`sup_{P in P(Gamma)} E_P|delta_Gamma-beta(P)| <= C_rho(q+X)`.

Therefore

`inf_{delta_Gamma Borel} sup_{P in P(Gamma)} risk <= C_rho(q+X)`

for each fixed `Gamma`. The constant is independent of `Gamma`, so taking the outer supremum preserves the same bound. There is no exchange with `inf_delta sup_Gamma`; a different public rule for each public pair is exactly what Q1 permits.

## Verdicts

- Selector existence/measurability: **PASS**, conditional only on M-C2-01’s explicit envelope.
- Tie breaking and fallback: **PASS**.
- Tail integration: **PASS**.
- Q1 lift and quantifier order: **PASS**.

