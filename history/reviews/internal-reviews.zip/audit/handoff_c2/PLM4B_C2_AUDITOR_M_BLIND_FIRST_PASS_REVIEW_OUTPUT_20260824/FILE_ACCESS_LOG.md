# Actual input-file access log

All paths below are relative to `PLM4B_C2_AUDITOR_M_BLIND_FIRST_PASS.zip`. “Read” means content was opened; directory names alone were first inspected to enforce the blind-material boundary.

## Orientation and forms read

- `README.md`
- `HUMAN_ONLY_REVIEW_NOTICE.md`
- `guides/INDEPENDENT_REVIEW_INSTRUCTIONS.md`
- `guides/MODEL_AND_QUANTIFIER_INDEX.md`
- `forms/AUDITOR_M_H1_H12_FORM.md`
- `forms/CREDENTIAL_AND_SCOPE_FORM.md`
- `forms/INDEPENDENCE_AND_CONFLICT_FORM.md`
- `forms/ISSUE_AND_DERIVATION_LOG.md`

## Controlling manuscript and primary source read

- `manuscript/anonymous_manuscript.pdf` — all 31 PDF pages read; proof-critical pages rendered for visual formula verification
- `sources/bartlett_bousquet_mendelson_primary.pdf` — Theorem 2.1 and surrounding definitions read from the supplied author-version source

## H01–H12 packets read

- `packets/H01_MODEL_FIELD_AND_MAIN_QUANTIFIERS.md`
- `packets/H02_EXTERNAL_EMPIRICAL_PROCESS_TRANSFER.md`
- `packets/H03_JOINT_CLASS_LOCALIZATION.md`
- `packets/H04_B9_AND_LOCALIZED_PROCESS.md`
- `packets/H05_O_BRANCH_ALL_Z.md`
- `packets/H06_R_BRANCH_ALL_Z.md`
- `packets/H07_SELECTOR_FALLBACK_AND_Q1_LIFT.md`
- `packets/H08_SCALAR_Q_AND_P_LOWER.md`
- `packets/H09_O_LOWER.md`
- `packets/H10_AB_LOWER.md`
- `packets/H11_M_LOWER.md`
- `packets/H12_ASSEMBLY_BOUNDARIES_AND_END_TO_END.md`

## Integrity/reproduction material read

- `PACKAGE_MANIFEST.tsv`
- `PROVENANCE.tsv`
- `MANUSCRIPT_HASH.txt`
- `reproduction/REPRODUCE.md`
- `reproduction/ENVIRONMENT_PORTABLE.md`
- `checks/current_field_scalar_checks.py`
- `checks/current_upper_geometry_checks.py`
- `checks/current_lower_identity_falsifier.py`

The three non-authoritative check scripts were run only after independent derivations. Their successful output was used as a finite falsifier cross-check, not as proof.

## Prohibited or external material

- Internal audit reports: not accessed.
- Reference answers/solutions: not accessed.
- Completed audit forms: not accessed.
- Expert S or other reviewer opinions: not accessed.
- Reference-after-first-pass material: not accessed.
- Prior review output: not opened or consulted during the C2 review.
- Internet sources: not used; the required BBM original statement was supplied in the packet.

