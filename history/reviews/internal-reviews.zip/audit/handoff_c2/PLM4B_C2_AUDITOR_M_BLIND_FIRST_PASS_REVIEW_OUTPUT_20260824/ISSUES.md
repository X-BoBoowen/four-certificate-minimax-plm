# Complete issue list

## M-C2-01 — public-class envelope is not fixed uniformly

- Audit units: H01, H03, H04, H05, H06, H12
- Verdict: CONDITIONAL PASS
- Severity: MAJOR
- Confidence: HIGH
- Locator: PDF p. 2 / manuscript p. 2, Section 2; PDF p. 11 / manuscript p. 11, Appendix A.2; PDF p. 14 / manuscript p. 14, joint class before (B.9)
- Claim: Proposition 2 has a constant depending only on `rho`, uniformly over every legal public pair.
- First failed step: The proof asserts that `J_mu={gamma T+f(X)}` has envelope `8B0`. The literal field bounds the true nuisances but does not state `|g|<=B0` for every candidate in each public class.
- Author’s route: “bounded nuisance classes,” followed by dominated convergence, contraction, Bernstein, and the `8B0` joint envelope.
- Independent check: Approximation and localized Rademacher constraints do not imply an `L_infinity` envelope. For `{0,L1_E}` with `P(E)=(r/L)^2`, the `L2` scale is `r` while `L` is arbitrary; the normalized local complexity can remain `O(n^{-1/2})`.
- Boundary/counterexample attempt: The spike class attacks the missing implication. I did not prove that it falsifies the final minimax rate, so I classify this as a theorem-field/proof condition rather than a theorem counterexample.
- Why it matters: Lemma 5’s envelope, square contraction, Bernstein range terms, empirical objective domination, and constants uniform over `Gamma` all use a fixed envelope.
- Minimum repair: Require every member of `G_mu` and `G_pi` and every represented candidate to be pointwise bounded by `B0`; or add a common envelope `B_G(rho)` to the fixed tuple and update constants.
- Effect of repair: The legal public-pair field is narrowed/clarified. The rate, budget exponents, selector, lower families, and parameter ranges in `n,a,s,b,t` do not change.
- Unconfirmed: The authors may intend “bounded nuisance classes” to mean exactly `B0`-bounded. Appendix A should say so explicitly because its displayed authoritative list currently does not.

## M-C2-02 — Lemma 3 needs conditional independence

- Audit unit: H04 (local concentration lemma)
- Verdict: CONDITIONAL PASS
- Severity: MINOR
- Confidence: HIGH
- Locator: PDF p. 12 / manuscript p. 12, Lemma 3 and (B.1)
- Claim: Independent variables that are conditionally centered given `F` satisfy (B.1) conditionally on `F`.
- First failed step: The proof multiplies conditional mgfs, which requires conditional independence given `F`; unconditional independence does not imply it.
- Author’s route: Conditional one-variable mgf bounds followed by multiplication.
- Independent counterexample: Let `W_1,...,W_200` be iid Rademachers and `F=sigma(W_1W_2,...,W_199W_200)`. Each `E(W_i|F)=0`. On the event all pair products are one, the sample is 100 duplicated signs. At `z=9`, (B.1)’s threshold is `sqrt(18/200)+18/600=0.33`, while the exact conditional probability of exceeding it is about `8.737198e-4`, greater than `2e^{-9}=2.468196e-4`.
- Why it matters: The abstract lemma is false under its literal wording.
- Minimum repair: State “conditionally independent and conditionally centered given `F`”; repeat the qualification in (B.1a).
- Effect of repair: None on the main theorem. All manuscript calls I checked condition on covariates/treatments or use unconditional iid variables, so the stronger condition holds.
- Unconfirmed: N/A.

No CRITICAL issue and no FAIL was found.
