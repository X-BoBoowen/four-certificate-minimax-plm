# Independent audit of q/P/O/ab/M lower bounds

## Shared testing calculus

Locator: PDF p. 19 / manuscript p. 19, Lemmas 6–7.

Thresholding an estimator at the midpoint gives

`max_l E_{Q_l}|hat_theta-theta_l| >= Delta(1-TV(Q_0,Q_1))/4`.

The factor is correct: each testing error costs at least `Delta/2`, the sum of testing errors is at least `1-TV`, and a maximum is at least half the sum. `TV(P,Q)<=sqrt(chi^2(P,Q))/2` is standard Cauchy–Schwarz.

For a uniform mixture over `2p` coordinate/sign laws with Gram entries `1+K`, `1-K`, and `1`, direct counting gives

`chi^2 = [((1+K)^N+(1-K)^N)/2-1]/p`.

I recomputed the `2p`, `2p`, and `4p(p-1)` ordered-pair counts. Lemma 7 is the ordinary Massart maximum bound; every actual localized application is to a symmetric difference class, so its Rademacher definition is compatible.

## q: scalar root-n witness

Locator: PDF p. 20 / manuscript p. 20, (C.8)–(C.9).

- Public pair: `G_mu=G_pi={0}`.
- Law: `T=+/-sqrt(v_0)`, `Y=(B0/2)R`, and `P_theta(R=1|T=t)=1/2+theta t/B0`.
- Target: `theta=+/-d_rho^*/sqrt(n)`.
- Membership: the probability shift is at most `1/16`; `|epsilon|<=9B0/16`; target and treatment envelopes hold; variance is exactly `v_0=v_-`.
- Distance: relative to the four-atom uniform reference, `K_q=4(d_rho^*)^2v_0/(nB0^2)<=1/(64n)`. With `N=2n`, the exact product second moment is below `1/31`, hence the cross-label TV is below `1/4`.
- Loss lower: target gap `2d_rho^*/sqrt(n)` gives `c_{q,rho}q` with `c_{q,rho}=3d_rho^*/8`.

Stress tests: `n=1`, large `B0`, and `v_-` close to `B0^2` remain legal because the target cap includes `B0/(16sqrt(v_-))`.

Verdict: **PASS, HIGH confidence**.

## P: propensity approximation against outcome resolution

Locator: PDF pp. 20–22 / manuscript pp. 20–22, (C.10)–(C.21).

On the nonparametric branch, `w=b∧s`, `eta=m_rho w/4`, `gamma=lambda_rho s/256`,

`Delta=2 eta gamma/v_0`, `kappa=gamma+Delta eta`.

The labels are

`(beta,pi,mu)=(0,z eta,z gamma)` and `(Delta,-z eta,z kappa)`.

The compensation identities

`kappa=gamma+Delta eta`, `Delta v_0=2 eta gamma`

give the same `E(Y|X)` and `E(TY|X)` while each component remains a legal PLM with exact variance `v_0`.

Public pair: `G_pi={0}` and `G_mu` contains every signed-coordinate `gamma` and `kappa` function before the hidden label/sign/coordinate is drawn. Propensity approximation is `eta<=b`; outcome approximation is zero. The finite outcome difference class has at most `16p^2` elements and envelope `2kappa`; the `log(32p^2)` Massart bound gives the all-positive-radius complexity ratio at most `c_rad s` after the `lambda_rho` scaling.

The label sign averages share the atomwise reference because

`Delta(v_0+eta^2)=eta(kappa+gamma)`.

The likelihood kernels have squared energies `K_0<=s^2/225` and `K_1<=s^2/196`; Walsh orthogonality supplies the off-coordinate Gram entry one. With `p=ceil(exp(64Ns^2))`, the mixture chi-square is exponentially below one. The target gap is

`lambda_rho m_rho s(b∧s)/(512v_0)`.

Splice: if `s^2<q`, then `P<q`; if `n<16`, then `P<=1<=4q`; zero active budgets are trivial. The scalar q lower supplies the remaining branches by a maximum.

Verdict: **PASS, HIGH confidence**.

## O: outcome approximation against propensity resolution

Locator: PDF pp. 22–24 / manuscript pp. 22–24, (D.1)–(D.15).

Here `w=a∧t`, `gamma=lambda_rho m_rho t/4`, `eta=w/256`, and

`Delta=gamma eta/(v_0+gamma^2)`.

Both labels share `pi=z gamma`; their outcome/target pairs are `(0,z eta)` and `(Delta,0)`. The public pair is `G_mu={0}` and a signed Walsh propensity dictionary. Outcome approximation is at most `a`; propensity approximation is zero. The propensity difference class satisfies the `t` budget after the `m_rho<=1/64` and `lambda_rho` scalings.

The common-reference identity is

`Delta(v_0+gamma^2)=gamma eta`.

The two likelihood energies are bounded by `t^2/9` and `t^2/256`, and the same finite-mixture calculation yields TV below `1/2`. The gap is bounded below by

`lambda_rho m_rho t(a∧t)/[1024(v_0+m_rho^2/16)]`.

The small-`t`, small-`n`, and zero branches close against q exactly as in the manuscript. Equality `t^2=q` belongs to the nonparametric branch and satisfies `Nt^2>=8`.

This is not a relabeling of P inside a fixed experiment: the propensity is common, the outcome perturbation is removed, and the denominator is `v_0+gamma^2`.

Verdict: **PASS, HIGH confidence**.

## ab: approximation-product witness

Locator: PDF pp. 24–26 / manuscript pp. 24–26, (E.1)–(E.13).

The public pair is literally `G_mu=G_pi={0}`. The Walsh functions index off-class truths; they are not disclosed candidates. Amplitudes `eta=m_rho b/4`, `gamma=a/512`,

`Delta=2eta gamma/v_0=m_rho ab/(1024v_0)`, `kappa=gamma+Delta eta`

satisfy both approximation budgets and every envelope. Both stochastic complexities are zero, including on zero-budget faces.

The sign-average identity is again

`Delta(v_0+eta^2)=eta(kappa+gamma)`.

The likelihood energies obey `K_0<=S/32`, `K_1<=S/8` for `S=a^2+b^2`. With `S>=q` and `n>=16`, the public mixture dimension gives exponential chi-square control. Expected-loss testing yields `3m_rho ab/(16384v_0)`. If `S<q`, then `ab<q/2`; if `n<16`, `ab<=4q`; q closes these cases.

Verdict: **PASS, HIGH confidence**.

## M: common stochastic witness

Locator: PDF pp. 26–28 / manuscript pp. 26–28, (F.1)–(F.15).

Let `w=s∧t`, `gamma=lambda_rho m_rho w/4`, `eta=lambda_rho w/256`, and

`Delta=gamma eta/(v_0+gamma^2)`.

The public pair contains a signed propensity dictionary and the zero-plus-signed outcome dictionary. Both truths are in class under both labels, so approximation error is zero. The outcome and propensity complexity calculations are separate:

`R_n(Delta G_mu)/(3r') <= 23lambda_rho w^2/(384s) <= c_rad s`,

`R_n(Delta G_pi)/(3r') <= 23lambda_rho m_rho w^2/(6t) <= c_rad t`.

This correctly uses `w<=s` and `w<=t` separately. The common-reference identity and Gram energies are the O-type identities with both amplitudes rescaled; the target gap is of order `lambda_rho^2m_rho w^2`. Small `w`, small `n`, and `w=0` are covered by q. The TV statement already quantifies over every Borel learner with access to the full public dictionary.

Verdict: **PASS, HIGH confidence**.

## Lower assembly and quantifier order

Locator: PDF p. 28 / manuscript p. 28, Appendix G.

For each component pair `Gamma_j`,

`R_pair >= inf_{delta_{Gamma_j}} sup_{P in P(Gamma_j)} risk`.

Taking the maximum over the five valid scalar inequalities is legitimate even though the public pairs differ. No priors or Bayes risks are added.

For `S_0=ab+M+O+P`, direct algebra gives `S_0<=X`. Conversely,

`AB=ab+at^2+bs^2+s^2t^2`,

with `at^2<=O`, `bs^2<=P`, and `s^2t^2<=M` on `[0,1]^4`; hence `X<=2S_0`. Zeros and ties require no division. The maximum-to-sum loss is exactly a factor five, followed by the factor two comparison.

Verdict: **PASS, HIGH confidence**.

## Empty and saturation strata

Locator: PDF p. 29 / manuscript p. 29, Appendix H.

Above `B0^2`, bounded residuals make the law class empty. At equality, `u^2=B0^2` almost surely and conditional centering gives the two residual signs with probability one half. Both treatment support points stay in `[-B0,B0]` only if `pi_0=0`. The moment identity identifies beta, and the displayed variance bound gives `1/sqrt(2n)`. The lower Bernoulli shift has one-observation affinity `sqrt(1-4delta_n^2)`; tensorization gives the stated TV and `3/(128sqrt(n))` lower.

Verdict: **PASS, HIGH confidence**.
