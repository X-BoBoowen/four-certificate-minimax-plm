# Reviewer M first independent mathematical review — C2

## Recommendation

**CONDITIONAL PASS.**

I regard the C2 manuscript as mathematically much stronger than its density initially suggests. I did not find a broken minimax rate, a failed O/P witness, an invalid BBM transfer, or a hidden sup/inf exchange. The lower half is especially well modularized: each of q, P, O, ab, and M is witnessed inside one label-blind public pair, and Appendix G combines scalar lower bounds by a maximum rather than pretending that Bayes risks from different experiments add.

My condition concerns the theorem field rather than the displayed rate. The public classes are called “bounded,” but Appendix A never states that every candidate is bounded by `B0` or by any envelope included in the fixed tuple `rho`. Appendix B nevertheless declares the joint class to have envelope `8B0` and uses fixed-envelope contraction, Bernstein range terms, and dominated convergence. A pair-specific finite bound is not enough for a constant uniform over the outer public-pair supremum. The clean repair is to place a common envelope—preferably `B0`—in the definition of every admissible public class. This narrows the model exactly to the field already used by the proof and does not alter the rate.

There is also a local statement defect in Lemma 3: its conditional-mgf proof needs the variables to be conditionally independent given the conditioning sigma-field. Unconditional independence plus conditional centering does not suffice. Every actual invocation I traced has the stronger conditional independence, so I do not propagate this into a main-theorem failure.

## My first-pass view of the paper

I think the paper is really proving a theorem about information interfaces, not merely adding two algebraic terms to a familiar product rate. The object is the outer-public-pair minimax risk

`sup_Gamma inf_{delta_Gamma Borel} sup_{P in P(Gamma)} E_P |delta_Gamma-beta(P)|`,

with four declared public budgets and two independently represented nuisance classes. The main interior claim is the fixed-field equivalence

`n^{-1/2} + (a+s^2)(b+t^2) + (s∧t)^2 + t(a∧t) + s(b∧s)`.

The most important mathematical increment is the necessity and attainability of the two oriented terms. The boundary result is conceptually separate: when the residual variance saturates the shared envelope, the propensity is identified and the nuisance terms disappear.

The proof chain that looked most fragile on first reading was not the Walsh-mixture lower bound. It was the upper route

`public localized complexity -> uniform localized process -> joint initial fit -> O/R calibration -> all-z tail -> expectation -> public selector -> Q1`.

Three places deserved disproportionate attention:

1. the transfer from the separate outcome class to the joint scalar/function class after (B.8);
2. the amplified `(d/r)` terms between (B.14), (B.18), and the layer-cake step;
3. the membership and mixture-distance certificates for the five lower mechanisms.

The first two survive once a uniform public-class envelope is made explicit. The third survives as written.

## Dependency structure

The upper and lower halves share the model and deterministic budget algebra but are otherwise largely independent.

`M1 representation + positive-radius complexity -> Lemmas 4–5 -> (B.7)/(B.9)`

`(B.7)/(B.9) -> O edit -> (B.18)/(B.20)`

`(B.7)/(B.9) -> R edit -> (B.29)/(B.30)`

`O/R bounds + public orientation + unsafe fallback -> fixed-pair upper -> Q1 upper`

`testing calculus + three-point channel -> {q, P, O, ab, M}`

`five scalar lower bounds -> maximum -> (G.2) algebra -> interior lower`

`envelope saturation -> pi_0=0 -> moment estimator and two-point lower`

This separation matters. A failure in one directional lower witness would delete one term; it could not be repaired by the other lower families or by the saturation theorem. Conversely, the envelope omission I found belongs to the upper theorem field and does not contaminate the finite lower constructions, whose public dictionaries are already uniformly tiny.

## What I checked and what survived

I checked BBM Theorem 2.1 in the supplied author version, not merely the manuscript paraphrase. Signing the class and choosing `alpha=1` gives Lemma 4 with exactly the displayed constants; the manuscript weakens the source probability from `1-e^{-z}` to `1-2e^{-z}` and therefore does not overclaim.

I initially worried that the scalar coefficient might cancel the nuisance direction in the joint class. The orthogonal identity

`||gamma T+f||_2^2 = v gamma^2 + ||gamma pi_0+f||_2^2`

prevents that: the stress choice `f=-gamma pi_0` leaves `gamma u` and hence retains curvature `v gamma^2`. The countable rational coefficient/difference core is sufficient for the fitted index.

I independently expanded (B.17). The `(d/r)w_z` term created by dividing the objective comparison by `sqrt(lambda_O)` appears exactly where it should: multiplied by `a` it gives `(ad/r)w_z`, and multiplied by `w_z` it gives `(d/r)w_z^2`. I found no missing standalone `(d/r)w_z` term. Integrating `w_z^p=(z/n)^{p/2}` produces the stated `q^p` scales; the `z<1` and `z>c n` pieces are legitimately absorbed by the threshold and clipping.

I replayed the R branch from (B.26) rather than swapping labels. The exact signed ratio identity (B.28), the two-sample calibration event, and the denominator floor use the correct conditioning sigma-fields. The resulting terms and expectation conversion mirror the O scales only after their own derivation.

I checked the selector as an actual measurable rule. Ties go to O; unsafe selected cells return zero; first-within-tolerance selections range over countable charts; and the fixed-pair law-uniform inequality is established before the outer public-pair supremum. I found no selector dependence on nuisance truths, realized errors, a hard label, or a population optimizer.

For the lower bounds I recomputed the finite atom normalizations, target gaps, public-class membership, stochastic budgets, common references, Gram entries, product-mixture chi-square bounds, and root-n splices. The q, P, O, ab, and M witnesses may use different public pairs because they separately lower-bound the same outer minimax scalar. Appendix G then uses a maximum and the verified inequality `S0<=X<=2S0`; it never adds Bayes risks from unrelated priors.

Finally, the saturation proof is independent and correct. `u^2<=B0^2` plus conditional variance `B0^2` forces `u=+/-B0`; conditional centering makes the signs equiprobable; and both treatment support points stay inside the envelope only if `pi_0=0`. The sample moment and the Hellinger two-point experiment give the stated parametric bounds.

## Main concern: public-class envelope

The earliest problem is textual but mathematically consequential. Section 2 says the public nuisance classes are “bounded.” Appendix A’s explicit authoritative bound is

`|Y|,|T|,|beta_0|,|mu_0|,|pi_0|,|u|,|epsilon| <= B0`,

which does not include arbitrary candidates `g` in either public class. At PDF p. 14, however, the proof declares

`J_mu={gamma T+f(X)}`

to have envelope `8B0`. That is true if every class candidate is `B0`-bounded; it is not a consequence of approximation budgets or localized Rademacher budgets.

This is not a cosmetic preference. A spike class `{0,L 1_E}` with `P(E)=(r/L)^2` has fixed `L2` radius `r` while `L` is arbitrary. Its localized Rademacher ratio can remain of order `n^{-1/2}`, so (A.1) does not force a uniform pointwise envelope. A merely pair-specific envelope would make the empirical-process constants depend on `Gamma`, contrary to Proposition 2 and the outer supremum.

The minimum repair is explicit and small:

`sup_{g in G_mu union G_pi}|g(x)| <= B0` for every `x`,

with the same restriction on the supplied countable representations. More generally, a fixed envelope `B_G(rho)` could be added to `rho`; then all constants should be allowed to depend on it and the numerical `8B0` line should be updated. With either repair, I find the upper proof supportable at the claimed rate.

## Minor local issue: conditional independence

Lemma 3 says the variables are “independent, conditionally centered given F,” then multiplies conditional moment generating functions. Literal unconditional independence need not survive conditioning. For a concrete falsifier, take 200 iid Rademacher variables and condition on all 100 adjacent products. Each coordinate remains conditionally centered. On the event that all products equal one, the coordinates occur in identical pairs; at `z=9` the displayed threshold is `0.33`, but the exact conditional tail is approximately `8.737e-4`, larger than `2e^{-9}`.

The repair is to say “conditionally independent and conditionally centered given F.” Given the sample sigma-fields used in Appendix B, the residuals do satisfy that stronger condition, so no rate, constant class, or estimator changes.

## Final judgment

I would not reject the mathematical result on the basis of the issues found. I would require the public-class envelope to be stated in the theorem field before accepting the claimed uniform upper bound. I would also correct Lemma 3’s conditional-independence hypothesis. Subject to those edits, my attacks on the empirical-process transfer, joint localization, specified formulas, measurable selector, all five lower bounds, assembly, and boundary theorem did not reveal a correctness failure.

## Scope, conflicts, and independence

This review covers theoretical statistics, learning-theoretic empirical processes, localized Rademacher arguments, concentration, semiparametric PLM algebra, minimax testing, chi-square/TV mixtures, measurability, and quantifier order. A comprehensive novelty search and non-BBM citation audit are outside the completed scope.

No author identity or institution was available, so author-specific conflicts cannot be assessed. As an AI-assisted execution identity I have no personal employment, financial, supervision, competitive, or social relationships. I did not read internal audits, reference answers, completed forms, reference-stage material, or another reviewer’s opinion. I did have prior-version exposure in the same conversation; the C2 conclusions above were re-derived without consulting the prior output, so this is C2-specific AI red-team material rather than a claim of total project-naivete or independent-human-review credit.

Reviewer: **Reviewer M — simulated independent expert review**  
Model: OpenAI Codex (GPT-5-based; exact deployment version not provided)  
Session/task ID: not provided  
Completed: 2026-08-24, Asia/Shanghai (UTC+08:00)  
Authentication: output ZIP SHA-256 is in the adjacent `.sha256.txt` file; internal file hashes are in `OUTPUT_CONTENT_MANIFEST.tsv`.

