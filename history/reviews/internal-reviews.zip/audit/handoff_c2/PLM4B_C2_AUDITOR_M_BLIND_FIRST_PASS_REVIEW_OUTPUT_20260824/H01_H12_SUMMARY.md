# H01–H12 conclusion table

| Unit | Scope | Verdict | Severity | Confidence | Independent derivation | Counterexample/attack |
|---|---|---|---|---|---|---|
| H01 | Model field and quantifiers | CONDITIONAL PASS | MAJOR | HIGH | Quantifier order and boundary field reconstructed | Uniform public-class envelope not explicit; Issue M-C2-01 |
| H02 | BBM transfer | PASS | N/A | HIGH | Exact source mapping and `alpha=1` substitution | Signed/noncentered misreadings excluded |
| H03 | Joint localization | CONDITIONAL PASS | MAJOR via M-C2-01 | HIGH | Joint curvature and Rademacher decomposition derived | Cancellation `f=-gamma pi_0` survives because of residual variance |
| H04 | (B.9) chain | CONDITIONAL PASS | MAJOR via M-C2-01 | HIGH | Basic inequality, multiplier/square processes, absorption derived | Random fitted-index insertion checked on countable uniform event |
| H05 | O branch/all-z | CONDITIONAL PASS | MAJOR via M-C2-01 | HIGH | (B.18)/(B.20) re-derived | `s=0`, ties, small cutoff, amplified terms checked |
| H06 | R branch/all-z | CONDITIONAL PASS | MAJOR via M-C2-01 | HIGH | (B.29)/(B.30) independently re-derived | `t=0`, denominator, conditioning, random propensity checked |
| H07 | Selector/fallback/Q1 | PASS | N/A | HIGH | Total Borel rule and fixed-pair lift derived | Ties, zero budgets, unsafe cells, `T_{1:n}=0` checked |
| H08 | q and P lower | PASS | N/A | HIGH | Raw likelihood and all-n splice derived | Zero budgets, `s^2=q`, full public dictionary checked |
| H09 | O lower | PASS | N/A | HIGH | Common propensity, gap, budgets, mixture TV derived | Not a relabeled P witness; equality boundaries checked |
| H10 | ab lower | PASS | N/A | HIGH | Singleton public pair and off-class truths derived | `a=0`, `b=0`, small `S`, small `n` checked |
| H11 | M lower | PASS | N/A | HIGH | Two separate stochastic budgets and common pair derived | Imbalanced `s,t`, zero face, full dictionary checked |
| H12 | Assembly and E/I/S boundary | CONDITIONAL PASS | MAJOR via M-C2-01 | HIGH | `S0<=X<=2S0`, max-to-sum, saturation reconstructed | Different pairs, zeros/ties, nonzero propensity at saturation checked |

The `MAJOR` label records the breadth of the theorem-field dependency, not a demonstrated rate error. With the explicit envelope repair, H03–H06 and the upper portion of H12 become PASS on my derivation.

