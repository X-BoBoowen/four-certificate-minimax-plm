# Auditor M issue and derivation log

Create one entry per issue or independent derivation.

## Entry M-C2-01

Page: PDF p. 2, p. 11, and p. 14 / manuscript pp. 2, 11, and 14  
Section: Section 2; Appendix A.2; Appendix B.1–B.2  
Equation, theorem, or proof step: Theorem 1/Proposition 2 field; Lemma 5 application; the sentence declaring `J_mu` to have envelope `8B0` before (B.9)  
H01-H12 unit: H01, H03, H04, H05, H06, H12  
Claim restated in reviewer notation: The upper constant is `C_rho`, uniform over every admissible represented public pair `Gamma`.  
Assumptions used: Every candidate in both public nuisance classes—and hence every difference function—must have a common pointwise envelope controlled by `rho`.  
Independent derivation or first failed step: The manuscript says only “bounded nuisance classes” and Appendix A’s authoritative `B0` list bounds the truths and residuals, not all candidates. The first proof step that cannot be justified from the literal field is `env(J_mu) <= 8B0`; subsequent contraction, Bernstein range terms, and dominated convergence inherit the same missing uniform bound.  
Potential counterexample: A two-function class `{0, L 1_E}` with `P_X(E)=(r/L)^2` has `L2` radius `r` while `L` can be arbitrarily large. Its localized Rademacher ratio can remain of order `n^{-1/2}`; hence (A.1) does not itself recover a uniform `L_infinity` envelope. This attacks the inference, not the final rate.  
Severity: MAJOR  
Evidence needed: Add an explicit condition such as `sup_{g in G_mu union G_pi}|g(x)| <= B0` for all `x` (or add a fixed envelope constant to `rho` and update constants).  
Reviewer confidence: HIGH  

## Entry M-C2-02

Page: PDF p. 12 / manuscript p. 12  
Section: Appendix B.1  
Equation, theorem, or proof step: Lemma 3, (B.1), and its conditional-mgf proof  
H01-H12 unit: H04 (local lemma statement; applications checked separately)  
Claim restated in reviewer notation: Unconditionally independent variables that are merely conditionally centered given `F` satisfy the displayed Bernstein bound conditionally on `F`.  
Assumptions used: The proof multiplies conditional mgfs and therefore needs conditional independence given `F`.  
Independent derivation or first failed step: The first unsupported step is “multiply the conditional moment generating functions.” Unconditional independence need not survive conditioning. With 200 iid Rademacher variables and `F=sigma(W1W2,...,W199W200)`, every `E(W_i|F)=0`; on the positive-probability event that every pair product equals one, the 100 pair signs are duplicated. At `z=9`, the claimed threshold is `0.33`, but the exact conditional tail is about `8.737e-4`, exceeding `2e^{-9}` (about `2.468e-4`).  
Potential counterexample: The paired-Rademacher construction above is admissible under the literal lemma assumptions.  
Severity: MINOR  
Evidence needed: Replace “independent, conditionally centered” by “conditionally independent and conditionally centered given `F`”; make the same qualification in the weighted form.  
Reviewer confidence: HIGH  

## Entry D-BBM

Page: Manuscript PDF p. 12; supplied BBM PDF p. 6  
Section: Appendix B.1; BBM Section 2  
Equation, theorem, or proof step: Lemma 4, (B.2); BBM Theorem 2.1  
H01-H12 unit: H02  
Claim restated in reviewer notation: A centered countable class with envelope `B` and second moment at most `sigma^2` has `sup |P_n W|` bounded by `4 R_n + sqrt(2 sigma^2 z/n)+8Bz/(3n)`.  
Assumptions used: Signed class, range `[-B,B]`, variance at most `sigma^2`, `alpha=1`, measurable supremum.  
Independent derivation or first failed step: Enlarge by negatives; the source one-sided supremum becomes the manuscript absolute supremum. Substitution gives the constants exactly. The manuscript’s `2e^{-z}` failure is weaker than the source’s `e^{-z}`. No failed step found.  
Potential counterexample: Checked non-symmetric and noncentered readings; both are excluded by the explicit signed enlargement and centering.  
Severity: N/A—PASS  
Evidence needed: N/A—source supplied and matched  
Reviewer confidence: HIGH  

## Entry D-B18-B20

Page: PDF pp. 15–16 / manuscript pp. 15–16  
Section: Appendix B.4  
Equation, theorem, or proof step: (B.17)–(B.20)  
H01-H12 unit: H05  
Claim restated in reviewer notation: The O branch has an all-`z` tail containing every amplified `(d/r)` term and integrates to `q+ay+x^2`.  
Assumptions used: O-safe cell, positive radius floor, Lemma 5, exact normalization, conditional weighted Hoeffding, clipping.  
Independent derivation or first failed step: Expanding the five terms in (B.17) reproduces (B.18), including `(ad/r)w_z` and `(d/r)w_z^2`. Integrals of `w_z^p=(z/n)^{p/2}` give `n^{-p/2}Gamma(1+p/2)`; the cutoff pieces are absorbed by clipping. No failed step found, conditional on M-C2-01.  
Potential counterexample: Tested `s=0`, `x=y`, `y<h_n`, and the cutoff `c_2 n<1`; each is covered by the positive `h_n` floor or clipping.  
Severity: N/A—PASS after M-C2-01 field repair  
Evidence needed: N/A beyond M-C2-01  
Reviewer confidence: HIGH  

## Entry D-B29-B30

Page: PDF pp. 17–18 / manuscript pp. 17–18  
Section: Appendix B.6  
Equation, theorem, or proof step: (B.26)–(B.30)  
H01-H12 unit: H06  
Claim restated in reviewer notation: The independently constructed R branch integrates to `q+bx+y^2`.  
Assumptions used: R-safe cell, two-sample calibration, empirical denominator event, correct conditioning sigma-fields, clipping.  
Independent derivation or first failed step: Direct substitution gives (B.28), not an O-by-symmetry formula. Decomposing the four terms reproduces (B.29); the `(bd/r)w_z` and `(d/r)w_z^2` integrals are absorbed by the displayed `bd/(r sqrt(n))` and `d/(nr)` inequalities. No failed step found, conditional on M-C2-01.  
Potential counterexample: Tested `t=0`, `b=0`, `x<h_n`, and random fitted propensity insertion; the uniform difference-class event precedes the insertion.  
Severity: N/A—PASS after M-C2-01 field repair  
Evidence needed: N/A beyond M-C2-01  
Reviewer confidence: HIGH  

## Entry D-SELECTOR-Q1

Page: PDF p. 18 / manuscript p. 18  
Section: Appendix B.7  
Equation, theorem, or proof step: (B.31)–(B.33) and Q1 lift  
H01-H12 unit: H07  
Claim restated in reviewer notation: A public Borel four-cell rule selects O on ties, otherwise R, and uses zero fallback on unsafe cells; the fixed-pair bound lifts to `sup_Gamma inf_delta sup_P`.  
Assumptions used: Countable public representations, known budgets, fixed `rho`, class-pair-specific Borel rules.  
Independent derivation or first failed step: The cells are disjoint and exhaustive; all optimization choices use countable first-within-tolerance rules. For every fixed `Gamma`, the constructed rule gives a law-uniform bound, hence the inner infimum is bounded before the outer supremum. No quantifier exchange occurs.  
Potential counterexample: Ties `x=y`, zero budgets, `T_{1:n}=0`, and an unsafe selected branch were checked; the O tie rule and deterministic fallback cover them.  
Severity: N/A—PASS  
Evidence needed: N/A  
Reviewer confidence: HIGH  

## Entry D-LOWER

Page: PDF pp. 19–28 / manuscript pp. 19–28  
Section: Appendices C–G  
Equation, theorem, or proof step: (C.3)–(C.21), (D.1)–(D.15), (E.1)–(E.13), (F.1)–(F.15), (G.1)–(G.3)  
H01-H12 unit: H08–H12  
Claim restated in reviewer notation: Five separate fixed public pairs yield `q`, `P`, `O`, `ab`, and `M`; their scalar minimax lower bounds combine by a maximum and deterministic algebra.  
Assumptions used: Strict interior, finite Walsh systems, public label-blind classes, exact variance `v_-`, bounded channels, chi-square/TV testing.  
Independent derivation or first failed step: The raw mass normalizations, common references, target gaps, class-budget inequalities, exact mixture identity, and root-`n` splices were recomputed. `S0<=X<=2S0` holds without division, including zeros and ties. No failed step found.  
Potential counterexample: Small `n`, zero active budget, equality `s^2=q`/`t^2=q`, singleton variance interval, and learner access to the full dictionary were checked and excluded by the stated branches/TV bound.  
Severity: N/A—PASS  
Evidence needed: N/A  
Reviewer confidence: HIGH  

## Entry D-BOUNDARY

Page: PDF p. 29 / manuscript p. 29  
Section: Appendix H  
Equation, theorem, or proof step: (H.1)–(H.6)  
H01-H12 unit: H12  
Claim restated in reviewer notation: Above `B0^2` the experiment is empty; at equality, support saturation forces `pi_0=0` and the risk is parametric.  
Assumptions used: `|u|<=B0`, `E(u|X)=0`, constant conditional variance, bounded target.  
Independent derivation or first failed step: Equality forces `u=+/-B0` conditionally with equal probabilities. Both treatment support points fit inside `[-B0,B0]` only when `pi_0=0`; the moment estimator and Hellinger lower then give the displayed constants. No failed step found.  
Potential counterexample: Nonzero propensity at saturation was attempted; one of `pi_0+/-B0` necessarily exits the treatment envelope.  
Severity: N/A—PASS  
Evidence needed: N/A  
Reviewer confidence: HIGH  
