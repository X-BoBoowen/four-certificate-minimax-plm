# BBM theorem-transfer audit

## Source identification

The supplied primary-source copy is Peter L. Bartlett, Olivier Bousquet, and Shahar Mendelson, *Local Rademacher Complexities*. The supplied author-version PDF is dated 14 May 2004; the manuscript cites the published 2005 *Annals of Statistics* version, volume 33(4), pp. 1497–1537. The transferred result is **Theorem 2.1**, located on supplied-source PDF p. 6 (author-version printed p. 6; corresponding published discussion around pp. 1503–1504).

I read the original statement. I did not use only the manuscript’s description.

## Symbol and assumption map

| BBM Theorem 2.1 | Manuscript Lemma 4 | Check |
|---|---|---|
| sample space `X` and iid observations `X_i` | the relevant iid base observation for a fixed shell/class | Same iid structure; fitted indices are inserted only after a uniform event |
| function class `F` | `W^± = W union (-W)` | Signing is necessary so a one-sided supremum equals the absolute supremum |
| range `[a,b]` | `[-B,B]` | `b-a=2B` |
| variance proxy `r` with `Var f(X_i)<=r` | `sigma^2`, since every `W` is centered and `E W^2<=sigma^2` | Exact |
| confidence variable `x>0` | `z>0` | Exact |
| tuning `alpha>0` in the first bound | `alpha=1` | Gives coefficient `2(1+1)=4` |
| `E R_n F` | `R_n(W)=E_{data,epsilon} sup_W |n^{-1}sum epsilon_i W_i|` | Equality follows from signed enlargement |
| `sup_f(Pf-P_nf)` | `Z=sup_W|P_nW|` | `PW=0`; signed class includes both tails in one supremum |
| probability at least `1-e^{-z}` | failure at most `2e^{-z}` | Manuscript is conservative |
| measurable supremum | countable `W` | Countability supplies measurability |

No source fixed point, star-shapedness, Bernstein condition, or loss-function assumption is imported here. Those belong to later BBM results and are not needed for Theorem 2.1.

## Re-derivation

The first BBM inequality is

`sup_{f in F}(Pf-P_nf) <= 2(1+alpha) E R_nF + sqrt(2rx/n) + (b-a)(1/3+1/alpha)x/n`

with probability at least `1-e^{-x}`.

For `F=W^±`, `PW=0`, `[a,b]=[-B,B]`, `r=sigma^2`, `x=z`, and `alpha=1`, this becomes

`Z <= 4 R_n(W) + sqrt(2 sigma^2 z/n) + 2B(1/3+1)z/n`

`   = 4 R_n(W) + sqrt(2 sigma^2 z/n) + 8Bz/(3n)`.

Therefore

`P{Z>4R_n(W)+sqrt(2sigma^2z/n)+8Bz/(3n)} <= e^{-z}`,

which implies the manuscript’s weaker `<=2e^{-z}` display.

## Quantifiers and later use

The theorem is applied to deterministic countable shell classes. The manuscript does not apply BBM pointwise to a fitted function and then claim uniformity; it constructs the uniform event first. The variance proxy and class range are fixed for each shell. Expectation is not converted into a high-probability Rademacher bound: the source theorem already contains the expected Rademacher term in a high-probability inequality.

## Verdict

**PASS — HIGH confidence.** The transfer is exact and slightly conservative in probability. The only upstream condition needed for subsequent uses is the manuscript’s own uniform class-envelope condition, addressed separately in Issue M-C2-01; it is not a BBM mapping error.

