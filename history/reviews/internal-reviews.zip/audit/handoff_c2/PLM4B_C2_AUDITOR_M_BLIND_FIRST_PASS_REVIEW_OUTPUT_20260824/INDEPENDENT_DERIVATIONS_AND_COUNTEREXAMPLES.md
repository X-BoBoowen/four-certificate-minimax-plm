# Independent derivations and counterexample log

## D1 — H01 quantifier reconstruction

For a fixed `rho=(B0,v_-,v_+,c_rad)`, integer `n`, and declared budgets, the risk is

`sup_{Gamma in G_{rho,n}} inf_{delta_Gamma Borel} sup_{P in P(Gamma)} E_P loss`.

The public pair may depend on `n` and budgets but is fixed before data and before a hard coordinate/sign/label. The rule may depend on the pair, fixed field, budgets, and data, but not on the law or proof-only comparators. All upper bounds must be pairwise and law-uniform before the outer supremum. Each lower bound needs only one public pair because the pair supremum is outermost.

Attack: exchange `sup_Gamma` and `inf_delta`. Result: rejected; the manuscript never makes that exchange.

## D2 — zero-radius complexity

The admissibility condition is explicitly

`sup_{r>=s,r>0} R_n(r;Delta G_mu)/(3r)<=c_rad s`

and similarly for `t`. No `0/0` quotient is defined. If a declared budget is zero and the difference class is the singleton zero class, every positive-radius numerator is zero.

Attack: set `s=0` or `t=0`. Result: survived; the positive `h_n` floor also keeps every upper localization radius positive.

## D3 — joint curvature and localization

For `j=gamma T+f(X)`, conditional centering gives

`||j||_2^2=v gamma^2+||gamma pi_0+f||_2^2`.

From `||f||_2<=||gamma pi_0+f||_2+B0|gamma|`,

`||j||_2^2 >= [v_-/{2(1+B0)^2}](gamma^2+||f||_2^2)`.

Thus `||j||_2<=R` implies `|gamma|<=R/sqrt(v_-)` and `||f||_2<=C_rho R`. Splitting the Rademacher supremum gives

`R_n(R;J_mu)<=R/sqrt(v_-) E|n^{-1}sum epsilon_iT_i| + R_{n,P_X}(C_rho R;Delta G_mu)`.

The scalar term is `O(R/sqrt(n))`, and the class term is `O(sR)` at every admissible positive radius. Taking `R>=C_rho(s∨h_n)` yields the Lemma 5 premise.

Attack: take `f=-gamma pi_0`. Result: `j=gamma u`, so the residual variance retains `v gamma^2`; cancellation does not defeat curvature.

Condition: the envelope of `f` must be uniformly controlled, which is precisely Issue M-C2-01.

## D4 — the (B.9) basic inequality

Choose represented comparators `beta^o,g^o` and define

`e^o=(beta^o-beta_0)T+(g^o-mu_0)`,

`j=(beta_hat-beta^o)T+(mu_hat-g^o)`.

Approximate empirical minimization gives exactly

`P_2j^2<=2P_2(epsilon j)-2P_2(e^o j)+tau_n`.

Uniform multiplier and square-process bounds give

`|P_2(epsilon j)|+|(P_2-P)j^2|<=C(delta_z||j||_2+delta_z^2)`.

Fixed-comparator Bernstein and empirical Cauchy–Schwarz give

`|P_2(e^oj)|<=C(a+eta+w_z)(||j||_2+delta_z)`.

After absorption and curvature,

`|beta_hat-beta_0|+||mu_hat-mu_0||_2`

`<=K(a+s+s_bar+w_z+rho_n)`.

Attack: the random fitted index could enter a pointwise event. Result: survived; the class and coefficient core are countable and the event is uniform before substitution.

## D5 — class-envelope stress test

Let `X` have an event `E` of probability `p=(r/L)^2` and take the two-function class `{0,L1_E}`. Its nonzero difference has `L2` norm `r`. For radii that contain this function, its Rademacher average is at most

`L sqrt(p/n)=r/sqrt(n)`.

Thus the normalized localized complexity can be of order `n^{-1/2}` while the pointwise envelope `L` is arbitrarily large. Approximation budgets constrain distances to truths, not candidate suprema. This shows that (A.1) does not imply the `8B0` joint envelope.

Result: successful attack on an unstated implication; recorded as M-C2-01. It is not a constructed counterexample to the final rate.

## D6 — conditional-independence falsifier

Let `W_1,...,W_200` be iid Rademacher variables and

`F=sigma(W_1W_2,W_3W_4,...,W_199W_200)`.

Each coordinate is conditionally centered given `F`, and the variables are unconditionally independent. On the positive-probability event that every recorded pair product is one, the 200 variables are 100 duplicated independent signs. With `B=sigma=1` and `z=9`, (B.1) claims the conditional tail past

`sqrt(2z/n)+2z/(3n)=0.33`

is at most `2e^{-9}=0.0002468196`. Exact binomial summation gives

`P(|100^{-1}sum_{k=1}^{100}R_k|>0.33)=0.0008737198`.

Result: Lemma 3 is false under the literal assumptions. All actual applications have conditional independence, so the repair is local (M-C2-02).

## D7 — O/R tails

The full derivations are in `SPECIFIED_FORMULAE_RECALCULATION.md`. The key stress was whether division by `sqrt(lambda)` creates a missing nonintegrable term. Because `sqrt(lambda_O)` and `sqrt(lambda_R)` are proportional to `r/d`, the norm bounds produce `(d/r)w_z`. In the exact error identities it is always multiplied by `a`, `b`, `w_z`, or another controlled factor. The radius floor `r>=C h_n` makes the resulting expectation scales finite.

Result: attack failed; both branches survive.

## D8 — selector and Q1

I checked all four orientation/safety cells, ties, zero budgets, and the treatment-vector-zero event. The public selector is total. The fixed-pair inequality is proved before the outer supremum, so no single estimator across unrelated public pairs is required.

Result: attack failed.

## D9 — finite lower identities

I recomputed the exact compensation identities:

- P/ab: `Delta(v_0+eta^2)=eta(kappa+gamma)`;
- O/M: `Delta(v_0+gamma^2)=gamma eta`.

I also expanded each sign-mixture square and recovered the diagonal/opposite/off-coordinate Gram entries. The supplied exact scripts reproduced zero residuals for the unmutated identities and nonzero residuals after deliberately doubling `Delta`.

Result: attack failed.

## D10 — assembly and boundary

For budgets in `[0,1]`, `at^2<=t(a∧t)`, `bs^2<=s(b∧s)`, and `s^2t^2<=(s∧t)^2`; hence `S0<=X<=2S0`. At saturation, a nonzero `pi_0` makes one of `pi_0+/-B0` leave the treatment envelope.

Result: both attacks failed.

