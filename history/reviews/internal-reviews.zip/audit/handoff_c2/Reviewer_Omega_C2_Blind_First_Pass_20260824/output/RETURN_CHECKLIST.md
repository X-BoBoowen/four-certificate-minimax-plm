# General reviewer return checklist

- [x] Review is independently written.
- [ ] Real identity, expertise, date, and authentication are supplied. — A real human identity/authentication cannot be supplied; this is AI red-team material and receives zero human-review credit.
- [x] Conflict disclosure is complete.
- [x] Actual manuscript and appendix coverage is stated.
- [x] Technical concerns have exact locators or are explicitly marked unverified.
- [x] Novelty/collision concerns identify public source versions and locators.
- [x] No other reviewer’s opinion was consulted before first-pass completion.

Reviewer name: Reviewer Ω — simulated independent top-tier expert review  
Date: 2026-08-24 20:17:53 +08:00 (Asia/Shanghai)  
Typed signature or verifiable authentication: `REV-OMEGA-C2-20260824-A7372F54`; AI-generated typed signature only, not human authentication  

