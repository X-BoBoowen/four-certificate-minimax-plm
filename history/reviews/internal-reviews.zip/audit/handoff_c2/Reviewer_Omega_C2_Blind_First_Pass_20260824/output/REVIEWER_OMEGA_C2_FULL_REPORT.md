# Reviewer Ω independent blind first-pass report

## 1. Review setup

**Target venue and standard.** The manuscript is formatted as an ICLR 2027 submission. I therefore applied a top-tier machine-learning-conference standard: correctness and reproducibility are necessary, while acceptance additionally requires a technically and conceptually meaningful advance over the closest public work.

**Material reviewed.** I read the 31-page anonymous manuscript in full, including all appendices A–K, and inspected every rendered PDF page. I also read the package README, general review instructions, human-only notice, blank review forms, manifest, provenance ledger, and checksum record. The manuscript SHA-256 is `A7372F5436DC2EA48F1A6499D9908FEEB9CACB604CD403CAF537E52735E20E49`, matching the package record. The input ZIP SHA-256 is `B2B4D05C0394B9E465BF4A98DA8DECCD2BE83A587BE5535A5F9D2767CAE00C6F`.

**Independence and instruction boundary.** The README and forms were treated as review logistics. The `HUMAN_ONLY_REVIEW_NOTICE.md` was treated as a package notice, not as evidence about the theorem. I did not read or seek any internal audit report, answer key, completed form, non-public source, or another reviewer’s report. This output is AI red-team material and, under the supplied notice, receives zero independent-human-review credit.

**Public literature cutoff.** Search and verification were performed on 2026-08-24 (Asia/Shanghai). The manuscript submission date was not supplied. I inspected public versions and exact locators for Bartlett–Bousquet–Mendelson (2005), Gu (COLT 2025), Gu–Yin–Cai–Fan (arXiv:2606.06368v1), Gu (arXiv:2607.21541v1), Jin–Syrgkanis (arXiv:2512.17341v2), and Jin–Mackey–Syrgkanis (arXiv:2507.02275v3), in addition to bibliographic checks of the remaining references.

**What is not assessable.** No LaTeX source, analytic-figure code, machine-readable proof notebook, or independent human verification was supplied. The package explicitly says that source material is omitted. I therefore assessed the PDF theorem and proof, but did not reproduce the figure from code or compare the PDF with source. A globally exhaustive novelty search is impossible; all novelty conclusions below are scoped to the searches and sources recorded here.

## 2. Overall judgment

### Paper’s real contribution

The paper gives a finite-sample expected-absolute-error minimax characterization for a deliberately narrow but nontrivial black-box partially linear experiment. With

\[
q=n^{-1/2},\quad A=a+s^2,\quad B=b+t^2,\quad
M=(s\wedge t)^2,\quad O=t(a\wedge t),\quad P=s(b\wedge s),
\]

the strict-interior claim is

\[
R^{\mathrm{pair}}_{n,\rho}(a,s,b,t)\asymp_\rho q+AB+M+O+P.
\]

The upper estimator is TAME-derived and not presented as a new generic editing method. The genuinely new-looking part is the lower closure: separate finite P and O hard families certify directional terms missing from the closest inherited lower envelope, after which native `q`, `ab`, and `M` experiments and deterministic max-to-sum algebra close the rate. A second contribution is the exact empty/interior/saturation phase split, including identification of the propensity at residual-envelope saturation.

### Atomic claim inventory and dependency map

| Claim | Required support | Supplied support | Survival judgment |
|---|---|---|---|
| C1. Q1/M1 defines a legal, noncircular statistical decision problem. | Measurable access, correct quantifier order, no law-dependent estimator. | pp. 2, 11; Appendix I; fixed-pair rule before the inner law supremum. | **Survives.** |
| C2. Every fixed interior public pair admits risk `≤ Cρ(q+X)`. | Initial-fit control; O/R calibration; branch tails; public selector; unsafe-cell fallback. | Proposition 2, pp. 3–4; Appendix B, especially (B.2a)–(B.33). | **Survives conditionally.** No counterexample found; Lemma 5 remains the most compressed proof node. |
| C3. The interior lower is `≥ cρ(q+X)`. | Five legal component hard pairs and valid max-to-sum algebra. | Sections 5–6; Appendices C–G. | **Survives.** |
| C4. `P=s(b∧s)` is necessary. | Public pair fixed before label; exact variance; both budgets; target gap; mixture TV. | pp. 4–5; (C.10)–(C.21). | **Survives.** |
| C5. `O=t(a∧t)` is necessary and not a relabeled P witness. | Common propensity, outcome-side perturbation, separate budget and TV certificate. | pp. 4–5; (D.1)–(D.15). | **Survives.** |
| C6. `q`, `ab`, and `M` fill the remaining lower components. | Native witnesses and no illicit addition of Bayes risks. | (C.8)–(C.9), Appendices E–F, (G.1)–(G.3). | **Survives.** |
| C7. The experiment is empty above saturation and parametric at equality. | Support equality, propensity identification, moment upper, one legal lower pair. | Theorem 1(E/S), p. 7; Appendix H. | **Survives.** |
| C8. The work is a sufficiently original ICLR-level advance. | Direct comparison with 2025–2026 closest work and evidence that O/P closure changes the order. | Fig. 1 rays; Section 11; public-source comparison below. | **Survives only in a narrow form.** Upper architecture strongly overlaps TAME; the credible increment is O/P lower closure, Q1/M1 exactness, and saturation. |

The principal dependency chain is:

`M1 representation + positive-radius local complexity → Lemma 5/joint localization → initial fits → O and R calibration/tails → four-cell selector/fallback → fixed-pair upper → Q1 upper`;

`equal-variance channel + finite-mixture testing → q/P/O/ab/M component lower bounds → outer-supremum maximum → deterministic equivalence (G.2) → Q1 lower`;

`envelope equality → u=±B0 and π0=0 → moment estimator and scalar lower experiment → saturation theorem`.

### Overall credibility

The proof is unusually explicit about quantifiers, measurability, zero budgets, fixed constants, and all-`n` closure. I attacked precisely the places where such a theorem usually breaks: fitting after the law, evaluating a localized quotient at zero, using latent hard indices as learner input, summing lower bounds from different public pairs, losing a stochastic-budget factor in the P/O/M certificates, and silently continuing an interior rate to saturation. Those attacks failed under the stated assumptions.

My main reservation is not a demonstrated mathematical error. It is that the model is intentionally information-theoretic and highly interface-specific: exact budgets are known; the rule is pair-specific and may be an arbitrary Borel map; public pairs may change with sample size and budget cell; observations and residuals are bounded; residual variance is constant; and no computational or adaptive guarantee is made. This makes the result clean, but reduces its direct algorithmic reach.

### Recommendation

**6/10 — Weak Accept.** I would support acceptance, but not strongly. The core theorem appears technically credible after substantial adversarial checking, and the O/P witnesses close a real order gap on explicit rays. The score is held below strong accept because much of the upper architecture and rate ancestry is already in the June/July 2026 Gu papers, and the remaining advance is specialized to a narrow decision-theoretic interface.

**Confidence: 4/5.** High on the model, quantifier order, selector algebra, lower-family budget certificates, boundary proof, and closest-work comparison. Moderate on a fully formal reconstruction of every empirical-process constant in Lemma 5 and on exhaustive novelty.

## 3. Strongest contributions

1. **The O/P lower certificates change the order, not only a constant.** On the O ray `(a,t)=(r,r), b=s=0`, the inherited `AB+M` contribution is `r^3`, while `O=r^2`; the mirror P ray has the same separation. This is the strongest accept-level fact because it shows that the four-budget decomposition contains information that two aggregate nuisance errors lose.

2. **The lower assembly respects the actual minimax order.** Appendix G takes a maximum of five lower bounds on the same outer-supremum scalar, then uses a deterministic max-to-sum argument. It does not add Bayes risks across different public pairs. This survived the most obvious quantifier attack.

3. **The paper treats measurability as part of the theorem.** The standard-Borel/pointwise-dense representation, countable near-minimizers, rational finite-dimensional charts, and fixed-pair Borel rule make the `supΓ infδΓ supP` claim auditable. This is more than cosmetic in a theorem whose estimator may otherwise be an undefined optimizer.

4. **The saturation result is conceptually clean.** Equality in the residual-envelope constraint forces `u=±B0`, then the bounded support of `T=π0(X)+u` forces `π0=0`. The nuisance geometry genuinely disappears at the boundary rather than merely producing bad constants.

5. **The paper is unusually honest about nonclaims.** It does not claim causality, efficient computation, unknown-budget adaptation, confidence intervals, practical dominance, or novelty of the TAME editor, `ab`, `M`, or generic testing technology.

## 4. Major concerns

### No confirmed fatal or major correctness defect

I found no `CONFIRMED FAILURE` or `STRONG CONCERN` that invalidates Theorem 1 under its literal assumptions. In particular, I did not find a valid counterexample to the P/O/M class-membership certificates after the fixed scaling `λρ=min{1,192crad/23}`.

### Acceptance-critical concern: the top-tier novelty/significance margin is narrow

**Classification:** `STRONG CONCERN`; **severity:** `MAJOR` for venue judgment, not for correctness; **confidence:** `HIGH`.

The July 2026 TAME paper already states a two-learner, two-branch upper remainder in Corollary 3.2, equation (3.7), of the form

`[a·(b+t)+(a+s)^2] ∧ [b·(a+s)+(b+t)^2]`, up to its notation and asymptotic remainder. That is the direct ancestor of this paper’s `Tμ∧Tπ` upper architecture. The June 2026 Gu–Yin–Cai–Fan Theorem A.1 already supplies a four-budget structure-agnostic lower envelope containing the `q+AB+M` ancestry. The present manuscript acknowledges both facts accurately.

After removing that ancestry, the defensible increment is: separate native O/P lower witnesses, exact bounded/M1/fixed-variance embeddings for all components, an all-budget Q1 closure, and the saturation phase theorem. I consider this enough for a weak accept because O/P can dominate the inherited lower envelope by an unbounded factor. However, readers seeking a new practical estimator or a broad semiparametric principle will find the advance smaller than the title may initially suggest. A stronger acceptance case would show that the directional lower phenomenon persists under a more standard estimator-access formulation or drives a concrete algorithmic consequence.

## 5. Detailed findings

### TECH-01 — Local empirical-process bridge is the most compressed proof node

- **Locator:** pp. 12–14, Lemmas 4–5, equations (B.2)–(B.4), joint class after (B.8).
- **Claim attacked:** the public positive-radius complexity bound yields uniform multiplier and square-process control, then legal initial fits without star-shapedness.
- **Strongest interpretation:** constants may depend arbitrarily on the fixed tuple `ρ`, including `crad`, but not on budgets, classes, laws, or `n`.
- **Attack:** I checked the exact Bartlett theorem transfer, multiplier/square contraction, radius floor, dyadic shelling, and use of the outcome class only at admissible positive radii.
- **Result:** `SURVIVED ATTACK`, with a residual `UNVERIFIED SUSPICION` about proof compression rather than a detected false step.
- **Evidence:** Bartlett–Bousquet–Mendelson Theorem 2.1 with `α=1`, range `[-B,B]`, and a sign-symmetrized class gives exactly the displayed `4R_n + sqrt(2σ²z/n) + 8Bz/(3n)` bound. The `h_n` floor bounds the number and confidence cost of relevant shells, and `Cρ` can absorb the treatment Rademacher term even for small fixed `crad>0`.
- **First possible failure step:** the sentence on p. 13 that Young’s inequality turns the shell bounds into (B.3)–(B.4) omits the explicit finite-shell calculation. I could reconstruct the logic, but a full derivation would materially improve auditability.
- **Requested evidence:** expand the shell calculation into a short lemma with the maximal shell index and constants, or provide a self-contained supplement.

### TECH-02 — Four-cell selector and max-to-sum algebra

- **Locator:** pp. 18 and 28; (B.31)–(B.33), (G.1)–(G.3).
- **Attack:** search for zero/tie/order-cell counterexamples and for an illicit cross-pair sum.
- **Independent check:** exhaustive grid over 28,561 boundary-heavy budget tuples plus 1,000,000 log-uniform random tuples. Checked `V≤W≤4V`, `X≤5V`, `V≤6X`, selected branch `≤2W`, and selected branch `≤48X`.
- **Result:** `SURVIVED ATTACK`; no numerical counterexample. The lower proof takes a maximum before converting it to a sum and is compatible with the outer `supΓ`.

### TECH-03 — P/O/M lower-family membership after λρ scaling

- **Locator:** pp. 19–28; (C.5), (C.10)–(C.21), (D.1)–(D.15), (F.1)–(F.15).
- **Attack:** determine whether the scaling fixes one complexity budget while silently breaking the other, target separation, positivity, exact variance, or common-reference identity.
- **Independent check:** algebraic budget checks plus 200,000 random regularity/budget draws. For each draw I rebuilt the three-point treatment channel and P/O/M raw laws, checked atom positivity, normalization, conditional mean/variance, and equality of the sign-averaged reference distributions. No failure occurred; maximum numerical identity error was `5.69×10^-14`.
- **Result:** `SURVIVED ATTACK`, `HIGH` confidence.
- **Budget check:** the P normalized ratio is at most `23λρ s/192≤crad s`; O is at most `23λρ t/384≤crad t`; the M outcome and propensity ratios are separately bounded using `w=s∧t≤s,t`. The target constants remain positive for every fixed `crad>0`, although they may degenerate as `crad↓0`, exactly as stated.

### TECH-04 — Saturation and empty strata

- **Locator:** p. 7; Appendix H, (H.1)–(H.6).
- **Attack:** test whether `E[u²|X]=B0²` and `|u|≤B0` really identify `π0`, and whether the lower bound is incorrectly asserted pairwise.
- **Result:** `SURVIVED ATTACK`. Equality forces `u²=B0²` almost surely; conditional centering makes the signs equiprobable; bounding both `π0±B0` by `B0` forces `π0=0`. The upper is pairwise; the lower is correctly witnessed by one legal outer pair.

### TECH-05 — Q1 quantifier and learner-information attacks

- **Locator:** pp. 2–4, 8, 11, 18, 28, 30–31.
- **Attack:** look for an estimator selected after `P`, a public class selected after the hard label, or a hard coordinate/sign hidden from a learner that is supposed to receive it.
- **Result:** `SURVIVED ATTACK`. The upper constructs one Borel rule for each fixed public pair. Each lower mixture fixes the finite public dictionary before the latent coordinate/sign/label and bounds every Borel rule even when the dictionary is fully known.

### SCOPE-01 — The risk experiment is narrower than standard algorithmic ML practice

- **Locator:** Table 1; pp. 2, 9, 11, 30.
- **Classification:** `STRONG CONCERN`; **severity:** `MODERATE`; **confidence:** `HIGH`.
- **Concern:** known exact budgets, pair-specific Borel rules, `n`- and budget-dependent public pairs, fixed conditional residual variance, bounded variables/residuals, and no runtime constraint make the theorem an information-theoretic closure rather than a deployable learning result.
- **Impact:** this does not falsify the rate. It limits external validity and is the main reason I do not give a strong-accept score.
- **Minimal strengthening:** show robustness of O/P necessity under a more conventional common estimator/access model, unknown-but-estimable budgets, or a computationally implementable subclass.

### REPRO-01 — Claimed included source code cannot be checked from this package

- **Locator:** p. 9, Reproducibility Statement; package README.
- **Classification:** `NOT ASSESSABLE`; **severity:** `MINOR`; **confidence:** `HIGH`.
- **Concern:** the manuscript says Figure 1 is generated by included source code, while the supplied review package intentionally contains no source bundle. This may be only a handoff omission, so I do not treat it as a contradiction in the submission.
- **Evidence needed:** the actual submission supplement/source and a one-command figure regeneration path.

### WRITE-01 — Meta-audit material should be reframed

- **Locator:** Table 4 on p. 8 (“Reviewer-2 audit”), Section 10, Appendix J (“hostile audit”), and the AI-use statement on p. 10.
- **Classification:** `CONFIRMED FAILURE` of presentation, not science; **severity:** `MINOR`; **confidence:** `HIGH`.
- **Concern:** “Reviewer-2 audit” and response-like defensive prose read as internal process residue rather than a scholarly exposition. They distract from the theorem and may confuse a blind reviewer about what is author argument versus review history.
- **Minimal repair:** rename the table as an author-side quantifier/access audit; shorten Appendix J; retain the candid AI disclosure but remove workflow-specific language not needed to verify the theorem.

## 6. Survived attacks

1. **`crad=0` degeneracy:** the headline lower would indeed fail there, but the theorem explicitly assumes fixed `crad>0` and states nonuniformity. The attempted boundary counterexample is excluded legitimately.
2. **Zero budgets and `0/0`:** localized quotients are defined only at positive radii; singleton zero classes have zero complexity at every positive radius. No division by a declared zero budget is needed.
3. **Estimator-after-law attack:** the rule is fixed for each public pair before the law supremum. No `sup/inf` exchange was found.
4. **Cross-pair lower-bound addition:** only a maximum of valid lower bounds is taken. The deterministic factor-ten conversion in (G.3) is valid.
5. **P/O relabeling attack:** P flips the propensity and compensates the outcome nuisance; O keeps the propensity common and removes an outcome perturbation through a different atomwise reference identity. They are not the same hard family with renamed variables.
6. **λρ repair attack:** the scaling satisfies all displayed stochastic budgets and leaves positive target separation for fixed `crad>0`.
7. **Large public dictionary leak:** the dictionary is public by design; the hard coordinate/sign remains latent. The mixture TV bound quantifies over arbitrary Borel rules with the full dictionary.
8. **Four-cell boundary attack:** zeros, ties, and weak-order cells satisfy (B.31)–(B.32); the fallback proof is valid when a small-radius predicate fails.
9. **Interior-to-saturation extrapolation:** the paper does not extrapolate; it gives a separate support-identification proof.
10. **Causal overclaim:** none. The target is repeatedly described as a statistical PLM coefficient.
11. **Computational overclaim:** none. The paper explicitly disclaims polynomial-time or finite-oracle guarantees.
12. **Figure/layout consistency:** all 31 pages rendered cleanly; Figure 1, tables, theorem statements, and appendix locators were visually consistent with the extracted text.

## 7. Prior-work and novelty assessment

### Closest-work collision matrix

| Public source | Exact locator | Overlap | Relationship |
|---|---|---|---|
| Gu, Yin, Cai & Fan, *Optimally taming biases in black-box models for efficient semiparametric estimation*, arXiv:2606.06368v1, 4 Jun 2026 | Appendix A.1, Theorem A.1, pp. 19–20 | Same broad PLM black-box four-budget setting; lower ancestry corresponding to `q+AB+M`; upper via an edited estimator/DML minimum. | **STRONG OVERLAP**, not direct collision with the new O/P lower closure. |
| Gu, *Optimal use of a black-box learner in semiparametric estimation*, arXiv:2607.21541v1, 23 Jul 2026 | Algorithm 1; Theorem 3.1; Corollary 3.2, eq. (3.7), pp. 13–16 | TAME editing/calibration, O/R branches, budget-based orientation, and an upper remainder algebraically ancestral to `Tμ∧Tπ`. | **STRONG OVERLAP** for the upper; manuscript correctly disclaims generic-editor novelty. |
| Gu, *Open Problem: Structure-Agnostic Minimax Risk for Partial Linear Model*, COLT/PMLR 291, 2025, pp. 6220–6224 | Abstract and open-problem statement | Establishes the importance of the structure-agnostic PLM minimax question and the role of variance. | **CONTEXTUAL / PROBLEM ANCESTRY**. |
| Jin & Syrgkanis, *Sharp Structure-Agnostic Lower Bounds for General Linear Functional Estimation*, arXiv:2512.17341v2 | Abstract and general framework | Broad general linear-functional lower theory and first-order-debiasing optimality, but not the same native four-budget, constant-variance Q1 theorem with explicit O/P certificates. | **PARTIAL OVERLAP**. |
| Jin, Mackey & Syrgkanis, *It’s Hard to Be Normal*, arXiv:2507.02275v3 / NeurIPS 2025 | Abstract and PLM noise-regime results | PLM structure-agnostic minimax behavior depends on treatment-noise law; different information/noise regime and higher-order procedures. | **CONTEXTUAL**, not a collision. |
| Bartlett, Bousquet & Mendelson, *Local Rademacher complexities*, Annals of Statistics 33(4), 2005 | Theorem 2.1, pp. 1503–1504 | Supplies the concentration inequality used in Lemma 4. | **TECHNICAL ANCESTRY**, accurately attributed. |

### Novelty conclusion

I found no direct public source, within the stated search scope, that proves both directional lower terms `O=t(a∧t)` and `P=s(b∧s)` in the manuscript’s exact bounded, fixed-variance, M1/Q1 experiment and closes them with the TAME-derived upper for all budgets and all `n`. This is a scoped non-hit, not a proof of global priority.

The broad phrase “four-budget minimax rate” would overstate novelty if read as claiming the full problem and upper mechanism from scratch. The manuscript mostly avoids that error. Its most defensible novelty statement is: **the previously unmatched four-budget upper is closed by separate O/P lower mechanisms under an explicit measurable public-pair decision problem, with a new saturation theorem.**

### Reference verification

All ten listed references resolve to real public records. DOI metadata match the manuscript for Bartlett et al. (2005), Chernozhukov et al. (2018), Foster–Syrgkanis (2023), Robins et al. (2009), and Robinson (1988). PMLR metadata match Gu (2025). ArXiv titles, authors, dates, and versions match arXiv:2606.06368v1, 2607.21541v1, 2512.17341v2, and 2507.02275v3. I found no fabricated DOI or author/title mismatch.

## 8. Broader significance assessment

**Correctness:** strong, conditional on accepting the compressed generic empirical-process bridge.

**Originality:** moderate-to-strong at the lower-bound/interface level; modest at the estimator level.

**Technical depth:** high. The finite hard families, exact variance preservation, mixture Gram calculations, measurability closure, and global boundary bookkeeping are substantial.

**Conceptual insight:** the directional decomposition is useful: approximation error on one side can interact with stochastic resolution on the other in a way hidden by two aggregate nuisance rates. The saturation phase change is also conceptually clean.

**Broad ML relevance:** moderate. The paper speaks to black-box semiparametric learning and the limits of orthogonalization, but the theorem is not a computational learning result and does not establish an adaptive method.

**Interdisciplinary interest:** strongest for learning theory, semiparametric statistics, and causal-methodology readers. The paper explicitly makes no causal identification claim, so impact on empirical causal practice is indirect.

**Immediate implications:** theoreticians should not compress four public budgets into two aggregate errors when seeking sharp minimax guarantees. The result also identifies where a directional calibration lower bound is missing from existing theory.

**Long-term implications:** potentially meaningful if the O/P phenomenon survives in broader access models, unknown-budget adaptation, and implementable estimators. Without such extensions, the contribution may remain a precise closure of a specialized minimax experiment.

**Positioning honesty:** unusually good. The paper credits TAME, Gu et al.’s `q+AB+M` ancestry, and generic testing methods, and states its nonclaims repeatedly.

## 9. Minor issues

1. Rename “Reviewer-2 audit” (Table 4) and remove review-process language from the scholarly narrative.
2. Expand the shell calculation in Lemma 5; this is the one place where “standard” reasoning carries too much downstream weight.
3. Give a short algebraic table mapping TAME Corollary 3.2’s upper remainder into `Tμ`, `Tπ`, and then `X`. The current prior-work table is accurate but too qualitative for the closest collision.
4. Supply the source code claimed in the reproducibility statement, or change “included source code” to an exact supplement locator.
5. State the literature-search cutoff in the manuscript if retaining any scoped “no direct collision found” language.

## 10. Unresolved uncertainties

1. A fully formal line-by-line derivation of Lemma 5’s shell constants was not reproduced from source code or a proof assistant. I found no contradiction, but this is the first node I would recheck if a technical rebuttal emerged.
2. Global priority for O/P cannot be certified by a finite web search, especially given the very recent and rapidly moving 2026 literature.
3. The analytic figure code and any source-level consistency checks are unavailable in the supplied package.
4. No empirical evidence exists—and none is required for the theorem—but practical stability of the editing objectives is unknown.
5. The extent to which the rate persists under unknown budgets, one common procedure across public pairs, nonconstant residual variance, or runtime constraints remains open.

## 11. What would change my judgment

The following evidence would most likely move the score upward:

1. A self-contained expanded proof of Lemma 5 plus an independently checkable source bundle that regenerates the theorem PDF and Figure 1.
2. A theorem showing that at least one directional term remains necessary under a more standard common-estimator or unknown-budget interface.
3. A sharper theorem-level comparison proving that neither Gu–Yin–Cai–Fan Theorem A.1 nor TAME Corollary 3.2 already implies O/P necessity under a simple reduction.

The following would move the score sharply downward:

1. A valid counterexample to one P/O/M public-budget certificate or to the fixed-pair mixture identity.
2. A direct public pre-2026/early-2026 theorem proving the same O/P lower closure under the same or more general information structure.
3. Evidence that the Borel upper rule uses a population comparator or fitted index outside the supplied M1 representation.

## 12. Completed forms and returned files

The output package contains:

- `REVIEWER_OMEGA_C2_FULL_REPORT.md`
- `ICLR_STYLE_REVIEW_FORM.md`
- `EXPERTISE_AND_CONFLICT_FORM.md`
- `RETURN_CHECKLIST.md`
- `TECHNICAL_ISSUE_LOG.md`
- `NOVELTY_AND_CITATION_LOG.md`
- `MAJOR_AND_MINOR_ISSUES.md`
- `SURVIVED_ATTACKS.md`
- `UNRESOLVED_UNCERTAINTIES.md`
- `OUTPUT_SHA256.txt`

No input file or manuscript was modified.

## 13. Independence statement and signature

**Capability statement.** This review covers mathematical definitions, minimax quantifiers, empirical-process reasoning, finite-mixture lower bounds, PLM/statistical interpretation, public literature comparison, reproducibility, and venue-level significance. It does not constitute a human expert authentication, a formal proof-assistant verification, an exhaustive global priority search, or an empirical reproduction.

**Conflict statement.** No observable collaboration, supervision, employment, financial, competitive, or personal relationship with the anonymous authors can be identified from the blind package. Because the authors are anonymous, unobservable conflicts cannot be ruled out. I did not attempt deanonymization.

**Independence statement.** I did not read an internal audit report, reference answer, another reviewer’s opinion, completed review form, or non-public material. Public literature was inspected independently. The manuscript’s own author-side audit prose was read as part of the submitted PDF, not as an external reviewer report.

**Evidence and tools.** PDF text extraction and 31-page rendering; SHA-256 verification; independent Python numerical checks (28,561 grid points, 1,000,000 selector random points, 200,000 hard-family draws); public arXiv/PMLR/DOI/Crossref inspection; and manual proof reconstruction. No unreported experiment was claimed.

Reviewer: **Reviewer Ω — simulated independent top-tier expert review**  
Reviewer instance ID: **REV-OMEGA-C2-20260824-A7372F54**  
Model/version: **OpenAI Codex (GPT-5 family; exact build not supplied)**  
Session ID: **Not supplied by the system**  
Completed: **2026-08-24 20:17:53 +08:00 (Asia/Shanghai)**  
Authentication: **AI-generated typed signature only; not a human signature**  
Output ZIP SHA-256: **recorded after packaging in the adjacent `.zip.sha256` sidecar; the ZIP-internal `OUTPUT_SHA256.txt` records its member files**

