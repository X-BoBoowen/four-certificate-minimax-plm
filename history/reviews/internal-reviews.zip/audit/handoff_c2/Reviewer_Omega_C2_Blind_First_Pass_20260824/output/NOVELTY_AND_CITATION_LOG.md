# Novelty and citation log

Paper title: Optimally taming biases in black-box models for efficient semiparametric estimation  
Authors: Yihong Gu; Qishuo Yin; Tianxi Cai; Jianqing Fan  
Version and year: arXiv v1, 4 June 2026  
Venue or repository: arXiv  
DOI, arXiv, OpenReview, or official URL: https://arxiv.org/abs/2606.06368  
Exact overlapping claim and locator: Appendix A.1, Theorem A.1, pp. 19–20: four-budget structure-agnostic PLM minimax upper/lower; lower ancestry expands to the manuscript’s `q+AB+M` terms but does not match the full TAME-side upper.  
Input/access comparison: Similar black-box function-class access and known budgets; the reviewed paper freezes an explicit M1 represented class pair and Q1 `supΓ infδΓ supP` order.  
Assumption/quantifier comparison: Gu et al. use bounded PLM laws with constant treatment variance and a class-family outer minimax; the reviewed paper adds exact B0-envelope strata, Borel coding, all-n closures, and fixed-pair hard-family certificates.  
Overlap strength: STRONG OVERLAP  
Relationship: Closest lower-rate ancestor; not a direct collision with separate O/P lower necessity.  
Reviewer confidence: HIGH  

---

Paper title: Optimal use of a black-box learner in semiparametric estimation  
Authors: Yihong Gu  
Version and year: arXiv v1, 23 July 2026  
Venue or repository: arXiv  
DOI, arXiv, OpenReview, or official URL: https://arxiv.org/abs/2607.21541  
Exact overlapping claim and locator: Algorithm 1 and Theorem 3.1, pp. 13–15; Corollary 3.2, equation (3.7), pp. 15–16. The two-learner TAME-2 remainder is `[a·(b+t)+(a+s)^2]∧[b·(a+s)+(b+t)^2]` up to notation/asymptotic remainder, directly ancestral to `Tμ∧Tπ`.  
Input/access comparison: TAME uses initial black-box fits and adversarial editing; the reviewed paper supplies exact M1 Borel selection, public safety cells, zero fallback, and Q1 fixed-pair closure.  
Assumption/quantifier comparison: TAME’s result is chiefly an upper/oracle statement under small-error/asymptotic conditions; the reviewed theorem is an all-budget/all-n expected-L1 minimax equality with native lower pairs.  
Overlap strength: STRONG OVERLAP  
Relationship: Direct upper-method ancestor. The reviewed manuscript correctly disclaims novelty of the generic editor and two-branch architecture.  
Reviewer confidence: HIGH  

---

Paper title: Open Problem: Structure-Agnostic Minimax Risk for Partial Linear Model  
Authors: Yihong Gu  
Version and year: Published 2025  
Venue or repository: COLT 2025, PMLR 291:6220–6224  
DOI, arXiv, OpenReview, or official URL: https://proceedings.mlr.press/v291/gu25b.html  
Exact overlapping claim and locator: Abstract/open-problem statement identifies structure-agnostic minimax optimality for the PLM and the role of treatment variance as an unresolved question.  
Input/access comparison: Problem-level rather than a matching theorem.  
Assumption/quantifier comparison: Less specific than the reviewed M1/Q1 bounded experiment.  
Overlap strength: CONTEXTUAL  
Relationship: Problem ancestry and significance support; no theorem collision.  
Reviewer confidence: HIGH  

---

Paper title: Sharp Structure-Agnostic Lower Bounds for General Linear Functional Estimation  
Authors: Jikai Jin; Vasilis Syrgkanis  
Version and year: arXiv v2, 5 January 2026  
Venue or repository: arXiv  
DOI, arXiv, OpenReview, or official URL: https://arxiv.org/abs/2512.17341  
Exact overlapping claim and locator: Abstract/general theory: sharp structure-agnostic lower bounds for linear functionals and optimality regimes for first-order debiasing.  
Input/access comparison: More general functional-estimation formalism, but not the same native two-class four-budget Q1 experiment with explicit directional O/P hard pairs.  
Assumption/quantifier comparison: Different oracle/information structure and functional-level formulation.  
Overlap strength: PARTIAL OVERLAP  
Relationship: Important general lower-bound ancestor; no direct O/P collision located.  
Reviewer confidence: MEDIUM-HIGH  

---

Paper title: It’s Hard to Be Normal: The Impact of Noise on Structure-agnostic Estimation  
Authors: Jikai Jin; Lester Mackey; Vasilis Syrgkanis  
Version and year: arXiv v3, 7 November 2025; NeurIPS 2025  
Venue or repository: arXiv / NeurIPS  
DOI, arXiv, OpenReview, or official URL: https://arxiv.org/abs/2507.02275  
Exact overlapping claim and locator: Abstract: PLM structure-agnostic rates depend on treatment-noise distribution; DML optimal for Gaussian noise and improvable for independent non-Gaussian noise.  
Input/access comparison: Noise-law/higher-order-estimation axis differs from the reviewed fixed-variance bounded public-class budget axis.  
Assumption/quantifier comparison: Different treatment-noise assumptions and practical ACE procedures.  
Overlap strength: CONTEXTUAL  
Relationship: Adjacent PLM minimax result, not a direct theorem collision.  
Reviewer confidence: HIGH  

---

Paper title: Local Rademacher complexities  
Authors: Peter L. Bartlett; Olivier Bousquet; Shahar Mendelson  
Version and year: Annals of Statistics 33(4), 2005  
Venue or repository: Annals of Statistics / arXiv math/0508275  
DOI, arXiv, OpenReview, or official URL: https://doi.org/10.1214/009053605000000282  
Exact overlapping claim and locator: Theorem 2.1, journal pp. 1503–1504, supplies the localized supremum concentration used in manuscript Lemma 4.  
Input/access comparison: Generic empirical-process theorem.  
Assumption/quantifier comparison: Mapping `[a,b]=[-B,B]`, variance `r=σ²`, confidence `x=z`, `α=1`, and sign-symmetrized class is correct.  
Overlap strength: CONTEXTUAL / TECHNICAL ANCESTRY  
Relationship: Correctly cited source theorem, not novelty collision.  
Reviewer confidence: HIGH  

---

Paper title: Four-Budget Minimax Rates for Bounded Partially Linear Models  
Authors: Anonymous  
Version and year: Supplied ICLR 2027 anonymous PDF; reviewed 24 August 2026  
Venue or repository: Blind review package  
DOI, arXiv, OpenReview, or official URL: Not publicly identified; no deanonymization attempted  
Exact overlapping claim and locator: Theorem 1, pp. 2–3; O/P certificates, pp. 4–5 and Appendices C–D.  
Input/access comparison: Exact represented public class pair, four known budgets, arbitrary pair-specific Borel rule, 2n iid observations.  
Assumption/quantifier comparison: Bounded PLM; constant residual variance; Q1 outer public-pair supremum; M1 access; all-n expected L1 risk.  
Overlap strength: SCOPED SEARCH RESULT — NO DIRECT O/P COLLISION FOUND  
Relationship: Novelty survives only as a scoped conclusion; upper architecture and q+AB+M ancestry are not new.  
Reviewer confidence: MEDIUM-HIGH  

Search scope and queries: arXiv, PMLR/COLT, DOI/Crossref, and general web search on 2026-08-24; exact title; “structure-agnostic minimax partial linear model”; “four-budget”; `s(b∧s)`; `t(a∧t)`; `q+AB+M`; TAME; black-box semiparametric lower bounds. Search non-hits are not evidence of global priority.  

