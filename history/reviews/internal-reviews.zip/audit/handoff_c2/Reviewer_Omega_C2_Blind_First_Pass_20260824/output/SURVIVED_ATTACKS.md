# Survived-attacks ledger

| ID | Target and locator | Attack performed | Outcome | Severity if failed | Confidence |
|---|---|---|---|---|---|
| SA-01 | Q1 risk, pp. 2, 11; (4) | Searched for estimator-after-law or `sup/inf` exchange. | One fixed-pair Borel rule precedes `supP`; outer `supΓ` is taken last. **SURVIVED ATTACK.** | FATAL | HIGH |
| SA-02 | M1 representation, pp. 2, 7, 11, 30 | Searched for an uncountable fitted-index insertion or hidden optimizer oracle. | Countable first-within-tolerance selection and rational charts cover all fitted choices used. **SURVIVED ATTACK.** | MAJOR | HIGH |
| SA-03 | `crad=0` boundary, pp. 3, 8, 11, 30 | Set `crad=0` and tested whether positive-budget lower survives. | It does not, but the theorem explicitly assumes fixed `crad>0` and makes no uniform boundary claim. **SURVIVED ATTACK.** | MAJOR | HIGH |
| SA-04 | Lemma 4, p. 12 | Checked exact transfer of Bartlett–Bousquet–Mendelson Theorem 2.1. | `α=1`, sign closure, range `2B`, and probability/constants match. **SURVIVED ATTACK.** | MAJOR | HIGH |
| SA-05 | Lemma 5, pp. 12–13 | Tested contraction, shell confidence, positive-radius floor, and lack of star-shapedness. | No false step found; proof remains compressed. **SURVIVED ATTACK conditionally.** | MAJOR | MEDIUM |
| SA-06 | Joint outcome fit, pp. 13–14; (B.8)–(B.9) | Tested whether complexity of `γT+f(X)` needs an undeclared joint-class assumption. | Orthogonal curvature localizes `γ` and `f`; treatment Rademacher term is absorbed into fixed `Cρ`. **SURVIVED ATTACK.** | MAJOR | MEDIUM-HIGH |
| SA-07 | O calibration, pp. 14–16; (B.10)–(B.20) | Tested exact normalization, Borel hyperplane chart, denominator perturbation, and amplified tail terms. | Identity and amplification terms are present; no missing standalone factor found. **SURVIVED ATTACK.** | FATAL | MEDIUM-HIGH |
| SA-08 | R calibration, pp. 16–18; (B.21)–(B.30) | Tested sample-split conditioning and random fitted-index substitution. | `m̂` excludes D1 treatments/outcomes; uniform event precedes substitution. **SURVIVED ATTACK.** | FATAL | MEDIUM-HIGH |
| SA-09 | Four-cell selector, p. 18; (B.31)–(B.33) | 28,561 boundary grid points and 1,000,000 log-random points. | No violation of displayed inequalities; unsafe fallback logic also checks. **SURVIVED ATTACK.** | FATAL | HIGH |
| SA-10 | q witness, p. 20; (C.8)–(C.9) | Recomputed probabilities, target, envelopes, product chi-square, TV, and constants. | All legal for every budget cell. **SURVIVED ATTACK.** | MAJOR | HIGH |
| SA-11 | Three-point channel, p. 19; (C.5)–(C.7) | Recomputed masses, mean, variance, and envelope margin over 200,000 random regularity tuples. | All masses positive; means/variance exact to numerical precision. **SURVIVED ATTACK.** | FATAL | HIGH |
| SA-12 | P witness, pp. 20–22 | Tested variance, raw-law positivity, public budget, reference identity, Gram/TV, target gap, and all-n splice. | No failure; normalized stochastic ratio `≤23λρs/192`. **SURVIVED ATTACK.** | FATAL | HIGH |
| SA-13 | O witness, pp. 22–24 | Tested common propensity, atomwise cancellation, budget, reference/Gram identity, target gap. | No failure; not a relabeled P construction. **SURVIVED ATTACK.** | FATAL | HIGH |
| SA-14 | ab witness, pp. 24–26 | Tested singleton public pair versus off-class truths and zero stochastic budgets. | Off-class Walsh directions never enter public classes; law remains legal. **SURVIVED ATTACK.** | MAJOR | HIGH |
| SA-15 | M witness, pp. 26–28 | Tested both stochastic budgets separately and zero faces. | (F.6) and (F.7) use `w≤s` and `w≤t` separately. **SURVIVED ATTACK.** | FATAL | HIGH |
| SA-16 | Lower assembly, p. 28; (G.1)–(G.3) | Searched for adding unrelated Bayes risks and for algebraic failure at zeros/ties. | Only a maximum is taken; `S0≤X≤2S0` is boundary-safe. **SURVIVED ATTACK.** | FATAL | HIGH |
| SA-17 | Saturation, p. 29; (H.1)–(H.6) | Recomputed support equality, identification, upper moment risk, and lower affinity. | `π0=0` follows from the shared envelope; quantifiers are correct. **SURVIVED ATTACK.** | FATAL | HIGH |
| SA-18 | Causal interpretation, pp. 1–2, 9, 11, 30 | Searched for potential-outcomes or treatment-effect overclaim. | The paper repeatedly limits the target to a statistical PLM coefficient. **SURVIVED ATTACK.** | MODERATE | HIGH |
| SA-19 | Computational interpretation, pp. 1–2, 9, 30 | Searched for efficient/practical overclaim. | The paper explicitly disclaims runtime, oracle cost, adaptation, and empirical superiority. **SURVIVED ATTACK.** | MODERATE | HIGH |
| SA-20 | Novelty collision | Searched exact formula/title/historical terminology and inspected closest 2025–2026 primary sources. | Strong upper/lower ancestry found and credited; no direct O/P matching theorem found in scope. **SURVIVED ATTACK only as a scoped novelty claim.** | MAJOR | MEDIUM-HIGH |
| SA-21 | PDF integrity/layout | Rendered and inspected all 31 pages. | No clipping, broken glyphs, missing pages, or obvious table/figure/text inconsistency. **SURVIVED ATTACK.** | MINOR | HIGH |

