# Ranked issue list

## Fatal issues

None confirmed.

## Major issues

### VENUE-01 — Narrow top-tier novelty/significance margin

- **Classification:** STRONG CONCERN
- **Severity:** MAJOR for ICLR-level venue judgment; not a correctness failure
- **Confidence:** HIGH
- **Locator:** pp. 1, 4, 9; Sections 1, 4, 11; closest public sources listed below
- **Root issue:** The upper editing/calibration and two-branch rate architecture strongly overlap Gu’s July 2026 TAME paper, while the `q+AB+M` lower ancestry appears in Gu–Yin–Cai–Fan’s June 2026 Theorem A.1. The most credible increment is therefore the O/P lower certificates, exact Q1/M1 all-budget closure, and saturation boundary theorem.
- **Why it matters:** O/P changes the order on explicit rays and is enough for my weak-accept recommendation, but the work is not a new generic editor or a broad algorithmic framework. A stricter committee could judge the residual contribution too specialized for ICLR.
- **Minimum response:** Give an equation-level comparison to TAME (3.7), isolate precisely which implications require the new lower constructions, and explain why that closure is important beyond the frozen information structure.

No major technical defect was found.

## Moderate issues

### SCOPE-01 — Information-theoretic interface limits external validity

- **Classification:** STRONG CONCERN
- **Severity:** MODERATE
- **Confidence:** HIGH
- **Locator:** Table 1; pp. 2, 9, 11, 30
- **Root issue:** Known exact budgets, arbitrary pair-specific Borel rules, sample-size/budget-dependent public pairs, fixed conditional treatment-residual variance, bounded variables/residuals, and no computation constraint.
- **Impact:** Does not falsify Theorem 1; limits direct ML/practical interpretation and cross-setting generality.
- **Minimum response:** Keep nonclaims prominent and, if possible, add one robustness theorem under a more standard access/adaptation condition.

### TECH-01 — Lemma 5 needs a full shell derivation

- **Classification:** UNVERIFIED SUSPICION
- **Severity:** MODERATE
- **Confidence:** MEDIUM
- **Locator:** pp. 12–14, (B.2a)–(B.4)
- **Root issue:** The highest-leverage empirical-process bridge is compressed into a proof sketch. I reconstructed the missing role of the envelope and `h_n`, but did not formalize every constant.
- **Impact:** If an extra logarithm or radius factor were missing, both O/R upper bounds would be affected. No such error was found.
- **Minimum response:** Add maximal-shell and Young-inequality details.

## Minor issues

### WRITE-01 — Internal-review language

- **Classification:** CONFIRMED FAILURE of presentation only
- **Severity:** MINOR
- **Confidence:** HIGH
- **Locator:** Table 4 (“Reviewer-2 audit”), Section 10, Appendix J (“hostile audit”)
- **Fix:** Recast as an author-side theorem/quantifier audit and remove workflow-specific labels.

### REPRO-01 — Figure source is not assessable

- **Classification:** NOT ASSESSABLE
- **Severity:** MINOR
- **Confidence:** HIGH
- **Locator:** p. 9 Reproducibility Statement; handoff README
- **Fix:** Supply the referenced source in the actual submission supplement or give an exact public locator. The handoff intentionally omitted source, so this is not treated as a confirmed submission defect.

### NOV-01 — Closest-work comparison should be algebraic

- **Classification:** STRONG CONCERN about exposition, not attribution dishonesty
- **Severity:** MINOR
- **Confidence:** HIGH
- **Locator:** Table 5, Section 11
- **Fix:** Expand TAME Corollary 3.2 (3.7) in the manuscript’s `(a,s,b,t)` notation and identify the exact missing lower terms.

