# Unresolved uncertainties

## UU-01 — Full formal closure of Lemma 5

- **Status:** UNVERIFIED SUSPICION
- **Impact if adverse:** MAJOR; both upper branches depend on it
- **Current evidence:** The source concentration theorem maps correctly; contraction and radius-floor logic appear sound; no counterexample found.
- **Missing evidence:** A complete shell-by-shell derivation or formal verification, including maximal shell index and constants.

## UU-02 — Exhaustive priority for O/P

- **Status:** NOT ASSESSABLE globally
- **Impact if adverse:** FATAL to the claimed novelty increment, not to correctness
- **Current evidence:** No direct collision found in scoped arXiv/PMLR/DOI searches through 2026-08-24. The closest Gu papers omit the matching O/P lower closure in their displayed results.
- **Missing evidence:** Broader database/forward-citation search and expert historical review; priority cannot be certified from search non-hits.

## UU-03 — Source and figure reproducibility

- **Status:** NOT ASSESSABLE
- **Impact if adverse:** MINOR for the analytic theorem; MODERATE for submission reproducibility
- **Current evidence:** PDF is internally consistent and Figure 1 matches the displayed formulas. The handoff intentionally omits source.
- **Missing evidence:** LaTeX/figure code, dependency versions, and a documented regeneration command.

## UU-04 — Unknown-budget adaptation

- **Status:** OPEN / outside theorem
- **Impact:** Determines practical relevance of the public selector
- **Current evidence:** The estimator uses exact declared upper budgets and the paper disclaims adaptation.
- **Missing evidence:** Observable budget estimators and a uniform analysis of selection error.

## UU-05 — Common-estimator and computational variants

- **Status:** OPEN / outside theorem
- **Impact:** Could materially strengthen or weaken the top-tier significance case
- **Current evidence:** Q1 deliberately permits pair-specific arbitrary Borel rules and n/budget-dependent public pairs.
- **Missing evidence:** Lower/upper bounds under a common procedure, finite oracle model, or polynomial-time restriction.

## UU-06 — Robustness beyond constant bounded residual variance

- **Status:** OPEN / outside theorem
- **Impact:** External validity and boundary interpretation
- **Current evidence:** Constant `E[u²|X]=v` and the shared `B0` envelope are used essentially in both the hard channels and saturation identification.
- **Missing evidence:** Heteroskedastic, unbounded/sub-Gaussian, or unequal-envelope extensions.

## UU-07 — Independent human verification

- **Status:** NOT PROVIDED
- **Impact:** Governance/release readiness, not a mathematical counterexample
- **Current evidence:** The manuscript itself says complete independent human verification has not yet occurred; the handoff notice assigns AI output zero human-review credit.
- **Missing evidence:** A named human expert’s independent review, conflict disclosure, and verifiable authentication outside the anonymous submission package.

