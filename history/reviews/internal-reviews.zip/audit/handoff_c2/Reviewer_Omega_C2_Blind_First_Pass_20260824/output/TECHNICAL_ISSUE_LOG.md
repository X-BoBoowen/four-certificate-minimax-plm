# Technical issue log

## Issue TECH-01 — Lemma 5 shell calculation is under-expanded

Page: 12–14  
Section: Appendix B.1–B.2  
Equation, theorem, proof step, or claim: Lemma 5, (B.2a)–(B.4), joint localization after (B.8)  
Exact concern: The proof compresses symmetrization, contraction, shellwise Lemma 4 applications, confidence allocation, and Young absorption into several sentences. Because every upper branch depends on this bridge, an omitted logarithmic or radius factor would propagate to Theorem 1. I found no such factor after reconstruction, but the maximal shell index and the use of `h_n` should be explicit.  
Attempted verification: Checked the exact Bartlett et al. Theorem 2.1 mapping; reconstructed contraction for bounded multiplier and square processes; checked the positive radius floor and finite number of nonempty shells under the envelope.  
Potential counterexample: None found. A counterexample would require a bounded class satisfying (B.2a) whose largest relevant shell makes `sqrt((z+j)/n)` exceed the claimed `δ_z` scale; the `h_n=sqrt(log(en)/n)` floor appears to prevent this.  
Severity: MODERATE; attack result `UNVERIFIED SUSPICION`, not a demonstrated failure  
Evidence needed: A complete shell derivation with maximal `j`, variance/envelope constants, and the final Young inequalities.  
Reviewer confidence: MEDIUM  

## Issue TECH-02 — Selector and deterministic rate equivalence

Page: 18 and 28  
Section: Appendix B.7 and Appendix G  
Equation, theorem, proof step, or claim: (B.31)–(B.33), (G.1)–(G.3)  
Exact concern: The six weak-order cells and the max-to-sum step are upstream of the global upper/lower statement; a missed zero/tie cell or illicit addition across public pairs would invalidate the rate.  
Attempted verification: Checked the proof algebra and evaluated 28,561 boundary-heavy grid tuples plus 1,000,000 log-uniform random tuples. Verified `V≤W≤4V`, `X≤5V`, `V≤6X`, selected branch `≤2W≤48X`. Confirmed the lower takes a maximum of five valid outer-supremum lower bounds.  
Potential counterexample: None found, including all-zero coordinates, ties `a=t`, `b=s`, and highly imbalanced scales.  
Severity: MAJOR if false; attack result `SURVIVED ATTACK`  
Evidence needed: None beyond the supplied proof for review purposes.  
Reviewer confidence: HIGH  

## Issue TECH-03 — P witness budget, variance, and mixture certificate

Page: 20–22  
Section: Appendix C.4–C.7  
Equation, theorem, proof step, or claim: (C.10)–(C.21)  
Exact concern: The compensating nuisance and `λρ` scaling might preserve observables while violating the outcome stochastic budget, exact residual variance, positivity, or target gap.  
Attempted verification: Recomputed the three-point channel, P raw masses, sign-averaged reference identity, stochastic-complexity bound, target gap, and all-n splice. Included in a 200,000-draw random construction audit.  
Potential counterexample: None found. The normalized class-complexity ratio is at most `23λρ s/192≤crad s`; all random atom masses were positive.  
Severity: FATAL if false; attack result `SURVIVED ATTACK`  
Evidence needed: None beyond the supplied proof for review purposes.  
Reviewer confidence: HIGH  

## Issue TECH-04 — O witness is not merely a relabeled P witness

Page: 22–24  
Section: Appendix D  
Equation, theorem, proof step, or claim: (D.1)–(D.15)  
Exact concern: The common-propensity construction could fail atomwise reference equality or silently use a learner-hidden propensity sign.  
Attempted verification: Recomputed treatment-channel moments, outcome probabilities, (D.8)–(D.11) common-reference/Gram identities, budget ratio, and target separation. Included in the 200,000-draw audit.  
Potential counterexample: None found. The propensity dictionary is public while the coordinate/sign remains a legal latent mixture index; the label-one outcome factor cancels only after the stated atomwise identity.  
Severity: FATAL if false; attack result `SURVIVED ATTACK`  
Evidence needed: None beyond the supplied proof for review purposes.  
Reviewer confidence: HIGH  

## Issue TECH-05 — M witness must satisfy two stochastic budgets simultaneously

Page: 26–28  
Section: Appendix F  
Equation, theorem, proof step, or claim: (F.1)–(F.15), especially (F.6)–(F.7)  
Exact concern: Using `w=s∧t` is not by itself a proof that both normalized positive-radius quotients fit their separately declared budgets.  
Attempted verification: Checked the two envelope/cardinality calculations separately and rebuilt the sign-averaged raw laws numerically.  
Potential counterexample: None found. The final inequalities use `w≤s` and `w≤t` separately; both zero faces collapse correctly.  
Severity: FATAL if false; attack result `SURVIVED ATTACK`  
Evidence needed: None beyond the supplied proof for review purposes.  
Reviewer confidence: HIGH  

## Issue TECH-06 — Saturation support identification

Page: 7 and 29  
Section: Section 8 and Appendix H  
Equation, theorem, proof step, or claim: Theorem 1(E/S), (H.1)–(H.6)  
Exact concern: Equality in a variance bound sometimes does not identify a nuisance without extra support assumptions; the paper relies on the shared `B0` envelope.  
Attempted verification: Derived `u²=B0²` almost surely, conditional sign balance, intersection of `|π0±B0|≤B0`, moment identification of β, upper variance, and the scalar lower experiment.  
Potential counterexample: Excluded by the shared envelope exactly as stated. If `T` and `u` had different bounds the argument would change, but that is outside the model.  
Severity: MAJOR if false; attack result `SURVIVED ATTACK`  
Evidence needed: None beyond the supplied proof for review purposes.  
Reviewer confidence: HIGH  

## Issue SCOPE-01 — Information structure limits external validity

Page: 2, 9, 11, 30  
Section: Table 1; Section 11; Appendices A and I  
Equation, theorem, proof step, or claim: Interpretation of the minimax characterization  
Exact concern: Exact known budgets, arbitrary pair-specific Borel rules, sample-size/budget-dependent public pairs, fixed conditional residual variance, bounded residuals, and no runtime constraint make the theorem narrower than a standard algorithmic ML guarantee.  
Attempted verification: Checked that these restrictions are disclosed and used consistently.  
Potential counterexample: Not a counterexample to the theorem; it is a competing interpretation of significance.  
Severity: MODERATE; attack result `STRONG CONCERN` about external validity, not correctness  
Evidence needed: Extension to unknown budgets, a common estimator/access model, nonconstant variance, or an implementable subclass.  
Reviewer confidence: HIGH  

## Issue WRITE-01 — Review-process language in the manuscript

Page: 8, 10, 30  
Section: Table 4, Section 10, Appendix J  
Equation, theorem, proof step, or claim: “Reviewer-2 audit” and “hostile audit” presentation  
Exact concern: These labels read as internal review history or answer-key residue rather than author exposition and can confuse blind-review provenance.  
Attempted verification: Distinguished this manuscript-internal prose from external review material; no other reviewer report was consulted.  
Potential counterexample: None; this is a confirmed presentation issue, not evidence of misconduct or a theorem defect.  
Severity: MINOR; attack result `CONFIRMED FAILURE` of presentation only  
Evidence needed: Rename/reframe as an author-side theorem audit.  
Reviewer confidence: HIGH  

