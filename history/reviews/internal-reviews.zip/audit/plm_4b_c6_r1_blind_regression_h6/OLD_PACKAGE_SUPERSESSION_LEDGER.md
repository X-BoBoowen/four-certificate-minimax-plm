# Old-package supersession ledger

Administrative status applied at H6:

`SUPERSEDED — DO NOT DISTRIBUTE FOR FUTURE REVIEW`

This status covers every pre-H6 blind review distribution package containing
Candidate-C1, Candidate-C2, Candidate-C3, Candidate-C4, Candidate-C5, or the
pre-R1 Candidate-C6 manuscript, including packages under the historical
`audit/handoff/`, `audit/handoff_c2/`, `audit/handoff_c3/`,
`audit/handoff_c4/`, and `audit/handoff_c5/` roots.

The status is an external ledger marker only.  No historical ZIP was opened,
rewritten, renamed, or byte-modified.  Return archives remain evidence records
and are not eligible as future review inputs.  H2 reference archives remain
separately closed and were not accessed.

The sole future-distribution controls are the three exact Candidate-C6-R1 ZIPs
in `audit/handoff_c6_r1/`.

