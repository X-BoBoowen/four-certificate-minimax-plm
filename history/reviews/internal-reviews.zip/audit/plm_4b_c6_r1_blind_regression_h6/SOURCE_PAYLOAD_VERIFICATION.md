# Primary-source payload verification

Verification date: `2026-08-26`.

M contains only the Bartlett--Bousquet--Mendelson journal paper, using the
official arXiv copy of the Annals of Statistics article.  S contains nine
source full texts.  G contains no source PDF.

| Role | Source/version | Pages | SHA-256 |
|---|---|---:|---|
| M | Bartlett--Bousquet--Mendelson, arXiv `math/0508275v1` / Annals 2005 | 43 | `A638D7C42C00D5D1385AC2B19B69DD779ED96B7936F56A5B0C302ACEBC690BBF` |
| S | Gu COLT open problem, PMLR 291 (2025) | 5 | `72A96E3352B728F6696F00260082097C441B4CD012327DBAA022E207BCE17E0B` |
| S | Gu--Yin--Cai--Fan, arXiv `2606.06368v1` | 23 | `AAE23C43852FD85CA2CBCDF218B36844A2FFAB1819F187E16A0DA62F875B99AD` |
| S | TAME, arXiv `2607.21541v1` | 31 | `82D53DBB082D831FC89377EF26E1D84A5AC6DDBEB782D2CA4DCB58E21756A446` |
| S | Balakrishnan--Kennedy--Wasserman, arXiv `2305.04116v2` | 34 | `57BE5566AE48FA193771C7E0F9DC586617D95D5213BEC94316755CB90559C400` |
| S | Robins et al., publisher-version Semiparametric Minimax Rates | 18 | `6D141971ED9760B86C4327934E84CEAD00E984A1BAE6CB80ACA241B66E54B5D0` |
| S | Calibrated DML, arXiv `2411.02771v3` | 109 | `EE36F045003D9D1731B9D43803190C2E6FEE0DC737AE1FB0A07E77B4BA17AB24` |
| S | Liu--Mukherjee--Robins, arXiv `2606.22391v1` | 27 | `ECA77324100D6724B19C7C2CB1946ABAE822140460C3863BABCDAC6B2AC0240F` |
| S | Jin--Mackey--Syrgkanis, arXiv `2507.02275v3` | 70 | `3B458299F3437117AD59412AABD675EF47CEFF47AD8627028CEAAA616D181247` |
| S | Jin--Syrgkanis, arXiv `2512.17341v2` | 117 | `0C7328D1C7D8CB462CB6ED05D3C347C3209244D4BC90D45EC5366FF07FA9197C` |

Every PDF passed the PDF signature, title-needle, and minimum-page full-text
checks.  Retrieval URLs and timestamps are in
`audit/handoff_c6_r1/evidence/SOURCE_PROVENANCE.tsv`.  These sources are blind
evidence, not an answer key and not a novelty determination.  H2 was not used.

