# Package, blinding, and sanitization report

## Final archives

| Role | Entries | Bytes | SHA-256 |
|---|---:|---:|---|
| M | 10 | 680971 | `019A4408482CCAF0900257ED583C977AF523F8B5B5EA07957E61D12307CDD226` |
| S | 19 | 6696979 | `ECA6A8A3B5D4616BFCCBADC8D5C7CEAB5128651769F86A010F9E6F50FB1F42D0` |
| G | 10 | 332136 | `B52FF28098EE4CB6A02BC629663498C65E451E6A2A70F41F19B58ECBB983125A` |

The independent package checks pass M `16/16`, S `24/24`, and G `15/15`.
All three embedded manuscript files are byte-identical to Candidate-C6-R1
(`F014C704...86C7654`).

## Isolation and sanitization

- Exact role whitelists pass; entries are unique, relative POSIX paths with no
  traversal, hidden, cache, temporary, directory-only, or encrypted member.
- Candidate metadata is anonymous; author/title/subject/keyword fields are
  empty.
- Windows/POSIX private paths, Codex/cache paths, local account/project
  identity, reference-stage markers, internal terminals, old numeric scores,
  and correction-history verdicts have `0` unexplained hits in every package.
- M contains one BBM source and mathematical forms only; S contains nine
  primary sources and source/significance forms only; G contains no source or
  M/S specialist form.
- Embedded manifests close `9/9`, `18/18`, and `9/9` non-manifest members.
- Three separate fresh temporary extractions reproduce `10/10`, `19/19`, and
  `10/10` entry hashes.  Extraction directories were deleted and never packed.
- Every human/AI response field is blank; reviewer execution count is `0`.
- All README files are usable from zero context and all packages carry the
  complete AI-credit/session-disclosure boundary.

## Failed-attempt handling

Build runs 1 and 2 failed before final distribution copy and remain isolated
under their explicit `DO_NOT_DISTRIBUTE` directories with their failure
evidence.  They were not overwritten.  Only the three ZIPs at the
`audit/handoff_c6_r1/` root are distributable.

