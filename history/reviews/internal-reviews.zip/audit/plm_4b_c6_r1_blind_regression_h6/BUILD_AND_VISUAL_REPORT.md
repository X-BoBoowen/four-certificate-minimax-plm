# C6-R1 build and visual report

Verification time: `2026-08-26T22:11:15.0802119+08:00`.

## Derivation and build

- `paper/master_r8_r1/` was copied from protected Master-R8 and changed only
  by frozen edits D1--D5.
- `paper/iclr2027_candidate_c6_r1/` was copied from the repaired Master-R8-R1
  tree and built independently.
- Both trees were built with Tectonic `0.17.0`; both final logs contain zero
  compilation errors, undefined citations/references, duplicate-label
  warnings, overfull/underfull boxes, or unresolved LaTeX/package warnings.
- The source scan finds `58` labels and `0` duplicate labels.

## Pagination and metadata

- Both PDFs have `37` pages.
- Main text ends on page `9`.
- References begin on page `10`; appendix material follows the bibliography.
- PDF author, title, subject, and keyword metadata are empty in both builds.
- No scientific content was removed or compressed to obtain the pagination.

## Equivalence and visual inspection

- Extracted text agrees page-by-page for `37/37` pages.
- Independent 1.5x raster hashes agree page-by-page for `37/37` pages.
- The all-page contact sheet was inspected for every page; full-resolution
  checks additionally covered the title/abstract, Proposition 3, page 9,
  Appendix L, and the final appendix pages.  No clipping, overlap, blank page,
  broken heading, unreadable formula, or malformed table was observed.
- Because every raster page agrees, the Candidate visual inspection also
  covers the Master rendering.

## Final PDFs

- Master-R8-R1: `5C2418B3308DACB160CA872199724AEB7CEF4E7CAF16A1FF4C7A28C0B1B586AD`.
- Candidate-C6-R1: `F014C7046C22C57B60D625C11407DD8A6CA363C001B64D314F6164F3B86C7654`.

Candidate-C6-R1 is the sole manuscript embedded in the new blind packages.

