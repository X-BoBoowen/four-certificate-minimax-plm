# C6-R1 regression and mutation report

Run date: `2026-08-26`.

## Authoritative regression replay

| Suite | Result |
|---|---:|
| C6 source, build, equivalence, protected, and nine hostile mutations | 119/119 |
| C5 protected integration and mutations | 64/64 |
| X1/R1 mathematical regression | 15/15 |
| PDF infinity extraction/mutation | 3/3 |
| positive-`c_rad` membership | 9/9 |
| scalar-q target cap and splice | 9/9 |
| joint empirical upper | 11/11 |
| C2-R1 validator | 12/12 |
| P raw-law identities | 7/7 |
| O raw-law identities | 9/9 |
| `ab` raw-law/falsifier | 16/16 |
| M raw-law/falsifier | 19/19 |
| K0 same-pair exact suite | 8/8 |
| Total registered authoritative checks | 301/301 |

## H6-specific gates

The H6 source, build, package, role-isolation, protected-file, and mutation
suite passes `81/81`.

The three new mutation families are independently detected:

1. reintroduction of the malformed sequential-M1 sentence;
2. regression from compatible-law membership to law membership in the public
   pair itself;
3. drift in the theorem rate, quantifier order, or bibliography.

No solver timeout, command failure, or search non-hit was interpreted as a
mathematical result.

