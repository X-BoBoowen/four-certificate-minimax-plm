# C4 G10 return provenance

## Intake rule

The three external return ZIPs were copied byte-for-byte into `intake/<role>/return.zip` after their controlling outer SHA-256 values matched. Safe unique relative entries were then extracted create-only into `intake/<role>/extracted/`. `FILE_MANIFEST.tsv` records every extracted byte string independently.

## M

- External SHA-256: `7AC0FE245C1B85FB5D2AE58A93B51CB24A5D73E8AC08F970879338755FA9EDA8`
- Entries: `22`; return-manifest rows: `21`; manifest errors: `0`
- Candidate closure: embedded `manuscript/anonymous_manuscript.pdf` is byte-identical to Candidate-C4.
- Declaration and full raw output: present.

## S

- External SHA-256: `8E408189C4369B08BADF118D0AA560078523545FAA2B4AA5FCF0DD0DE65FD1F4`
- Entries: `18`; checksum rows: `17`; checksum errors: `0`
- Candidate closure: return-only package; `LOCAL_FILES_AND_TOOLS_LOG.md` records the sealed S input archive SHA-256 `FB8C411141277811093B86A60DFEFC7D0594C8EAD9A37D68DFD36D18760A2BB1` and Candidate-C4 SHA-256 `F78A14D9377388B893DC7033F0308BCC62BF46F8150710E3F0DBFDB2CFA05226`.
- Declaration and full unabridged output: present.

## G

- External SHA-256: `669F6C3D277C0DF5A1ECB77ADC3AF4EF71BA45EBF3FF1964FB8F4108FFFA4AF1`
- Entries: `22`; return-manifest rows: `20`; manifest errors: `0`
- Candidate closure: embedded `manuscript/anonymous_manuscript.pdf` is byte-identical to Candidate-C4.
- Declaration and full raw output: present.

## Isolation and protected boundaries

No return declares receipt of another reviewer's substantive output. Operational mentions of sibling role labels or filenames do not supply their content. No returned manuscript differs from Candidate-C4. No H2 closed reference ZIP was listed, opened, copied, extracted, or read during intake.

The intake closes byte/provenance identity only. It does not certify the mathematical truth, source accuracy, or venue judgment of any return.
