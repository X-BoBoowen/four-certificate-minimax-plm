# AI-credit boundary

The M, S, and G returns are authenticated AI-generated red-team evidence.

- Independent-human mathematical audit credit: `0`
- Independent-human source audit credit: `0`
- Independent-human ICLR review credit: `0`
- Proof-complete credit from reviewer agreement: `0`
- Novelty or priority credit from search non-hit: `0`
- Submission-readiness credit: `0`

Provider/model/session declarations are preserved verbatim in the intake. They are not human names, signatures, credentials, or institutional attestations. Every correctness and attribution allegation must be independently checked against the manuscript, proof source, analytic derivation, or primary full text. Majority agreement cannot replace that check.

K0 does not contact reviewers, run new reviews, fill return forms, or promote any AI output to human evidence.
