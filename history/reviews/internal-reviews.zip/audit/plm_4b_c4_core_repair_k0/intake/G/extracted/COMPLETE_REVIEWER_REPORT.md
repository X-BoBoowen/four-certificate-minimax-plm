# Complete Reviewer G report

## Recommendation

**4/10 (weak reject), confidence 4/5.** This is a simulated independent Reviewer G report, not an official ICLR review. I recommend rejection of the submitted statement because the main minimax lower bound is mathematically false on an explicitly allowed covariate space. I would view a corrected fixed-infinite-space revision much more favorably.

## Paper and contribution

The manuscript gives a finite-sample, expected-absolute-error minimax characterization for a bounded partially linear coefficient under four pre-data public upper budgets: outcome approximation/stochastic budgets `(a,s)` and treatment approximation/stochastic budgets `(b,t)`. Its proposed interior rate is

`q + AB + M + O + P`,

where `q=n^-1/2`, `A=a+s^2`, `B=b+t^2`, `M=(s∧t)^2`, `O=t(a∧t)`, and `P=s(b∧s)`. The upper bound uses two public oriented branches; the lower bound uses five finite testing witnesses. A shared envelope yields empty, interior, and saturated regimes.

The strongest residual contribution is the directional O/P phenomenon. It raises the inherited `AB+M` lower order from `r^3` to `r^2` on the O and P rays. The saturation result is also conceptually sharp. Public-source checks support the paper's attribution of the TAME upper and earlier PLM lower results; I found no verified direct collision for the O/P theorem, without treating search non-hits as proof of novelty.

## Decisive correctness finding

Section 2 fixes a standard Borel covariate space before defining `Gamma`, compatible laws, and the Q1 risk. Appendix A emphasizes that this includes all finite spaces. Theorem 1 then claims the lower rate for every budget tuple. Yet Appendix C.4 sets the covariate space to a Walsh group whose dimension grows with the number of hard directions. Because `Gamma` contains only the two function classes, not the underlying space, that step is not legal for an already fixed finite space.

The contradiction is explicit on a singleton. In that experiment `pi0` and `mu0` are constants. Pair the `2n` samples and define

`A_i=(T_{2i-1}-T_{2i})(Y_{2i-1}-Y_{2i})`,

`D_i=(T_{2i-1}-T_{2i})^2`,

and estimate `beta0` by the clipped ratio `Abar/max(Dbar,v_-)`. Since `E[D_i]=2v>=2v_-` and `A_i-beta0 D_i=(Delta T_i)(Delta epsilon_i)` is mean zero and bounded by `4B0^2`,

`E|delta-beta0| <= 4B0^2/(v_-sqrt(n)) + 6 exp{-n v_-^2/(8B0^4)}`.

This is uniform over all public pairs and compatible laws on the singleton, so the Q1 outer supremum is also root-n. But at `(a,s,b,t)=(0,1/2,0,1/2)`, the paper's nuisance quantity is `X=5/16`, and Eq. (6) demands a nonvanishing lower bound. Thus the headline theorem is false as written.

The minimal plausible repair is to require one fixed **infinite** standard Borel space and embed all finite Walsh families into it, or to put the covariate space itself inside the outer adversary. Either way, claims covering arbitrary finite spaces must be removed or replaced by a separate finite-space theorem.

## What survived attack

The failure above should not obscure real technical strengths. I independently recalculated the saturation implication, the P/O moment identities, the signed-mixture Gram algebra, and the max-to-sum assembly. All survived. The exact Q1 order does allow different component witnesses, so combining their scalar lower bounds via a maximum is correct. The sample-split conditional-centering logic and measurable M1 selectors also appear sound. Two million random budget tuples produced no violation of the deterministic inequalities relating `V`, `W`, `X`, and `S0`. These are meaningful positive findings, conditional on correcting the domain.

## Scope, novelty, and significance

Even after the correction, the theorem is narrower than a generic four-budget minimax characterization. The public pair may vary with `n` and the budget cell, and each lower component may use a different pair. The learner knows the budgets and may use a pair-specific rule. This is all disclosed, and hence is not a correctness defect, but it means the sum rate need not be the difficulty of one fixed natural class or one adaptive procedure. The title and abstract should foreground the pair-specific known-budget envelope, or the paper should add a common-pair/fixed-sequence result.

The O/P terms and boundary synthesis appear plausibly novel in the checked public record. Literature positioning should nevertheless add calibrated debiased machine learning, notably van der Laan, Luedtke, and Carone (arXiv:2411.02771), which also exploits one-good/one-poor nuisance behavior. I found conceptual adjacency, not a direct minimax collision.

## Clarity, reproducibility, limitations, and ethics

The writing is dense but professional and unusually honest about assumptions. Technical correctness, novelty, and importance are not interchangeable here: the current theorem is incorrect; the repaired technical contribution could still be novel; and its broader impact remains moderate because of the specialized Q1/M1 interface, bounded homoskedastic model, known budgets, and lack of common-rule adaptation.

The theory is mostly reproducible from the 23-page appendices. The manuscript hash matches, all 32 pages were read and visually checked, and the key formulas were independently recalculated. The Figure 1 generator named on page 9 was not included in the supplied archive, so that executable claim was not assessable.

There is no direct ethics concern. The paper correctly refuses a causal interpretation without further assumptions and transparently discloses substantial generative-AI use plus the lack of complete independent human verification.

## Questions whose answers could change the recommendation

1. Is the intended theorem on a fixed infinite standard Borel space? If so, can every lower family be reconstructed inside that one space and the finite-space claims removed?
2. What is the correct fixed-finite-space minimax law, starting with `|X|=1`?
3. Can the directional terms be realized by one fixed public pair or sequence, or can the scope be retitled more narrowly?
4. Can calibrated-DML work be cited and theorem-level differences stated?
5. Can the referenced figure generator and an independent human proof audit be supplied?

The strongest acceptance case is that the infinite-space repair is local and preserves a technically substantial directional minimax result. The strongest rejection case, which controls my present score, is the explicit singleton contradiction to Eq. (6).
