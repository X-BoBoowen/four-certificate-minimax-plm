# 来源声明

Provider：OpenAI

Model：Codex（基于 GPT-5）

Exact model/version：平台未提供

Session or instance ID：平台未提供

Reviewer instance ID：Reviewer G（用户指定；平台内部实例 ID 未提供）

是否为全新会话：是；就当前可见上下文而言，这是第一次接触本项目

此前是否接触过本项目：否；未接触 M、S、其他 G、旧评分、内部审计、参考答案、修订历史或其他审稿意见

审查日期、时间及时区：2026-08-26 15:55:41，Asia/Shanghai（UTC+08:00）

联网、计算及文件处理能力：可访问公开互联网；可在本地安全解压 ZIP、读取并渲染 PDF、提取文本、运行 Python/NumPy 独立计算、检查 DOI/Crossref 与官方 arXiv/PMLR 页面、生成新文件和 ZIP、计算 SHA-256。未访问非公开数据库或其他审稿材料；未搜索匿名作者身份。完整工具与来源记录见 `EXTERNAL_SOURCE_AND_TOOL_LOG.md`。

输入 ZIP SHA-256：`0BD56802468FAB1847F20AC5A899AC9213B0AFFC0D5A971F4707A6D868D4EC05`

输出 ZIP SHA-256：见最终答复以及与 ZIP 同目录的 `.sha256` 侧车文件。归档文件无法稳定地在自身内部嵌入其最终自哈希，因为任何内嵌更新都会改变该哈希。

材料说明：请求正文写的是 C2，但实际附件为 `PLM4B_C4_GENERAL_ICLR_REVIEWER_BLIND_FIRST_PASS.zip`；本次审查仅针对实际附件 C4。
