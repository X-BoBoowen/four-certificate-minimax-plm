# External source, file-access, and tool log

## Independence and isolation

- First project contact in the visible session: yes.
- Prior substantive project context in the visible session: none.
- M, S, other G, old-score, audit, correction, reference-answer, and author-expectation materials accessed: none.
- Anonymous author identification attempted: no.
- The attached archive was C4 although the request prose said C2; only the attached C4 archive was reviewed.

## Input files actually read

1. `README.md`
2. `GENERAL_ICLR_REVIEW_INSTRUCTIONS.md`
3. `AI_OR_HUMAN_REVIEW_NOTICE.md`
4. `EXPERTISE_CONFLICT_MODEL_DECLARATION.md`
5. `ICLR_STYLE_REVIEW_FORM.md`
6. `TECHNICAL_ISSUE_LOG.md`
7. `NOVELTY_CITATION_LOG.md`
8. `RETURN_CHECKLIST.md`
9. `PACKAGE_MANIFEST.tsv`
10. `MANUSCRIPT_HASH.txt`
11. `manuscript/anonymous_manuscript.pdf`, pages 1--32 inclusive.

Generated inspection intermediates read: full PDF text extraction and rendered images for pages 1--32. Operational skill/instruction files are enumerated in `EXPERTISE_CONFLICT_MODEL_DECLARATION.md`.

## Public sources inspected

- PMLR official page: https://proceedings.mlr.press/v291/gu25b.html
- arXiv official pages: https://arxiv.org/abs/2607.21541 and https://arxiv.org/html/2607.21541
- arXiv official pages: https://arxiv.org/abs/2606.06368 and https://arxiv.org/html/2606.06368
- arXiv official HTML: https://arxiv.org/html/2507.02275
- arXiv official HTML: https://arxiv.org/html/2512.17341
- arXiv official page: https://arxiv.org/abs/2411.02771
- DOI/Crossref metadata for 10.1214/009053605000000282, 10.1111/ectj.12097, 10.1214/23-AOS2258, 10.1214/09-EJS479, and 10.2307/1912705.

Search themes included exact cited titles; the exact expressions `t(a∧t)` and `s(b∧s)`; four-budget/directional/structure-agnostic PLM minimax phrasing; and calibrated nuisance-robust inference. Exact-phrase non-hits were recorded only as non-hits, never as proof of novelty.

## Tools and operations

- PowerShell/.NET: directory inspection, safe ZIP-entry validation/extraction, copying into a separate return tree, text search (fallback after `rg` was unavailable), timestamps, checksums, and archive creation.
- SHA-256: input ZIP, manuscript, every returned file, and final output ZIP.
- Poppler `pdfinfo`: page count, media size, encryption/form status, and metadata.
- Poppler rendering and local image viewer: visual inspection of all 32 pages.
- Python `pdfplumber`: full-text extraction with page separators.
- Python/NumPy: two-million-point random stress test of the manuscript's deterministic budget inequalities. All claimed inequalities survived; this was corroboration, not proof.
- Direct algebra plus ordinary computation: P/O lower-family moment identities and the singleton-space counterexample. SymPy import failed because the package was absent; no result depends on it.
- Public web browsing: official PMLR/arXiv pages and public search.
- Crossref REST API: bibliographic field verification.
- Patch-based local editing: all completed forms and generated reports.

## Key computed evidence

- Input ZIP SHA-256: `0BD56802468FAB1847F20AC5A899AC9213B0AFFC0D5A971F4707A6D868D4EC05`.
- Manuscript SHA-256: `F78A14D9377388B893DC7033F0308BCC62BF46F8150710E3F0DBFDB2CFA05226`, exactly matching `MANUSCRIPT_HASH.txt`.
- PDF: 32 pages, US Letter, unencrypted, no interactive form.
- Deterministic inequality stress test: no negative margin or ratio violation in 2,000,000 independent uniform budget tuples.
- Decisive analytic counterexample: fixed singleton covariate space gives uniform root-n risk, while the theorem's `(0,1/2,0,1/2)` budget quantity is `X=5/16`.
