# ICLR-style review

Summary:

The paper studies expected absolute-error minimax estimation of the coefficient in a bounded partially linear model under four public upper budgets: outcome-side approximation and stochastic budgets `(a,s)`, and treatment-side budgets `(b,t)`. Under a pair-specific M1 access model and Q1 minimax order, it proposes the interior rate

`n^{-1/2} + (a+s^2)(b+t^2) + (s∧t)^2 + t(a∧t) + s(b∧s)`,

with an oriented two-branch upper estimator, five finite testing lower bounds, and separate empty/interior/saturation regimes induced by the common bounded envelope. The directional `O=t(a∧t)` and `P=s(b∧s)` terms and the saturation calculation are the paper's clearest conceptual contributions.

I found the proof architecture unusually explicit and several central algebraic and probabilistic components survived independent attack. However, Theorem 1 is false under the covariate-space quantifier as written. Section 2 first fixes an arbitrary standard Borel space, which explicitly includes finite spaces, while the lower bound later replaces it by Walsh groups whose dimension grows with the required number of directions. On the valid one-point space, a simple pair-difference slope estimator has uniform `O(n^{-1/2})` risk for every public pair and every four-budget cell, contradicting the positive nuisance lower bound in Eq. (6), for example at `(a,s,b,t)=(0,1/2,0,1/2)`. This is a confirmed reject-level correctness problem in the main theorem statement, although a restricted theorem on a fixed infinite standard Borel space may be repairable without changing the core constructions.

Strengths:

1. The manuscript clearly separates approximation from stochastic budgets and identifies genuinely directional interactions that a one-rate-per-learner summary obscures.
2. The upper construction is technically thoughtful: it makes the branch choice public, addresses all-budget fallbacks, supplies Borel selectors, and keeps fitted-index substitutions behind uniform events.
3. The P- and O-family moment matching is nontrivial and, on independent recalculation, correct. The max-to-sum lower assembly is also valid for the exact Q1 risk.
4. The saturation result is clean: the shared envelope forces `u=±B0`, `pi0=0`, and hence a direct sample-moment representation of `beta0`.
5. Assumptions, nonclaims, AI use, pair-specificity, lack of causal interpretation, and absence of empirical evidence are disclosed more candidly than usual.
6. Public-source checks support the paper's attribution of the inherited TAME upper and earlier `AB+M` lower envelopes. I found no verified direct collision for the new O/P minimax terms, while treating search non-hits as inconclusive.

Weaknesses:

1. **Confirmed main-theorem failure:** the lower bound changes the already fixed covariate space. A one-point standard Borel counterexample gives parametric risk in budget cells where Eq. (6) asserts a constant-order nuisance lower bound.
2. **Narrow scientific scope:** the Q1 outer supremum permits a different public class pair for each sample size, budget cell, and lower-bound component. Thus the displayed sum need not be the difficulty of one fixed natural learning problem. The authors state this correctly, so it is not a hidden proof error, but it materially limits the significance suggested by the title and headline minimax formula.
3. **Literature positioning is incomplete:** calibrated/debiased learning work provides a conceptually adjacent one-good-nuisance/one-poor-nuisance route and should be discussed, even though it does not appear to supply the exact four-budget PLM minimax theorem.
4. The theoretical formulas are largely reproducible from the appendices, but the Figure 1 generator named on page 9 was not included in the supplied archive and could not be checked.

Questions:

1. Was Theorem 1 intended only for a fixed **infinite** standard Borel space, or was the covariate space intended to be part of the outer adversary? Please state the intended quantifier formally and redo the lower construction inside that fixed space.
2. What is the correct minimax law for a fixed finite covariate space, at least for `|X|=1` and fixed finite `|X|`? The one-point calculation shows that the current four-budget lower law cannot hold there.
3. Can the O, P, M, and `ab` difficulties be realized by one fixed public pair (or a fixed sequence independent of the budget cell), rather than only by separate pairs combined through the outer supremum?
4. Can the result be extended to unknown budgets or one common rule, or can the paper more prominently qualify the title/abstract as a known-budget pair-specific envelope result?
5. Please cite and distinguish calibrated debiased/orthogonal learning results that also exploit directional nuisance behavior.
6. Can the referenced analytic figure generator be included with the submission materials?

Correctness:

Not correct as stated. The counterexample in Issue G-1 directly contradicts the lower half of Theorem 1 for an allowed covariate space. Conditional on repairing the domain to a fixed infinite standard Borel space (or explicitly placing the space in the outer supremum), I did not find another confirmed failure in the estimator identities, testing constructions, saturation proof, or lower-bound assembly. Those components survived substantial but not formal-machine-checked review.

Novelty:

Promising but conditional. The public record supports the stated ancestry: the TAME-style branch upper and the earlier `AB+M` lower are inherited, while the O/P bridge terms and shared-envelope three-stratum synthesis appear to be the main residual contribution. Exact-phrase and theorem-neighborhood searches found no direct public collision, but a search non-hit is not proof of priority or novelty. The omitted calibrated-DML work is conceptually adjacent and should be differentiated.

Significance:

Moderate. The directional phenomenon is interesting to semiparametric and structure-agnostic learning theory, and it directly addresses a recent open-problem line. The impact is reduced by fixed known budgets, homoskedastic treatment residuals, bounded shared envelopes, pair-specific rules, and lower components that may use different public pairs. The current finite-space counterexample further invalidates the broad stated domain.

Clarity:

Generally strong and unusually explicit about quantifiers and limitations, but very dense. The central fixed-space/lower-construction inconsistency is especially consequential precisely because the paper emphasizes native quantifiers and claims inclusion of all finite spaces.

Soundness:

Mixed. Many proof modules are carefully engineered and survived attack, but the main minimax theorem is unsound under its stated domain. This is not cured by the correctness of the conditional infinite-space construction.

Presentation:

Professional, well organized, and visually clean. The main nine pages convey the thesis and proof map, although full verification necessarily depends on the long appendices. The literature table is useful but too narrow to substitute for a broader related-work discussion.

Contribution:

If the domain is repaired, the paper offers a technically substantial characterization of a sharply specified minimax experiment, especially through the directional O/P lower bounds and the saturation boundary. As submitted, the headline theorem overclaims its covariate-space scope.

Limitations:

The paper explicitly acknowledges most interface limitations: no causal claim, no budget adaptation, no single common rule, no computational guarantee, no heteroskedastic result, no empirical superiority, and pointwise constants. It does not acknowledge the decisive distinction between fixed finite and fixed infinite covariate spaces.

Ethics:

No direct ethical concern. The statistical coefficient is not presented as causal without additional identification assumptions. The extensive AI-use statement is transparent and appropriately requests human verification. I did not seek author identity.

Reproducibility:

The mathematical model, estimators, lower families, constants, and proof audit are supplied in the appendices. I independently checked the manuscript hash, rendered and read all 32 pages, recalculated the decisive counterexample, checked O/P moment identities, and stress-tested the deterministic budget inequalities over two million random tuples without finding a violation. The Figure 1 script referenced on page 9 was absent from the review archive, and no formal proof assistant or author code was available.

Overall score 1-10: **4/10 (weak reject).** The main theorem is false as written, but the repair may be localized to the covariate-space domain and the remaining technical contribution appears substantial.

Confidence 1-5: **4/5.** High confidence in the counterexample and scope assessment; not 5 because I did not formally machine-check every appendix argument and the intended covariate-space quantifier may have been different from the written one.

Strongest reject-level objection:

Theorem 1 quantifies after fixing an arbitrary standard Borel `X`, but the lower proof changes `X` to growing Walsh groups. For the allowed singleton `X`, the pair-difference estimator has uniform root-n risk, contradicting Eq. (6) whenever `X(a,s,b,t)` stays bounded away from zero.

Strongest acceptance case:

If the intended theorem is explicitly restricted to a fixed infinite standard Borel space, every required finite Walsh group can plausibly be embedded in that fixed space, while the oriented upper bound, O/P testing laws, deterministic equivalence, and saturation theorem retain their substance. Under that repaired statement, the paper appears to make a real and technically nontrivial contribution to the structure-agnostic PLM literature.

Does the main nine-page contribution stand independently:

**No as submitted.** Pages 1--9 communicate the contribution and the decisive formulas, but the main theorem is invalid under its stated domain and the proof-validity case depends essentially on the appendices. Conceptually, the contribution could stand after a corrected domain statement and corresponding lower-bound embedding argument.
