# General ICLR first pass

1. Read `manuscript/anonymous_manuscript.pdf` from the beginning without external project context.
2. Follow `GENERAL_ICLR_REVIEW_INSTRUCTIONS.md`.
3. Fill the declaration, review, issue, citation, and return files in this archive.
4. Return the completed files together with the full raw review output and model disclosure.

Do not seek author identity or another reviewer's opinion.
