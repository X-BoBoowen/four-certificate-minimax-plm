# AC-style synthesis

This is a simulated AC-style synthesis from one independent Reviewer G analysis; it is not an official decision and does not aggregate other reviewers.

The paper has a potentially valuable technical core: four public nuisance budgets reveal directional terms missed by the inherited product/shared-stochastic envelope, and the common bounded envelope creates a mathematically clean saturation regime. Several components that would normally attract skepticism—the O/P moment matching, the signed-mixture reduction, the max-to-sum assembly, the sample-split upper identities, and the boundary calculation—survived independent attack. The paper also discloses its narrow access model and nonclaims with unusual clarity.

The decisive issue is nevertheless a real main-theorem correctness failure, not a matter of reviewer taste. The experiment fixes an arbitrary standard Borel covariate space, explicitly including finite spaces, but the lower proof replaces that space by Walsh groups with dimension increasing in `n` and the budget. On the allowed singleton space, a paired-difference estimator has uniform root-n risk for all public pairs, directly contradicting the nuisance lower bound at fixed positive stochastic budgets. This should dominate the present recommendation.

The severity is tempered by repairability. If the intended domain is a fixed infinite standard Borel space, the finite hard instances can plausibly be embedded into it and most of the technical paper may survive. That is more than typography: the theorem, abstract, formal experiment, Appendix I, and claims about finite spaces must all change, and finite spaces have genuinely different minimax behavior. A revision should make the quantifier explicit and prove the embedding inside one fixed space.

Correctness and novelty should be scored separately. The submitted theorem is incorrect, supporting rejection. Conditional on the domain repair, the O/P lower terms and saturation synthesis appear plausibly novel and technically substantial; the public search found no direct theorem collision, but non-hits do not establish priority. Significance remains moderate rather than broad because Q1 allows different public pairs across components, sample sizes, and budget cells and assumes known budgets and pair-specific rules. This is a disclosed scope choice, not a proof defect.

Evidence most likely to change the assessment:

1. A corrected theorem on a fixed infinite standard Borel space, with every Walsh family embedded measurably into that same space and all constants/budgets rechecked.
2. A separate theorem or discussion for fixed finite `X`, beginning with the singleton root-n case.
3. A common-pair or fixed-sequence lower construction, or a clearer title/abstract that foregrounds the pair-specific outer-envelope interpretation.
4. A precise comparison to calibrated DML and any other theorem-level contemporaneous work.
5. Independent human verification of the long proof, as already requested by the manuscript's AI-use statement.

Recommended outcome on the present version: **4/10, weak reject; confidence 4/5.** I would not endorse rejection on lack of experiments, unfamiliarity, or stylistic density. I would endorse it because Eq. (6) is mathematically false on an explicitly allowed experiment.
