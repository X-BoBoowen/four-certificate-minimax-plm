# Independent review notice

This archive is a blind first-pass review package. Review only the enclosed materials and do not seek author identity or project history.

If an AI system performs the review, its return must disclose provider, exact model and version or state that the version is not exposed, session or instance identifier or state that it is not exposed, session date, every file read, every tool used, and the full unedited raw output. An AI system must not claim a human name, signature, credential, or independent-human status. AI output is red-team evidence only and cannot substitute for human review.

Do not consult another reviewer or any answer, reference, correction, or prior-review package. Do not edit the manuscript. A literature search non-hit is not evidence of novelty, priority, or absence of collision.
