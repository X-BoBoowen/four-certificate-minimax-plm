# Full raw Reviewer G output

This file contains the complete final review output delivered by the AI reviewer. It does not claim to expose hidden chain-of-thought or private scratch reasoning. No portion of the final review has been withheld; the structured forms and evidence tables in this return package are part of this output.

## Independence confirmation and material identity note

This was my first contact with the project in the visible conversation. The conversation contained no substantive prior project information. I did not read, search for, or infer M, S, another G report, an old score, internal audit, correction, answer key, author expectation, or revision history. I did not seek the anonymous authors' identities. Sibling archive filenames became visible only while resolving the supplied file path; no sibling content was opened.

The request prose names a C2 archive, but the supplied attachment is `PLM4B_C4_GENERAL_ICLR_REVIEWER_BLIND_FIRST_PASS.zip`. No C2 attachment was available. This report is therefore a review of the attached C4 archive only.

## Final recommendation

**Overall: 4/10 (weak reject). Confidence: 4/5.**

The main minimax theorem is false under its stated covariate-space quantifier. The defect is decisive for the submitted version but plausibly repairable by restricting the theorem to a fixed infinite standard Borel covariate space or explicitly placing the covariate space inside the outer adversary. Conditional on that repair, the paper contains a nontrivial and plausibly novel technical contribution.

## Complete Reviewer report

The paper studies expected absolute-error estimation of the coefficient in a bounded partially linear model with two sample halves and four pre-data public upper budgets: outcome approximation/stochastic budgets `(a,s)` and treatment approximation/stochastic budgets `(b,t)`. Under its M1 access convention and pair-specific Q1 minimax order, it proposes the interior rate

`n^-1/2 + (a+s^2)(b+t^2) + (s∧t)^2 + t(a∧t) + s(b∧s)`.

The upper bound uses a public oriented selector between two TAME-derived branches, with a bounded fallback. The lower bound constructs separate finite witnesses for the parametric, `ab`, shared-stochastic, O, and P terms and combines them through the outer public-pair supremum. A common bounded envelope produces an empty regime above the feasible residual-variance boundary, the four-budget interior regime, and a saturated root-n regime at equality.

The strongest contribution is the directional O/P phenomenon. On the O-ray `(a,t)=(r,r), b=s=0` and its P mirror, the inherited lower envelope is order `r^3`, whereas the new directional term is order `r^2`. The shared-envelope saturation calculation is also elegant and useful. The paper is unusually explicit about measurability, public information, pair-specificity, missing adaptation, lack of computational claims, noncausal interpretation, and AI use.

Several hard technical components survived independent scrutiny. The P construction's two labels match `E[Y|X]` and `E[TY|X]` after imposing `kappa=gamma+Delta eta` and `Delta v=2 eta gamma`. The O construction's required treatment-outcome moment matches under `Delta=gamma eta/(v+gamma^2)`. The signed-mixture Gram calculation and max-to-sum assembly are algebraically consistent. The latter is legitimate for the exact Q1 risk: the scalar outer supremum separately dominates every component witness, after which a deterministic maximum-to-sum equivalence can be used. The sample-split upper-bound conditioning and the Borel-selector construction also survived the attacks I could perform. The saturation boundary follows rigorously from equality in the bounded second-moment constraint. Two million independent random budget tuples produced no violation of the deterministic inequalities used to compare the selector rate to the stated rate.

The decisive problem occurs earlier, at the theorem's quantifier. Page 2 fixes a standard Borel covariate space before defining the model and Q1 risk. Appendix A explicitly says this includes all finite spaces. Yet Appendix C.4 declares `X` to be a finite Walsh group whose dimension depends on the number of hard directions and hence on `n` and the budget. The public pair `Gamma` contains the function classes, not a replacement covariate space. Appendix I again calls the Appendix-A space fixed. The lower construction therefore leaves the experiment whenever the initially fixed space cannot host the growing Walsh dictionary.

The allowed singleton space gives a direct contradiction. In that experiment `pi0` and `mu0` are constants. Pair the `2n` samples. Let

`A_i=(T_{2i-1}-T_{2i})(Y_{2i-1}-Y_{2i})`,

`D_i=(T_{2i-1}-T_{2i})^2`,

and set `delta=clip_[−3,3](Abar/max(Dbar,v_-))`. Because `Delta Y=beta0 Delta T+Delta epsilon`,

`E[A_i]=beta0 E[D_i]`, `E[D_i]=2v>=2v_-`,

and `W_i=A_i-beta0D_i=Delta T Delta epsilon` is mean zero with `|W_i|<=4B0^2`. Thus `E|Wbar|<=4B0^2/sqrt(n)`. Since `D_i` lies in `[0,4B0^2]`, Hoeffding gives

`P(Dbar<v_-) <= exp{-n v_-^2/(8B0^4)}`.

Clipping then yields the uniform bound

`E|delta-beta0| <= 4B0^2/(v_-sqrt(n)) + 6 exp{-n v_-^2/(8B0^4)}`.

The estimator ignores the public pair, so this is uniform after the Q1 outer supremum. The admissible set is nonempty. For any interior regularity tuple, take the budget cell `(a,s,b,t)=(0,1/2,0,1/2)`. The paper's nuisance quantity is `X=(1/4)(1/4)+1/4=5/16`, so Eq. (6) asserts a positive asymptotic lower bound. This contradicts the uniform root-n estimator. The failure is mathematical, not stylistic or a preference about method.

The most economical repair is to assume a fixed infinite standard Borel space and explicitly embed every finite Walsh family into that same space, extending functions measurably off the finite support. An alternative is to place the covariate space in the outer adversary. Either repair changes the stated domain and requires removing the claim that the same lower theorem covers arbitrary finite spaces. A separate finite-space characterization would strengthen the paper.

The second important point is scope rather than correctness. The Q1 rate is an envelope over public pairs that may change with `n` and the budget cell. Appendix G also uses different pairs for different lower components. The displayed sum therefore need not be the simultaneous difficulty of one fixed natural class or one adaptive learning problem. The paper says this, so I do not call it a hidden gap. It nevertheless reduces significance and should be foregrounded in the title/abstract or addressed by a common-pair/fixed-sequence result.

The public literature check supports the stated technical ancestry. Gu's COLT 2025 open problem identifies the structure-agnostic PLM/variance issue. Gu's arXiv:2607.21541 contains the two directional upper branches that map to `T_mu∧T_pi`. Gu, Yin, Cai, and Fan's arXiv:2606.06368 contains the inherited PLM lower structure summarized as `AB+M`. The Jin--Mackey--Syrgkanis and Jin--Syrgkanis results are adjacent lower-bound sources rather than identical theorem statements. I found no verified direct collision for O/P in the public sources searched, but a non-hit is not proof of novelty. The related-work discussion should add van der Laan, Luedtke, and Carone, arXiv:2411.02771, because calibrated debiased learning also exploits one-good/one-poor nuisance behavior, while carefully distinguishing its asymptotic linear-functional inference target from this finite-sample PLM minimax theorem.

The paper is technically dense but professionally presented. No empirical experiment is required for a pure minimax theorem. Reproducibility is strong at the formula/proof level, although the Figure 1 generator named on page 9 was absent from the archive. The ethics posture is sound: the coefficient is not mislabeled causal, and substantial generative-AI use plus the need for human verification are plainly disclosed.

The strongest acceptance case is therefore substantial: after a correct infinite-space restriction, the oriented upper bound, O/P testing mechanisms, deterministic equivalence, and saturation result appear to form a real contribution. The strongest rejection case controls the submitted score: Eq. (6) is false on an explicitly allowed singleton experiment.

## Complete issue disposition

- **G-1: CONFIRMED FAILURE, Major, high confidence.** Fixed-space quantifier versus growing Walsh spaces; singleton root-n counterexample. Reject-level as written.
- **G-2: STRONG CONCERN, Moderate, high confidence.** Q1 is a reselectable public-pair envelope, not necessarily one fixed learning problem. Significance limitation, not a proof error.
- **G-3: PLAUSIBLE ALTERNATIVE, Minor, medium confidence.** Calibrated-DML adjacency should be cited and distinguished; no direct collision confirmed.
- **G-4: NOT ASSESSABLE, Minor, high confidence.** Referenced figure generator absent; no claim that Figure 1 is wrong.

Full page locations, original claims, first-failure points, derivations, scoring impacts, reverse-fairness checks, and minimal repairs appear in `FULL_ISSUE_LIST.md`.

## Claims explicitly recorded as surviving attack

The saturation theorem; P and O moment matching; mixture chi-square algebra; Q1 max-to-sum assembly; deterministic budget equivalences; sample-split conditional centering; measurable M1 selection; the stated ancestry of the TAME upper and inherited lower; and the absence of a causal overclaim all survived the attacks performed. Details are in `SURVIVED_ATTACKS.md`.

## Simulated AC-style synthesis

The correctness issue is real and should dominate the present decision. It is not an over-demand for experiments or a disagreement about research taste. At the same time, the paper should not be dismissed as empty: most of the difficult proof machinery appears internally consistent, the directional phenomenon is interesting, and the domain repair may preserve it. A revised theorem must use one explicitly fixed infinite space or a formal space-level outer supremum and must stop claiming the same nuisance lower law on arbitrary finite spaces. Correctness warrants rejection now; conditional novelty and technical depth warrant encouragement to revise.

Evidence most likely to change the assessment is: a corrected fixed-infinite-space theorem with in-space embeddings; a finite-space result; a common-pair or more clearly qualified scope; a calibrated-DML comparison; and independent human proof verification.

## Sources, limitations, and disclosure

All 32 manuscript pages and every archive control file were read. The manuscript SHA-256 exactly matched the package declaration. Public web use was limited to official PMLR/arXiv pages and DOI/Crossref metadata. No identity or other-review search was performed. The complete URLs, file list, tools, and computational checks are in `EXTERNAL_SOURCE_AND_TOOL_LOG.md`; bibliographic field checks are in `REFERENCE_VERIFICATION_REPORT.md`; unresolved matters are in `UNCONFIRMED_AND_MATERIAL_LIMITS.md`.

Provider: OpenAI. Model: Codex based on GPT-5. Exact build/version and session/instance ID: platform not provided. Reviewer instance label: G, user supplied. Date/time zone: 2026-08-26, Asia/Shanghai (UTC+08:00). This is AI-generated red-team evidence and does not claim a human identity, credential, signature, or official Reviewer/AC authority.
