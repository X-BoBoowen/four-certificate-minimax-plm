# Reference verification report

Verification date: 2026-08-26 (Asia/Shanghai). Public official pages and DOI/Crossref metadata were used. “Verified” means that the checked bibliographic fields and cited role agree with the public source; it does not certify every proposition in the cited work.

| Manuscript reference | Fields checked | Result | Notes |
|---|---|---|---|
| Bartlett, Bousquet & Mendelson (2005), *Local Rademacher Complexities*, DOI 10.1214/009053605000000282 | Title, authors, journal, year, volume/issue, DOI | Verified | DOI metadata agrees. The manuscript's pp. 1497--1537 are consistent with the journal citation; the Crossref response used did not independently expose the full page field. |
| Chernozhukov et al. (2018), *Double/Debiased Machine Learning for Treatment and Structural Parameters*, DOI 10.1111/ectj.12097 | Title, authors, journal, year, volume/issue, pages, DOI | Verified | Crossref metadata agrees with 21(1):C1--C68. |
| Foster & Syrgkanis (2023), *Orthogonal Statistical Learning*, DOI 10.1214/23-AOS2258 | Title, authors, journal, year, volume/issue, DOI | Verified | DOI metadata agrees. The manuscript's pp. 879--908 were not returned as a page field in the Crossref response used. |
| Gu (2025), *Open Problem: Structure-Agnostic Minimax Risk for Partial Linear Model* | Title, author, venue, volume, pages, year, abstract-level role | Verified | Official PMLR page gives COLT 2025, PMLR 291:6220--6224 and identifies variance as the unresolved structure-agnostic issue. |
| Gu (2026), *Optimal Use of a Black-Box Learner in Semiparametric Estimation*, arXiv:2607.21541 | Title, author, submission date/version, cited upper formula | Verified | Official arXiv page gives v1, 23 July 2026. Cor. 3.2 Eq. (3.7) contains the minimum of the two directional remainder branches mapped in the manuscript to `T_mu∧T_pi`. |
| Gu, Yin, Cai & Fan (2026), *Optimally Taming Biases in Black-Box Models for Efficient Semiparametric Estimation*, arXiv:2606.06368 | Title, authors, submission date/version, Theorem A.1 role | Verified | Official arXiv page gives v1, 4 June 2026. The checked theorem contains the inherited product/shared-stochastic PLM lower structure summarized as `AB+M`. |
| Jin & Syrgkanis (2026), *Sharp Structure-Agnostic Lower Bounds for General Linear Functional Estimation*, arXiv:2512.17341 | Title, authors, version/date, Theorem 7.5 target | Verified | The checked theorem is an anchored PLM-restricted expected conditional covariance result, adjacent but not identical to coefficient estimation. The manuscript's distinction is accurate. |
| Jin, Mackey & Syrgkanis (2025), *It's Hard to Be Normal: The Impact of Noise on Structure-Agnostic Estimation*, arXiv:2507.02275 / NeurIPS 2025 | Title, authors, version/date, Theorem B.1 role | Verified | Official arXiv HTML exposes the strengthened binary PLM coefficient lower result used as adjacent testing technology. |
| Robins, Tchetgen Tchetgen, Li & van der Vaart (2009), *Semiparametric Minimax Rates*, DOI 10.1214/09-EJS479 | Title, authors, journal, year, DOI | Verified | DOI metadata agrees. The manuscript's pp. 1305--1321 were not returned as a page field in the Crossref response used. |
| Robinson (1988), *Root-N-Consistent Semiparametric Regression*, DOI 10.2307/1912705 | Title, author, journal, year, volume/issue, starting page, DOI | Verified | DOI/Crossref metadata agrees with *Econometrica* 56(4), starting at p. 931; the manuscript gives pp. 931--954. |

Additional adjacent source identified:

- Lars van der Laan, Alex Luedtke & Marco Carone, *Automatic Doubly Robust Inference for Linear Functionals via Calibrated Debiased Machine Learning*, arXiv:2411.02771 (first submitted 5 November 2024). Official arXiv metadata and abstract were verified. It is relevant to directional nuisance robustness but was not found to contain the same four-budget PLM minimax theorem in the inspected public material.

No bibliographic field conflict material to the review outcome was confirmed. Some page ranges were only partially cross-verified because the Crossref records queried did not expose them; these are marked above rather than silently treated as fully verified.
