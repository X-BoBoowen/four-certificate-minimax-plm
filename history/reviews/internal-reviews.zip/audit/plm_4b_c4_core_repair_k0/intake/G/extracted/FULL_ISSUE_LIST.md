# Full issue list and attack records

## G-1 — Fixed covariate-space quantifier invalidates the lower bound

- **Attack result:** CONFIRMED FAILURE.
- **Severity:** Major; reject-level for the paper as written.
- **Confidence:** High (approximately 0.98).
- **PDF location:** Page 2, Section 2, lines 75--76 and Eq. (4); page 3, Theorem 1, Eq. (6); page 21, Appendix C.4, lines 1082--1085; page 30, Appendix I, lines 1592--1596.
- **Original claim:** After fixing a standard Borel `(X,A)`, Theorem 1 asserts `R_pair ≍ q+X(a,s,b,t)` for every budget tuple in the interior regime. Appendix A explicitly says the domain includes all finite spaces.
- **First possible failure:** Appendix C.4 no longer works inside the fixed experiment. It sets `X` to a uniform Walsh group of dimension `m=ceil(log2(p+1))`, where `p` grows with `n` and the stochastic budget. That is a change of the previously fixed covariate space, not a choice of a law or public pair on it.
- **Independent counterexample:** Take the valid one-point standard Borel space. Then `pi0` and `mu0` are constants. Pair the `2n` observations and set

  `A_i=(T_{2i-1}-T_{2i})(Y_{2i-1}-Y_{2i})`,

  `D_i=(T_{2i-1}-T_{2i})^2`.

  With bars denoting averages, define

  `delta = clip_[−3,3]( Abar / max(Dbar,v_-) )`.

  Because `Delta Y = beta0 Delta T + Delta epsilon`, conditional mean-zero errors give `E[A_i]=beta0 E[D_i]`, while `E[D_i]=2v >= 2v_-`. Let `W_i=A_i-beta0 D_i=Delta T Delta epsilon`. The envelope gives `|W_i|<=4B0^2`, hence `E|Wbar|<=4B0^2/sqrt(n)`. Hoeffding gives

  `P(Dbar<v_-) <= exp{-n v_-^2/(8B0^4)}`.

  Therefore, uniformly over every public pair and every compatible law on the singleton,

  `E|delta-beta0| <= 4B0^2/(v_- sqrt(n)) + 6 exp{-n v_-^2/(8B0^4)} = O(n^-1/2)`.

  This estimator ignores `Gamma`, so the outer pair supremum does not change the bound. The admissible set is nonempty (for example, singleton zero nuisance classes and a bounded `u=±sqrt(v)` law). Now choose an interior tuple such as `B0=3`, `v_-=v_+=1`, any `BG>0,c_rad>0`, and budgets `(a,s,b,t)=(0,1/2,0,1/2)`. The manuscript's quantity is

  `X=(1/4)(1/4)+(1/2)^2=1/16+1/4=5/16`,

  so Eq. (6) asserts a positive asymptotic lower bound `c_rho(5/16+o(1))`, contradicting the uniform root-n upper bound.
- **Why this is not a preference:** It is a direct mathematical contradiction between an allowed experiment and the lower half of the headline theorem. It also invalidates Appendix I's statement that the fixed-space formulation retains every finite hard instance: a fixed singleton cannot contain the growing Walsh instances.
- **Effect on core conclusion and score:** The theorem is false on part of its explicitly claimed domain. This is the decisive reason for a weak-reject recommendation despite the apparent strength of the infinite-space construction.
- **Minimal repair:** Either (i) require the fixed covariate space to be infinite and embed each finite Walsh construction measurably into that same space; or (ii) include the covariate space in the outer adversary and rewrite Eq. (4) accordingly. The paper should then remove the claim covering arbitrary finite spaces and ideally state the finite-space rate/interpolation separately.
- **Reverse-fairness check:** The risk definition makes `Gamma=(G_mu,G_pi)` rather than including the underlying space, and Appendix I again calls the Appendix-A space fixed. I found no definition that authorizes changing `X`. If the intended convention was a universal infinite space, that intention is not what the theorem presently states.

## G-2 — The Q1 envelope need not describe a single fixed learning problem

- **Attack result:** STRONG CONCERN, not a correctness failure for the exact Q1 definition.
- **Severity:** Moderate; mainly significance and interpretation.
- **Confidence:** High (approximately 0.95).
- **PDF location:** Page 2, Eq. (4) and lines 102--107; page 3, lines 149--157; pages 28--29, Appendix G, lines 1499--1513; page 8, lines 454--457.
- **Original claim:** The paper presents a four-budget minimax law `q+AB+M+O+P`.
- **First possible failure:** A natural reading is that all terms are simultaneous difficulties of one public problem. In fact, Q1 permits the hard public pair to vary with `n` and the budget cell, and Appendix G explicitly uses different pairs for the `q`, `ab`, `M`, `O`, and `P` certificates.
- **Independent evidence:** For the exact scalar outer supremum, `R >= max_j L(Gamma_j)` is valid. The deterministic equivalence between this maximum and the sum is also valid up to constants. However, this proves an envelope across separately chosen pairs, not that one fixed class pair or one natural problem incurs all directional components.
- **Why this is not merely personal taste:** Whether a lower bound holds for one fixed learning problem or only after reselecting the public interface changes what the theorem says about algorithms, class geometry, and applicability. It is a standard quantifier-level distinction in minimax theory.
- **Effect on core conclusion and score:** It does not refute Eq. (6) under Q1, and the manuscript is commendably explicit. It nevertheless limits ICLR significance, generality, and the force of the headline “four-budget rate.”
- **Minimal repair:** Qualify the title and abstract more prominently as a known-budget, pair-specific outer-envelope theorem; or add a result using one fixed public pair/sequence and one common or adaptive rule.
- **Reverse-fairness check:** The authors already disclaim budget adaptation, one common rule, and one fixed natural pair. I therefore do not classify this as hidden technical invalidity or demand that a pure theorem paper run experiments.

## G-3 — Related calibrated-DML work should be differentiated

- **Attack result:** PLAUSIBLE ALTERNATIVE, not a verified novelty collision.
- **Severity:** Minor.
- **Confidence:** Medium (approximately 0.75).
- **PDF location:** Page 8, Table 5 and surrounding related-work text; page 10 references.
- **Original claim:** The manuscript identifies the closest prior theorem fields and frames the directional one-good/one-poor nuisance phenomenon as a residual contribution.
- **First possible failure:** The bibliography does not discuss calibrated debiased machine learning, which also obtains favorable inference when one nuisance is estimated well and the other may be arbitrarily slow or inconsistent.
- **Independent source:** L. van der Laan, A. Luedtke, and M. Carone, *Automatic Doubly Robust Inference for Linear Functionals via Calibrated Debiased Machine Learning*, arXiv:2411.02771 (first submitted 2024). The official abstract makes the one-good-nuisance guarantee explicit.
- **Why this is not merely preference:** That conceptual relationship affects how readers interpret the directional motivation and novelty boundary.
- **Effect on core conclusion and score:** Small. The calibrated-DML paper studies asymptotic inference for linear functionals and does not, from the checked public materials, provide this exact bounded PLM four-budget minimax characterization or the O/P lower terms.
- **Minimal repair:** Add the citation and one precise paragraph distinguishing calibrated asymptotic linearity from the present finite-sample pair-specific minimax theorem.
- **Reverse-fairness check:** I found no theorem-level direct collision, so I do not label the current novelty claim false.

## G-4 — Referenced figure-generation source was unavailable

- **Attack result:** NOT ASSESSABLE.
- **Severity:** Minor/material limitation.
- **Confidence:** High.
- **PDF location:** Page 9, Reproducibility Statement, lines 469--475.
- **Original claim:** Figure 1 can be regenerated with `figures/+generate_theory_summary.py`.
- **First possible failure:** That path is not present in the supplied archive.
- **Independent evidence:** The archive manifest contains only the PDF and review-control files. The script was not available, so its implementation and exact output could not be checked.
- **Why this is not merely preference:** It is an executable reproducibility claim tied to a missing artifact.
- **Effect on core conclusion and score:** Negligible for the theorem because Figure 1 is analytic and contains no data. It lowers artifact reproducibility only.
- **Minimal repair:** Include the script or state that it will be released separately.
- **Reverse-fairness check:** I did not infer that the figure is wrong; its displayed formulas are consistent with the text.
