# Unconfirmed matters and material limitations

## Unconfirmed matters

- I did not formally machine-check every proof line. Apart from the confirmed covariate-space failure, no additional hidden proof gap can be ruled out.
- I did not establish a complete novelty or priority result. Public exact-expression and theorem-neighborhood searches produced no direct O/P collision, but search non-hits are inconclusive.
- The calibrated-DML relationship is conceptual from the checked abstract/public version; I did not claim direct theorem overlap.
- The manuscript's exact intended meaning of the fixed covariate space is not externally knowable. I evaluated the literal and conventional mathematical quantifier in Sections 2 and A/I.
- I did not test whether every finite Walsh hard family can be embedded without any constant changes into every fixed infinite standard Borel space, although standard Borel measurability makes this plausible.
- The asymptotic root-n bound on a singleton is a mathematical counterexample; no simulation is needed. I did not infer behavior for all fixed finite cardinalities beyond the singleton.

## Material limits of the supplied package

- The user request text names a `C2` archive, while the attached file is `PLM4B_C4_GENERAL_ICLR_REVIEWER_BLIND_FIRST_PASS.zip`. No C2 attachment was available. This report reviews only the attached C4 archive.
- Sibling archive filenames were visible during path resolution. Their contents were never opened or read. No M, S, other G, prior audit, answer key, old score, or project history was consulted.
- The archive supplied only the PDF and review-control files. The source tree and the Figure 1 generator mentioned on page 9 were unavailable.
- No author identity was sought. Anonymous-authorship conflicts therefore cannot be exhaustively assessed.
- Exact model build/version and session/instance identifier were not exposed by the platform.
- SymPy was unavailable; the O/P identities were checked by direct algebra and ordinary computation. No conclusion relies on the failed import.
- External browsing was restricted to public official or bibliographic sources. No nonpublic database, account, correspondence, or review system was accessed.
