# General ICLR review instructions

Review the anonymous manuscript as a fresh general ICLR reviewer. Assess correctness, clarity, originality, significance, reproducibility, ethics, limitations, and confidence. Distinguish a technical defect from a narrow interface or positioning concern. Give precise page, theorem, and equation locations for every substantive issue. Do not seek author identity or project history.
