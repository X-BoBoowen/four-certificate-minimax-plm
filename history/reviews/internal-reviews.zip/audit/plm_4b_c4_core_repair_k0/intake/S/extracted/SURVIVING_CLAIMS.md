# 经受住审查的主张清单

1. **模型识别 PASS：** interior `v>0` 下 β 可由 PLM moment 识别；saturation `v=B0²` 下进一步强制 `π0=0`。
2. **Q1 量词 PASS：** 上界在固定 Γ 内统一；下界对外层 Γ supremum 合法；没有 sup/inf exchange。
3. **不同公共类对 assembly PASS：** 证明只用 `max`，没有谎称同一 Γ 同时困难。
4. **O/P 射线 PASS：** `r²` 对 `r³` 的阶差计算正确，非单纯常数改进。
5. **hard-label 独立性 PASS：** 公共 Walsh dictionaries 在 latent sign/coordinate 之前固定。
6. **fixed variance certificates PASS：** O/P/M constructions 的标签分布保持同一条件残差方差；未发现把 variance 当可学习 oracle 的偷换。
7. **public-class certificates PASS：** approximation radii、finite-class localized Rademacher scaling 和 bounded candidate requirements 相容。
8. **TAME 来源归属部分 PASS：** 稿件明确说 upper architecture/calibration/editing 来自 Gu Cor.3.2，而非自称发明。
9. **GYCF 来源归属 PASS：** 稿件明确承认 `q+AB+M` lower 已存在。
10. **Borel closure PASS：** countable representations 与 first-within-tolerance selection 足以支持所有 fit/edit/indicator/fallback 的可测性主张。
11. **unsafe fallback PASS：** 不安全半径格会强制 q 或 M/O/P 中至少一项达到固定阈值，clipped zero loss 可被 `q+X` 吸收。
12. **边界三分层 PASS：** `v->B0²` 为空；`v-=B0²` 是独立识别层；不应从 interior 常数连续外推，稿件处理正确。
13. **无因果冒领 PASS：** 稿件只声称 statistical coefficient，并明确排除 causal conclusion。
14. **无计算/适应冒领 PASS：** 没有宣称 polynomial time、finite oracle、unknown-budget adaptation、common rule 或 confidence intervals。
15. **直接碰撞检索 PASS（限已记录范围）：** 未发现保持全部字段并给完整 `q+AB+M+O+P` matching rate 的先例。

例外：Theorem 1 的 `Cρ<1` 不通过；SA 谱系归属不通过。它们分别记录为 S-01、S-02。
