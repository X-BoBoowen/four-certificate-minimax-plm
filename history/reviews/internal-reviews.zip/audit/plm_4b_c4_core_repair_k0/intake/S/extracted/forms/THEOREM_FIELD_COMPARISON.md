# Theorem-field comparison

Complete independently. Leave no required field unaddressed in the returned copy.

Overall direct or routine collision verdict: **未发现 DIRECT COLLISION。** Gu/TAME 对上界架构构成直接祖先，GYCF 对 `q+AB+M` 构成直接祖先，Balakrishnan–Kennedy–Wasserman 对 SA fixed-pilot/product lower 构成基础强重叠；但这些已核原始定理都不同时给出本文 exact M1/Q1 字段中的 O/P 双向必要性和全 n expected-L1 matching rate。故结论是 STRONG OVERLAP + 受限真实增量，而不是“无先例的全新范式”。

| Source theorem | Input and access | Model | Quantifiers | Assumptions | Conclusion | Residual difference |
|---|---|---|---|---|---|---|
| Bartlett–Bousquet–Mendelson Thm 2.1 | 已知 bounded function class；经验/期望 Rademacher complexity | 通用 empirical process | 对固定类的高概率 uniform deviation | range `[a,b]`、统一 variance≤r | one-sided concentration，系数 `2(1+α)` 等 | 仅是稿件 Lemma 4 的工具；不涉及 PLM/minimax/novelty collision |
| Gu (COLT 2025) Eq. (8), Thm 1 | 四预算类；算法可用类 | bounded PLM，`X∼Unif` | outer over nuisance classes，inner estimator，sup laws | approximation/local Rademacher budgets；variance role 未闭合 | lower `q+(a+s²)(b+t²)`；upper `q+(a+s)(b+t)` | loss 按印刷为 squared error 且尺度有歧义；没有 `M,O,P`、M1 representation、all-n L1 closure |
| Gu–Yin–Cai–Fan Thm A.1 | 两个 black-box classes 与四预算 | bounded PLM；lower 中 `E[u²|X]≡v≥1/3` | `sup_F inf_est sup_P`，2n samples | expected L1；approximation/local complexity certificates | lower `q+AB+M`；upper `q+min{A,(a+s)(b+t)}` 的非匹配形式 | `q+AB+M` 完全是 prior art；没有 O/P lower matching 和本文表示/边界闭合 |
| Gu Cor. 3.2 Eq. (3.7) | 初始 black-box fits 与 TAME editing | PLM | 给定 learner 的高概率误差展开 | `δμ+δπ=o(1)`，regularity/smallness | remainder `Tμ∧Tπ+o(q)` | 直接上界架构祖先；不是全 n expected-L1 minimax theorem，无 O/P necessity |
| Jin–Mackey–Syrgkanis Thm B.1 | fixed pilots `ĝ,q̂` 与 L2 neighborhoods | binary T,Y PLM coefficient | fixed-confidence quantile minimax | overlap；一般 `g(1-g)`；pilot local model | `δ^-1(cθ ε1²+ε1ε2)` lower | 无 public-class stochastic budget、constant conditional variance、expected L1；可启发 O/P 但不字段保持 |
| Jin–Mackey–Syrgkanis Thm 3.2 | fixed pilots；精确知道 Gaussian treatment noise law | Gaussian-treatment PLM coefficient | quantile minimax | T unbounded；known `σ²`；L2/Ls neighborhoods | product term（带 logs）+q；known variance 去掉 nuisance-square | boundedness/噪声/信息结构不同；不导出 O/P |
| Jin–Syrgkanis Thm 7.5 | fixed anchor distribution 与 nuisance L2 radii | binary PLM-restricted **ECC functional** | fixed-confidence quantile minimax | overlap、bounded density | `εg εq+q` lower | target 不是 PLM coefficient；无四预算 public class/constant v；Remark 7.1 明说 coefficient result 不由 general theorem 直接推出 |
| Balakrishnan–Kennedy–Wasserman Thm 1(3), Thm 2 | 给定 fixed pilots `μ̂,π̂`；两个 L2 radii | binary-treatment expected conditional covariance | fixed-pilot local minimax，MSE | `X∼Unif`、bounded probabilities | MSE lower/upper `r_n s_n+1/n` | SA 框架和 product lower 的直接祖先；但 target/loss/公类预算/constant slope-v 字段不同 |
| Robins et al. Thm 2.1, Thm 4.1 | Hölder model；两组 mixture perturbations | missing data/ECC semiparametric models | classical minimax squared loss | Hölder smoothness与密度条件 | mixture-affinity lemma；smoothness-dependent ECC rate | fuzzy-testing 方法祖先，不是 structure-agnostic framework |
