# 模型与关键量词审计

## 结论

模型是特殊但合法的理论 experiment。除 Theorem 1 对上界常数额外施加 `Cρ<1` 外，未发现识别、信息泄露或 sup/inf 顺序错误。中心速率结论必须被理解为 exact Q1 risk，而不是自然固定类或未知预算下的普遍 PLM 定理。

## 信息结构

| 对象 | 规则可见 | 规则不可见 | 审计结论 |
|---|---|---|---|
| 数据 | 2n 个 i.i.d. `(X,T,Y)`，可两半使用 | hidden clean sample、hard label | PASS |
| 公共类 | `Γ=(Gμ,Gπ)`、countable measurable representations、`BG` | truth、population best approximant | PASS |
| 预算 | 已知上界 `(a,s,b,t)` 与固定 `ρ` | realized approximation/estimation errors | PASS；oracle-like 但披露充分 |
| 方差 | 知道 `v∈[v-,v+]` 且 `E[u²|X]=v` 为常数 | 实际 v（除 singleton interval 或 saturation） | PASS |
| 决策规则 | 每个 Γ 可选择独立 Borel map | common rule across Γ、label/law-dependent rule | PASS |

## Q1 量词

风险为

`sup_Γ inf_{δΓ Borel} sup_{P∈P(Γ)} E_P|δΓ-β(P)|`。

- 上界：Appendix B 先固定 Γ，构造只依 Γ/预算/数据的规则，对所有 `P∈P(Γ)` 统一控制，然后才取外层 supremum。合法。
- 下界：每个 component 只需给出一个 legal Γ。不同 component 可用不同 Γ；由 `R≥max_j c_j r_j` 和 `sum_j r_j≤5 max_j r_j` 得总和阶。合法。
- 没有证明 `inf_δ sup_Γ sup_P` 的 common-rule 风险，也没有证明一个 Γ 同时承载五个 hard mechanisms。稿件明确没有这样声称。

## 定理常数反例

对 `B0=3`、`v-=v+=10^-3`、零预算 singleton classes，令 `T=±sqrt(v)`，`Y=±B0/2`，并使 `E[Y|T]=βT`。取 n=16、`β=±B0/(8sqrt(vn))`。2n-sample KL 为 0.250326，Pinsker TV 上界 0.353784。稿件 Lemma 6 给

`Rpair ≥ 3.831589 n^-1/2`。

所以 Theorem 1(I) 不可能有 `Cρ<1`。应改为有限常数 `Cρ<∞`。

## 上界审计

1. Bartlett Theorem 2.1 到 Lemma 4 的双向 empirical-process transfer 常数和范围代入正确。
2. 正半径 floor 避免 s=0/t=0 时除零；unsafe cell 用 q 或 X 的固定阈值吸收 clipped zero loss，逻辑完备。
3. O/R edits 只对 represented class differences 做 calibration；应用处的 comparator/fit 都属于表示序列，不需要访问真 nuisance。
4. `x≤y` 选 O、`y<x` 选 R 的 selector 满足 `Tselected≤2W`；六个 budget order cells 对 `W≲X` 的覆盖包含零和 ties。
5. countable first-within-tolerance fits、有限维 convex edit、clipping 和 indicators 支持 Borel measurability。

## 下界审计

1. q：合法零类参数子模型；本报告也用其构造了 S-01 反例。
2. ab：singleton classes 与相互补偿的 off-class truths 给乘积偏差。
3. M：两个 exact-in-class finite dictionaries；难度取较小 stochastic resolution 的平方。
4. O：outcome approximation 与 propensity dictionary resolution；label 前公共；固定 v；射线为 r²。
5. P：O 的镜像但统计通道独立；同样 label 前公共、固定 v。
6. 五项合并只依 outer Γ supremum 和有限项代数，不依一对类同时困难。

## 方差边界

- `v->B0²`：由 `u²≤B0²` 得空模型，PASS。
- `v-=B0²`：`u²=B0²` a.s.，条件均值零给 `u=±B0` 各半；`|π0(X)±B0|≤B0` 强制 `π0=0`；故 `β=E[TY]/B0²`，PASS。
- 这是 shared envelope saturation 的特殊识别，不是一般 homoskedastic PLM 的普遍现象。
