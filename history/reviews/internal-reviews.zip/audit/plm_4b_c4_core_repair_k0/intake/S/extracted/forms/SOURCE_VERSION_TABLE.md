# Source version table

Complete independently. Leave no required field unaddressed in the returned copy.

Overall source-integrity verdict: **PASS with one disclosed version-format distinction.** 五份包内 arXiv/PMLR PDF 与公开固定版本逐字节 SHA-256 一致；Bartlett 包内文件是 2004-05-14 作者预印本（36 页），不是 2005 AoS 正式排版（41 页），但正式版 Theorem 2.1 与所用不等式内容一致。稿件中各 DOI/arXiv ID、作者、年份和所引定理位置总体准确。

| Source | Version checked | Stable identifier | Theorem or page | Notes |
|---|---|---|---|---|
| Bartlett, Bousquet & Mendelson, *Local Rademacher Complexities* | 包内作者预印本，2004-05-14；另核对 AoS 33(4), 2005 正式 PDF | https://doi.org/10.1214/009053605000000282 | Theorem 2.1；正式版 pp.1503–1504（PDF pp.7–8） | 包内 PDF 哈希与正式版不同，因为排版/版本不同；核心 theorem statement 一致。稿件 Lemma 4 的常数代入与方向正确。 |
| Gu, *Open Problem: Structure-Agnostic Minimax Risk for Partial Linear Model* | PMLR 291, 2025，包内 PDF；与公开 PDF 哈希一致 | https://proceedings.mlr.press/v291/gu25b.html | Eq. (8), Theorem 1, PDF pp.3–4 | 按印刷定义为 squared-error risk，但展示 `n^-1/2` 尺度，存在来源自身的 loss-scale 歧义；四预算模型、下界 `q+(a+s²)(b+t²)`、上界 `q+(a+s)(b+t)`。 |
| Gu, Yin, Cai & Fan, *Optimally Taming Biases in Black-Box Models for Efficient Semiparametric Estimation* | arXiv v1，2026-06-04；包内与公开 PDF 哈希一致 | https://arxiv.org/abs/2606.06368 | Appendix A.1, Theorem A.1，PDF pp.19–20；Eq. (3.3), p.15 | 2n 样本、expected L1、outer class supremum；给出 `q+AB+M` 下界及非匹配上界。 |
| Gu, *Optimal Use of a Black-Box Learner in Semiparametric Estimation* | arXiv v1，2026-07-23；包内与公开 PDF 哈希一致 | https://arxiv.org/abs/2607.21541 | Corollary 3.2, Eq. (3.7)，PDF p.16；Proposition 2.3 | `Tμ∧Tπ` calibration/editing 上界架构的直接来源；高概率渐近余项，不是本文全 n expected-L1 Q1 定理。 |
| Jin, Mackey & Syrgkanis, *It’s Hard to Be Normal: The Impact of Noise on Structure-Agnostic Estimation* | arXiv v3，2025-11-07；NeurIPS 2025；包内与公开 PDF 哈希一致 | https://arxiv.org/abs/2507.02275 | Theorem 3.2, PDF p.5；Theorem B.1, PDF p.26 | fixed-pilot/L2 neighborhood、quantile risk；Gaussian PLM theorem 有已知噪声分布且 T 无界，binary theorem 无本文固定条件方差与四预算类接口。 |
| Jin & Syrgkanis, *Sharp Structure-Agnostic Lower Bounds for General Linear Functional Estimation* | arXiv v2，2026-01-05；包内与公开 PDF 哈希一致 | https://arxiv.org/abs/2512.17341 | Theorem 7.5, PDF pp.29–30；Remark 7.1 | Theorem 7.5 是 PLM-restricted expected conditional covariance，不是 PLM coefficient；fixed anchor、quantile risk。 |
| Balakrishnan, Kennedy & Wasserman, *The Fundamental Limits of Structure-Agnostic Functional Estimation* | arXiv v2，2025-06-07（正文日期 2025-06-14）；34 页 | https://arxiv.org/abs/2305.04116 | Sec. 3.1；Theorem 1(3), PDF p.12；Theorem 2, pp.13–14；ECC proof pp.27–29 | 最早公开 2023-05-06。modern structure-agnostic fixed-pilot 框架的直接奠基来源；稿件漏引。MSE 而非 expected L1，研究 ECC 而非 PLM coefficient。 |
| Robins, Tchetgen Tchetgen, Li & van der Vaart, *Semiparametric Minimax Rates* | EJS 3 (2009), 1305–1321，正式 PDF | https://doi.org/10.1214/09-EJS479 | Theorem 2.1, pp.1307–1308；Theorem 4.1, p.1312 | 提供 two-mixture Hellinger/fuzzy-testing 工具，并在 Hölder 平滑模型给 ECC 速率；不是 structure-agnostic fixed-pilot/public-class 框架。 |
| Liu, Mukherjee & Robins, *On the Asymptotic Inadmissibility of Double Machine Learning Estimators Under Structure-Agnostic Models* | arXiv v1，2026-06-21；27 页 | https://arxiv.org/abs/2606.22391 | Abstract；Secs. 1–3（相关结论） | 研究 SA 模型中 DML 的渐近不可容许性；ECC 情形未给严格支配。与本文四预算 PLM rate 不碰撞，属 contextual/pre-review 候选。 |
