# Contribution and prior-work matrix

Complete independently. Leave no required field unaddressed in the returned copy.

Overall attribution verdict: **部分通过，需实质补正。** 稿件诚实承认 Gu–Yin–Cai–Fan 的 `q+AB+M` 下界和 Gu/TAME 的两分支上界；这点优于常见的过度宣称。主要缺口是漏引 Balakrishnan–Kennedy–Wasserman，并把 Robins et al. (2009) 的 fuzzy-testing 技术与 modern structure-agnostic 框架混写。没有证据支持 DIRECT COLLISION；真实新增是 exact M1/Q1 字段中的 O/P necessity、全边界可测闭合与 E/I/S 分层，而非 generic TAME 或 product lower-bound principle。

| Manuscript claim | Closest source theorem | Exact overlap | Exact residual | Routine consequence | Evidence |
|---|---|---|---|---|---|
| 完整内点速率 `q+AB+M+O+P` | GYCF Thm A.1；Gu Cor. 3.2 | `q+AB+M` lower 已有；`Tμ∧Tπ` upper remainder 已有 | O/P matching necessity；同一 M1/Q1、全 n expected-L1、Borel selector closure | **否，非字段保持的直接推论。** 需重新构造 bounded、fixed-variance、public-dictionary hard pairs 并验证复杂度 | 稿件 pp.1–6、Apps. B–G；GYCF pp.19–20；Gu p.16 |
| O=`t min(a,t)` 必要性 | fixed-pilot product lower ideas：Balakrishnan Thm 1(3)、JMS B.1 | product/fuzzy-mixture 技术与一个 nuisance radius 乘另一个 radius 的思想已有 | 一侧是 off-class approximation、另一侧是 in-class stochastic resolution；还要保持 constant variance 与 constant PLM slope，并让类在标签前公开 | **不是现成定理的字段保持推论；但技术谱系接近，属专门化新构造而非新 lower-bound paradigm** | 稿件 Prop. 1/O、App. D；BKW Sec. 3/B.3；JMS B.1 |
| P=`s min(b,s)` 必要性 | 同上，方向互换 | 同类 product-mixture 技术 | 角色互换后的公共 outcome dictionary、propensity off-class truth 与 fixed variance 约束 | 同上 | 稿件 Prop. 1/P、App. C.3；BKW/JMS |
| `q+AB+M` 下界 | GYCF Thm A.1 | 速率表达完全重合 | 本文补 bounded M1 fixed-variance embeddings 与整体 assembly | **速率本身不是新贡献** | 稿件明确承认；GYCF pp.19–20 |
| `Tμ∧Tπ` 上界/编辑机制 | Gu Cor. 3.2 Eq. (3.7) | 代入 `δμ=a+s, δπ=b+t` 后式子相同；calibration/editing architecture 相同 | 本文给全 n expected-L1、known-budget selector、Borel/measurable interface、unsafe fallback | **核心上界思想为直接继承；闭合细节有独立工作量** | 稿件 p.8 明确承认；Gu p.16 |
| Q1 公共类对极小极大形式 | GYCF Eq. (3.3)/App. A；Gu COLT Eq. (8)；BKW Sec. 3.1 | outer class/instance supremum、pair-specific estimator 与 2n sample splitting 的思想高度接近 | 本文强制 represented pair、四张 known certificates、Borel maps、nonempty compatibility | **大部分框架是扩展/精化，不是全新范式** | 三份来源的风险定义；稿件 p.2/App. A |
| 五项可由不同公共类对见证并 max-to-sum | 经典 minimax outer supremum 逻辑 | `supΓ` 允许选择不同 hard Γ；max-to-sum 是常数阶代数 | 本文逐预算格构造五个 legal pairs 并证明 `X` 与组件和的关系 | **量词汇合本身常规；legal certificates 构造非平凡** | 稿件 pp.5–6、App. G |
| E/I/S 方差包络边界 | JMS Thm 3.2 讨论 known Gaussian noise；Gu COLT 强调 variance role | 方差信息影响 PLM minimax 难度这一主题已有 | `|u|≤B0` 与 `v-=B0²` 强制 `u=±B0`、再由 `|T|≤B0` 得 `π0=0`；exact saturation risk | **识别代数简单但在本精确包络模型中是新的闭合结果；不是广泛 variance theorem** | 稿件 Sec. 8/App. H；Gu COLT；JMS 3.2 |
| “structure-agnostic functional estimation”谱系 | Balakrishnan–Kennedy–Wasserman Sec. 3.1, Thm 1–2；Robins 2009 Thm 2.1 | Robins 提供 fuzzy/two-mixture 技术；BKW 提供 modern SA fixed-pilot formalization/product lower | 本文的 class-based四预算拆分不同 | **必须补引并拆分归属** | 稿件 p.8；BKW arXiv:2305.04116；Robins DOI 10.1214/09-EJS479 |
