# Prior-work collision 检索日志与候选表

## 时间、平台与判定阈值

检索日期：2026-08-26，Asia/Shanghai。

平台：Codex 公开网页检索后端（具体供应商未提供）、arXiv、PMLR/COLT、Project Euclid/IMS、Wiley DOI 页面、DOI 稳定链接、公开 PDF 直接下载。无付费 Scopus/Web of Science/MathSciNet 全库或登录版 Google Scholar。

DIRECT COLLISION 要求候选保持同一 target、观测信息、四预算定义、Q1 量词、constant-v/bounded assumptions、loss 和结论；仅公式相似或可借鉴 proof technique 不足以认定碰撞。

## 完整检索式记录

1. `site:arxiv.org "Four-Budget Minimax Rates" partially linear`
2. `"t(a ∧ t)" semiparametric OR "s(b ∧ s)"`
3. `"structure-agnostic" "partial linear model" minimax approximation stochastic error`
4. `"known budgets" "partially linear" minimax black-box learner`
5. `"On the Asymptotic Inadmissibility of Double Machine Learning Estimators Under Structure-Agnostic Models"`
6. `site:arxiv.org "asymptotic inadmissibility" "structure-agnostic"`
7. `site:openreview.net "structure-agnostic" "partial linear"`
8. `site:proceedings.mlr.press "structure-agnostic" semiparametric`
9. `site:arxiv.org "The fundamental limits of structure-agnostic functional estimation"`
10. `"fundamental limits of structure-agnostic functional estimation" publication`
11. `site:projecteuclid.org "structure-agnostic" functional estimation`
12. `site:openreview.net "Four-Budget" "Partially Linear"`
13. `site:projecteuclid.org/journals/annals-of-statistics "Local Rademacher complexities"`
14. `"Local Rademacher Complexities" Bartlett Bousquet Mendelson 1497 1537 pdf`
15. `"partially linear model" "localized Rademacher" minimax nuisance classes`
16. `"partial linear model" "approximation error" "stochastic error" minimax`
17. `"adversarial moment" calibration editing semiparametric`
18. `"black-box nuisance" minimax "partial linear"`
19. `"TAME-2" semiparametric`
20. `"δ appr" "δ stoc" "partial linear model" minimax`
21. `"approximation and stochastic budgets" semiparametric`
22. `"public class" "structure-agnostic" minimax`
23. `"Open Problem: Structure-Agnostic Minimax Risk for Partial Linear Model" -proceedings.mlr.press`
24. `"Optimally Taming Biases in Black-Box Models" partially linear minimax`
25. `"Optimal Use of a Black-Box Learner in Semiparametric Estimation" lower bound`
26. `"Sharp Structure-Agnostic Lower Bounds" partial linear coefficient`
27. DOI/标识符定向核验：`10.1214/009053605000000282`、`10.1214/09-EJS479`、`10.1111/ectj.12097`、`10.1214/23-AOS2258`、`10.2307/1912705`、arXiv IDs 2305.04116、2507.02275、2512.17341、2606.06368、2606.22391、2607.21541。

## 候选表

| 候选 | 最早公开 | 核查版本 | 关键位置 | 分类 | 理由 |
|---|---:|---|---|---|---|
| Balakrishnan–Kennedy–Wasserman, *The Fundamental Limits of Structure-Agnostic Functional Estimation* | 2023-05-06 | arXiv v2 | Sec.3.1, Thm1(3), Thm2 | STRONG OVERLAP | SA fixed-pilot framework + ECC product lower；loss/target/access 与本文不同 |
| Gu, *Open Problem: Structure-Agnostic Minimax Risk for Partial Linear Model* | 2025-06/07 | PMLR 291 | Eq.(8), Thm1 | STRONG OVERLAP | 四预算 PLM open formulation；rate gap 未闭合；loss as printed 不同/歧义 |
| Jin–Mackey–Syrgkanis, *It’s Hard to Be Normal* | 2025-07-03 | arXiv v3 / NeurIPS 2025 | Thm3.2, ThmB.1 | PARTIAL OVERLAP | PLM coefficient、noise role、product lower；fixed pilots/quantile/Gaussian or binary fields 不同 |
| Jin–Syrgkanis, *Sharp Structure-Agnostic Lower Bounds for General Linear Functional Estimation* | 2025-12-19 | arXiv v2 | Thm7.5, Rem7.1 | PARTIAL OVERLAP | general/ECC lower；不是本文 coefficient/four-budget Q1 |
| Gu–Yin–Cai–Fan, *Optimally Taming Biases...* | 2026-06-04 | arXiv v1 | App.A.1 ThmA.1 | STRONG OVERLAP | `q+AB+M` lower 直接重合；无 O/P lower |
| Liu–Mukherjee–Robins, *On the Asymptotic Inadmissibility...* | 2026-06-21 | arXiv v1 | main results | CONTEXTUAL | 研究 SA decision-theoretic admissibility，不是 four-budget PLM minimax rate |
| Gu, *Optimal Use of a Black-Box Learner...* | 2026-07-23 | arXiv v1 | Cor3.2 Eq.(3.7) | STRONG OVERLAP | `Tμ∧Tπ` upper/calibration/editing 直接祖先；无 O/P necessity |
| Robins et al., *Semiparametric Minimax Rates* | 2009 | EJS 正式版 | Thm2.1, Thm4.1 | CONTEXTUAL | fuzzy/two-mixture method；Hölder model，非 SA framework |
| Bartlett et al., *Local Rademacher Complexities* | 2004/2005 | preprint + AoS final | Thm2.1 | CONTEXTUAL | empirical-process 工具 |

## 结论

在上述检索平台、检索式、时间边界和候选文献范围内，我没有发现直接碰撞。没有命中不能写成“证明不存在”；未索引、付费或非公开工作仍可能未被覆盖。
