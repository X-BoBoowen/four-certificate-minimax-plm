# Reviewer S：第一次、完全独立的理论、模型、文献与创新性盲审

## 独立性与材料边界

这是我第一次接触本项目；当前对话不存在本项目的既往内容；我没有获得其他审稿人的判断。不存在需要报告为“会话可能受到既往上下文污染”的实质性既往上下文。

用户正文写的是 `PLM4B_C2_AUDITOR_S_BLIND_FIRST_PASS.zip`，但实际附加并可读取的文件是 `PLM4B_C4_AUDITOR_S_BLIND_FIRST_PASS.zip`。本审查以实际 C4 附件为唯一审稿包。除该 ZIP 内允许材料和公开原始文献外，我没有读取内部审计、参考答案、旧评分、修订历史、已填写表格、其他专家意见或非公开投稿信息；没有识别或推测匿名作者。

输入 ZIP 的 SHA-256 为：

`FB8C411141277811093B86A60DFEFC7D0594C8EAD9A37D68DFD36D18760A2BB1`

包内 20 个文件的路径、字节数与清单哈希全部匹配。稿件 PDF 的 SHA-256 为：

`F78A14D9377388B893DC7033F0308BCC62BF46F8150710E3F0DBFDB2CFA05226`

## 总体判断

我的审计结论是 **CONDITIONAL PASS**，但 ICLR 推荐是 **Weak Reject（4/10，置信度 4/5）**。

这是一个数学上相当认真、量词意识异常清楚的稿件。作者对自己的信息结构做了少见的明确限定：两半各 n 个样本；bounded PLM；条件处理残差方差为常数；两个 represented public classes；四个已知上界证书；估计器可以依公共类对而定，但不能知道真 nuisance、实现误差或 hard label；风险为 expected absolute error；硬公共类对可随 n 和预算格变化；五个 lower components 不要求在同一公共类对上同时困难。逐项检查后，我没有发现 sup/inf 偷换、hard label 泄露、用不同公共类对却声称同时困难，或 saturation 结论错误。

中心速率

`q + (a+s²)(b+t²) + min(s,t)² + t min(a,t) + s min(b,s)`

在所定义的 Q1 模型中有可信的完整证明结构。`q+AB+M` 来自 Gu–Yin–Cai–Fan，`Tμ∧Tπ` 上界来自 Gu/TAME；稿件明确承认这两点。真正的新内容是两个方向项 O/P 的必要性、把已有上界架构闭合为全 n expected-L1 的 Borel 规则，以及有界残差包络导致的 E/I/S 三分层。独立检索没有发现保持全部这些字段的直接先例。

不过，稿件目前有一处明确的定理陈述错误：Theorem 1 要求 `Cρ<1`，这在合法的零预算参数子模型中为假。它不只是“证明常数没有追紧”，而是存在简单反例；所幸把 `<1` 改成 `<∞` 即可，不改变速率阶。另一个必须修正的问题是文献谱系：稿件把 structure-agnostic product lower 与 Robins et al. (2009) 混写，却漏引真正正式化 modern fixed-pilot structure-agnostic minimax 的 Balakrishnan–Kennedy–Wasserman。这个遗漏不会推翻 O/P 新下界，但会把读者对创新基线的理解推得过远。

即使这两点修正，我对 ICLR 仍略偏拒。原因不是“模型特殊所以错误”，而是贡献的外延很窄：upper architecture 和 base lower envelope 都有直接祖先；新增 lower engineering 发生在已知四预算、pair-specific arbitrary Borel rule、fixed conditional variance、bounded envelope、可随预算/n改变的 worst public pair 这一高度定制的 experiment 中。稿件没有 unknown-budget adaptation、common rule、computational estimator、confidence result 或一个固定自然类族上的后果。对于理论统计专门读者，这个闭环有价值；对于 ICLR 的广泛意义，当前还差一步。

## 我对论文结果的重建

观测为 2n 个 i.i.d. `Z=(X,T,Y)`，按两半使用。模型为

`T=π0(X)+u`, `Y=β0 T+μ0(X)+ε`,

且 `E[u|X]=0`、`E[ε|X,T]=0`、`E[u²|X]=v`，其中 v 是某个未知常数，属于 `[v-,v+]`。`Y,T,β0,μ0,π0,u,ε` 受同一 `B0≥3` 控制，公共候选受 `BG` 控制。目标是统计 PLM coefficient，不包含潜在结果意义。

公共实例 `Γ=(Gμ,Gπ)` 提供可测的 countable pointwise-dense 表示和四个已知上界 `(a,s,b,t)`。a、b 控制 nuisance truth 到公共类的 L2 approximation；s、t 控制公共 difference class 在所有正半径、从自身预算以上开始的 localized Rademacher complexity。风险顺序是

`sup_{Γ∈Gρ,n(a,s,b,t)} inf_{δΓ Borel} sup_{P∈P(Γ)} E_P |δΓ-β(P)|`。

因此：

1. Γ 由外层对手选，但每个 Γ 有自己的估计器；不是一条规则应对所有类。
2. Γ 可依 n 和预算格而变，但必须在样本和 hard label 之前固定。
3. lower bound 只需为每一项找一个合法 Γ；将五个下界取最大值，再用有限项 `sum≤5 max` 得到总和阶。这不是 sup/inf 交换。
4. 四预算是证书上界，不要求等于真实误差；估计器预先知道它们。

记 `q=n^-1/2`，`A=a+s²`，`B=b+t²`，`M=min(s,t)²`，`O=t min(a,t)`，`P=s min(b,s)`，`X=AB+M+O+P`。上界定义 `x=a+s`、`y=b+t`、`Tμ=a y+x²`、`Tπ=b x+y²`，按 x≤y 或 y<x 选 TAME-derived branch；半径证书不安全时采用有界零 fallback。Appendix B 的关键点不是重新发明 TAME，而是让这一选择对每个 represented Γ 为 Borel、对所有 n/边界可用，并用 `Tselected≤2 min(Tμ,Tπ)≤48X` 和 unsafe-cell 下界把它提升到 Q1。

下界的 q、ab、M、O、P 可使用不同公共类对。O/P 的方向性体现在：一侧 nuisance 以 off-class approximation 变化，另一侧 truth 留在公开的有限字典中、其可分辨率由 stochastic budget 决定；hard label 不进入公共类。沿 O-ray `(a,t)=(r,r), b=s=0` 或 P-ray 对称情形，既有 `AB+M` 为 `r³`，而新方向项为 `r²`，确有无界阶差。

边界方面，`|u|≤B0` 强制 `v≤B0²`。若 `v->B0²`，模型为空。若 `v-=B0²`，则 `u²=B0²` a.s.；条件均值为零进一步给出 `u=±B0` 等概率。又因 `|T|=|π0(X)+u|≤B0` 同时对两个支撑点成立，只能有 `π0(X)=0`，所以 `β0=E[TY]/B0²`，问题降为参数率。这一逻辑成立；它是特定 shared-envelope 模型的识别现象，不应被外推为一般固定方差 PLM 结论。

## 主要问题 S-01：Theorem 1 的 `Cρ<1` 为假

**位置。** PDF p.3，Theorem 1(I)，式 (6)，首次错误是“there are `0<cρ≤Cρ<1`”。

**原始主张。** 对任意固定内点正则参数组 `ρ=(B0,BG,v-,v+,crad)`，存在严格小于 1 的常数 Cρ，使所有 n 和所有预算格都有 `Rpair≤Cρ(q+X)`。

**反例。** 取合法固定参数组

`B0=3`, `v-=v+=v0=10^-3`, 任意 `BG>0`, `crad>0`。

令 X 退化，`Gμ=Gπ={0}`，预算 `a=s=b=t=0`，于是 `X=0` 且 `q=n^-1/2`。置 `τ=sqrt(v0)`，令 `T=u` 在 `±τ` 上等概率。令 `c=B0/2`，在给定 T 时让 `Y∈{−c,c}`，满足

`P(Y=c|T)=(1+βT/c)/2`。

则 `E[Y|T]=βT`；取 `μ0=π0=0` 和 `ε=Y-βT`，得到完整 PLM。只要 `|β|τ≤c`，所有变量、nuisance 和 residual 都受 B0 控制，且条件残差方差恰为 v0。

在 `n=16`，考虑

`β±=±δ`, `δ=B0/(8τ sqrt(n))=2.964635...<3`。

把每个观测压缩为 `sign(T) sign(Y)`，两假设分别是成功概率 `(1±h)/2` 的 Bernoulli，`h=1/(4sqrt(n))=1/16`。2n 个样本的精确 KL 是

`2n h log((1+h)/(1-h)) = 0.250326...`。

Pinsker 给 `TV≤0.353784...`。使用稿件自己的 Lemma 6 保守界 `max risk ≥ Δ(1-TV)/4`，其中参数间距 `Δ=2δ`，可得

`Rpair ≥ δ(1-TV)/2 = 3.831589... q`。

但 Theorem 1 的 `Cρ<1` 会给 `Rpair<Cρ q<q`，矛盾。这个反例完全位于零预算 singleton public pair 中，不依赖 O/P 或任何复杂类。

**第一处出错步骤。** 不是 Appendix B 的 rate algebra，而是 Theorem 1 额外把通常的有限比较常数写成了严格小于 1。Proposition 2 和 Appendix B 实际只产生一个依赖 ρ 的有限常数，没有证明它小于 1。

**影响。** Theorem 1 按字面为假；摘要中的速率阶和中心 upper/lower architecture 不因此失效。

**最小修复。** 改为 `0<cρ≤Cρ<∞`，或仅说存在有限正数 cρ、Cρ。不要通过把 q 重新缩放来掩盖，因为 q 已固定为 `n^-1/2`。

**判定。** 模型/定理陈述错误；中等严重度；高置信度。

## 主要问题 S-02：structure-agnostic 谱系归属错误且漏引基础 prior work

**位置。** PDF p.8，Sec. 11 第一段；首次问题句为：“Structure-agnostic functional estimation supplies product lower bounds and fuzzy-testing methodology (Robins et al., 2009).” 参考文献表没有 Balakrishnan–Kennedy–Wasserman。

**原始来源证据。** Robins, Tchetgen Tchetgen, Li & van der Vaart (2009), *Semiparametric Minimax Rates*, DOI 10.1214/09-EJS479：Theorem 2.1 是 two-mixture Hellinger affinity 工具；Theorem 4.1 在 Hölder smooth semiparametric model 中给 expected conditional covariance 的 smoothness-dependent minimax rate。它是 fuzzy-testing 的重要方法祖先，但不是 modern structure-agnostic fixed-pilot/public-class formalization。

Balakrishnan, Kennedy & Wasserman, *The Fundamental Limits of Structure-Agnostic Functional Estimation*, arXiv:2305.04116（v1 2023-05-06；核查 v2 2025-06-07）：Sec. 3.1 明确定义 fixed black-box pilot 周围的 structure-agnostic minimax model；Theorem 1(3) 给 expected conditional covariance 的 MSE lower `r_n s_n+1/n`；Theorem 2 给 matching first-order upper。包内 Gu/Jin 最近文献也一致把 SA 框架归给此文。

**相同与不同。** BKW 与本稿在“只给 nuisance 高层误差信息并做第二阶段 minimax”这一概念上强重叠，也提供 product lower 和 mixture proof lineage。不同点是：BKW 给 fixed pilots 与两个 L2 邻域、MSE、ECC target；本稿给 represented public classes、approximation/stochastic 四预算、expected L1、PLM coefficient、constant v 和 Q1 outer class pair。它不直接给 O/P。

**影响。** 这不是单纯漏一条背景引用。它会把 structure-agnostic 框架的发明、product lower 的基线和本文真正新增部分全部错位，进而抬高读者感受到的原创性。O/P 仍可是真增量，但必须在 BKW 的强重叠背景下陈述。

**最小修复。** 把现句拆成两句：Robins et al. (2009) 只归为 two-mixture/fuzzy lower-bound technology；BKW 归为 structure-agnostic formalization 与 ECC product lower。把 BKW 加入参考文献和 Table 5，并精确说明 loss、target、pilot/class access 与 quantifier 差别。

**判定。** 引用归属错误 + 重要 prior work 漏引；中等严重度；高置信度。

## 问题 S-03：模型合法，但 ICLR 意义高度依赖 Q1 信息结构

**位置。** PDF pp.1–2 的 Abstract、Table 1、式 (4)，p.6 lower assembly，p.8 limitations。

稿件已经诚实披露：规则可依 Γ，知道四张预算证书；不同 lower components 可由不同 Γ 见证；Γ 可随 n/预算格变化；只要求 arbitrary Borel 而非计算可行；没有 adaptation/common rule/causal claim。我的判断不是“这模型不合理”。它是一个合法的 oracle/envelope minimax 问题，用来解析 approximation 和 stochastic difficulty 的方向性是有理论用途的。

但这一信息结构决定了结果不能自动读成：对一个固定自然 hypothesis class、一个实际学习算法、或未知预算情形，O/P 就是不可避免的。总和 lower 来自外层最坏类对和有限项 max-to-sum；它没有证明存在一个固定 Γ 同时呈现五种机制。pair-specific estimator 也比实践中的单一程序得到更多实例信息。

因此，这一点不构成正确性缺陷，却直接限制 ICLR significance。最有说服力的后续强化是：给出一个随 n 自然嵌套、而不是按预算格定制的固定类族；或证明 unknown-budget selector 的适应代价；或给出可计算版本与自然 ML class 的实例化。没有这些内容时，应把标题和摘要中的“sharp”始终限定为 exact Q1 experiment。

**判定。** 模型特殊但合理；中等 ICLR 意义限制；高置信度。

## 问题 S-04：Gu (2025) 的 theorem-field 边界应在表中显式给出

**位置。** PDF p.8 Sec. 11 将 Gu (2025) 称为四预算接口的来源；p.9 Table 5 标题为 “Checked theorem fields”，但没有 Gu (2025) 行。

Gu (2025), PMLR 291:6220–6224 的 Eq. (8) 按印刷文本定义 `E|hatθ-θ|²` 风险，而 Theorem 1 写出 `n^-1/2` 尺度的上下界，来源自身存在 loss-scale/notation 歧义。它给四预算 lower `q+(a+s²)(b+t²)` 和 upper `q+(a+s)(b+t)`，没有本文 M、O/P、M1 表示或 all-n expected-L1 Borel closure。

稿件的文字“isolates the four-budget PLM interface”并非错误，但在一个强调 exact fields 的稿件中，不应跳过这个最直接 open-problem source 的 loss 与 quantifier 行。最小修复是在 Table 5 加一行，并写 “loss as printed” 以避免替来源解决歧义。

**判定。** 文献字段披露不完整；低严重度；高置信度。

## 文献与创新性结论

最接近的 prior art 可分四层。

第一层是通用方法：Bartlett–Bousquet–Mendelson Theorem 2.1 支撑 localized empirical process transfer；Robins et al. (2009) 支撑 two-mixture/fuzzy lower-bound calculus。这些是工具，不是结果碰撞。

第二层是 structure-agnostic 信息结构：Balakrishnan–Kennedy–Wasserman 正式提出 fixed-pilot SA minimax，并给 ECC product lower；Gu (2025) 把问题推进到四预算 PLM 公共类接口。本文应明确站在这两者之后。

第三层是直接 rate predecessors：Gu–Yin–Cai–Fan Theorem A.1 已含 `q+AB+M` lower；Gu Corollary 3.2 Eq. (3.7) 已含 `Tμ∧Tπ` upper architecture。稿件在这两点上基本正确归属。

第四层是相邻 PLM/general-functional lower theory：Jin–Mackey–Syrgkanis 的 fixed-pilot binary/Gaussian PLM coefficient lower，以及 Jin–Syrgkanis 的 general linear-functional/ECC lower。它们显示 product lower 和噪声信息的角色，但不保持本文 bounded constant-v four-budget M1/Q1 fields。

我还核查了 Liu–Mukherjee–Robins (2026-06-21) 关于 SA 模型下 DML 渐近不可容许性的工作。它讨论 minimax 之外的 decision-theoretic dominance；对 ECC，文中没有给 DML 的严格渐近支配。它与本文四预算 PLM rate 不碰撞，但作为 2026 年 6 月已公开的 contextual work，值得在广义 SA 文献讨论中出现。

**碰撞分类：**

- DIRECT COLLISION：未发现。
- STRONG OVERLAP：BKW 的 SA/product framework；Gu (2025) 四预算 open problem；GYCF `q+AB+M`；Gu/TAME `Tμ∧Tπ` upper。
- PARTIAL OVERLAP：JMS binary/Gaussian PLM lower；Jin–Syrgkanis general/ECC lower。
- CONTEXTUAL：Bartlett empirical process；Robins fuzzy testing；Robinson PLM；DML/orthogonal learning；Liu et al. inadmissibility。
- FALSE LEAD：精确标题、精确 O/P 公式和 OpenReview 查询返回的二手页面/摘要，没有产生可保持字段的 theorem collision。

严格表述：**在 `COLLISION_SEARCH_LOG.md` 所列公开平台、检索式、2026-08-26 时间边界及候选原始论文范围内，我没有发现直接碰撞。** 这不是对所有未索引、付费、未公开或未来文献“不存在”的证明。

## 经受住审查的主张

1. Q1 的 `supΓ infδΓ supP` 量词顺序被上、下界实际遵守；没有把 pair-specific rule 偷换成 common rule。
2. 不同 lower components 用不同 Γ 是合法的，因为目标风险先对 Γ 取 supremum；证明只取最大值，再做有限项 max-to-sum，没有声称一个 Γ 同时困难。
3. O/P 射线相对 `AB+M` 的阶分离正确：在 `(a,t)=(r,r), b=s=0` 上为 `r²` 对 `r³`，镜像同理。
4. hard public dictionaries 在 latent sign/coordinate 之前固定，未发现 label-dependent class 泄露。
5. Walsh finite-class 的 L2 norm、Gram structure 与全正半径 complexity certificate 的缩放一致；零预算 singleton 也被正确处理。
6. TAME-derived O/R 分支的 public selector 只使用 Γ、ρ、预算和数据；未调用真 nuisance、population best approximant 或实现误差。
7. countable representation、first-within-tolerance 选择、有限维编辑、indicator、fallback 与 clipping 给出合理的 Borel closure。
8. `Tselected≤2W≤48X` 的预算格代数在零、tie 和六个 weak-order cells 上未发现反例；独立随机压力测试亦无违反。
9. q、ab、M、O、P 的 component lower assembly 与 `AB+M+O+P` 的展开/吸收关系一致。
10. `v->B0²` 空模型以及 `v-=B0²` 强制 `π0=0` 的边界结论正确；饱和层使用单独定理而非把内点常数连续延伸到边界是必要的。
11. 稿件没有把 statistical coefficient 冒充 causal effect，没有声称 computational efficiency、unknown-budget adaptation、confidence intervals 或 practical superiority。
12. 除 S-01 外，没有发现推翻中心 rate order 的确定性数学错误。

## ICLR 评价

**正确性。** Conditional pass。S-01 必修，但中心阶未被反驳。

**原创性。** 中等。作者把直接祖先拆得较清楚，O/P necessity 在核查范围内没有直接先例；但 generic editor、two-branch upper、product/fuzzy testing 与 base envelope 都不是新技术。

**技术深度。** 较高。特别是 fixed-variance-preserving finite mixtures、公共字典证书、全边界拼接与 measurable closure。

**重要性/广度。** 中低。结果关闭的是一个精确、oracle-like、class-pair-specific 的信息论 experiment，而不是广泛可部署或可适应的 PLM 学习问题。

**最强接收理由。** 这是一篇知道自己没有发明什么、并把真正缺失的 O/P lower mechanisms 做完整的理论论文；显式射线显示新增项不是常数改善，边界定理和可测闭合也避免了“只写渐近 remainder”常见缺口。

**最强拒稿理由。** 一旦扣除 GYCF lower 和 TAME upper，剩余创新主要是定制字段的 lower-certificate engineering；其最坏 Γ 可以按预算格改变，规则预知所有预算，且没有自然固定类/适应/计算后果。S-01 和 S-02 还说明当前稿尚未达到最终定理与谱系表述的精确程度。

**推荐。** Weak Reject。若修复定理常数和基础归属，并增加至少一个自然固定类或 unknown-budget adaptation 的非平凡后果，我会重新考虑到 borderline accept。

## 未确认事项与检索限制

1. 包内没有 ICLR 实际提交时间戳。对 2026-06/07 的文献，我只能确定其早于本次审查和稿件 PDF 的 2026-08-26 构建时间；无法从公开材料绝对区分“投稿前”与“concurrent”。2023–2025 文献显然属于较早 prior work。
2. 没有访问付费 Scopus、Web of Science、MathSciNet 全库或登录版 Google Scholar；公开网页索引可能漏掉尚未被抓取的工作。
3. Bartlett 包内来源是 2004 作者预印本；我另核对 2005 正式版，定理内容一致，但两 PDF 哈希和页数不同。
4. Gu (2025) Eq. (8) 的 squared-loss 定义与 `n^-1/2` displayed rate 存在来源自身歧义；我按印刷字段记录，没有替作者推断其本意。
5. 我逐页读取稿件并核对关键证明链和所有主要 hard family，但没有使用形式化证明助理认证每一个常数恒等式；“未发现其他错误”不是形式证明。
6. 未尝试识别匿名作者；因此不能对未知真实身份作个体冲突核查。

## 来源声明

Provider：OpenAI  
Model：Codex（GPT-5 系列）  
Exact model/version：平台未提供  
Session or instance ID：平台未提供  
是否为全新会话：是  
此前是否接触过本项目：否  
审查日期、时间及时区：2026-08-26 15:42:10 +08:00，Asia/Shanghai  
联网与数据库能力：可访问公开互联网、公开论文页面和公开 PDF；无付费数据库订阅或登录账户；无法保证覆盖未索引或非公开材料  
实际检索平台：Codex 公开网页检索后端（具体供应商未暴露）、arXiv、PMLR/COLT、Project Euclid/IMS、Wiley DOI 页面、DOI 稳定链接、公开 PDF 直接下载；本地使用 pypdf、Poppler、PIL 与 SHA-256 工具  
输入 ZIP SHA-256：`FB8C411141277811093B86A60DFEFC7D0594C8EAD9A37D68DFD36D18760A2BB1`  
输出 ZIP SHA-256：见 ZIP 旁同名 `.sha256.txt` 文件及最终回复（该文件不放入其所校验的 ZIP，以避免自引用）
