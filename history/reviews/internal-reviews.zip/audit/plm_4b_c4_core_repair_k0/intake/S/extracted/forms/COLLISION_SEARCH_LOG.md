# Collision search log

Complete independently. Leave no required field unaddressed in the returned copy.

Search date: 2026-08-26（Asia/Shanghai）。证据截止时间为本次审查结束时；稿件实际投稿时间未提供。

Databases or venues searched: Codex 公开网页检索后端（具体搜索供应商平台未提供）；arXiv；PMLR/COLT；Project Euclid/IMS；Wiley DOI 页面；DOI 稳定链接；公开 PDF 直接下载。未访问付费 Scopus、Web of Science、MathSciNet 全文或登录版 Google Scholar。

Overall collision verdict: **NO DIRECT COLLISION FOUND。** 在下列平台、检索式、时间边界和候选文献范围内，我没有发现同时保持 bounded PLM、条件常方差、represented public class pair、四个已知 approximation/stochastic budgets、Q1 `supΓ infδΓ supP`、2n 样本、expected L1、全 n，以及完整 `q+AB+M+O+P`（尤其 O/P 双向必要性）的直接先例。发现多项 STRONG OVERLAP：基础 SA 框架/乘积下界、`q+AB+M`、以及 `Tμ∧Tπ` 上界均已有来源；因此本文并非从零开始，其真实增量限于精确字段中的 O/P 下界、可测闭合和边界拼接。

| Query | Source found | Theorem location | Field comparison | Disposition |
|---|---|---|---|---|
| `site:arxiv.org "Four-Budget Minimax Rates" partially linear`；`site:openreview.net "Four-Budget" "Partially Linear"` | 无同名或同公式稿件 | 不适用 | exact-title / venue 检索 | 无命中；不能据此证明不存在 |
| `"t(a ∧ t)" semiparametric OR "s(b ∧ s)"`；`"δ appr" "δ stoc" "partial linear model" minimax` | Gu 2026 两篇及相关索引，无包含 O/P 完整下界的先例 | Gu Cor. 3.2；GYCF Thm A.1 | 相同预算语言；前者仅上界，后者仅 `AB+M` 下界 | STRONG OVERLAP，非直接碰撞 |
| `"structure-agnostic" "partial linear model" minimax approximation stochastic error`；`"known budgets" "partially linear" minimax black-box learner` | Gu (2025, 2026)；Gu–Yin–Cai–Fan (2026)；Jin–Mackey–Syrgkanis (2025) | Gu 2025 Thm 1；GYCF A.1；JMS 3.2/B.1 | PLM 相同，但 loss、信息结构、方差、预算拆分或结论不同 | STRONG/PARTIAL OVERLAP |
| `"The fundamental limits of structure-agnostic functional estimation"`；`site:arxiv.org/abs/2305.04116` | Balakrishnan–Kennedy–Wasserman | Sec. 3.1；Thm 1(3), Thm 2 | fixed-pilot SA；MSE；ECC；两个 L2 半径，无四预算公共类和 O/P | STRONG OVERLAP；**稿件漏引** |
| `"black-box nuisance" minimax "partial linear"`；`"public class" "structure-agnostic" minimax` | 上述 Gu/Jin/Balakrishnan 系列 | 见各行 | 没有命中完整 M1/Q1/O/P 字段 | 候选集已逐篇核查 |
| `"TAME-2" semiparametric`；`"adversarial moment" calibration editing semiparametric` | Gu, arXiv:2607.21541v1 | Cor. 3.2, Eq. (3.7) | 完全相同 `Tμ∧Tπ` remainder 架构；高概率渐近上界，无 O/P lower、无全 n Q1 closure | STRONG OVERLAP；直接上界祖先，稿件已承认 |
| `"Optimally taming biases in black-box models" partially linear minimax` | Gu–Yin–Cai–Fan, arXiv:2606.06368v1 | App. A.1, Thm A.1 | 2n、expected L1、outer class risk；lower `q+AB+M`；没有 O/P | STRONG OVERLAP；稿件已承认 |
| `"It’s Hard to Be Normal" structure-agnostic estimation`；`"known variance" structure-agnostic PLM` | Jin–Mackey–Syrgkanis, arXiv:2507.02275v3 | Thm 3.2；Thm B.1 | PLM coefficient/fixed pilots；Gaussian已知方差或 binary；quantile loss；不满足本文 bounded fixed-variance class field | PARTIAL OVERLAP |
| `"Sharp Structure-Agnostic Lower Bounds" partial linear coefficient` | Jin–Syrgkanis, arXiv:2512.17341v2 | Thm 7.5；Remark 7.1 | PLM-restricted ECC 与 general functional lower；不是本文 coefficient/four-budget class minimax | PARTIAL OVERLAP |
| `"On the Asymptotic Inadmissibility of Double Machine Learning Estimators Under Structure-Agnostic Models"` | Liu–Mukherjee–Robins, arXiv:2606.22391v1 | Abstract；main results | 决策论 inadmissibility；不是本文 minimax-rate 字段；ECC 情形不产生严格支配 | CONTEXTUAL；公开于审查前，建议讨论但非碰撞 |
| `10.1214/09-EJS479`；`"Semiparametric minimax rates" fuzzy mixture expected conditional covariance` | Robins et al. (2009) | Thm 2.1；Thm 4.1 | Hölder smoothness；two-mixture Hellinger；不是 SA public/fixed-pilot 模型 | CONTEXTUAL 方法祖先；稿件归属措辞需修正 |
| `"Local Rademacher Complexities" Bartlett Bousquet Mendelson 1497 1537 pdf` | Bartlett et al. (2005) | Thm 2.1 | 通用 empirical-process concentration，仅支撑本文 Lemma 4 | CONTEXTUAL；引用正确 |
| `"partially linear model" "localized Rademacher" minimax nuisance classes`；`"partial linear model" "approximation error" "stochastic error" minimax` | 主要回到 Gu 2025/2026 与相邻结构化 PLM 文献 | 见上述定理 | 未找到完整四预算 O/P 下界 | 无直接碰撞；检索范围限制见附件 |
| `"Open Problem: Structure-Agnostic Minimax Risk for Partial Linear Model" -proceedings.mlr.press`（后向引用） | Gu 2026 两篇、Jin 系列和二手索引 | 见上述 | 找到的实质一手结果均已加入候选表 | 无额外直接碰撞 |
| `site:openreview.net "structure-agnostic" "partial linear"`；`site:proceedings.mlr.press "structure-agnostic" semiparametric` | PMLR Gu (2025)；无 OpenReview 完整碰撞 | Gu 2025 Eq. (8)/Thm 1 | 四预算 open problem；loss as printed 与本文不同 | STRONG OVERLAP，非直接碰撞 |
