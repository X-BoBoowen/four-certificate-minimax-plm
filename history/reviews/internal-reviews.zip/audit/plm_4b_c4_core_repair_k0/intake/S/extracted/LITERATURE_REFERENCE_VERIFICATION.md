# 文献引用核验记录

## 核验标准

优先读取原始论文 PDF 和正式出版页面；二手摘要仅用于发现候选，不作为定理字段证据。版本日期、页码和标识符均来自包内 PDF、公开固定版本或出版方页面。所有 arXiv/PMLR 关键文件均与公开版本做 SHA-256 对比。

## 关键来源

### 1. Peter L. Bartlett, Olivier Bousquet, Shahar Mendelson

- 标题：*Local Rademacher Complexities*
- 稳定标识符：https://doi.org/10.1214/009053605000000282
- 最早检查到的作者预印本日期：2004-05-14；正式出版：*Annals of Statistics* 33(4):1497–1537, 2005
- 核查版本：包内 36 页作者预印本；公开 41 页正式版
- 位置：Theorem 2.1，正式版 pp.1503–1504
- 实际内容：bounded class、uniform variance upper bound、Rademacher average 控制的双向高概率偏差
- 与本文：正确支持 Lemma 4；不涉及 PLM/minimax/创新碰撞
- 版本结论：包内与正式版哈希不同，定理内容一致

### 2. Yihong Gu

- 标题：*Open Problem: Structure-Agnostic Minimax Risk for Partial Linear Model*
- 稳定链接：https://proceedings.mlr.press/v291/gu25b.html
- 最早公开/会议时间：COLT 2025，2025-06-30 至 2025-07-04
- 核查版本：PMLR 291:6220–6224；包内与公开 PDF SHA-256 一致
- 位置：Eq. (8), Theorem 1，PDF pp.3–4
- 模型/结论：bounded PLM、四预算；lower `q+(a+s²)(b+t²)`，upper `q+(a+s)(b+t)`
- loss：Eq. (8) 按印刷为 squared error，而显示 rate 为 `n^-1/2` 尺度；记录为来源自身歧义
- 与本文：四预算问题接口的直接前身；没有 M/O/P matching、M1 representation 或 all-n expected-L1 closure

### 3. Yihong Gu, Qishuo Yin, Tianxi Cai, Jianqing Fan

- 标题：*Optimally Taming Biases in Black-Box Models for Efficient Semiparametric Estimation*
- 稳定链接：https://arxiv.org/abs/2606.06368
- 最早公开：2026-06-04
- 核查版本：arXiv v1；包内与公开固定版本 SHA-256 一致
- 位置：Eq. (3.3), Theorem 3.1；Appendix A.1, Theorem A.1，PDF pp.19–20
- 模型/信息：2n samples、expected L1、outer over function classes、approximation/local Rademacher budgets；lower 嵌入固定条件方差
- 结论：双 learner lower `q+AB+M`；upper 非匹配，包含 outcome-only/TAME 与 DML 选择
- 与本文：`q+AB+M` 是直接 prior art；本文新增不能包含这部分 rate 本身

### 4. Yihong Gu

- 标题：*Optimal Use of a Black-Box Learner in Semiparametric Estimation*
- 稳定链接：https://arxiv.org/abs/2607.21541
- 最早公开：2026-07-23
- 核查版本：arXiv v1；包内与公开固定版本 SHA-256 一致
- 位置：Corollary 3.2, Eq. (3.7)，PDF p.16；Proposition 2.3
- 结论：`[aδπ+δμ²]∧[bδμ+δπ²]` 的 TAME-2 high-probability remainder；one-learner matching lower
- 与本文：令 `δμ=a+s`, `δπ=b+t` 后即本文 `Tμ∧Tπ`。上界架构、calibration 和 editing 是直接继承；本文 residual 是 all-n L1/Borel/Q1 closure 和 O/P lower

### 5. Jikai Jin, Lester Mackey, Vasilis Syrgkanis

- 标题：*It’s Hard to Be Normal: The Impact of Noise on Structure-Agnostic Estimation*
- 稳定链接：https://arxiv.org/abs/2507.02275
- 最早公开：2025-07-03；核查 v3：2025-11-07；NeurIPS 2025
- 位置：Theorem 3.2，PDF p.5；Theorem B.1，PDF p.26
- 实际字段：fixed pilots/L2 neighborhoods、fixed-confidence quantile risk。Thm 3.2 为 exact-known Gaussian treatment-noise distribution，T 无界；B.1 为 binary T,Y、一般 propensity variance
- 与本文：PLM coefficient 和 product/noise ideas 强相关，但不保持 bounded constant-v public-class four-budget expected-L1 字段

### 6. Jikai Jin, Vasilis Syrgkanis

- 标题：*Sharp Structure-Agnostic Lower Bounds for General Linear Functional Estimation*
- 稳定链接：https://arxiv.org/abs/2512.17341
- 最早公开：2025-12-19；核查 v2：2026-01-05
- 位置：Theorem 7.5，PDF pp.29–30；Remark 7.1
- 实际字段：fixed anchor、L2 radii、quantile minimax；Theorem 7.5 的目标是 expected conditional covariance，即使限制在 PLM distributions 中也不是 coefficient β
- 与本文：general lower theory 和 invariant perturbation 相邻；Remark 7.1 明确说 JMS coefficient result 不是 general theorem 的直接特例

### 7. Sivaraman Balakrishnan, Edward H. Kennedy, Larry Wasserman

- 标题：*The Fundamental Limits of Structure-Agnostic Functional Estimation*
- 稳定链接：https://arxiv.org/abs/2305.04116
- 最早公开：2023-05-06；核查 v2：2025-06-07；34 页，to appear in *Statistical Science*
- 位置：Sec. 3.1，Theorem 1(3)（PDF p.12），Theorem 2（pp.13–14），ECC proof（pp.27–29）
- 模型/信息：给定 fixed pilot nuisance estimates，truth 位于两个 L2 neighborhoods；MSE risk；ECC target；`X∼Unif`
- 结论：MSE lower `r_n s_n+1/n`，matching first-order upper
- 与本文：modern SA formalization/product lower 的基础强重叠；非 direct collision，因为 target/loss/公共类/四预算/constant-v 不同
- 稿件状态：重要漏引，且 Robins 2009 的归属需拆分

### 8. James Robins, Eric Tchetgen Tchetgen, Lingling Li, Aad van der Vaart

- 标题：*Semiparametric Minimax Rates*
- 稳定链接：https://doi.org/10.1214/09-EJS479
- 出版：*Electronic Journal of Statistics* 3:1305–1321, 2009
- 核查版本：正式 PDF
- 位置：Theorem 2.1，pp.1307–1308；Theorem 4.1，p.1312
- 模型/结论：Hölder smooth semiparametric models；two-mixture Hellinger affinity；smoothness-dependent ECC rate
- 与本文：fuzzy-testing 技术祖先，非 structure-agnostic fixed-pilot/public-class 框架

### 9. Lin Liu, Rajarshi Mukherjee, James M. Robins

- 标题：*On the Asymptotic Inadmissibility of Double Machine Learning Estimators Under Structure-Agnostic Models*
- 稳定链接：https://arxiv.org/abs/2606.22391
- 最早公开/核查版本：arXiv v1，2026-06-21
- 位置：Abstract、Introduction 与 main result sections
- 模型/结论：在 SA fixed-pilot 模型中研究 DML 的 asymptotic admissibility；对两类 monotone-bias functionals 给 HOIF dominance，对 ECC 则 DML/HOIF 均 minimax，互不严格支配
- 与本文：决策论 contextual，非 four-budget PLM rate collision

## 其余稿内引用

- Chernozhukov et al., *Double/Debiased Machine Learning for Treatment and Structural Parameters*, DOI 10.1111/ectj.12097：作者、期刊、21(1):C1–C68、2018 均核对；作为 PLM/DML root-n 背景合适。
- Foster & Syrgkanis, *Orthogonal Statistical Learning*, DOI 10.1214/23-AOS2258：书目信息和背景用途合适。
- Robinson, *Root-N-Consistent Semiparametric Regression*, DOI 10.2307/1912705：Econometrica 56(4):931–954, 1988，书目信息和 classical PLM 背景用途合适。

## 时间分类

- 明确早期 prior work：Bartlett 2004/2005；Robinson 1988；Robins 2009；DML 2017/2018；BKW 2023；Gu COLT 2025；JMS 2025；Jin–Syrgkanis 2025/2026。
- 早于本次审查与稿件 2026-08-26 构建时间，但相对真实投稿日无法确定 pre-submission/concurrent：GYCF 2026-06-04；Liu et al. 2026-06-21；Gu/TAME 2026-07-23。
- 投稿后工作：因投稿时间未提供，未认定任何候选为投稿后。
