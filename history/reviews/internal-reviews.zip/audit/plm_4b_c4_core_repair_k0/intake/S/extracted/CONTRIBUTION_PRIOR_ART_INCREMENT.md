# 贡献—prior art—真实增量对照

| 本稿模块 | prior art | 本稿真正增加的内容 | 我的判断 |
|---|---|---|---|
| `q+AB+M` lower envelope | Gu–Yin–Cai–Fan Thm A.1 | bounded M1/fixed-v embeddings 与整体 assembly | rate 非原创；嵌入有技术增量 |
| `Tμ∧Tπ` upper | Gu Cor. 3.2 Eq.(3.7) | all-n expected-L1、public known-budget selector、Borel closure、unsafe fallback | 架构继承；闭合细节真实但较窄 |
| O=`t min(a,t)` lower | BKW/JMS product-mixture ideas | off-class outcome approximation × in-class propensity resolution，同时保持 constant v/PLM coefficient/public class | 在核查字段内未见直接先例；专门化原创 |
| P=`s min(b,s)` lower | 同上，镜像技术谱系 | off-class propensity × in-class outcome resolution 的独立 finite witness | 同上 |
| 五项 assembly | 标准 outer-sup/minimax algebra | 为每项提供 legal Γ 与统一常数依赖 | 量词代数常规，证书构造非平凡 |
| E/I/S boundary | Gu COLT/JMS 的 variance-role 主题 | shared bounded envelope 在 equality 强制 `π0=0` 和 parametric risk | 本模型内新且正确；外延有限 |
| SA/public-class framework | BKW fixed-pilot SA；Gu 2025/GYCF class-budget risk | countable represented M1、exact Borel access、四预算 pair-specific Q1 | 框架精化，不是全新范式 |

真实贡献的最窄而准确表述应为：

> 在一个 bounded、conditionally constant-variance、represented-public-pair、known-four-budget、pair-specific、expected-L1 的 Q1 PLM experiment 中，本文补足了既有 `q+AB+M` lower 与 `Tμ∧Tπ` upper 之间缺失的两个方向性必要项 O/P，并给出全 n 可测闭合与 shared-envelope saturation 分层。

不应表述为：一般 black-box PLM 的通用最优算法、未知预算自适应定理、共同规则下界，或新发明的 TAME/product lower-bound principle。
