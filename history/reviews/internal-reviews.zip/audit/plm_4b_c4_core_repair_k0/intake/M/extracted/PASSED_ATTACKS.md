# Items that survived attack

The following checks did not reveal a mathematical failure.

1. **Theorem field and target identification.** The bounded PLM and positive conditional treatment-residual variance make beta a well-defined statistical coefficient. No causal claim is required.
2. **Q1 quantifiers.** The fixed-pair estimator precedes the law supremum; lower witnesses enter the outer pair supremum separately; no quantifier exchange occurs.
3. **BBM transfer.** Theorem 2.1's range, variance, Rademacher, confidence, and measurability assumptions map exactly to Lemma 4.
4. **Finite shells.** The envelope supplies a maximal shell, the confidence sum is geometric, and the range/variance terms have the claimed delta_z scales.
5. **Positive-radius boundaries.** No stochastic-complexity quotient at radius zero is used; the h_n floor handles zero budgets.
6. **Joint localization.** Orthogonality preserves v gamma^2 against the cancellation f=-gamma pi0, and no new joint-complexity assumption is needed.
7. **O calibration.** Exact empirical normalization is enforced by the optimization domain; the random represented difference is substituted only after a uniform event.
8. **O tail and expectation.** All amplified terms in (B.18) survive into layer-cake integration; (B.20) follows under the stated safe cell.
9. **R conditioning.** D1 treatments remain random after the R edit is formed from D2 and D1 covariates; the sigma-field choices in (B.29) are valid.
10. **R tail and expectation.** The signs in (B.28), denominator event, amplified terms, and (B.30) integration pass.
11. **Selector and fallback.** Orientation is public; ties and unsafe cells are covered; zero fallback is rate-valid.
12. **Q1 lift.** The uniform fixed-pair inequality is established before taking the outer supremum.
13. **Finite group and Walsh system.** With m=ceil(log2(p+1)), the group has at least p nonzero characters. Their means, norms, and pairwise orthogonality are correct.
14. **Parametric q lower.** Positivity, envelopes, exact variance, likelihood ratios, product second moment, TV, and loss conversion pass.
15. **P lower.** The propensity sign flip, outcome compensation, public pair, complexity, common reference, Gram matrix, and all-n closure pass.
16. **O lower.** The common propensity, deleted outcome perturbation, response factor cancellation, complexity, and mixture distance pass.
17. **ab lower.** Singleton public classes are legal on every stochastic-budget cell; off-class Walsh truths do not leak side information.
18. **M lower.** Both stochastic budgets are checked separately using w<=s and w<=t; public knowledge of both dictionaries is accounted for by the mixture distance.
19. **Maximum-to-sum.** Different pairs are combined only via a maximum; S0<=X<=2S0 is valid on all zeros and ties.
20. **All-n closure.** n=1, n<16, small interactions, equalities, and zero terms are exhaustively spliced with q.
21. **Empty and saturation strata.** Emptiness, propensity identification, parametric upper, and explicit outer lower all pass.

The sole condition on the global upper is the representation issue M-01; none of the passed items above silently resolves or removes that issue.

