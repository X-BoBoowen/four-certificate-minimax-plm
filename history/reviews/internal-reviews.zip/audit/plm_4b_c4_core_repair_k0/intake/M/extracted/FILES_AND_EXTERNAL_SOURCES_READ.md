# Files read, external sources, and tools used

## Attached archive and integrity checks

- Input archive: `D:/29722/Desktop/弱小但是有梦想的BoBoo文/paper/paper/audit/handoff_c4/PLM4B_C4_AUDITOR_M_BLIND_FIRST_PASS.zip`
- Input archive SHA-256: `A52E442D7A8E0E91C497404FB427B4FEDCB1A0B839A9CDB5624DCCEFDDBB979E`
- Every entry was inventoried by filename and size before extraction.
- Every manifest-listed input file was independently hashed after extraction; all hashes matched.
- Anonymous manuscript SHA-256: `F78A14D9377388B893DC7033F0308BCC62BF46F8150710E3F0DBFDB2CFA05226`, matching `MANUSCRIPT_HASH.txt` and `PACKAGE_MANIFEST.tsv`.

## Archive files actually read

1. `README.md` - read first, in full.
2. `manuscript/anonymous_manuscript.pdf` - all 32 pages read through extracted text and page renders; full 32-page contact-render inspection plus full-resolution checks where formulas or typography required confirmation.
3. `guides/MATHEMATICAL_AUDIT_INSTRUCTIONS.md` - read in full after opening the manuscript.
4. `sources/bartlett_bousquet_mendelson_primary.pdf` - PDF metadata and text extracted; Theorem 2.1 on source PDF p. 6 and its proof on source PDF p. 30 read and visually checked at full resolution; surrounding local-complexity context inspected as needed.
5. `AI_OR_HUMAN_REVIEW_NOTICE.md` - read in full.
6. `MANUSCRIPT_HASH.txt` - read and verified.
7. `PACKAGE_MANIFEST.tsv` - read in full; every listed hash verified.
8. `forms/IDENTITY_MODEL_INDEPENDENCE_DECLARATION.md` - blank original read, then completed in the returned copy.
9. `forms/ISSUE_LEDGER.md` - blank original read, then completed in the returned copy.
10. `forms/MODEL_QUANTIFIER_CHECKLIST.md` - blank original read, then completed in the returned copy.
11. `forms/PROOF_DEPENDENCY_CHECKLIST.md` - blank original read, then completed in the returned copy.
12. `forms/RETURN_CHECKLIST.md` - blank original read, then completed in the returned copy.
13. `forms/THEOREM_BY_THEOREM_VERDICT_FORM.md` - blank original read, then completed in the returned copy.

No suspicious or forbidden project file was opened. The archive contained no filled form, prior score, correction, internal certificate, other review, or author-identifying file.

## Generated intermediates actually inspected

- `tmp/pdfs/manuscript/manuscript_text.txt` - searchable extraction used to read the manuscript in page blocks.
- `tmp/pdfs/manuscript/contact_1.png` through `contact_4.png` - visual inspection of all 32 manuscript page renders.
- `tmp/pdfs/manuscript/page-03.png` - full-resolution theorem-statement check.
- `tmp/pdfs/source_bbm/source_text.txt` - searched for the exact source theorem, proof, and transfer context.
- `tmp/pdfs/source_bbm/page-06.png` - full-resolution source Theorem 2.1 check.
- `tmp/pdfs/source_bbm/page-30.png` - full-resolution source proof check.

These intermediates are not included in the return ZIP.

## Operational instruction files read

These files governed tool use only and were not used as evidence about the manuscript:

- `C:/Users/29722/.codex/plugins/cache/openai-curated-remote/superpowers/6.3.0/skills/using-superpowers/SKILL.md`
- `C:/Users/29722/.codex/plugins/cache/openai-curated-remote/superpowers/6.3.0/skills/using-superpowers/references/codex-tools.md`
- `C:/Users/29722/.codex/skills/nature-reviewer/SKILL.md`
- `C:/Users/29722/.codex/plugins/cache/openai-primary-runtime/pdf/26.819.11345/skills/pdf/SKILL.md`

## External sources used

Only the source enclosed in the ZIP was used:

- Peter L. Bartlett, Olivier Bousquet, and Shahar Mendelson, “Local Rademacher Complexities,” *The Annals of Statistics* 33(4), 1497-1537 (2005), DOI 10.1214/009053605000000282. Audited portions: Theorem 2.1 and its proof.

No internet search or external website was used. No search non-hit, novelty inference, priority conclusion, author identification, or comparison with another review was made.

## Tools used

- Local PowerShell and .NET archive APIs for file inventory and safe extraction.
- SHA-256 hashing for input, manuscript, manifest entries, completed outputs, and sealed return archive.
- Bundled Python with `pypdf` for text extraction and `Pillow` for contact-sheet generation.
- Poppler `pdfinfo` and `pdftoppm` for PDF metadata and page rendering.
- Local image inspection for rendered-page verification.
- A local randomized arithmetic stress test of 1.2 million budget tuples for the selector inequalities; used only as supporting evidence.
- Markdown patch editing and ZIP creation for the return package.
- Internet capability was available but was not used.

