# Mathematical audit instructions

Independently audit the mathematical correctness of the anonymous manuscript. State the first unsupported implication rather than repairing it silently.

Required coverage

- Theorem field and Q1/M1 public-class model, public information, quantifiers, envelopes, and all sample sizes.
- Conditional-variance strata, including empty, strict-interior, and saturation regimes.
- The exact use of Bartlett--Bousquet--Mendelson Theorem 2.1 and every transfer step.
- Finite shells, joint localization, and the O/R upper branches.
- Displayed steps (B.18), (B.20), (B.29), and (B.30), including constants and conditioning.
- Measurable selector, fallback branch, tail integration, and the Q1 lift.
- Lower-bound branches q, P, O, ab, and M, including model membership and finite experiments.
- Maximum-to-sum assembly, zero budgets, equality boundaries, and all-n splices.
- Finite-group and Walsh definitions, marginal law, group size, orthogonality, and dimensional indexing.
- The most likely counterexample location if any global statement fails.

For each theorem, record PASS, CONDITIONAL PASS, or FAIL and provide an independent derivation or the first failed line. Treat computer checks as supporting evidence only.
