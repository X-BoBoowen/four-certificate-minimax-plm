# Complete issue list

## M-01 - Pointwise density is insufficient for the claimed L2-infimum transfer

- **Severity:** Moderate, local and repairable; affects the stated M1 theorem field and the interior upper proof, but not the proposed rate after repair.
- **Location:** Anonymous manuscript PDF p. 13, end of Appendix B.1 after (B.5); repeated on PDF p. 30, Appendix I.
- **Claim:** A bounded countable pointwise-dense representation preserves the population L2 approximation infimum by dominated convergence.
- **First failed step:** Ordinary topological pointwise density does not ensure a pointwise-convergent approximating sequence for each class element.
- **Independent evidence:** On X=[0,1], enumerate finite unions B_k of rational intervals with Lebesgue measure at most 1/2 and take g_k=1_[0,1]\B_k. Every finite set of points is contained in some B_k, so 0 is in the pointwise closure of {g_k}. But ||g_k||_2^2>=1/2 for all k, while 0 belongs to the full class. Hence the represented and full-class L2 infima differ.
- **Downstream impact:** The deterministic represented near-best comparators in (B.6)-(B.9) are not justified under the literal density wording. Proposition 2 and Theorem 1(I)'s upper half are conditional on repair. Lower bounds and E/S strata are unaffected.
- **Minimal repair:** Require sequential pointwise density for each class element, or rewrite the empirical comparison using a fixed full-class comparator and a countable shifted fitted class.
- **Does the repair change the main conclusion?** No change to the minimax rate, constants' parameter dependence, or budget range. It clarifies/narrows M1 or changes a local proof device.
- **Verdict:** Confirmed local proof/interface gap; CONDITIONAL PASS.
- **Confidence:** 0.94.

No other substantive mathematical issue was confirmed. The C2/C4 filename discrepancy is recorded as a material limitation rather than a mathematical issue.

