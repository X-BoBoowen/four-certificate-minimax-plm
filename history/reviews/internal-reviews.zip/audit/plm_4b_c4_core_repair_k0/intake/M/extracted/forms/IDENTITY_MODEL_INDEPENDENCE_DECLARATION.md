# Identity, model, and independence declaration

Complete independently. Leave no required field unaddressed in the returned copy.

Reviewer type: AI mathematical reviewer, acting as Reviewer M; not an independent human reviewer.
Provider or affiliation: OpenAI. No human affiliation or credential is claimed.
Model and version or not exposed: GPT-5-based Codex; exact model/version is not exposed by the platform.
Session or instance identifier or not exposed: Platform not provided.
Session date: 2026-08-26, Asia/Shanghai (UTC+08:00).
Relevant expertise: The review was carried out using theoretical-statistics and theoretical-machine-learning reasoning appropriate to empirical processes, localized Rademacher complexity, semiparametric PLMs, minimax testing, chi-square/TV mixtures, and concentration inequalities. This is a description of the review mode, not a claim of human credentials.
Conflict declaration: No conflict, author identity, project history, prior score, reference answer, correction package, internal audit, or other review was accessed or sought. The attachment filename is C4 although the request body says C2; the actual attached C4 archive was reviewed and the mismatch is disclosed.
Independent first-pass declaration: This was my first contact with the project. The current conversation contained no prior substantive project content. The conclusions were formed independently and were not influenced by another reviewer.
Files read: Every file in the attached archive was inventoried. README.md was read first; all 32 manuscript pages were read; the mathematical-audit guide, the relevant primary-source theorem and proof, all blank forms, the manifest, hashes, and review notice were read. A complete path-and-scope inventory is attached as FILES_AND_EXTERNAL_SOURCES_READ.md.
Tools used: Local filesystem and archive inspection; SHA-256 hashing; PowerShell/.NET; bundled Python with pypdf and Pillow; Poppler pdfinfo/pdftoppm; local image inspection; Markdown editing and ZIP creation. Internet access was available but not used.
Authentication or signature: AI-generated review; no human signature, name, credential, or authentication is supplied.
