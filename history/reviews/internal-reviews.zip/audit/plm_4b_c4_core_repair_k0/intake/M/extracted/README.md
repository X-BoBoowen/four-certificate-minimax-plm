# Mathematical correctness first pass

1. Open `manuscript/anonymous_manuscript.pdf`.
2. Read `guides/MATHEMATICAL_AUDIT_INSTRUCTIONS.md` and the enclosed primary source.
3. Re-derive the requested claims independently and fill every file under `forms/`.
4. Return all completed forms together with the full raw review output and model disclosure.

Do not seek external context, author identity, or another reviewer's opinion.
