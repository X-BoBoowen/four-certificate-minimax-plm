# Theorem-by-theorem verdict

Complete independently. Leave no required field unaddressed in the returned copy.

Overall mathematical verdict: CONDITIONAL PASS. The main rate and all lower/boundary mechanisms pass; Proposition 2 and the interior upper half of Theorem 1 are conditional on the M1 repair in Issue M-01.

| Theorem or lemma | Verdict | Independent derivation or first failure | Location | Confidence |
|---|---|---|---|---|
| Theorem 1(E), empty stratum | PASS | Since the absolute value of u is at most B0, E(u^2 given X)<=B0^2; v>=v_->B0^2 is impossible. | PDF p. 29, Appendix H | 0.99 |
| Theorem 1(I), interior minimax law | CONDITIONAL PASS | All lower components and deterministic assembly pass. The first unsupported upper-proof step is the claimed L2-infimum transfer from ordinary pointwise density; see M-01. | PDF pp. 3, 13, 29-30 | 0.94 |
| Theorem 1(S), saturation stratum | PASS | Equality forces u=+/-B0 conditionally with equal probabilities, then the T envelope forces pi0=0; beta=E(TY)/B0^2. The projected moment gives 1/sqrt(2n), and the two-point binary experiment gives 3/(128 sqrt(n)). | PDF pp. 29-30, (H.1)-(H.6) | 0.99 |
| Proposition 2, global class-pair upper | CONDITIONAL PASS | O/R oracle inequalities, selector, fallback, and Q1 lift pass. It inherits only M-01 from the initial-fit representation argument. | PDF pp. 4, 11-19 | 0.93 |
| Lemma 3, bounded Bernstein | PASS | The conditional mgf argument and two-tail optimization yield the displayed conservative constants. | PDF p. 12, (B.1)-(B.1a) | 0.98 |
| Lemma 4, localized supremum concentration | PASS | Exact parameter mapping from BBM Theorem 2.1: symmetric class, alpha=1, range length 2B, variance sigma^2. | PDF p. 12, (B.2); source PDF pp. 6, 30 | 0.99 |
| Lemma 5, localized multiplier and square processes | PASS | Finite dyadic shells terminate by the fixed envelope; confidence allocation is summable; variance and range terms give delta_z times the L2 norm of f plus delta_z^2, without star-shapedness. | PDF pp. 12-13, (B.2a)-(B.4) | 0.95 |
| q lower certificate | PASS | Exact four-atom likelihood ratio has K_q<=1/(64n); N=2n gives cross-label TV<1/4 and risk >=(3d*_rho/8)q. | PDF p. 20, (C.8)-(C.9) | 0.99 |
| P lower certificate | PASS | Common reference identity Delta(v0+eta^2)=eta(kappa+gamma), Walsh orthogonality, and p>=exp(64Ns^2) give exponentially small chi-square; gap is proportional to s(b min s). | PDF pp. 21-23, (C.10)-(C.21) | 0.97 |
| O lower certificate | PASS | The common propensity is legal, Delta(v0+gamma^2)=gamma eta makes the references agree, and the finite mixture yields the t(a min t) gap. | PDF pp. 23-25, (D.1)-(D.15) | 0.97 |
| ab lower certificate | PASS | Singleton public classes have zero stochastic complexity; off-class Walsh truths meet approximation budgets; the common-reference mixture gives a gap proportional to ab. | PDF pp. 25-26, (E.1)-(E.13) | 0.97 |
| M lower certificate | PASS | Both truths are in the public dictionaries; the two stochastic budgets are checked separately using w<=s,t; the gap is proportional to (s min t)^2. | PDF pp. 26-28, (F.1)-(F.15) | 0.97 |
| Lemma 6, testing/chi-square/Gram mixtures | PASS | Midpoint testing gives Delta(1-TV)/4; Cauchy--Schwarz gives TV<=sqrt(chi-square)/2; ordered-pair counting gives the exact finite-mixture formula. | PDF p. 19, (C.1)-(C.3) | 0.99 |
| Lemma 7, finite-class complexity | PASS | Conditional log-sum-exp/Hoeffding optimization yields R sqrt(2 log M/n); localization only reduces the supremum. | PDF p. 19, (C.4) | 0.99 |
| Lower maximum-to-sum assembly | PASS | AB=ab+at^2+bs^2+s^2t^2 and the three extra terms are bounded by O,P,M, so S0<=X<=2S0; five valid pairwise lower bounds combine via a maximum. | PDF pp. 28-29, (G.1)-(G.3) | 0.99 |
