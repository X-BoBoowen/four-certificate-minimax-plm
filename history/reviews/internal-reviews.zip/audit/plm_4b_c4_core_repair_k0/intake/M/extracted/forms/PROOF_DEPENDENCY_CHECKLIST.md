# Proof dependency checklist

Complete independently. Leave no required field unaddressed in the returned copy.

BBM transfer verdict: PASS. Bartlett--Bousquet--Mendelson Theorem 2.1 is applied to the symmetric centered class with [a,b]=[-B,B], variance r=sigma^2, x=z, and alpha=1. This gives 4 R_n + sqrt(2 sigma^2 z/n) + 8Bz/(3n); the manuscript's 2e^{-z} failure probability is conservative relative to the source's e^{-z}. Countability supplies measurability.
Selector verdict: PASS. The x<=y/y<x orientation is public, deterministic, disjoint, and exhaustive. The inequalities T_selected<=2W<=48X are conservative; independent randomized boundary checks found much smaller worst ratios and no violation. Unsafe cells imply either q or M/P/O is bounded below by a fixed threshold, so zero fallback is rate-valid.
Tail-integration verdict: PASS. In (B.18) and (B.29), the amplified (d/r)sqrt(z/n) terms are retained. Layer-cake integration yields scales q, (ad/r)q or (bd/r)q, q^2, d/(nr), q^3, and ell q. The floor r>=C sqrt(log(en)/n), clipping, and the endpoint z=cn control all pieces. Pointwise-in-z events suffice.
Upper assembly verdict: CONDITIONAL PASS solely because of Issue M-01. Conditional on sequential pointwise density (or the stated alternative proof repair), the initial fits, O/R branches, fallback, measurability, and Q1 lift are valid.
Lower assembly verdict: PASS. The q, P, O, ab, and M experiments separately satisfy model membership and mixture-distance bounds. Their maxima lower-bound the same scalar outer-pair risk. S0<=X<=2S0 and max>=sum/5 yield (G.3), including all zero and equality faces.
Comments: Conditioning in (B.18) is correct: fitted O weights are fixed given D1 X,T and D2 before outcome-noise averaging. Conditioning in (B.29) is correct: the R edit uses D1 covariates and D2 outcomes but not D1 treatments, so P1(r_m u) remains centered given F_X.
