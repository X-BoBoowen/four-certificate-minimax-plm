# Independent derivations and counterexample attempts

This file records the calculations used to audit the manuscript. Computer checks were used only as supporting evidence; the judgments below follow the displayed derivations.

## 1. BBM Theorem 2.1 to Lemma 4

For a centered countable class W with |W|<=B and EW^2<=sigma^2, enlarge it by negatives. The source one-sided supremum over this symmetric class is exactly `sup_w |P_n W(w)|`. In Bartlett--Bousquet--Mendelson Theorem 2.1 set alpha=1, range [a,b]=[-B,B], r=sigma^2, and x=z. Then

`2(1+alpha) E R_n = 4 E R_n`,

`sqrt(2 r x/n) = sqrt(2 sigma^2 z/n)`,

and

`(b-a)(1/3+1/alpha)x/n = 2B(1/3+1)z/n = 8Bz/(3n)`.

The source probability is 1-e^{-z}; allowing 2e^{-z} is conservative. This reproduces (B.2).

## 2. Finite-shell calculation

Let delta_z dominate r0, h_n=sqrt(log(en)/n), and sqrt(z/n). On shell j, ||f||_2<=R_j=2^j delta_z. Lemma 4 gives three contributions:

1. localized Rademacher mean: `C delta_z R_j`;
2. variance: `C R_j sqrt((z+j+1)/n)`;
3. range: `C(z+j+1)/n`.

Because the envelope ends the shells at J=O(log(en)), `sqrt(j/n)<=C h_n` and `j/n<=C h_n^2`. Hence the last two contributions are at most `C delta_z R_j` and `C delta_z^2`. For j>=1, R_j<2||f||_2; on the inner ball R_0=delta_z. This gives (B.3)-(B.4). The confidence allocation x_j=z+2j+log 8 has a finite geometric failure sum.

## 3. Joint curvature and localization

For j=gamma T+f(X), write T=pi0(X)+u. Conditional centering gives

`E j^2 = v gamma^2 + ||gamma pi0+f||_2^2`.

Also `||f||_2 <= ||gamma pi0+f||_2+B0|gamma|`. Thus the joint norm controls both gamma and f. On a joint L2 ball of radius R,

`|gamma|<=R/sqrt(v_-)`, `||f||_2<=C_rho R`.

The scalar T direction has Rademacher mean at most `C R/sqrt(n)`. The public outcome difference direction is bounded by `C s R` at the enlarged positive radius. Taking the base radius `C_rho(s max h_n)` proves the claimed joint localization.

## 4. O identity and tail integration

Exact normalization P1(T a_hat)=1 gives

`beta_hat_O-beta0 = P1(epsilon w) + P1[epsilon(a_hat-w)] + P1[(mu0-g)w] + P1[(mu0-g)(a_hat-w)] + P1[(g-mu_hat)a_hat]`,

where w=u/v. This is an algebraic identity; no population normalization is substituted for the empirical one.

The objective comparison has penalty lambda_O proportional to `(r/d)^2`. Dividing only the norm inequality by lambda_O produces `(d/r)sqrt(z/n)`, which then appears multiplied by a or sqrt(z/n). Thus (B.18) correctly retains `(ad/r)sqrt(z/n)` and `(d/r)z/n`, and does not need a standalone `(d/r)sqrt(z/n)`.

For a tail term z^{p/2}n^{-p/2} with failure C e^{-z}, layer cake contributes a fixed Gamma moment times n^{-p/2}. Therefore:

- sqrt(z/n) integrates to q=n^{-1/2};
- z/n integrates to q^2;
- z^{3/2}/n^{3/2} integrates to q^3;
- `(ad/r)sqrt(z/n)` integrates to `(ad/r)q`;
- `(d/r)z/n` integrates to d/(nr).

The split h_n<=y versus y<h_n gives `a h_n<=ay` in the first case and `a h_n<=h_n^2<=2q` in the second because a<=x<=y<h_n. This also controls `(ad/r)q`. Since r>=C h_n, d/(nr)<=Cq. The remaining base and ell terms have the same scale, giving (B.20).

## 5. R identity, conditioning, and integration

Let e_pi=pi_hat-pi0, r_m=m_hat-m0, and D=P1(u-e_pi)^2. Since `Y-m0=beta0 u+epsilon`,

`D(beta_hat_R-beta0) = P1[epsilon(u-e_pi)] - P1[r_m(u-e_pi)] + beta0{P1(u e_pi)-P1(e_pi^2)}`.

This verifies every sign in (B.28).

The edit m_hat is a function of D2 and D1 covariates, but not D1 treatments. Given F_X, r_m is fixed and E(u_i given X_i)=0, so P1(r_m u) is centered. Given F_T, the coefficient of epsilon is fixed and E(epsilon_i given X_i,T_i)=0. The fitted public difference is inserted into the uniform calibration event, not a pointwise event.

Replacing a,y with b,x in the O integration gives the scales in (B.29). The split h_n<=x versus x<h_n controls b h_n because b<=y<x on the R cell. This yields (B.30).

## 6. Selector algebra

Write x=a+s, y=b+t, `T_mu=ay+x^2`, and `T_pi=bx+y^2`.

If x<=y, then `T_mu=ay+x^2<=xy+xy=2xy`, while `T_pi=bx+y^2>=xy`; hence `T_mu<=2T_pi`. The mirror holds for y<x. Thus the selected branch is at most `2 min(T_mu,T_pi)`.

For `A=a+s^2`, each component of X is bounded by a fixed multiple of A: AB<=2A and M,O,P<=A, so X<=5A. Also AB,M,O,P are each at most xy, so X<=4xy. The six weak-order cells used by the manuscript control X by T_mu or T_pi. The constants 4, 6, and 48 are loose but valid. A randomized check of 1.2 million tuples in [0,1]^4 found maxima approximately X/V=3.981, W/V=3.380, selected/X=2.541, and X/S0=1.999, all below the manuscript's bounds.

For an unsafe O cell with h_n below the fixed threshold, s is above that threshold. If t>=s/2, then M>=s^2/4. Otherwise x<=y implies b>s/2, so P=s min(b,s)>s^2/2. The R case is symmetric. This proves the fallback implication.

## 7. Parametric q lower

Under the common uniform four-atom reference, the label likelihoods are 1+/-h with

`h(t,r)=2 r delta_n t/B0`, `E_Q h=0`, and `K_q=E_Q h^2=4 delta_n^2 v0/B0^2<=1/(64n)`.

For N=2n, `(1+K_q)^N-1<1/31`. Each label is within TV `1/(2 sqrt(31))` of the reference, so cross-label TV is below 1/4. Target separation is `2d*_rho/sqrt(n)`, giving risk at least `(3d*_rho/8)q`.

## 8. P finite mixture

For side atoms, the common-reference condition is

`Delta(v0+eta^2)=eta(kappa+gamma)`.

Because `Delta v0=2eta gamma` and `kappa=gamma+Delta eta`, both sides are equal. At the middle atom both vanish. The centered likelihood coefficients multiply the Walsh sign z. Equal coordinate/sign pairs have Gram entry 1+K, opposite signs 1-K, and distinct coordinates 1 by orthogonality. With `p>=exp(64Ns^2)` and K<=s^2/196,

`chi^2 <= exp(NK)/p <= exp[-(64-1/196)Ns^2]`.

On the nonparametric branch Ns^2>=8, so the distance is far below the required constant. The target gap is `lambda_rho m_rho s(b min s)/(512v0)`.

## 9. O finite mixture

The common propensity is pi=z gamma. The reference identity is

`Delta(v0+gamma^2)=gamma eta`,

which holds by definition of Delta. The label-one response factor cancels in the likelihood ratio against the common reference. K0<t^2/9 and K1<t^2/256, so the same p construction gives exponentially small chi-square. The target gap is bounded below by a fixed-rho constant times t(a min t).

## 10. ab and M mixtures

For ab, both public classes are singletons. The Walsh functions occur only in the law and remain off-class. The same compensation identity as P gives common references. Since S=a^2+b^2 and K<=S/8, p>=exp(64NS) makes the mixture close. The target gap is `m_rho ab/(1024v0)`.

For M, both truths are public. Let w=min(s,t). The outcome complexity is at most a constant times `eta w`, divided by r>=s; because w<=s this is at most a constant times s^2. The propensity calculation divides by r>=t and uses w<=t. Thus the two stochastic budgets are proved separately. The target gap is a fixed-rho multiple of w^2.

## 11. Maximum-to-sum

`AB=ab+at^2+bs^2+s^2t^2`.

If a<=t, at^2<=at=O; if a>t, at^2<=t^2=O. The bs^2 inequality is the mirror. Since max(s,t)<=1, s^2t^2<=min(s,t)^2=M. Hence `S0<=X<=2S0`. Each component separately lower-bounds the same outer-pair risk, so the risk lower-bounds their maximum. The maximum of five nonnegative values is at least one fifth of their sum, producing (G.3).

## 12. Saturation

At v_-=B0^2, `u^2<=B0^2` and `E(u^2 given X)>=B0^2` imply `u^2=B0^2` almost surely. Conditional mean zero gives equal conditional masses at +/-B0. Both `pi0(X)+B0` and `pi0(X)-B0` must lie in [-B0,B0], whose intersection forces pi0=0. Therefore

`beta0=E(TY)/B0^2`.

The empirical average of 2n bounded terms has standard deviation at most 1/sqrt(2n) after normalization. For the lower experiment, one-observation Hellinger affinity is `sqrt(1-4delta_n^2)`. Tensorization and `1-(1-x)^N<=Nx` give `TV^2<=4Ndelta_n^2=72/1024<1/4`; target separation 2delta_n gives (H.6).

## 13. Successful counterexample to the representation claim

The construction in Issue M-01 is a direct counterexample to the manuscript's statement that pointwise density alone and boundedness allow dominated convergence to preserve L2 infima. It does not attack the rate after sequential density is added.

## 14. Counterexample attempts that did not succeed

- **Variance boundary:** Attempted to retain nonzero pi0 at saturation. The simultaneous T-envelope constraints for both residual signs force pi0=0, so the attack fails.
- **Different-pair lower assembly:** Attempted to invalidate addition across public pairs. The proof takes a maximum of scalar lower bounds before deterministic max-to-sum algebra; no Bayes risks are added, so the attack fails.
- **Public dictionary reveals the hard coordinate:** Allowing the learner the entire finite dictionary does not reveal the latent coordinate/sign; the mixture TV inequality already quantifies over all Borel rules, so the attack fails.
- **Zero stochastic budgets:** The positive-radius quotient is never evaluated at zero; singleton difference classes have exactly zero complexity for every positive radius, so the attack fails.
- **R-branch dependence:** Although the edit uses D1 covariates, it does not use D1 treatments; residual centering survives conditioning, so the attack fails.
- **Selector algebra:** Boundary and randomized tests did not find a violation; direct order arguments validate the loose constants.

