# Reviewer M: independent mathematical proof audit

## Review status and scope

This is my first contact with the project. The current conversation contained no prior substantive project material, score, correction history, reference answer, internal audit, or other review. I did not seek author identity or outside project context, and no other reviewer influenced the conclusions.

The request body names `PLM4B_C2_AUDITOR_M_BLIND_FIRST_PASS.zip`, but the actual attachment is `PLM4B_C4_AUDITOR_M_BLIND_FIRST_PASS.zip`. I reviewed the attached C4 archive. The input archive SHA-256 is `A52E442D7A8E0E91C497404FB427B4FEDCB1A0B839A9CDB5624DCCEFDDBB979E`. The manuscript hash independently matches the enclosed manifest: `F78A14D9377388B893DC7033F0308BCC62BF46F8150710E3F0DBFDB2CFA05226`.

## Overall verdict

**CONDITIONAL PASS.**

I did not confirm a failure of the claimed minimax rate, any lower-bound component, the variance-boundary theorem, the Q1 maximum-to-sum assembly, or the BBM concentration transfer. I found one real, localized M1 interface/proof gap: the manuscript uses ordinary “pointwise density” as if it guaranteed a pointwise-convergent sequence and hence preservation of population L2 approximation infima by dominated convergence. That implication is false without a sequential-density condition. Strengthening the M1 definition or rewriting the comparator step repairs the issue without changing the rate, constants, lower constructions, or boundary regimes.

This is therefore not a FAIL, but Proposition 2 and the interior upper half of Theorem 1 are not fully established under the most literal reading of the present M1 wording.

## Confirmed issue M-01: pointwise density does not by itself preserve L2 infima

**Location.** Anonymous manuscript PDF p. 13, end of Appendix B.1 after (B.5), and p. 30, Appendix I.

**Claim checked.** The supplied countable pointwise-dense representation permits deterministic represented near-best population comparators, because bounded pointwise density allegedly transfers population L2 infima by dominated convergence.

**First unsupported step.** A topologically pointwise-dense countable subset need not contain a sequence converging pointwise to a given class element. Without such a sequence, dominated convergence is unavailable.

**Counterexample.** Let X=[0,1] with Lebesgue measure. Enumerate all finite unions B_k of rational-endpoint intervals having total measure at most 1/2, and define

`g_k = 1_{[0,1] \ B_k}`.

For every finite set x_1,...,x_m, there is some B_k containing all those points and having measure at most 1/2. Hence g_k vanishes on that finite set, so 0 belongs to the closure of {g_k} in the topology of pointwise convergence. Thus {g_k} is pointwise dense in `G={0} union {g_k}` in the ordinary topological sense. Nevertheless,

`||g_k||_2^2 = 1 - Leb(B_k) >= 1/2`

for every k. Consequently, the representation has L2 distance at least 1/sqrt(2) from 0, whereas the full class has approximation infimum zero. The space is standard Borel and all functions are bounded and measurable.

**Downstream effect.** The deterministic represented comparators invoked in the initial propensity and joint outcome fits are not justified by the stated density condition. The rest of the O/R upper proof is built after those initial-fit bounds, so the global upper is conditional on fixing this step. The finite lower bounds do not use the problematic interface and are unaffected.

**Minimal repair.** State that the representation is sequentially pointwise dense: for every g in G there exists a sequence from the representation converging to g at every x. The fixed envelope then makes dominated convergence valid for every compatible P_X. A second valid repair is to compare empirical minima directly with a fixed full-class near-best g and run the uniform process argument over the countable shifted fitted class `{g_j-g}`; this avoids claiming L2 density of the representation.

**Effect on main conclusion.** No change to the rate, budget exponents, lower witnesses, constants' dependence on rho, model, or parameter range is required. The repair does narrow or clarify the M1 access definition, which is why I do not mark the current text unconditionally PASS.

**Judgment and confidence.** Local repairable proof/interface gap; confidence 0.94.

## Audit of the main load-bearing chain

### Model, envelopes, and quantifiers

The fixed law field is coherent. Positive conditional treatment-residual variance identifies beta as a statistical PLM coefficient. The fixed B0 and BG envelopes are used where needed, and the lower constructions explicitly shrink public candidates through lambda_rho. The stochastic budgets are upper certificates, so singleton classes remain legal on larger declared cells.

The Q1 order is preserved. For the upper bound, one Borel rule is constructed for each fixed public pair before the supremum over compatible laws. For the lower bound, each component inserts one legal public pair into the same outer supremum. Different component pairs are never added as Bayes risks; only their valid scalar lower bounds are combined by a maximum. I found no sup/inf exchange.

### Conditional-variance strata

- **E passes.** From |u|<=B0, one has E(u^2 given X)<=B0^2, so v_->B0^2 makes the experiment empty.
- **I passes conditional on M-01.** The lower bound and deterministic assembly pass; the upper inherits only the representation issue.
- **S passes.** At v_-=B0^2, equality and centering force u=+/-B0 with conditional probability 1/2. The T envelope then forces pi0=0. Thus beta=E(TY)/B0^2. The projected empirical moment has expected error at most 1/sqrt(2n), while the displayed two-point binary experiment gives 3/(128 sqrt(n)). No interior constant is improperly continued to saturation.

### Exact BBM Theorem 2.1 transfer

The source theorem is applied to the symmetric enlargement of the centered class. The exact mapping is

- source range [a,b] -> [-B,B], hence b-a=2B;
- source variance r -> sigma^2;
- source confidence x -> z;
- source alpha -> 1;
- source one-sided supremum over the symmetric class -> the absolute empirical supremum Z;
- source expected Rademacher term -> the manuscript's absolute R_n.

The source bound becomes

`4 R_n + sqrt(2 sigma^2 z/n) + 2B(1/3+1) z/n`

which is exactly `4 R_n + sqrt(2 sigma^2 z/n) + 8Bz/(3n)`. The source probability is at least 1-e^{-z}; the manuscript's failure allowance 2e^{-z} is conservative. Countability supplies the measurability assumed by the source. Lemma 4 passes.

### Finite shells and joint localization

The fixed envelope terminates the dyadic shells. With x_j=z+2j+log 8, the multiplier/square and two-sided failures are summable. The variance term is of order R_j sqrt(x_j/n), the range term is x_j/n, and h_n=sqrt(log(en)/n) controls both the maximum shell index and confidence allocation. This yields delta_z||f||_2+delta_z^2 without star-shapedness or rescaling. The positive radius floor correctly handles s=0 or t=0.

For the joint class j=gamma T+f(X), orthogonality gives

`||j||_2^2 = v gamma^2 + ||gamma pi0 + f||_2^2`.

It follows that |gamma|<=||j||_2/sqrt(v_-) and ||f||_2<=C_rho||j||_2. The scalar T direction costs O(n^{-1/2}) and the public difference direction uses the admissible positive radius. This supplies the required joint localization without an unstated joint-complexity hypothesis.

### O branch: (B.18) and (B.20)

Exact normalization is enforced because H_mu(a) is finite only on P1(Ta)=1. The comparator a0=u/P1(Tu) lies on that hyperplane on the denominator event. Uniform multiplier and square bounds established before fitted substitution imply (B.12)-(B.16).

The conditioning is legal: given D2 and D1 values of X,T, the fitted O weights are fixed and the D1 outcome residuals remain centered. The term involving `(mu0-g_mu)u/v` is centered given D1 covariates. The calibrated represented difference is inserted only after the countable uniform event.

The amplified terms in (B.18) are necessary and present. Writing r=bar{s}, d=d_pi, and w_z=sqrt(z/n), layer-cake integration sends the nonconstant terms to

- w_z -> q;
- (ad/r)w_z -> (ad/r)q;
- w_z^2 -> q^2;
- (d/r)w_z^2 -> d/(nr);
- w_z^3 -> q^3;
- ell w_z -> ell q.

Since r>=C h_n, d is bounded and also d<=C(y+r+rho_n), the split h_n<=y versus y<h_n bounds every term by C(q+ay+x^2). The interval z>cn is controlled by clipping on the failure event at z=cn. Thus (B.20) passes, conditional only on M-01 upstream.

### R branch: (B.29) and (B.30)

The R edit is not a formal symmetry argument. It uses D2 outcomes and D1 covariates, but not D1 treatments. Therefore, after conditioning on F_X, the D1 residuals u_i remain independent and centered, validating the bound for P1(r_m u). Outcome noise is handled after conditioning on F_T. The fitted propensity difference is inserted into (B.25) only after a uniform public-class event.

The denominator identity (B.26) is exact, and the denominator is bounded below on z<=c_3 n. Direct substitution yields (B.28) with the correct signs. The amplified terms in (B.29) match the objective comparison. Their integrations mirror the O calculation with b,d,bar{t}; the h_n<=x versus x<h_n split controls bd and (bd/r)q. Thus (B.30) passes, again conditional only on M-01 upstream.

### Selector, fallback, and Q1 lift

The public orientation uses only declared budgets. Ties go to O; safe and unsafe cells are disjoint and exhaustive. With T_mu=ay+x^2 and T_pi=bx+y^2, the selected branch is at most 2 min(T_mu,T_pi). The manuscript's comparison through V is conservative; independent randomized checks over 1.2 million budget tuples found no violation of X/5<=V, W<=4V, or the final selector bound.

If an O cell is unsafe and h_n is not already large, then s exceeds a fixed threshold. Either t>=s/2 and M>=s^2/4, or x<=y forces b>s/2 and P>s^2/2. The R argument is the mirror using O. Hence the clipped zero fallback is valid. The fixed-pair uniform inequality is established before the outer public-pair supremum, so the Q1 lift passes.

## Lower-bound audit

### Native q experiment

With T=+/-sqrt(v0) and the binary response channel, the one-observation likelihood ratio is 1+/-h with E_Q h=0 and K_q=4(d*_rho)^2v0/(nB0^2)<=1/(64n). For N=2n, each label is close to the common reference and the cross-label TV is below 1/4. The target separation 2d*_rho/sqrt(n) gives the stated `(3d*_rho/8)q` lower bound. All envelopes and every declared budget cell are legal.

### P witness

For label 0 and label 1, the raw six-atom laws have exact variance v0. The identity

`Delta(v0+eta^2)=eta(kappa+gamma)`

makes the sign-averaged references equal atom by atom. Restoring z=sigma phi_j(X), Walsh orthogonality gives Gram entries 1+K, 1-K, and 1. With p>=exp(64Ns^2) and K<=s^2/196, the mixture chi-square is exponentially small. Both labels share one public pair; the target gap is proportional to s(b min s). Model membership, approximation, stochastic complexity, and the all-n splice pass.

### O witness

Both labels share pi=z gamma. The identity

`Delta(v0+gamma^2)=gamma eta`

equalizes the sign-averaged references. The label-one outcome factor cancels only after division by the positive common reference, as claimed. The finite public propensity dictionary meets the t budget, and the target gap is proportional to t(a min t). The mixture and all-n splice pass.

### ab witness

The public pair is exactly the singleton pair, so both stochastic complexities vanish. Walsh functions index off-class laws only and are not public side information. The two approximation errors are within a and b, the raw laws are positive PLMs with exact variance v0, and the common-reference Gram calculation gives the ab gap. This branch passes.

### M witness

Both nuisance truths lie in the public finite dictionaries. The stochastic certificates are checked separately: w=min(s,t) is divided by s on the outcome side and by t on the propensity side. The common-reference calculation matches the O mechanism with both dictionaries public, and the target gap is proportional to w^2. This branch passes.

### Maximum-to-sum and edge cases

Let S0=ab+M+O+P. Expanding AB gives `ab+at^2+bs^2+s^2t^2`. On [0,1]^4,

- at^2<=t(a min t)=O;
- bs^2<=s(b min s)=P;
- s^2t^2<=(s min t)^2=M.

Therefore S0<=X<=2S0. The outer risk dominates each legal component pair, so it dominates the maximum of the five component bounds; the maximum is at least one fifth of their sum. This proves (G.3) without combining incompatible priors. Zero budgets, equality faces, n=1, n<16, and small-interaction branches are all explicitly covered.

## Items that survived targeted attacks

- The source-to-Lemma-4 BBM constant mapping and probability.
- Finite shell termination, maximum shell, geometric confidence allocation, and positive-radius floors.
- Joint beta/mu curvature; the potential cancellation f=-gamma pi0 cannot remove v gamma^2.
- Exact O normalization and legal insertion of a random fitted outcome difference after a uniform event.
- R-branch conditioning despite use of D2 outcomes and D1 covariates.
- The amplified terms and separate layer-cake scales in (B.18) and (B.29).
- Selector orientation, unsafe-cell fallback, and the fixed-pair-to-Q1 quantifier lift.
- Positivity, exact variance, envelopes, common references, Walsh orthogonality, group size, and dictionary cardinalities in all five lower branches.
- All-n splices, zero budgets, equality boundaries, singleton variance intervals, and saturation.
- Maximum-to-sum assembly using different legal public pairs only through the outer supremum.

## Unconfirmed matters and material limitations

- I did not use the internet. No external source beyond the enclosed Bartlett--Bousquet--Mendelson primary PDF was used as mathematical evidence.
- I did not assess novelty, priority, author identity, computational usefulness, adaptation, causal interpretation, or empirical performance.
- The attachment/body C4-versus-C2 mismatch remains an administrative identification issue.
- Constants K_i in the upper proof are existential fixed functions of rho rather than numerically instantiated. I found no incompatible dependence, but I did not reconstruct a single optimized numerical C_rho; the theorem claims only existence.
- The review is AI-generated red-team evidence and is not an independent-human verification.

## Source declaration

Provider: OpenAI

Model: GPT-5-based Codex

Exact model/version: Platform not provided

Session or instance ID: Platform not provided

Whether this is a new session: Yes; first project contact in the visible context

Whether the project was encountered previously: No

Review date, time, and timezone: 2026-08-26, Asia/Shanghai (UTC+08:00); sealing time is recorded in the detached checksum file and final return message

Tools and network capability: Local filesystem/archive inspection, PowerShell/.NET, SHA-256, bundled Python with pypdf/Pillow, Poppler PDF inspection/rendering, local image inspection, Markdown editing, and ZIP creation. Internet capability was available but not used.

Input ZIP SHA-256: A52E442D7A8E0E91C497404FB427B4FEDCB1A0B839A9CDB5624DCCEFDDBB979E

Output ZIP SHA-256: Reported after archive sealing in the detached `OUTPUT_ZIP_SHA256.txt` and the final return message; embedding an archive's own final hash inside itself would change that hash.

