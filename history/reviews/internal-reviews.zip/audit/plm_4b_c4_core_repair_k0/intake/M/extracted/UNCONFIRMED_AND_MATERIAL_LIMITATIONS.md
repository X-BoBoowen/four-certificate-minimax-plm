# Unconfirmed matters and material limitations

1. **Attachment identity.** The request body names a C2 archive, but the attached and reviewed file is C4. I did not search for or infer a missing C2 package.
2. **No external project context.** No old score, correction, author expectation, internal report, other reviewer, or project history was consulted.
3. **External literature boundary.** No internet search was performed. The only external mathematical source used was the enclosed Bartlett--Bousquet--Mendelson primary PDF, specifically Theorem 2.1 and its proof. No novelty or priority inference is made.
4. **Existential upper constants.** The manuscript leaves K_i as fixed functions of rho. I verified the dependence and absorption logic but did not reconstruct an optimized single numerical C_rho. This is not a contradiction because only existence is claimed.
5. **M1 interpretation.** If the authors define “pointwise-dense representation” elsewhere to mean sequential pointwise approximation for every class function, Issue M-01 becomes a wording/definition omission rather than a failed proof step. That stronger definition is not explicit in the reviewed package.
6. **Nonclaims not assessed.** Computational efficiency, unknown-budget adaptation, confidence intervals, causality, empirical advantage, and uniform boundary constants are expressly outside the theorem and were not treated as defects.
7. **AI status.** This audit is AI-generated red-team evidence. It does not claim a human identity, credential, institution, signature, or replacement for independent human verification.

