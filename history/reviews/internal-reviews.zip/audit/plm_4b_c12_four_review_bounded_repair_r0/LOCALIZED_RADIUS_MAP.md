# Seven-call localized-radius map

Appendix A states, for positive admissible radii,

```text
R*_{mu}(r) <= 3 c_rad s r,
R*_{pi}(r) <= 3 c_rad t r.
```

Core domination transfers these inequalities to the ordinary measurable
represented cores.  Lemma B.2a is therefore invoked with the following exact
base radii.

| Primitive call | Class | Base radius `r0` | Reason |
|---|---|---:|---|
| `P_{pi,2}^u(z)` | represented propensity difference core | `3t` | direct A.1/core-domination call |
| `P_{mu,2}^{sq}(z)` | represented outcome difference core | `3s` | direct A.1/core-domination call |
| `P_{J,2}^{epsilon}(z)` | countable joint class `J_mu` | `C_J(s vee h_n)` | independent joint-class localization after B.8 |
| `P_{mu,1}^u(z)` | represented outcome difference core | `3s` | direct A.1/core-domination call |
| `P_{pi,2}^{xi}(z)` | represented propensity difference core | `3t` | direct A.1/core-domination call |
| `P_{pi,2}^{m0}(z)` | represented propensity difference core | `3t` | direct A.1/core-domination call |
| `P_{pi,1}^{m0}(z)` | represented propensity difference core | `3t` | direct A.1/core-domination call |

The simple calls obey

```text
K1(3s vee h_n) <= 3 K1(s vee h_n),
K1(3t vee h_n) <= 3 K1(t vee h_n).
```

Because `C_f>=1`, the declared `C_J` is at least four.  The already frozen

```text
C_rad = 1 + K_{1,*}(1+C_J)
```

dominates both `3 K_{1,*}` and `K_{1,*} C_J`.  The live constant parser finds
the original acyclic order and no duplicate assignment.  No downstream
constant, estimator tuning, or rate was altered.

At zero stochastic budget the matching simple-core base radius is zero
directly; the proof never evaluates the Appendix A quotient at zero.

