# Outer-expectation and represented-core audit

## Corrected objects

For an arbitrary public class `H`, Candidate-C13 defines the sample/sign
supremum `Z_H(r)` at the exact population `L2(P_X)` radius and sets

```text
R*_{n,P_X}(r;H) = E* Z_H(r),
```

where `E* Z` is the infimum of `E U` over measurable majorants `U >= Z`.
The common envelope makes these quantities finite.  If `Z` is measurable,
outer and ordinary expectations agree.

For a supplied representation `G^rep={g_j}`, the difference core
`Delta G^rep={g_j-g_k}` is countable.  Each summand is measurable, hence the
supremum of the countable family is a measurable random variable and its
ordinary expectation is defined.  Since the represented core is a subset of
the full difference class, the samplewise inequality

```text
Z_{Delta G^rep}(r) <= Z_{Delta G}(r)
```

implies, by the definition and monotonicity of outer expectation,

```text
R_{n,P_X}(r;Delta G^rep) <= R*_{n,P_X}(r;Delta G).
```

This is the only full-to-core localized-complexity implication used by the
upper proof.

## Measurability boundary

- The model-field certificates in both Appendix A occurrences use `R*` for
  the arbitrary full classes.
- Lemma B.2a and all seven empirical-process calls retain ordinary expectation
  on countable represented cores or on the separately countable joint class.
- Sequential M1 still transfers population approximation infima and finite-
  sample continuous objectives.  It is not asserted to make every exact
  population-radius full-class supremum measurable, nor to make the full and
  represented localized complexities equal.
- Lemma B.8(iii) concerns finite-sample calibration suprema without the exact
  population-`L2` ball restriction; its density argument is therefore not the
  rejected measurability step.
- Every lower dictionary is finite.  Its supremum is measurable, so its outer
  and ordinary expectations coincide and every previous finite-class
  calculation remains unchanged.

## Zero-budget boundary

At `s=0` or `t=0`, the nonnegative full-class outer complexity is forced to
zero at every positive radius.  Core domination therefore gives zero ordinary
core complexity.  Appendix B uses the direct base radius `r0=0` and retains
the positive `h_n` process floor.  No quotient is evaluated at radius zero.

## Verdict

The repair closes the nonmeasurable-full-supremum gap without strengthening
M1, shrinking the theorem field, or changing the estimator.  Independent
hostile replay found no unsupported equality or hidden concentration call.

