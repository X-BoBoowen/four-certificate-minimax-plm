# Four-review input intake

All four files were read completely before protocol freeze.  They are external
AI red-team evidence, not human reviews or controlling proof sources.

| ID | SHA-256 | Bytes | Intake result |
|---|---|---:|---|
| R1 | `30F4F91968F8D995EFA87750D1DA1CF038A555D3FD9BF2FFA2A6C81D96C36282` | 30637 | hash match; local wording/typo findings reproduced; its full-class measurability conclusion is superseded by the explicit counterexample in R2/R3 |
| R2 | `556C724116A9F833D1EA0CAEE76EE2D7B1F91E6E5DB15B15594E9454B0561978` | 28826 | hash match; full-class nonmeasurability counterexample reproduced; outer-expectation repair accepted as a candidate only after independent source audit |
| R3 | `7F872DE158D5F441C2DBFA3E5891B3FE4F1C8596E608AE74A39576D57770938B` | 17731 | hash match; independent nonmeasurability and two boundary-cap errata reproduced |
| R4 | `A6CE5633DBDB6A3E4FA37F0FC6497DF22BA9F74AD6FC0C11AD2DACB68C6B95A7` | 21701 | hash match; factor-three primitive-radius omission and Jin squared-radius positioning reproduced |

The controlling Candidate-C12 PDF independently matched
`1561D1261D6FEE85DC5C2A8856EE1060FC925CF5D7F8C88B6AE165DFA16FFD2B`.
The review-copy directory was used only as a locator; every accepted finding
was checked against the authoritative Candidate-C12 source tree.

No report vote, score, or prose was treated as proof.  No report supplies
novelty, priority, human-review, or submission-readiness credit.
