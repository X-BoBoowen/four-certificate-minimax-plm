# 读取范围与输入完整性

## 输入完整性

- 输入 ZIP：`PLM4B_C5_AUDITOR_S_BLIND_REGRESSION.zip`
- SHA-256：`56a4b2ff875e30172053b58a5f66a01afe0e9cfabd221f7229e4c3e87b010689`
- 候选 PDF SHA-256：`d8dd7eb9f01038d0aa863f78c3972950ad98b6b6225e4a69d3cf7f92e45e2259`
- 解包前检查了 ZIP 条目，未发现绝对路径、路径穿越或覆盖输入目标。
- `PACKAGE_MANIFEST.tsv` 中的文件长度/哈希与解包文件逐项相符。

## 已完整读取的输入文件

- 根目录：`README.md`、`AI_OR_HUMAN_REVIEW_NOTICE.md`、`PACKAGE_MANIFEST.tsv`、`CANDIDATE_SHA256.txt`。
- 候选稿：`manuscript/anonymous_manuscript.pdf`，34 页。
- 随附 primary PDFs：BKW 34 页；Calibrated DML 70 页；Gu COLT 5 页；TAME 31 页；Gu–Yin–Cai–Fan 23 页；Jin–Mackey–Syrgkanis 70 页；Jin–Syrgkanis 117 页；Robins et al. 18 页。
- 总计逐页读取：402 PDF 页。
- 全部 8 个空白 role forms 已读取并在返回目录完整填写。

## 视觉核验

候选稿 pp. 1–10, 23–30 及每个核心来源的定理页均渲染为图像检查，以避免纯文本提取丢失公式：BKW p. 12；Gu COLT p. 4；GYCF pp. 19–20；TAME pp. 15–16；JMS pp. 4–5；JS pp. 29–30；Robins pp. 4–5；并检查 Calibrated DML v2/v3 的页数和标题页。

## 隔离

没有读取输入 ZIP 以外的本项目文件。公开下载只限论文原始版本与稳定元数据；没有读取其他审稿、修改历史、内部审计或非公开材料。

