# Contribution and prior-work matrix

| Claim | Closest work | Exact common content | Exact residual difference | Classification | Significance consequence | Location |
|---|---|---|---|---|---|---|
| Interior four-budget pair-risk rate `q+AB+M+O+P` | Gu–Yin–Cai–Fan, Thm A.1; TAME Cor. 3.2 | 同一 bounded PLM 邻域；前者已有 `q+AB+M` 下界，后者已有相同二分支上界 | 本文在 fixed-infinite, constant-variance, sequential-M1, known-budget, expected-L1 pair-specific Q1 中补出 matching `O/P` necessity 与闭合 | **Strong overlap; residual contribution survives** | 不是全新率架构；真实增量集中在两个方向项及精确接口 | 稿件 pp. 3–6, 9, 22–30；GYCF pp. 19–20；TAME p. 15 |
| `O=t(a∧t)` 必要性 | 无同场域命中；最接近 TAME outcome-easier branch | TAME 上界含可产生 `O` 的方向余项 | 未找到 prior 在同信息/损失/量词下证明 `O` lower certificate | **Search-surviving novelty claim, not priority proof** | 本文最强原创分量之一 | 稿件 pp. 5, 24–25, 30；TAME p. 15 |
| `P=s(b∧s)` 必要性 | 无同场域命中；最接近 TAME mirror branch | TAME 上界含可产生 `P` 的镜像余项 | 未找到 prior 在同信息/损失/量词下证明 `P` lower certificate | **Search-surviving novelty claim, not priority proof** | 本文最强原创分量之一 | 稿件 pp. 5, 22–23, 30；TAME p. 15 |
| 两分支上界 `min{a(b+t)+(a+s)^2,b(a+s)+(b+t)^2}` | TAME Cor. 3.2, eq. (3.7) | 逐式相同 | 本文补 M1 可测实现、全部预算边界、安全回退、pairwise finite-sample lift | **Direct upper ancestor / technical closure** | 不能把上界架构作为新 generic editor | 稿件 pp. 3–5, 13–20；TAME p. 15 |
| `q+AB+M` lower ancestry | Gu–Yin–Cai–Fan Thm A.1 | 同样 expected-L1、2n、bounded PLM、constant variance 和四预算表达 | 本文改变 ambient/access 细节并与 `O/P` 共同组装 | **Direct predecessor / strong overlap** | `ab`、`M` 本身没有原创性权重 | 稿件 pp. 1, 6, 9, 26–30；GYCF pp. 19–20 |
| Fixed-pilot product lower framework | BKW Thms 1–2；Bonvini Prop. 1；Jin–Syrgkanis | 固定 nuisance 输入、L2 误差邻域、product remainder/lower bound | 本文输入为公共类与逼近/复杂度证书，不给 fixed pilot；estimand/风险也不同 | **Framework ancestry** | 支持技术谱系，不构成碰撞 | BKW pp. 12–15；Bonvini p. 6；稿件 p. 9 |
| Fuzzy/product mixture lower-bound technology | Robins et al. Thm 2.1 | 混合 Hellinger/χ² 型 testing reduction | 本文针对四种有界 PLM 通道构造 finite Walsh dictionaries | **Technical ancestry** | 证明技术不新；具体嵌入可能是新适配 | Robins PDF pp. 4–5；稿件 pp. 21–28 |
| E stratum `v_->B0^2` empty | 有界随机变量的二阶矩基本事实 | `E(u²\|X)≤B0²` | 无实质残差 | **Routine implication** | 不能承担主要创新性 | 稿件 pp. 3, 8, 30–31 |
| S stratum `v_-=B0²` root-n | 支持饱和与 moment identity | `\|u\|≤B0`, `E u²=B0²`, `E(u\|X)=0` 推出二点支持 | 本文放入三层定理并给显式常数 | **Routine/model-specific implication** | 正确但由共同 envelope 的特殊边界产生 | 稿件 pp. 3, 8, 30–31 |
| Sequential-M1 interface closure | TAME 的校准架构；一般可测近似思想 | 可数候选与校准/拟合目标 | 本文明确要求逐点处处 sequential density，证明全类与表示类 infima 转移及 Borel selector | **Nontrivial technical adaptation** | 有真实技术价值，但不扩展 estimand 或信息范围 | 稿件 pp. 2, 10–20, 31–32 |
| SA 决策最优性/可容许性背景 | Liu–Mukherjee–Robins Thms 0,3 | SA 邻域、DML/HOIF minimax 与 ECC | 不研究本文 β、四预算公共类或 `O/P` | **Contextual/partial overlap** | 应补引以完整定位；非 collision | Liu pp. 4, 14；稿件未引 |
| Hölder/ECC 与 hybrid-SA 邻域 | McClean et al. Thm 2；Bonvini et al. Props 1–2 | semiparametric minimax、SA 与 smoothness 边界 | 估计量、参数空间与信息条件不同 | **Contextual work** | 缺失削弱领域地图，不影响主定理 | McClean p. 17；Bonvini pp. 6, 8 |
