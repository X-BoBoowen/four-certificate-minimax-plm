# 交付索引

1. `FULL_RAW_REVIEW.md`：完整、未经摘要或删节的最终盲审原文。
2. `CONTRIBUTION_PRIOR_WORK_MATRIX.md`：贡献—prior art—残差增量矩阵。
3. `ICLR_SIGNIFICANCE_FORM.md`：ICLR 意义、录用/拒绝理由、评分与置信度。
4. `ISSUE_LEDGER.md`：模型、引用、贡献与范围问题台账。
5. `MODEL_QUANTIFIER_COMPARISON_FORM.md`：原生输入、可用/不可用信息和量词逐源比较。
6. `NOVELTY_COLLISION_SEARCH_LOG.md`：指定检索表。
7. `SOURCE_VERSION_THEOREM_FIELD_TABLE.md`：来源、版本、定理字段、损失与结论表。
8. `SOURCE_MODEL_SESSION_DECLARATION.md`：provider/model/version/session/联网/隔离声明。
9. `RETURN_CHECKLIST.md`：完成清单。
10. `MODEL_INFORMATION_QUANTIFIER_ANALYSIS.md`：独立模型与量词重建。
11. `CITATION_VERIFICATION_RECORD.md`：全部指定来源及实质候选的引用核验记录。
12. `PRIOR_WORK_CANDIDATE_MATRIX.md`：候选文献同模型/同信息/同损失排除矩阵。
13. `SEARCH_LOG_COMPLETE.md`：完整查询簇、平台、时间边界和 non-hit 声明。
14. `SURVIVING_CLAIMS.md`：经受检索与比较的主张。
15. `LIMITATIONS_AND_UNRESOLVED.md`：未确认事项、付费墙与数据库限制。
16. `ANALYTIC_VERIFICATION_LOG.md`：关键代数证明与完整数值反例搜索输出。
17. `READ_FILES_AND_INTEGRITY.md`：逐页读取与输入完整性。
18. `FILE_SHA256SUMS.txt`：主要输出文件哈希（打包前生成）。

最终 ZIP 的 SHA-256 由 ZIP 外部同目录 `.sha256` 文件记录，因为 ZIP 不可能在保持自身哈希不变的同时内嵌其最终哈希。
