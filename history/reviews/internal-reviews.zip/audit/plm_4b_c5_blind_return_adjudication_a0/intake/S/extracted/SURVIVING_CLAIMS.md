# 经受住检索与比较的主张清单

1. **Interior rate 的证明结构未被本次审计推翻。**在 exact pair-specific Q1 experiment 中，`q+AB+M+O+P` 与 upper/lower assembly 一致；置信度：中高。
2. **`O=t(a∧t)` necessity 经受住搜索。**在本次范围内没有同信息、同损失、同量词的 prior lower theorem；置信度：中等（non-hit 不是不存在证明）。
3. **`P=s(b∧s)` necessity 经受住搜索。**结论同上；置信度：中等。
4. **方向项改变 minimax 阶而非只改常数。**在 O-ray/P-ray 上既有 `AB+M` 可为 `r^3`，方向项为 `r^2`；置信度：高。
5. **TAME 是完整上界式的直接祖先。**本文不应把 minimum-of-two-branches 当原创；置信度：极高。
6. **GYCF 是 `q+AB+M` 的直接 lower predecessor。**其损失实际为 expected L1，条件方差实际为常数；置信度：极高。
7. **sequential-M1 closure 是非平凡技术适配。**它提供 Borel 实现和 full-to-represented infimum transfer；置信度：中高。
8. **五分量组装在声明的量词下合法。**论文取 outer maximum 后作确定性 max-to-sum，没有声称同一 Γ simultaneous hardness；置信度：高。
9. **E/S boundary 在共同 envelope 下正确。**它是特殊模型支持饱和事实，不是一般 PLM phase transition；置信度：高。
10. **未发现完整 direct collision。**仅限本次 arXiv/PMLR/PMC/公开网页检索；置信度：中等，不是优先权判断。

