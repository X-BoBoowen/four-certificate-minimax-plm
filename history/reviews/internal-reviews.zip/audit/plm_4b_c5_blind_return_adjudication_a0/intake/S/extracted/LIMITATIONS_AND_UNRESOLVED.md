# 未确认事项、付费墙与检索限制

## 未确认事项

- 没有对 34 页稿件的每一个常数和每一条概率尾界进行形式化 proof-assistant 验证；复杂 fuzzy-mixture 附录做了全文、关键页面、支持/矩/距离/量词和核心代数检查。
- Gu COLT 2025 公开 PDF 将 risk 写为 expected squared error 而显示 root-n/product 尺度。审计只记录“按原文打印”，没有证据确认作者意图或勘误。
- 没有证明 `O/P` prior 不存在；只报告本次公开检索 non-hit。
- 没有验证匿名作者身份，也没有尝试反匿名。
- 没有判断源代码可运行性；候选附件只包含 PDF 和表格，论文自己声明 Figure 1 脚本不在本 handoff 内。

## 付费墙

README 指定的核心来源均有随附或公开全文；实质 theorem 判断没有依赖付费墙后的摘要。Robinson (1988) 等标准背景只核对稳定 DOI/书目和其被使用的常识性定位，没有把不可公开全文中的未核对定理用于 novelty 判断。

## 数据库限制

实际使用 arXiv、PMLR、PMC、DOI 和一般公开网页检索。未使用或无法声称穷尽 Scopus、Web of Science、MathSciNet、zbMATH、ProQuest、闭源引文图谱或未公开会议投稿系统。索引延迟、版本撤回、later work、并发工作与术语错配仍是残余风险。

## 会话与材料限制

本会话没有项目历史、旧评分、内部审计、其他评审、参考答案或修改记录。没有读取任何已填写外部表格。所有判断仅来自输入 ZIP 和公开 primary sources。

