# Novelty and collision search log

检索截止：2026-08-26 19:28:49 +08:00。平台：arXiv、PMLR、PMC、DOI 稳定页、一般公开网页检索。所有“non-hit”仅描述本次范围，不产生优先权证明。

| Query or source | Version | Claim compared | Classification | Evidence | Location |
|---|---|---|---|---|---|
| `"four-budget" minimax "partially linear"`；`"public budgets" PLM minimax` | 2026-08-26 search | 完整四预算定理 | Search non-hit | 未找到同场域 theorem；命中集中于 Gu/GYCF/TAME 链或不相关预算优化 | 一般网页/arXiv 检索 |
| `"a+s^2" "b+t^2" partial linear model minimax` | 2026-08-26 search | `AB` 与四预算表达 | Strong overlap hit | 命中 GYCF/TAME 相邻结果；无额外 direct collision | arXiv:2606.06368, 2607.21541 |
| `"(s\\wedge t)^2" minimax`；`"TAME-2" lower bound` | 2026-08-26 search | `M` 及 TAME matching lower | Search non-hit beyond known sources | GYCF 给 `M`；未找到 TAME `O/P` lower | arXiv/PMLR/web |
| `"t(a∧t)"`、`"s(b∧s)"` 及 ASCII/LaTeX 变体 | 2026-08-26 search | `O/P` 精确公式 | Search non-hit | 未找到包含同式且同 PLM theorem field 的公开工作 | arXiv/web |
| `pair-specific minimax public class partially linear` | 2026-08-26 search | `supΓ infδΓ supP` 风险 | Search non-hit | 未找到同一量词与四预算；fixed-pilot SA 结果量词不同 | arXiv/web |
| `sequentially dense M1 structure-agnostic`；`countable measurable representation nuisance class` | 2026-08-26 search | sequential-M1 closure | Search non-hit | 无同名 M1 接口定理；命中一般 separability/measurability 内容不构成 collision | web/arXiv |
| BKW, *Fundamental Limits...* | arXiv:2305.04116 v2, 2025-06-07 | product lower/first-order upper | Technical/framework ancestry | fixed pilots 与 L2 balls；ECC/ATE 等；无四预算类复杂度 | Thms 1–2, pp. 12–15 |
| Robins et al., *Semiparametric Minimax Rates* | EJS 2009, DOI 10.1214/09-EJS479 | fuzzy mixture 与 classical minimax | Technical ancestry | 同下界工具，不同 Hölder 参数空间与 estimand | Thms 2.1,4.1 |
| Gu, COLT open problem | PMLR 291, 2025 | PLM SA open problem | Direct problem predecessor | 同 PLM；方差/损失/信息不同；没有解四预算 exact rate | Thm 1, p. 4 |
| Gu–Yin–Cai–Fan | arXiv:2606.06368 v1, 2026-06-04 | `q+AB+M` | Strong overlap/direct predecessor | expected-L1 lower 直接包含三项；无 `O/P` | Thm A.1, pp. 19–20 |
| TAME | arXiv:2607.21541 v1, 2026-07-23 | two-branch upper | Direct upper ancestor | Cor. 3.2/eq. (3.7) 逐式相同；没有 matching four-budget lower | p. 15 |
| Calibrated DML | arXiv:2411.02771 v3, 2026-08-20 | directional calibration | Conceptual neighbor | 渐近 linearity/partial orthogonality；无本文 minimax risk | v3 main theorems/application section |
| Jin–Mackey–Syrgkanis | arXiv:2507.02275 v3, 2025-11-07 | PLM/ECC fixed-pilot lower | Strong partial overlap | noise-sensitive anchored/fixed-pilot risks；无 public four budgets | Thms 3.1–3.2, pp. 4–5 |
| Jin–Syrgkanis | arXiv:2512.17341 v2, 2026-01-05 | general functional lower | Strong partial overlap | anchored estimates/quantile risk；PLM section object not same β experiment | pp. 29–30 |
| Bonvini et al. | arXiv:2405.08525 v2, 2024-12-12 | pure/hybrid SA minimax | Partial/contextual overlap | ATE fixed pilots；Prop. 1 product lower，Prop. 2 hybrid squares | pp. 6, 8 |
| McClean et al. | arXiv:2403.15175 v3, 2025-05-07 | ECC DCDR minimax | Contextual | Hölder smoothness与 density structure；无 black-box four budgets | Thm 2, p. 17 |
| Jin–Syrgkanis ATE/ATT | arXiv:2402.14264 v4, 2025-06-08 | treatment-effect SA optimality | Partial overlap | fixed nuisance estimates；ATE/ATT，不是 PLM β | main theorems |
| Liu–Mukherjee–Robins | arXiv:2606.22391 v1, 2026-06-21 | SA DML minimax/inadmissibility | Contextual/partial overlap | Thm 0 一般 inadmissibility；Thm 3 ECC；无四预算 β | pp. 4, 14 |

