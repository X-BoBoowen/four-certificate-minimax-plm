# 模型、信息结构与关键量词分析

## 1. 统计模型与 estimand

观测为 `Z=(X,T,Y)`，两个独立半样本 `D1,D2` 各含 `n` 个 i.i.d. 观测。模型是

`T=π0(X)+u`, `Y=β0 T+μ0(X)+ε`,

满足 `E(u|X)=0`、`E(ε|X,T)=0`、`E(u²|X)=v`（常数）。目标 `β(P)=β0` 是统计 PLM 投影系数。论文没有给潜在结果、无混杂、consistency 或 overlap 假设，因此不能把主定理读成因果效应定理。定位：稿件 pp. 2, 10–11。

支持与 envelope 同时约束 `T,Y,u,ε,μ0,π0,β0`。这一共同上界是 E/I/S 分层的决定性组成，而不仅是技术矩条件。

## 2. 参数空间

在 `n`、预算和公共类对之前固定一个非空、无限 standard Borel measurable space `(X,A)`。每个公共类对 `Γ=(Gμ,Gπ)` 含：

1. 两个完整 nuisance 类；
2. 各自有序、可数、逐点有界的可测表示；
3. measurable evaluation maps；
4. 对每个完整类元素存在表示序列逐点处处收敛；
5. 公共 envelope `BG`；
6. 四个公开预算证书 `(a,s,b,t)∈[0,1]^4`。

`a,b` 限制 law-specific truth 到相应完整公共类的 L2 逼近误差；`s,t` 是公共类的 localized Rademacher 上界证书。sequential-M1 不等于 smoothness、convexity、realizability 或 computational tractability。定位：稿件 pp. 2, 10–14, 31。

## 3. 学习者可用与不可用信息

可用：固定 ambient space、完整 Γ 及其可数编码、四预算、`n`、`B0,BG,v_-,v_+,crad` 等固定结构常数、两半样本。

不可用：`μ0,π0`、最佳逼近器、law-specific realized approximation errors、实际 localized complexity、lower-mixture sign/index/label、测试中的隐藏 dictionary element，以及任何匿名作者或投稿历史。

因此这不是 oracle truth estimator；但它是 **known-budget, pair-aware** estimator。预算和公共类信息的公开性比实际未知难度的学习任务更强。

## 4. 风险与量词

核心风险为

`Rpair(n,a,s,b,t)=sup_{Γ∈Gρ,n(a,s,b,t)} inf_{δΓ Borel} sup_{P∈P(Γ)} E_P|δΓ(D1,D2)-β(P)|`。

关键后果：

- `inf` 位于 `supΓ` 之内；每个 Γ 可选择不同 Borel rule。
- δ 可依赖 Γ、预算与 n，无 common/adaptive rule 要求。
- Γ 可随 n 和预算格点变化。
- 下界只需分别构造一个使 `q`、`ab`、`M`、`O`、`P` 困难的 Γ；最外层 `supΓ` 取得最大，再用确定性不等式把 maximum 换成 sum。
- 该组装证明的是 outer pair-risk matching rate，不是一个固定 Γ 内五种机制 simultaneous hardness。

这套量词数学上自洽，稿件也明示；但不能换成 `inf_δ sup_{Γ,P}`，也不能推断未知预算适应性。定位：稿件 pp. 3, 6, 10–12, 30–32。

## 5. 预算、率与量词覆盖

定义

`q=n^-1/2`, `A=a+s²`, `B=b+t²`, `M=(s∧t)²`, `O=t(a∧t)`, `P=s(b∧s)`，

主率是 `q+AB+M+O+P`。Theorem 1 的 interior 陈述覆盖全部 `n≥1` 和全部 `[0,1]^4` 预算，包括零预算；但常数是对固定 `ρ=(B0,BG,v_-,v_+,crad)` pointwise 的，可在结构边界处退化。

## 6. E/I/S 信息结构

- E：`v_->B0²`。由 `u²≤B0²` 可知无 compatible law。是空模型事实。
- I：`0<v_-<B0²`。支持内部有扰动余量，四种 nuisance lower constructions 可嵌入。
- S：`v_-=B0²`。共同 envelope 与方差饱和强制 `u=±B0` 条件等概率并进一步强制 `π0=0`，故 `β=E(TY)/B0²`，只剩 root-n。

这不是一般异方差 PLM 的 phase transition；它依赖同一个 `B0` 同时界定 residual、treatment 和方差端点。

## 7. 与最接近来源的精确量词差异

- GYCF A.1：同为 outer family、known budgets、2n、expected-L1、constant variance，故最接近；但 X 固定为 uniform cube，类族证书与 sequential-M1 不同，且 lower 只到 `q+AB+M`。
- TAME：同一二分支 estimator remainder，但目标是渐近高概率推断条件，不是上述 outer minimax 风险。
- BKW/Jin–Syrgkanis/JMS：输入是被视为固定的 pilot nuisance estimates/radii，而不是本文的公共候选类及 approximation/stochastic 分解。
- Robins 2009/McClean：参数空间由 Hölder smoothness、维数与 density regularity 给出，信息强于结构不可知预算，但不是同一 neighborhood。

## 8. 审计结论

没有发现把 `sup` 与 `inf` 交换、把 law-dependent optimizer 暗中交给 estimator、或把不同下界直接相加的错误。主要限制来自定义本身：pair-specific、known-budget、component-wise witness、fixed-infinite space 与 constant variance。

