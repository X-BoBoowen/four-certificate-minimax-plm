# Model and quantifier comparison form

| Claim | Native input | Available information | Unavailable information | Quantifier order | Comparator source | Finding | Location |
|---|---|---|---|---|---|---|---|
| 本文 interior minimax law | 公共类对 Γ、sequential-M1 表示、已知 `(a,s,b,t)`、两个 n 样本半组 | Γ、预算、n、结构常数 | nuisance truths、best approximants、realized errors、mixture labels、计算 oracle | `supΓ infδΓ supP E\|δΓ-β(P)\|` | 全部 | 定理仅是 pair-specific；不能解释为一个共同/adaptive rule | 稿件 pp. 2–3, 10–12 |
| TAME-derived upper | 公共候选类/learner 与一侧校准任务；渐近 consistent regime | 训练/评估样本、选择的校准方向 | 本文 lower labels；不提供 Q1 minimax outer experiment | 先构造 estimator，再在满足条件的 law sequences 上高概率/渐近界 | TAME Cor. 3.2 | 余项逐式相同；本文残差是 finite-sample M1/boundary closure | TAME p. 15；稿件 pp. 3–5, 13–20 |
| GYCF Appendix A.1 lower | `X~Unif[0,1]^d`、函数族、四预算 | 类族与预算；constant variance | 本文一般 fixed infinite Borel ambient/sequential representation | outer sup over legal function families，内部 minimax expected-L1 | GYCF Thm A.1 | 直接覆盖 `q+AB+M`，未覆盖 matching `O/P` | GYCF pp. 19–20 |
| BKW structure-agnostic risk | 外部样本生成后被固定的 nuisance pilots 与 L2 radii | pilots、deterministic error radii | 公共候选类的 approximation/stochastic 分解 | 条件于固定 pilots 的 `inf estimator sup law` | BKW Thms 1–2 | 技术框架祖先，信息结构不同 | BKW pp. 12–15 |
| Gu COLT open problem | `X~Unif[0,1]^d`、PLM 函数类与误差率 | rate conditions | sequential-M1、pair-specific rule、常数条件方差 | source 自定义 minimax MSE | Gu Thm 1 | 同 estimand 邻近，但 loss 和假设不等价 | Gu p. 4 |
| Jin–Mackey–Syrgkanis PLM/ECC | 固定或 anchored pilots；binary/Gaussian noise 实验 | pilots/radii/noise structure | 四个公共类预算、M1 接口 | fixed-pilot minimax/quantile 型 | JMS Thms 3.1–3.2 | 强邻近；无 `O/P` 四预算结论 | JMS pp. 4–5 |
| Jin–Syrgkanis general lower | 固定 nuisance estimates 与 anchored neighborhoods | pilots、radii | 本文公共类和已知 approximation/stochastic split | quantile-risk lower over anchored neighborhoods | JS general theorems/PLM section | PLM 显示对象为 binary-treatment ECC numerator，不是同一 β 风险 | JS pp. 29–30 |
| Calibrated DML | 数据驱动 nuisance estimates 与 isotonic calibration | folds、learners、calibration operators | 本文四预算 pair-specific minimax oracle | 渐近线性/regularity over law sequences/submodels | CalDML v3 | directional conceptual neighbor，无四预算有限样本 lower | CalDML v3 pp. 15–40 |
| Liu–Mukherjee–Robins | 固定 SA pilots/rates；一阶与二阶 estimator | pilots 与 SA radii | 四预算公共类、PLM β | 渐近 scaled-MSE admissibility/minimax | Liu Thms 0,3 | 相关决策背景，不是 collision | Liu pp. 4, 14 |
| Robins et al. 2009 | Hölder nuisance classes与 density assumptions | smoothness、维数、模型结构 | public black-box budgets | `inf estimator sup law` 的经典 smoothness minimax | Robins Thms 2.1,4.1 | testing ancestry；参数空间和信息更结构化 | Robins PDF pp. 4–5, 10–11 |
