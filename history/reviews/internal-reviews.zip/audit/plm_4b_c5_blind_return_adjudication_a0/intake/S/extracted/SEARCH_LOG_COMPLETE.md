# 完整 prior-work 检索日志

## 检索原则

先按 theorem tuple 比较，而不是按关键词相似度：estimand、观测模型、可用输入、未知信息、假设、风险量词、损失、参数范围、版本日期和结论必须逐项一致才可判 direct collision。

## 实际平台与时间边界

- 截止：2026-08-26，Asia/Shanghai。
- 平台：arXiv、PMLR、PMC、DOI 稳定页、一般公开网页检索。
- 未覆盖：Scopus、Web of Science、MathSciNet、zbMATH 付费完整接口；未验证穷尽 Google Scholar；未公开、未索引或 later work。

## 查询簇与结果

1. 精确题名/公式：`"Four-Budget Minimax Rates"`、`"four-budget" partially linear minimax`、`"a+s^2" "b+t^2" PLM`、`"t(a∧t)"`、`"s(b∧s)"`、相应 ASCII 与 LaTeX 变体。
   - 结果：命中稿件所列 Gu/GYCF/TAME 链或无关页面；没有额外同场域 theorem。

2. 模型同义词：`partial linear model structure-agnostic minimax`、`semiparametric regression black-box nuisance lower bound`、`expected conditional covariance fixed pilot minimax`、`orthogonal learning nuisance approximation stochastic error minimax`。
   - 结果：BKW、Gu COLT、GYCF、JMS、JS、Bonvini、McClean、Liu 等；均进入 candidate matrix。

3. 方向性机制：`directional nuisance calibration minimax lower bound`、`TAME-2 lower bound`、`one-sided calibration partially linear minimax`、`approximation error against stochastic complexity lower bound`。
   - 结果：TAME/Calibrated DML 的上界与推断工作；未见 matching `O/P` lower。

4. 信息/量词：`pair-specific minimax public class`、`known budget adaptive nuisance minimax`、`sup class inf estimator partially linear`、`fixed covariate space sequential representation minimax`。
   - 结果：fixed-pilot SA 与一般 minimax 文献；无同一 `supΓ infδΓ supP` 四预算结果。

5. 可测接口：`sequentially dense nuisance class measurable selector`、`countable measurable representation local Rademacher calibration`、`M1 structure-agnostic`。
   - 结果：一般 separability/measurability 内容与稿件自身；无直接前作命中。

6. 前向/后向引用链：从 BKW、Gu COLT、GYCF、TAME、JMS、JS 的 references/related work 向 Bonvini、McClean、Jin–Syrgkanis ATE/ATT、Liu–Mukherjee–Robins 扩展。
   - 结果：发现若干必须定位的 contextual/partial overlaps，但没有 theorem tuple 全同者。

## Non-hit 声明

在上述平台、查询和截止时间范围内未发现完整 direct collision。这个陈述不意味着证明不存在，也不授予优先权；并发工作、later work、未公开稿件、付费索引未覆盖条目和使用完全不同术语的工作仍可能存在。

