# Source, model, and session declaration

**Reviewer type (AI or human):** AI

**Provider:** OpenAI

**Model:** Codex（基于 GPT-5）

**Version or build:** 平台未提供

**Session or instance identifier:** 平台未提供

**Fresh session status:** 是；本次是全新、相互隔离的审稿会话。

**Prior manuscript or project exposure:** 否；本会话此前没有接触本项目的实质性历史信息。

**Date:** 2026-08-26 19:28:49

**Timezone:** Asia/Shanghai（UTC+08:00）

**Network capability:** 可访问公开互联网与无需账户授权的公开学术全文/元数据；不能声称穷尽付费或封闭数据库。

**Tools used:** 安全 ZIP 清单与哈希核验；PDF 文本逐页提取与页面渲染；公开网页/arXiv/PMLR/PMC/DOI 检索；本地代数数值复核；Markdown 表格与 ZIP 完整性验证。

**Actual search platforms:** arXiv、PMLR、PubMed Central/PMC、DOI 稳定解析页、一般公开网页检索。未使用 Scopus、Web of Science、MathSciNet、zbMATH 付费完整接口；未把搜索摘要作为关键定理证据。

**Files read:** 根目录 `README.md`、`AI_OR_HUMAN_REVIEW_NOTICE.md`、`PACKAGE_MANIFEST.tsv`、`CANDIDATE_SHA256.txt`；候选稿 `manuscript/anonymous_manuscript.pdf`（34 页）；全部 8 个 `sources/*.pdf`（BKW、Robins 2009、Gu COLT 2025、Gu–Yin–Cai–Fan、TAME、Calibrated DML、Jin–Mackey–Syrgkanis、Jin–Syrgkanis）；全部 8 个根任务表格；以及公开 primary PDFs：Calibrated DML v3、Bonvini et al. v2、McClean et al. v3、Jin–Syrgkanis ATE v4、Liu–Mukherjee–Robins v1。公开页面仅用于版本史、稳定链接及扩展检索。

**Context-isolation statement:** 没有读取内部报告、参考答案、其他专家意见、已填写表格、旧评分、修改历史或非公开投稿材料；没有尝试识别匿名作者；没有向用户询问或推测预期结论；没有修改或覆盖任何输入文件。

**Human identity or credential claimed:** 无。未虚构姓名、机构、资格、签名或真人评审身份。

**Full unedited raw output included:** 是，见 `FULL_RAW_REVIEW.md`。

**Input ZIP SHA-256:** `56a4b2ff875e30172053b58a5f66a01afe0e9cfabd221f7229e4c3e87b010689`

**Candidate PDF SHA-256:** `d8dd7eb9f01038d0aa863f78c3972950ad98b6b6225e4a69d3cf7f92e45e2259`

**Output ZIP SHA-256:** 见 ZIP 外部同目录的 `PLM4B_C5_AUDITOR_S_BLIND_REGRESSION_RETURN_20260826.zip.sha256` 及最终交付消息。ZIP 无法在不改变自身哈希的情况下内嵌其最终 SHA-256。

