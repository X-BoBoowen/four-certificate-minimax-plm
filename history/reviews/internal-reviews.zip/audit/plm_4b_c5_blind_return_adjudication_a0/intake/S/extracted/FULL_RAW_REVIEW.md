# 完整、未经摘要或删节的盲审原文

## 一、最终判断

**建议：Weak Reject（5/10，边缘低于录用线）；置信度：4/5。**

我没有发现足以推翻主定理的模型错误、量词偷换或明显计算错误。论文对自己的狭窄信息结构也相当坦率。在本次可复核的公开检索范围内，我没有找到与本文同时满足“同一有界 PLM 系数、同一四个公开预算、同一 sequential-M1 接口、同一固定条件方差、同一 pair-specific 外层极大风险、同一 expected-L1 损失并给出同一全参数范围匹配率”的 prior work；因此我不认定存在 direct collision。这个结论只表示本次检索没有命中，不能证明不存在未被索引、未公开或我未覆盖的工作。

但是，ICLR 层面的主要障碍不是目前可见的正确性，而是**真实增量相对于定理场域的宽度与领域影响不足**。主上界的两分支余项在 TAME Corollary 3.2、式 (3.7) 已经逐式出现；Gu–Yin–Cai–Fan Appendix A.1 已经给出同一 PLM 邻域中 `q+AB+M` 型下界。本文真正经受住逐项比较的核心，是在其特制实验中证明两个方向性交叉项

`O=t(a∧t)` 与 `P=s(b∧s)`

也分别必要，并把 TAME 型构造闭合到可测的 sequential-M1、所有预算边界和 pair-specific 量词中。这个增量是真实的，也不是简单改符号；但它依赖固定无限协变量空间、条件方差常数、已知四预算、允许每个公共类对使用不同决策规则、允许不同下界项由不同公共类对见证、且类对可随 `n` 和预算格点变化。论文不提供共同规则、自适应、计算、置信区间、异方差、有限空间或因果结论。在这一实际范围下，我认为结果更接近一项严谨而窄的 minimax completion，而不是足以支撑 ICLR 录用的广泛理论机器学习贡献。

## 二、论文与结论重建

论文研究统计性的 partially linear model

`T=π₀(X)+u`,  `Y=β₀T+μ₀(X)+ε`,

其中 `E(u|X)=0`、`E(ε|X,T)=0`、`E(u²|X)=v` 为常数，并且 `X,T,Y,u,ε,μ₀,π₀,β₀` 受共同常数控制。目标是标量 PLM 系数 `β₀`，不是潜在结果参数；论文第 2 页明确否认因果识别结论。

样本是两个相互独立、各含 `n` 个观测的半样本，总观测量为 `2n`（第 2、10–12 页）。在 `n`、预算和公共类对之前，先固定一个非空、无限、standard Borel 协变量空间。公共实例 `Γ=(Gμ,Gπ)` 包含完整函数类、逐点有界的有序可数可测表示、可测 evaluation maps，以及对完整类中每个元素逐点处处收敛的表示序列。学习者知道 `Γ` 与四个公开证书 `(a,s,b,t)`，但不知道真 nuisance、最佳逼近器、真实误差、下界混合标签或实现的候选索引。

`a,b` 是 outcome/propensity 的逼近预算，`s,t` 是相应局部随机复杂度预算。记

- `q=n^{-1/2}`；
- `A=a+s²`, `B=b+t²`；
- `M=(s∧t)²`；
- `O=t(a∧t)`；
- `P=s(b∧s)`；
- `Xrate=AB+M+O+P`。

pair-specific 风险的量词是

`sup_Γ inf_{δ_Γ measurable} sup_{P∈P(Γ)} E_P|δ_Γ(D₁,D₂)-β(P)|`。

因此规则可以依赖整个公开类对、预算、`n` 和固定结构常数；不同 `Γ` 可以有不同规则。下界只需为每个分量展示一个合法 `Γ`，再由最外层 `sup_Γ` 和确定性的 max-to-sum 不等式合并；不要求一个共同的公共类对同时实现五种困难。论文摘要、第 3、6、10、30–32 页均明确承认这一点。

主定理（第 3 页，Theorem 1）分三层：若 `v_->B₀²`，由有界性知模型为空；若 `0<v_-<B₀²`，则对全部 `n≥1` 和全部四预算有

`c_ρ(q+Xrate) ≤ R_pair ≤ C_ρ(q+Xrate)`；

若 `v_-=B₀²`，支持饱和使 `π₀=0`，风险回到参数阶，论文给出 `3/(128√n)` 与 `1/√(2n)` 的显式夹界。

## 三、三重专家视角

### 视角 A：理论正确性与可测性

我重点复核了主定理的量词、上界依赖、下界组装、边界层和附录中的关键通道，而不只是正文叙述。

上界使用两个 TAME-derived 分支。设 `x=a+s`、`y=b+t`，论文第 3–5 页定义

`Tμ=a y+x²`, `Tπ=b x+y²`, `W=min(Tμ,Tπ)`，

由公开预算决定方向，并在不安全格点使用有界回退。这个选择没有使用真 nuisance 或实现误差。附录 B 将全类问题转到可数表示类，使用 first-within-tolerance 选择，因而保持 Borel 可测；Lemma 6（第 14 页）用共同 envelope 和逐点处处逼近，通过 dominated convergence 与有限样本连续性证明 population/empirical infima 的转移。这个闭合逻辑是合理的：表示序列属于完整类，复杂度上界不会因为表示化而扩大，且没有假设存在不可测的全类 argmin。

我独立检查了核心代数。令 `S₀=ab+M+O+P`。因为

`AB=ab+a t²+b s²+s²t²`，

并且 `a t²≤t(a∧t)=O`、`b s²≤s(b∧s)=P`、`s²t²≤(s∧t)²=M`（四预算均在 `[0,1]`），所以 `S₀≤Xrate≤2S₀`。我还对固定种子下 2,000,000 个随机点和 `51^4` 个规则网格点复算；没有发现 `S₀≤Xrate≤2S₀` 或论文使用的 `W≤24Xrate` 的违反。随机样本中最大 `Xrate/S₀≈1.99927`，规则网格最大值为数值精度下的 2；随机样本最大 `W/Xrate≈2.36057`，远低于证明使用的常数 24。这不能替代证明，但支持正文第 30 页 Appendix G 的代数。

下界方面，论文没有把五个分别成立的下界非法相加。第 5–6 页先公开说明各分量可由不同合法类对见证，第 30 页式 (G.1)–(G.3) 先取最大，再用五项 max-to-sum 和 `S₀`/`Xrate` 等价组装。`P` 证书在第 5、22–23 页，`O` 证书在第 5、24–25 页，`ab` 在第 26 页，`M` 在第 27–28 页，参数项和组装在第 29–30 页。有限 Walsh 字典嵌入预先固定的无限 standard Borel 空间，而不是随样本改变 ambient space。就我检查的支持、矩约束、类成员关系、混合距离和量词而言，没有发现明显缺口。

边界层也是正确但较初等的。由 `|u|≤B₀` 与 `E(u²|X)=B₀²` 得 `|u|=B₀` 条件几乎处处成立，再由 `E(u|X)=0` 得条件正负各半。又因 `|T|≤B₀` 且 `T=π₀(X)+u`，两端同时落入支持迫使 `π₀(X)=0`。于是 `β₀=E(TY)/B₀²`，可直接 root-`n` 估计（第 8、30–31 页，Appendix H）。`v_->B₀²` 为空同样是 envelope 与二阶矩的直接后果。它们是模型选择产生的真相，不是模型错误，但本身不能承担很高的新颖性权重。

正确性结论：**未发现致命或主要技术错误；中高置信度。**仍未做逐行形式证明检查，最复杂的 fuzzy-mixture 常数和附录 B 的所有尾界只做了结构与关键等式复核，因此不是“证明已机器验证”。

### 视角 B：原创性、直接碰撞与引用

1. **Balakrishnan–Kennedy–Wasserman。**公开版本为 [arXiv:2305.04116 v2（2025-06-07）](https://arxiv.org/abs/2305.04116)。Theorems 1–2（PDF 第 12–15 页）处理外部训练样本上固定的 nuisance pilots，以确定性 `L²` 邻域给出结构不可知的 product lower bound 和一阶上界。模型主要是 ECC/ATE 等泛函，输入是固定 pilots，不是本文的两个公开候选类、四个逼近/复杂度预算或 pair-specific selector。分类：**technical/framework ancestry；不是 collision**。

2. **Robins–Tchetgen Tchetgen–Li–van der Vaart (2009)。**原文 [EJS 3:1305–1321, DOI 10.1214/09-EJS479；PMC 全文](https://pmc.ncbi.nlm.nih.gov/articles/PMC5884174/)。Theorem 2.1（文章 1307–1308，PDF 第 4–5 页）是混合 Hellinger-affinity 下界工具；Theorem 4.1（文章 1313–1314，PDF 第 10–11 页）是 Hölder 模型的 semiparametric minimax 结果。它提供 fuzzy/product testing 技术祖先，但结构类、信息和 estimand 均不同。分类：**technical ancestry**。

3. **Gu COLT 2025 open problem。**[PMLR 291:6220–6224](https://proceedings.mlr.press/v291/gu25b.html)，Theorem 1（PDF 第 4 页）对 `X∼Unif[0,1]^d` 的 PLM 给出开问题式上下界；条件方差只要求下界，不是本文的常数方差，且公开 PDF 把风险写成 expected squared error，却把结论写为 root-`n` 加 product 尺度。本文没有把该打印陈述当作同损失的已解定理。分类：**source statement/open-problem predecessor；强相关但不碰撞**。这个 loss/rate 尺度异常应在引用时持续明确标注，不能默默改成 L1。

4. **Gu–Yin–Cai–Fan。**[arXiv:2606.06368 v1（2026-06-04）](https://arxiv.org/abs/2606.06368)，Appendix Theorem A.1（PDF 第 19–20 页）是最接近的直接前作。它在 `X∼Unif[0,1]^d`、有界 PLM、常数条件方差下，以 expected absolute loss 和 `2n` 样本得到上界 `q+min{A,(a+s)(b+t)}` 及外层类族下界 `q+AB+M`。其逼近证书是 class-level uniform 形式，未给本文的 sequential-M1 接口，也没有 `O/P` 匹配必要性。分类：对 `q+AB+M` 是 **direct predecessor/strong overlap**；对本文完整定理不是 collision。稿件 Table 5（第 9 页）把该源写成 “squared loss” 和 “variance lower bound”，两项都与原文 (A.1)–(A.2) 不符：原文风险是 `E|θ̂-θ(P)|`，并写明 `E[u²|X]≡v≥1/3`。这会把最接近前作错误地描述得比实际更远，必须修正。

5. **TAME。**[arXiv:2607.21541 v1（2026-07-23）](https://arxiv.org/abs/2607.21541)，Corollary 3.2 与式 (3.7)（PDF 第 15 页）给出的二分支余项逐式为

`min{a(b+t)+(a+s)², b(a+s)+(b+t)²}`，

与本文 `W=min(Tμ,Tπ)` 完全相同。TAME 是渐近、高概率、consistent-regime 的推断结果，只要求无条件 treatment residual 二阶矩下界，且它没有本文四预算 Q1 风险下的 `O/P` 下界。分类：对上界架构是 **routine implication/direct upper ancestor**；对 matching minimax law 是 **strong overlap but not collision**。

6. **Calibrated DML。**当前公开记录为 [arXiv:2411.02771 v3（2026-08-20）](https://arxiv.org/abs/2411.02771)。它研究 isotonic calibration、partial orthogonality、方向性稳健和渐近线性，不给本文的四预算有限样本 minimax 定理。分类：**conceptual/technical neighbor**。这里发现一项可复核的版本错误：附件 `calibrated_dml_primary.pdf` 的 SHA-256 为 `b9ae...a67`，与公开 v2 完全相同（70 页）；公开 v3 为 109 页、SHA-256 `ee36...b24`。稿件参考文献却把随附源标为 2026-08-20 v3。该错误不改变上述非碰撞结论，但必须修正文献版本和定理页码。

7. **Jin–Mackey–Syrgkanis。**[arXiv:2507.02275 v3（2025-11-07）](https://arxiv.org/abs/2507.02275)，Theorems 3.1–3.2（PDF 第 4–5 页）在固定/anchored nuisance pilots 和特定 binary/Gaussian treatment-noise 实验下给出 PLM/ECC 邻近下界。它没有公开候选类的逼近与 stochastic budgets，也不是本文的 expected-L1 pair-specific 风险。分类：**strong adjacent fixed-pilot work；不是 collision**。

8. **Jin–Syrgkanis。**[arXiv:2512.17341 v2（2026-01-05）](https://arxiv.org/abs/2512.17341)，一般线性泛函的 anchored lower bounds 及 PLM/ECC 专节（PDF 第 29–30 页）仍以固定 pilots 和 quantile-risk 邻域为核心。PLM 部分的显示对象是 binary-treatment ECC numerator，不是本文带公开四预算的 `β₀`。分类：**technical/strong partial overlap；不是 collision**。

独立向外检索还检查了：Bonvini–Kennedy–Dukes–Balakrishnan [arXiv:2405.08525 v2](https://arxiv.org/abs/2405.08525) Proposition 1（PDF 第 6 页）的 ATE pure-SA product lower bound；McClean et al. [arXiv:2403.15175 v3](https://arxiv.org/abs/2403.15175) Theorem 2（PDF 第 17 页）的 Hölder/ECC DCDR minimax 结果；Jin–Syrgkanis [arXiv:2402.14264 v4](https://arxiv.org/abs/2402.14264) 的 ATE/ATT fixed-pilot 结果；以及 Liu–Mukherjee–Robins [arXiv:2606.22391 v1（2026-06-21）](https://arxiv.org/abs/2606.22391) Theorem 0（PDF 第 4 页）和 ECC Theorem 3（PDF 第 14 页）的 SA inadmissibility/minimax 分析。它们分别是 ATE、Hölder ECC、固定 pilot 或一般 SA 决策比较，均未产生同场域的 `O/P` collision。

Liu–Mukherjee–Robins 在 TAME 与本文引用的 2026-08-20 文献之前已公开，且直接讨论 SA 模型下 DML 与 higher-order estimator 的 minimax/inadmissibility。稿件不引用它，属于**引用不完整**，尽管不是定理碰撞。Bonvini et al. 与 McClean et al. 也适合作为结构不可知与传统光滑度 minimax 之间的定位材料；缺失它们主要削弱领域定位，而不推翻原创性。

原创性结论：在本次搜索范围内，`O/P` 必要性和其 exact-M1/Q1 closure **经受住了检索和定理比较**；但这不是优先权证明。上界架构、`ab`、`M`、混合检验和 fixed-pilot SA 框架均有清楚祖先。E/S 边界是正确但基本由共同 envelope 的饱和直接推出。

### 视角 C：ICLR 领域意义

支持录用的最强理由是：论文确实识别了“每个 nuisance 只用一个聚合误差”会丢失方向信息；`O/P` 在显式射线上把既有 `AB+M` 阶从 `r³` 提升到 `r²`，而且作者没有把继承内容包装成原创。证明处理了零预算、全部有限 `n`、可测 selector 和固定 ambient space，技术完成度高。

反对录用的最强理由是：实际 theorem field 太窄，且风险量词明显减轻了统计任务。学习者预先知道四个预算和完整公共类对；每个类对允许专门设计一个规则；下界五项不要求在同一个类对中同时困难；公共类对还可随 `n` 和预算变化。因而结果没有证明存在一个可部署的共同方法在未知难度下达到这张 phase diagram，也没有证明现实 nuisance learner 的估计误差必然呈现这些预算。固定条件方差和无限协变量空间又是下界可嵌入与边界现象的重要组成。对 ICLR 的一般机器学习读者，结论目前主要是“在一个精心限定的外层实验中，两种额外交叉方向不可忽略”，而不是广泛的算法、学习理论或因果推断原则。

此外，论文完全没有实证或模拟表现（第 9、32 页明确说明），也不声称计算可实现。理论论文不必有实验，但当核心增量本身是狭窄量词下的两个 rate terms 时，缺少对一般 heteroskedastic PLM、共同规则或未知预算的延伸使影响论证不足。

领域意义结论：**统计理论上有真增量、技术上严谨；以 ICLR 的广度和影响门槛衡量仍偏低。**若投向更专门的统计理论场合，或补出至少一个 common/adaptive rule、一个同一公共类对的联合下界、或对异方差/更一般线性泛函的扩展，评价可能明显上升。

## 四、主要问题

### 主要问题 1：核心增量必须按 theorem field 收缩表述

稿件第 1、9 页已经相当坦率，但标题与“four-budget minimax law”仍容易让非专家理解为一般 PLM 的四预算答案。事实上，TAME 已给完全相同的上界二分支，Gu–Yin–Cai–Fan 已给 `q+AB+M` 下界；本文新增的是 `O/P` necessity 加 exact-M1/Q1 closure。建议在摘要、引言贡献列表和结论第一句直接写成这一残差贡献，并把 E/S 层降为模型边界事实而非并列主要创新。

影响：不改变定理正确性，但决定 novelty/significance 的真实级别。置信度：高。

### 主要问题 2：pair-specific 与 component-wise lower witnesses 限制了“minimax”解释

量词 `sup_Γ inf_{δΓ} sup_P` 允许规则依赖 Γ；五个下界分量由不同 Γ 见证后才通过外层 supremum 合并。这个数学定义合法，稿件也没有隐藏，但它比 `inf_δ sup_{Γ,P}` 的共同规则风险或固定一个 Γ 的 simultaneous lower bound 弱得多。论文最有意义的后续问题正是：在一个自然、固定的公共类对内能否同时产生这些项；或一个不知预算的共同规则能否自适应实现相同相图。

影响：显著削弱外推和 ICLR 领域意义，不是证明错误。置信度：高。

### 主要问题 3：对最接近前作的 theorem field 有两项事实错误

稿件 Table 5（第 9 页）把 Gu–Yin–Cai–Fan Appendix A.1 写作 squared loss 和仅有 variance lower bound。原文第 19 页式 (A.1)–(A.2) 分别是条件方差恒等 `E[u²|X]≡v≥1/3` 和 expected absolute loss。也就是说，该前作在损失和 constant-variance 方面与本文比表中所示更接近。作者虽正确承认其 `q+AB+M` 下界，但 theorem-field differential 必须据原文改写。

影响：直接影响最接近 prior 的差异分析和 novelty positioning；不消除本文 `O/P` 残差贡献。置信度：极高。

### 主要问题 4：现有工作定位仍不完整

Liu–Mukherjee–Robins v1（2026-06-21）直接讨论 SA 模型下 DML 的 asymptotic inadmissibility 与 ECC minimax；Bonvini et al. v2 和 McClean et al. v3 分别提供 pure/hybrid SA 与 Hölder-ECC 的相邻 minimax 边界。这些并不碰撞 `O/P`，但应进入“为什么本结论仍只适用于特定信息结构”的讨论。否则当前 prior-work map 过度集中于附件列出的链条。

影响：引用与领域定位不完整；不改变主率。置信度：高。

## 五、次要问题与未确认事项

1. **Calibrated DML 版本不一致。**稿件引用 v3/2026-08-20，随附文件实际是 v2。应以 arXiv version history 和最终所引 theorem 页码修正。影响：可复核性；置信度：极高。

2. **Gu COLT 2025 的损失尺度必须逐字保留。**公开源把风险写成 MSE 而结论显示 root-`n` 尺度；这可能是原文打印/命名问题，但审稿人无权替源修正。稿件比较时应继续标注 “as printed”。影响：避免错误等价；置信度：高。

3. **固定常数的非一致性。**`c_ρ,C_ρ` 在 `v_-↑B₀²`、`B_G↓0` 或复杂度半径常数趋于边界时可退化；稿件第 13、30–32 页已承认。摘要可更明确说 theorem 是 pointwise-in-ρ，而不是对这些结构常数 uniform。影响：解释范围；置信度：高。

4. **有限空间不是技术小节。**singleton covariate space 可回到 root-`n`，所以 “fixed infinite standard Borel” 对匹配下界是实质假设。建议把它从 limitations 提升到主定理解释。影响：外推；置信度：高。

5. **没有检查匿名作者身份，也没有使用投稿历史、旧评分、内部审计或其他评审。**所有比较来自附件论文与公开 primary sources。

## 六、经受住审查的主张

- 在稿件精确定义的 interior stratum、pair-specific expected-L1 实验中，主率的 algebraic form 与已检查证明结构一致；未发现反例或量词错误。
- `O=t(a∧t)` 与 `P=s(b∧s)` 在显式方向射线上确实可支配既有 `AB+M`，因此四预算不能总被压成两个聚合 nuisance 误差。
- TAME 直接提供相同上界余项，但不提供本文 exact experiment 下的 matching `O/P` necessity。
- Gu–Yin–Cai–Fan 直接先于本文给出 `q+AB+M`；稿件正确地没有把 `ab` 或 `M` 宣称为原创。
- sequential-M1 条件确实解决了全类 infimum 与可数可测实现之间的接口，而不是光滑性或可实现性假设。
- `v_->B₀²` 的空模型与 `v_-=B₀²` 的 root-`n` 饱和层在给定共同 envelope 下成立，但属于特殊模型边界事实。
- 在 arXiv、PMLR、PMC 和一般网页检索的本次范围内，未发现同场域直接碰撞；这不是不存在性证明或优先权认定。

## 七、最终评分分解

- 正确性：7.5/10（未见主要错误；复杂附录未形式化验证）。
- 原创性：6/10（`O/P` matching necessity 与接口闭合是真增量；上界和多数下界结构已有直接祖先）。
- 技术深度：8/10。
- 清晰度与诚实边界：8/10。
- 广度/ICLR 意义：4.5/10。
- 综合：5/10，Weak Reject；置信度 4/5。

## 八、检索限制

实际使用的平台为 arXiv、PMLR、PubMed Central/PMC、DOI 稳定解析和一般公开网页检索。没有使用 Scopus、Web of Science、MathSciNet、zbMATH 的付费完整接口，也没有可验证地穷尽 Google Scholar；没有访问非公开投稿材料。所需核心论文均取得公开全文，没有因付费墙而只能依赖摘要的实质判断。检索时间边界为 2026-08-26（Asia/Shanghai）。并发或稍后公开、未被索引、题名/术语完全不同或仅存在于非公开渠道的工作可能未被覆盖。
