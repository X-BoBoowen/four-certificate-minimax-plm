# ICLR significance form

**Overall significance assessment:** 统计理论上存在真实而窄的增量；以 ICLR 的广度与影响门槛衡量，处于边缘低于录用线。建议 **Weak Reject，5/10**。

**Most important contribution:** 在作者精确定义的 fixed-infinite、constant-variance、known-four-budget、sequential-M1、pair-specific expected-L1 PLM 实验内，证明方向性交叉项 `O=t(a∧t)` 与 `P=s(b∧s)` 分别是 minimax 必要的，并把 TAME-derived 上界闭合到可测、全有限样本和全部预算边界。

**Strongest scope limitation:** 量词是 `sup_Γ inf_{δΓ} sup_P`，规则可依赖 Γ，且五个 lower components 可由不同 Γ 见证后再通过外层 supremum 合并。结果不提供共同规则、未知预算自适应、同一公共类对 simultaneous hardness、异方差、有限协变量空间、计算、置信区间或因果结论。

**Reason an Area Chair should accept:** 论文技术完成度高、贡献归属诚实；`O/P` 在显式射线上把既有 `AB+M` 阶从 `r^3` 改为 `r^2`，说明把每个 nuisance 压成一个聚合误差会丢失 minimax 方向信息。没有发现同场域 direct collision 或致命正确性问题。

**Reason an Area Chair should reject:** 完整上界式已由 TAME Cor. 3.2/eq. (3.7) 给出，`q+AB+M` 下界已由 Gu–Yin–Cai–Fan Thm A.1 给出；新内容主要是两个额外交叉项及定制接口闭合。结合已知预算、pair-specific 规则、component-wise lower witnesses 与特殊模型限制，当前结果更像狭窄 minimax completion，领域外推和可部署意义不足。

**Confidence:** 4/5。全部附件论文已逐页读取；核心公开版本与定理已核对；复杂附录未形式化机器验证，因此不取 5/5。

