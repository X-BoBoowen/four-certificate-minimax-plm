# 完整引用核验记录

本记录覆盖 README 指定的全部随附 primary sources，以及独立检索中实际进入实质判断的候选来源。页码均为相应 PDF 页码，另有说明时给文章页码。

## A. 随附来源逐项核验

### A1. Balakrishnan, Kennedy, Wasserman

- 稳定记录：[arXiv:2305.04116](https://arxiv.org/abs/2305.04116)，v1 2023-05-06，v2 2025-06-07。
- 随附文件 SHA-256：`57be5566ae48fa193771c7e0f9dc586617d95d5213bec94316755cb90559c400`；与公开 v2 字节一致。
- 核对位置：Theorems 1–2，PDF pp. 12–15。
- 原生字段：由外部训练数据得到后被固定的 nuisance pilots；确定性 L2 邻域；ECC/ATE 等 structure-agnostic functional estimation；MSE/rate 结论。
- 对稿件的核验：稿件称其为 fixed-pilot product lower/first-order upper framework ancestor，准确；它没有本文四预算 `O/P` theorem。
- 分类：technical/framework ancestry。

### A2. Robins, Tchetgen Tchetgen, Li, van der Vaart (2009)

- 稳定记录：[PMC full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC5884174/)，DOI `10.1214/09-EJS479`，EJS 3:1305–1321。
- 随附文件 SHA-256：`ead5e59666df1c71b7ef957adad6a9ca8542d132b28aee2cd90bef23fd326bdf`。
- 核对位置：Theorem 2.1，PDF pp. 4–5 / article pp. 1307–08；Theorem 4.1，PDF pp. 10–11 / article pp. 1313–14。
- 原生字段：mixture Hellinger-affinity testing lemma；Hölder/smoothness semiparametric minimax examples。
- 对稿件的核验：作为 fuzzy/product testing 技术祖先准确；不是相同 PLM public-budget experiment。
- 分类：technical ancestry。

### A3. Gu, COLT 2025 open problem

- 稳定记录：[PMLR 291:6220–6224](https://proceedings.mlr.press/v291/gu25b.html)。
- 随附文件 SHA-256：`72a96e3352b728f6696f00260082097c441b4cd012327dbaa022e207bce17e0b`。
- 核对位置：Theorem 1，PDF p. 4。
- 原生字段：`X~Unif[0,1]^d` 的 PLM；bounded variables；`E[u²|X]≥1/3`；source risk 按打印文本为 expected squared error。
- 结论按打印文本：root-n 加 product 型 lower/upper 尺度。loss 名称和 rate 尺度存在表面不协调，审计不擅自修正。
- 对稿件的核验：是直接问题前身；与本文 constant variance、expected L1、sequential-M1 不等价。
- 分类：direct problem predecessor/source-statement caution。

### A4. Gu, Yin, Cai, Fan

- 稳定记录：[arXiv:2606.06368](https://arxiv.org/abs/2606.06368)，v1 2026-06-04。
- 随附文件 SHA-256：`aae23c43852fd85ca2cbcdf218b36844a2ffab1819f187e16a0da62f875b99ad`；与公开 v1 字节一致。
- 核对位置：Appendix A.1, equations (A.1)–(A.2), Theorem A.1，PDF pp. 19–20。
- 原生字段：`X~ν_d`（uniform cube）、bounded PLM、`E[u²|X]≡v≥1/3`、2n observations、outer function-family minimax、known four budgets。
- 损失与结论：`E|θhat-θ(P)|`；upper `q+[a+s²]∧[(a+s)(b+t)]`；lower `q+[a+s²][b+t²]+(s∧t)²`。
- 对稿件的核验：这是 `q+AB+M` 的 direct lower predecessor。稿件 Table 5 错写为 “squared loss” 和 “variance lower bound”；原文是 expected absolute loss 与 constant conditional variance。这两项必须修正。
- 分类：strong overlap/direct predecessor；无 `O/P` collision。

### A5. Gu, TAME / *Optimal Use of a Black-Box Learner...*

- 稳定记录：[arXiv:2607.21541](https://arxiv.org/abs/2607.21541)，v1 2026-07-23。
- 随附文件 SHA-256：`82d53dbb082d831fc89377ef26e1d84a5ac6ddbeb782d2ca4dcb58e21756a446`；与公开 v1 字节一致。
- 核对位置：Corollary 3.2, equation (3.7)，PDF p. 15；上下文 pp. 14–16。
- 原生字段：semiparametric estimation with one-sided editing/calibration；渐近、高概率、consistent nuisance regime；残差二阶矩无条件下界。
- 结论：TAME-2 remainder 为 `min{a(b+t)+(a+s)^2,b(a+s)+(b+t)^2}+o(n^-1/2)`（换成稿件符号）。
- 对稿件的核验：稿件承认其上界架构继承，准确；TAME 没有本文 exact Q1 下 matching `O/P` lower。
- 分类：direct upper ancestor。

### A6. van der Laan, Luedtke, Carone, Calibrated DML

- 稳定记录：[arXiv:2411.02771](https://arxiv.org/abs/2411.02771)：v1 2024-11-05，v2 2025-06-27，v3 2026-08-20。
- 随附文件 SHA-256：`b9ae8b991e476c5160f9b199dc73dacb0afb1cddeb120917f8a3fd3695ab7a67`，70 页，与公开 v2 完全相同。
- 当前公开 v3：109 页，SHA-256 `ee36f045003d9d1731b9d43803190c2e6fee0dc737ae1fb0a07e77b4ba17ab24`。
- 原生字段：isotonic calibration、partial orthogonality、asymptotic linearity/regularity；含 PLM/ECC 类应用，但没有本文四预算 finite-sample minimax law。
- 对稿件的核验：作为 directional asymptotic neighbor 合理。稿件 reference 写 v3/2026-08-20，但提供的 primary PDF 是 v2，构成确定版本错误。
- 分类：conceptual/technical neighbor；source-version mismatch。

### A7. Jin, Mackey, Syrgkanis

- 稳定记录：[arXiv:2507.02275](https://arxiv.org/abs/2507.02275)，v1 2025-07-03，v3 2025-11-07；NeurIPS 2025。
- 随附文件 SHA-256：`3b458299f3437117ad59412aabd675ef47ceff47ad8627028ceaaa616d181247`。
- 核对位置：Theorems 3.1–3.2，PDF pp. 4–5。
- 原生字段：fixed/anchored nuisance pilots；binary-treatment 与 Gaussian treatment/noise cases；noise shape affects lower bounds。
- 对稿件的核验：确为 PLM/ECC 强邻近 lower work，但信息输入、损失与四预算均不同。
- 分类：strong partial overlap；not collision。

### A8. Jin, Syrgkanis, *Sharp Structure-Agnostic Lower Bounds...*

- 稳定记录：[arXiv:2512.17341](https://arxiv.org/abs/2512.17341)，v1 2025-12-19，v2 2026-01-05。
- 随附文件 SHA-256：`0c7328d1c7d8cb462cb6ed05d3c347c3209244d4bc90d45ec5366ff07fa9197c`。
- 核对位置：general functional lower theorems；PLM/ECC discussion PDF pp. 29–30；全文及附录均读取。
- 原生字段：fixed nuisance estimates、anchored balls、quantile-risk lower bounds；affine/general linear functional distinctions。
- 对稿件的核验：PLM 专节的显示量是 binary-treatment ECC numerator，不是本文 bounded continuous-treatment β 的 public-four-budget pair risk。
- 分类：technical/strong partial overlap；not collision。

## B. 独立检索候选

### B1. Bonvini, Kennedy, Dukes, Balakrishnan

- [arXiv:2405.08525 v2](https://arxiv.org/abs/2405.08525)，2024-12-12。
- Proposition 1, PDF p. 6：ATE pure-SA fixed-pilot expected-L1 product lower bound；Proposition 2, p. 8：hybrid smoothness/SA squared-radius lower bounds。
- 排除 direct collision：ATE、fixed pilots、不同额外 smoothness 信息，无 PLM β four-budget classes。

### B2. McClean et al.

- [arXiv:2403.15175 v3](https://arxiv.org/abs/2403.15175)，2025-05-07。
- Theorem 1, PDF p. 14；Theorem 2, p. 17：ECC double-cross-fit estimator 及 Hölder/density assumptions 下 minimax optimality。
- 排除 direct collision：结构化 smoothness 类，不是 SA public-budget experiment。

### B3. Jin–Syrgkanis ATE/ATT

- [arXiv:2402.14264 v4](https://arxiv.org/abs/2402.14264)，2025-06-08。
- fixed nuisance estimates/radii 下 ATE/ATT structure-agnostic optimality。
- 排除 direct collision：estimand 与信息输入不同；后续 general paper 已覆盖其 lower-bound line。

### B4. Liu, Mukherjee, Robins

- [arXiv:2606.22391 v1](https://arxiv.org/abs/2606.22391)，2026-06-21。
- Theorem 0, PDF p. 4：monotone-bias SA 类中 first-order DML 的 asymptotic inadmissibility 条件；Theorem 3, p. 14：ECC 下 first/second-order estimators 均 asymptotically minimax。
- 排除 direct collision：fixed-pilot SA 与 scaled-MSE admissibility，不是本文 β、四预算、pair-specific expected-L1。
- 引用判断：属于稿件应补的 contextual prior，特别是其公开日在 TAME 和稿件引用的 2026-08-20 v3 之前。

## C. 标准背景引用抽查

稿件 references 中 Bartlett–Bousquet–Mendelson (2005) 的 DOI `10.1214/009053605000000282`、Chernozhukov et al. (2018) 的 DOI `10.1111/ectj.12097`、Foster–Syrgkanis (2023) 的 DOI `10.1214/23-AOS2258`、Robinson (1988) 的 DOI `10.2307/1912705` 与公开书目信息一致。它们只承担标准 localized complexity、DML/orthogonality 与 PLM 背景，未作为本文 novelty 的直接 comparator；没有发现影响主结论的书目冲突。

## D. 总结

确定的引用问题有两类：

1. GYCF theorem field 被稿件错误写成 squared loss 与仅 variance lower bound；实际是 expected-L1 和 constant conditional variance。
2. Calibrated DML 的附件是 v2，但稿件/附件标签宣称 v3。

确定的引用不完整：Liu–Mukherjee–Robins 2026 应纳入 SA 决策定位；Bonvini et al. 与 McClean et al. 适合补充邻近领域地图。没有发现随附来源中存在与完整 `O/P` theorem 的直接碰撞。

