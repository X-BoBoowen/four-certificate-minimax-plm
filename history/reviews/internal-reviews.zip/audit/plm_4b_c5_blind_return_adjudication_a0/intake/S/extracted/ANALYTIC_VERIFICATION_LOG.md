# 独立解析与数值核验日志

## 目标

复核稿件 Appendix G 使用的

`S0=ab+(s∧t)^2+t(a∧t)+s(b∧s)`，

`X=(a+s^2)(b+t^2)+(s∧t)^2+t(a∧t)+s(b∧s)`，

以及 TAME-derived branch remainder `W` 与 `X` 的确定性比较。预算域为 `[0,1]^4`。

## 解析核验

`X-S0=a t^2+b s^2+s^2t^2≥0`。

又因 `a t^2≤t(a∧t)`、`b s^2≤s(b∧s)`、`s^2t^2≤(s∧t)^2`，故 `X≤2S0`。这与稿件 p. 30, Appendix G 一致。

## 完整原始数值输出

```text
seed=20260826 samples=2000000
min(X-S0)= 3.1913421794094177e-08
max(X/(S0 or nan))= 1.9992727549487594
max(W/X)= 2.3605709619413044
violations S0<=X<=2S0: 0
violations W<=24X: 0
grid=51^4
grid max X/S0= 2.0000000000000004
grid max W/X= 2.3485939750735896
grid violations= 0
```

方法：固定 seed 20260826 的 2,000,000 个独立 uniform 四元组，加上每坐标 51 个等距点的 `51^4` 全网格。浮点输出只作独立反例搜索，不替代上面的解析证明。

