# Prior-work candidate matrix

| Candidate | Earliest public date / checked version | Same model & estimand? | Same information/access? | Same assumptions? | Same loss/quantifiers? | Same theorem/rate? | Final classification and exclusion reason |
|---|---|---|---|---|---|---|---|
| Gu–Yin–Cai–Fan A.1 | 2026-06-04 / v1 | 是，bounded PLM β，X 更具体 | 四预算相近；class-family 而非 sequential-M1 | constant variance 相同方向；ambient 更窄 | expected L1、2n、outer family 很接近 | 已有 `q+AB+M`，无 `O/P` | **Strong overlap/direct predecessor**；完整定理仍有 residual difference |
| TAME | 2026-07-23 / v1 | PLM/一般 semiparametric，目标相近 | editing/calibration learner；非 Q1 outer risk | 渐近 consistent；方差条件更一般 | 高概率/渐近，不是 pair minimax L1 | 上界二分支完全相同；无 matching lower | **Direct upper ancestor** |
| Gu COLT | 2025 / PMLR 291 | 是，PLM β | rate-class/open problem 接近 | X uniform cube；variance only lower | source prints MSE；量词不同 | gap/open problem，不是完整答案 | **Direct problem predecessor** |
| BKW | 2023-05-06 / v2 2025-06-07 | 主要 ECC/ATE 等，不同 | fixed pilots + L2 balls | structure-agnostic bounded examples | MSE/fixed-pilot minimax | product lower/first-order upper | **Framework ancestry** |
| Jin–Mackey–Syrgkanis | 2025-07-03 / v3 | 有 PLM/ECC 邻近 | fixed/anchored pilots | binary/Gaussian noise-specific | quantile/minimax formulation不同 | pilot product/square lower | **Strong partial overlap**；无 public four budgets |
| Jin–Syrgkanis general | 2025-12-19 / v2 | general linear functional；PLM section object不同 | anchored fixed estimates | noise/affine conditions不同 | quantile risk | product/square terms，无 `O/P` | **Strong partial overlap** |
| Calibrated DML | 2024-11-05 / v3 | PLM/ECC 类应用相近 | learned nuisances + isotonic calibration | asymptotic law sequences | inference/regularity | 无 finite-sample minimax lower | **Conceptual neighbor** |
| Robins et al. 2009 | 2009 | 不同 smoothness functionals | 结构参数空间已知 | Hölder/density | classical minimax | 提供 mixture/Hellinger 技术 | **Technical ancestry** |
| Bonvini et al. | 2024-05-14 / v2 | ATE，不同 | fixed pilots；hybrid smoothness | pure/hybrid SA | expected L1 lower | product/squared radii | **Partial/contextual overlap** |
| McClean et al. | 2024-03-22 / v3 | ECC，不同 | regression estimators + smoothness | Hölder/density | convergence/minimax | non-root-n ECC rates | **Contextual** |
| Jin–Syrgkanis ATE/ATT | 2024-02-22 / v4 | ATE/ATT，不同 | fixed nuisance estimates | treatment-effect neighborhoods | quantile/minimax | product-rate lower | **Partial overlap** |
| Liu–Mukherjee–Robins | 2026-06-21 / v1 | ECC/一般 SA，不同 β | fixed pilots/rates | SA 与 assumption-lean | scaled-MSE asymptotic admissibility | DML/HOIF minimax，不给四预算 `O/P` | **Contextual/partial overlap；应补引** |

结论：在核对的同模型候选中，GYCF 与 TAME 分别覆盖已有 lower core 和全部 upper architecture；没有候选同时覆盖本文 exact information structure 和 matching `O/P` lower。该 non-hit 不是优先权或不存在性证明。

