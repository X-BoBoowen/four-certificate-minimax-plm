# Source and contribution issue ledger

| Issue | Severity | Claim affected | Primary-source evidence | Location |
|---|---|---|---|---|
| 上界两分支逐式来自 TAME | Major significance/positioning；非技术错误 | “matching four-budget characterization” 中的 upper novelty | TAME Cor. 3.2, eq. (3.7) 为 `min{a(b+t)+(a+s)^2,b(a+s)+(b+t)^2}` | 稿件 pp. 3–5, 9；TAME p. 15 |
| `q+AB+M` 已由 Gu–Yin–Cai–Fan 给出 | Major novelty boundary；稿件已部分承认 | `ab` 与 `M` 下界的新颖性 | GYCF Thm A.1 expected-L1 lower `q+AB+M` | 稿件 pp. 1, 6, 9, 26–30；GYCF pp. 19–20 |
| 稿件错误记录 GYCF 的损失和方差假设 | Major citation/model-field correction | 最接近 prior 与本文的差异大小 | 稿件 Table 5 写 “squared loss; variance lower bound”；原文 (A.1)–(A.2) 是 `E[u²\|X]≡v≥1/3` 与 `E\|θ̂-θ(P)\|` | 稿件 p. 9；GYCF p. 19 |
| pair-specific 规则与 component-wise witnesses 限制解释 | Major significance；模型选择，不是量词错误 | “minimax law”的可迁移性与共同算法含义 | 量词 `supΓ infδΓ supP`；摘要及 lower assembly 明示不同 Γ 见证 | 稿件 pp. 1, 3, 6, 10, 30–32 |
| 固定无限协变量空间是实质假设 | Major scope；合理但特殊 | 下界广泛性 | 稿件说明 singleton 空间只剩 root-n；Walsh 字典嵌入固定无限空间 | 稿件 pp. 2–3, 21–30, 31 |
| 常数条件方差与共同 envelope 产生 E/I/S phase change | Moderate scope；特殊但合理模型选择 | boundary novelty 与一般 PLM 外推 | `\|u\|≤B0` 和 `v=B0²` 直接强制饱和、`π0=0` | 稿件 pp. 3, 8, 30–31 |
| Calibrated DML 随附版本与稿件引用不一致 | Minor/mandatory correction | 版本、页码、可复核性 | 附件 SHA-256 `b9ae...a67` 与 arXiv v2 相同（70 页）；公开 v3 SHA-256 `ee36...b24`（109 页） | 稿件 references pp. 9–10；附件 source；arXiv:2411.02771 version history |
| 未引 Liu–Mukherjee–Robins 2026 | Moderate citation incompleteness；非 collision | SA minimax/decision-theoretic context | v1 2026-06-21，Thm 0 与 ECC Thm 3 直接讨论 SA 下 DML/HOIF | Liu PDF pp. 4, 14；稿件 prior-work section p. 9 |
| 未引 Bonvini et al. 与 McClean et al. | Minor citation incompleteness | SA–smoothness 与 ECC minimax 的领域地图 | Bonvini Props 1–2；McClean Thm 2 | Bonvini pp. 6, 8；McClean p. 17 |
| Gu COLT 公开源的 risk/rate 尺度按打印文本不一致 | Source-statement caution；未确认是 typo | 与 open problem 的损失比较 | source p. 4 把 risk 写作 expected squared error，而结论显示 root-n/product 尺度 | Gu COLT p. 4；稿件 p. 9 |
| `cρ,Cρ` 非 uniform 接近结构边界 | Minor clarity；稿件已承认 | “all budgets/all n” 的常数解释 | 常数可在 `v_-↑B0²`, `BG↓0`, `crad↓0` 时退化 | 稿件 pp. 13, 30–32 |
| 未发现 `O/P` 同场域直接先例 | No issue / search non-hit | 核心 residual novelty | 精确公式、模型同义词、TAME lower、four-budget/public-budget/pair-specific/M1 查询均只命中已比较来源或不相关结果 | 完整检索日志；截止 2026-08-26 |
