# Return checklist

- [x] Every required role form is completed.
- [x] Every substantive issue has a page, theorem, lemma, or equation locator.
- [x] The source/model/session declaration is complete.
- [x] The complete unedited raw output is attached.
- [x] No other role's material or output was viewed.
- [x] No author identity was sought.
- [x] No human identity, credential, or signature was invented.
- [x] Literature non-hits were not converted into novelty or priority claims.
- [x] Input ZIP and candidate PDF hashes were independently recomputed.
- [x] All enclosed primary PDFs were read in full and key theorem pages were visually rendered.
- [x] Public version histories and stable primary-source links were checked.
- [x] Final ZIP contents and detached output SHA-256 were verified after creation.
