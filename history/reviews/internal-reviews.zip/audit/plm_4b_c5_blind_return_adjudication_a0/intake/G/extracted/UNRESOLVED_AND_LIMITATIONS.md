# Unresolved matters and review limitations

## Unresolved technical matters

1. **Full formal verification was not performed.** The paper is 34 pages and contains long conditional empirical-process and lower-bound constant chains. The decisive steps were read and attacked, but no proof assistant checked every algebraic line. The most fragile remaining location is Appendix B, PDF pp. 15–19, Eqs. (B.18)–(B.30). Classification: **UNVERIFIED SUSPICION**, not a discovered error.

2. **Global literature priority is not established.** Public primary sources were checked and no same-interface `O/P` theorem was found. A finite search cannot prove absence. Classification: **NOT ASSESSABLE** beyond the logged sources.

3. **Exact figure reproduction is unavailable.** The named generator script is absent from the package. Classification: **CONFIRMED FAILURE**, minor and artifact-specific.

4. **Computational implementability is outside the theorem.** The permitted rule is an arbitrary public-pair Borel estimator, and lower dictionaries may be tailored to `n` and the budget cell. The review does not infer an efficient algorithm. Classification: **STRONG CONCERN** for scope, not correctness.

5. **Unknown-budget adaptation is not covered.** All rate claims are pointwise at known upper budgets. No claim about adaptation penalties should be inferred.

6. **Heteroskedastic or finite-ambient variants are not covered.** The theorem fixes constant conditional treatment variance and an infinite standard Borel covariate space. The saturation result particularly depends on this exact field.

7. **Empirical validity is not applicable.** No empirical performance claim is made. This review does not invent an empirical requirement and does not treat the absence of experiments as a correctness defect.

## Tool and epistemic limitations

- Numerical recomputation used double-precision arithmetic at representative lower-witness parameter points and broad budget grids. It is corroborative, not a substitute for symbolic proof.
- PDF text extraction garbled some formulas; those locations were checked against high-resolution rendered pages.
- No author identity was sought, and no attempt was made to de-anonymize citations.
- No other review, response, score, audit, expected conclusion, or modification history was read.
- A web search result exposed the existence of an OpenReview page, but it was not opened or consulted.
- Exact provider-side model snapshot, build, session ID, and instance ID were not exposed by the platform and are therefore recorded as “Platform not provided.”

## Evidence that would change the recommendation

- **Toward rejection:** a same-interface primary theorem already proving `O/P`; an explicit illegal conditioning step in Eqs. (B.18)–(B.30); a budget-violating raw mass in the all-budget lower cases; or a counterexample to the M1 closure.
- **Toward stronger acceptance:** a fixed/common-estimator or unknown-budget extension; a clear computational corollary; an example where the directional terms change a concrete methodological choice; or a formal/machine-checkable verification supplement.

