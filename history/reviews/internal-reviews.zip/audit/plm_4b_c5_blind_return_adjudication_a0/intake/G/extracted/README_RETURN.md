# Blind review return package

This package contains the complete independent general-ICLR review of the manuscript **“Four-Budget Minimax Rates for Bounded Partially Linear Models.”**

The input archive was treated as read-only. The review used the archive-root `README.md` as the only project-level instruction. No other review, filled form, modification history, internal audit, expected decision, or author-identity material was consulted.

## Contents

- `FINAL_REVIEW_FULL.md`: complete reviewer report, AC-style synthesis, issue inventory, survived attacks, limitations, external-source record, and declaration.
- `RAW_REVIEW_OUTPUT.md`: complete public audit record and preserved calculation output from this review session.
- `COMPLETE_ISSUE_LIST.md`: every substantive issue, with classification, locator, evidence, impact, repair, severity, and confidence.
- `SURVIVED_ATTACKS.md`: claims that survived attempted falsification.
- `UNRESOLVED_AND_LIMITATIONS.md`: matters not established and review boundaries.
- `EXTERNAL_SEARCH_AND_TOOL_LOG.md`: public-source and tool-use record.
- `VERIFICATION_OUTPUT.txt`: preserved numerical-verification output.
- `forms/`: every form required by the input README, fully completed.
- `PACKAGE_MANIFEST.tsv`: generated delivery manifest with SHA-256 values for the files inside this package.

The SHA-256 of the final ZIP cannot be stored inside that ZIP without changing the ZIP itself. It is therefore supplied in the external sidecar file delivered next to the ZIP and in the delivery message.

