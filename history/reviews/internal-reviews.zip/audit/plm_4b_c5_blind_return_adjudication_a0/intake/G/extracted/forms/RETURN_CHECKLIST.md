# Return checklist

- [x] Every required role form is completed.
- [x] Every substantive issue has a page, theorem, lemma, equation, source, or package locator.
- [x] The source/model/session declaration is complete; unavailable platform metadata is marked “Platform not provided.”
- [x] The complete unedited public raw output is attached as `RAW_REVIEW_OUTPUT.md`, with preserved numerical output in `VERIFICATION_OUTPUT.txt`.
- [x] No other role's material or output was viewed.
- [x] No author identity was sought.
- [x] No human identity, credential, or signature was invented.
- [x] Literature non-hits were not converted into novelty or priority claims.
- [x] Input archive and manuscript hashes were verified before review.
- [x] The original input ZIP and manuscript were not modified or overwritten.
- [x] Reviewer-style report and AC-style advisory synthesis are both included.
- [x] Complete issue, survived-attack, unresolved-matter, source, and tool logs are included.
- [x] Output files and final ZIP are subjected to fresh integrity and completeness checks before delivery.

