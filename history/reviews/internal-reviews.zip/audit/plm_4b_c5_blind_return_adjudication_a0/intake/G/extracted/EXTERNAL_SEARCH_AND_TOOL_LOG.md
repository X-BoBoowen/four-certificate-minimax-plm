# External search and tool log

## Isolation and file handling

- Input ZIP was inventoried before extraction and hashed as `81DBCF0FD08FE219E590D22B5850E180E9E3F4D05F105222205C9E7E92728DA0`.
- Every archive path was checked before safe extraction into a new directory. The input ZIP was not overwritten.
- Candidate PDF hash was verified against both `CANDIDATE_SHA256.txt` and `PACKAGE_MANIFEST.tsv`: `D8DD7EB9F01038D0AA863F78C3972950AD98B6B6225E4A69D3CF7F92E45E2259`.
- All 34 PDF pages were text-extracted and raster-rendered. Nine contact sheets covering pages 1–34 were visually inspected; pages 15, 17, 18, 19, 23, 25, 30, and 31 were additionally inspected at high resolution because they contain decisive formulas.
- No source file or manuscript was modified.

## Computation

- Deterministic rate algebra: 28,561 boundary-grid points plus 1,000,000 seeded random budget quadruples.
- Assertions: `V≤W≤4V`, `X/5≤V≤6X`, selected branch `≤2W`, and `S0≤X≤2S0`.
- Lower-witness checks: representative `P`, `O`, `ab`, and `M` raw six-atom laws; normalization, positivity, conditional moments, constant variance, reference equality, target gaps, and Gram energies.
- Exact preserved output: `VERIFICATION_OUTPUT.txt`.

## Public primary sources opened and read

The search was restricted to review-necessary public primary papers and formal metadata. No other review was opened.

| Source | Public URL | Local PDF SHA-256 | Use |
|---|---|---|---|
| Gu (2025), “Optimal Rates for Estimating Linear Functionals of Nonparametric Regression” | <https://proceedings.mlr.press/v291/gu25b.html> | `72A96E3352B728F6696F00260082097C441B4CD012327DBAA022E207BCE17E0B` | Read the full five-page PMLR paper and checked the stated open-problem lower/upper gap. |
| Balakrishnan, Kennedy, Wasserman, “Optimal use of regression models in semiparametric estimation” | <https://arxiv.org/abs/2607.21541> | `82D53DBB082D831FC89377EF26E1D84A5AC6DDBEB782D2CA4DCB58E21756A446` | Checked Theorem 3.1 and Corollary 3.2; mapped the two upper branches. |
| Gu, Liu, Han, “Optimally Taming the Difficult Directions in Model-Based Inference” | <https://arxiv.org/abs/2606.06368> | `AAE23C43852FD85CA2CBCDF218B36844A2FFAB1819F187E16A0DA62F875B99AD` | Checked Theorem A.1 for the `AB+M` lower ancestry. |
| Balakrishnan, Kennedy, Wasserman, “The Fundamental Limits of Structure-Agnostic Functional Estimation” | <https://arxiv.org/abs/2305.04116> | `57BE5566AE48FA193771C7E0F9DC586617D95D5213BEC94316755CB90559C400` | Checked general lower-bound ancestry and metadata. |
| Jin, Syrgkanis, “Structural Limitations of Plug-in Estimation: An Asymmetric Minimax Theory” | <https://arxiv.org/abs/2512.17341> | `0C7328D1C7D8CB462CB6ED05D3C347C3209244D4BC90D45EC5366FF07FA9197C` | Checked Theorem 2.1 and Remark 7.1 for asymmetric perturbation overlap and information-structure differences. |
| Jin, Guo, Rothenhäusler, “Diagnosing the Role of Observational Data in Causal Inference” | <https://arxiv.org/abs/2507.02275> | `3B458299F3437117AD59412AABD675EF47CEFF47AD8627028CEAAA616D181247` | Checked Theorem B.1; formal NeurIPS 2025 page also checked. |
| van der Laan, Luedtke, Carone, “Automatic Debiased Machine Learning via Calibrated Estimation” | <https://arxiv.org/abs/2411.02771> | `EE36F045003D9D1731B9D43803190C2E6FEE0DC737AE1FB0A07E77B4BA17AB24` | Checked cited directional/calibrated-DML adjacency and metadata. |

## Formal metadata checks

- arXiv API records were checked for versions, titles, and author lists of `2305.04116`, `2411.02771`, `2507.02275`, `2512.17341`, `2606.06368`, and `2607.21541`.
- Official NeurIPS 2025 proceedings metadata was checked for Jin–Guo–Rothenhäusler.
- Crossref DOI metadata was checked for:
  - `10.1214/009053605000000282` (Bartlett–Bousquet–Mendelson);
  - `10.1111/ectj.12097` (Chernozhukov et al.);
  - `10.1214/23-AOS2258` (Foster–Syrgkanis);
  - `10.1214/09-EJS479` (Robins et al.);
  - `10.2307/1912705` (Robinson).
- The checked title/author/year/venue fields were consistent with the manuscript bibliography. No material citation mismatch was found.

## Search boundary and non-hits

- Exact-title, key-term, cited-author, and theorem-ancestry searches were used only to locate primary sources.
- No non-hit was treated as proof of novelty or priority.
- One search result listed an OpenReview page. It was deliberately not opened because other review material was outside scope.

## Model/session metadata check

- Official OpenAI documentation was consulted only to determine whether exact model/session metadata could be recovered from the present platform context. The platform exposed no exact model snapshot, build, response ID, session ID, or instance ID for this task. Those fields are therefore marked “Platform not provided”; no value was inferred from generic model documentation.

