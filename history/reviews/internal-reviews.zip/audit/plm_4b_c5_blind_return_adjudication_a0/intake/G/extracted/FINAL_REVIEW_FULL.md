# Complete independent blind review

## Review identity and independence

This is one independent general ICLR Reviewer/AC-style expert assessment, using several analytical lenses but not inventing multiple reviewers. It was conducted by an AI system in a fresh isolated session. The archive-root `README.md` was the only project-level instruction. No other review, filled form, score, internal audit, modification history, expected conclusion, non-public source, or author-identity material was read. The input archive and manuscript remained unchanged.

## Manuscript

**Title:** “Four-Budget Minimax Rates for Bounded Partially Linear Models”

**Recommendation:** **6/10 — Weak Accept**

**Reviewer confidence:** **4/5**

**AC-style advisory disposition:** **Lean Accept / Weak Accept**

The AC-style disposition is only an independent synthesis. It does not claim actual Area Chair authority or a formal editorial decision.

---

# Reviewer-style report

## 1. Summary and strongest fair reading

The paper studies estimation of the slope `beta` in the bounded partially linear model

`T = pi_0(X) + u`,

`Y = beta_0 T + mu_0(X) + epsilon`,

under conditional centering, an exactly constant conditional residual-treatment variance `E[u^2|X]=v`, and bounded support. Its distinctive statistical interface makes four public upper budgets available: two approximation budgets and two estimation budgets for the treatment and outcome nuisance functions. For every public pair of nuisance classes, an estimator may be selected specifically for that pair; Nature then ranges over laws satisfying those public budgets. The ambient covariate space is a fixed nonempty infinite standard Borel space, and public classes satisfy a bounded sequential-M1 representation.

Let

`q = n^{-1/2}`,

`A = a+s^2`, `B = b+t^2`, `M=(s∧t)^2`,

`O=t(a∧t)`, `P=s(b∧s)`,

and `X_rate = AB+M+O+P`.

Theorem 1 gives three regimes. If `v_->B0^2`, the experiment is empty. If `0<v_-<B0^2`, the minimax absolute-error risk is of order `q+X_rate`, with constants depending only on the stated structural ratio. At the boundary `v_-=B0^2`, support saturation collapses the problem to the parametric rate.

The strongest fair interpretation is not that the paper invents a new practical estimator family. Its upper-bound architecture is explicitly inherited from TAME-type regression use, and earlier fuzzy-hypothesis work provides the `AB+M` ancestry. The paper's real claims are narrower and more defensible:

1. the two directional terms `O` and `P` are genuinely necessary under this public-class/known-budget information structure;
2. a pair-specific Borel upper rule can be closed over sequential-M1 classes at exactly the same rate;
3. the resulting theorem covers the full nonnegative budget cube, including boundary cells; and
4. the variance-support saturation boundary produces a distinct parametric phase.

Read this way, the contribution is technically deep, apparently correct, and conceptually meaningful. It is also specialized, and that specialization is the main weakness.

## 2. Core claim/evidence dependency map

| Core claim | Conditions needed | Most fragile premise | Independent check | Outcome |
|---|---|---|---|---|
| Upper risk is `O(q+X_rate)`. | Public exact budgets; sequential-M1 classes; bounded envelope; constant conditional variance; pair-specific Borel estimator; valid split/edit conditioning. | Random nuisance/edit choices must not expose the residual before the conditional process bound. | Traced Eqs. (B.9)–(B.33), sigma-fields, tail integration, selector/fallback; independently stress-tested deterministic algebra. | **SURVIVED ATTACK.** |
| Lower risk contains `q, ab, M, O, P`. | Each lower experiment is a legal public pair; raw laws satisfy moments/support; fuzzy alternatives share the required reference and bounded divergence. | Directional `O/P` six-atom masses and common-reference identities. | Recomputed representative raw laws, moments, reference equality, target gaps, and Gram energies. | **SURVIVED ATTACK.** |
| Separate component pairs imply the sum-rate order. | Outer `sup` over public pairs; finite nonnegative component list; proof uses `max`, not sum of incompatible Bayes risks. | Possible quantifier mismatch between pair-specific estimators and separate lower dictionaries. | Re-expanded Eq. (4) and reconstructed max-to-sum comparison. | **SURVIVED ATTACK.** |
| Sequential M1 is sufficient for closure. | Countable pointwise approximants with a common bounded envelope and a Borel first-hit rule. | Pointwise closure might be too weak for population or finite-sample objective closure. | Applied dominated convergence and checked countable first-within-tolerance selection. | **SURVIVED ATTACK.** |
| Boundary `v_-=B0^2` is parametric. | Exact variance equality, `|u|≤B0`, conditional mean zero, and bounded `T`. | A nonzero treatment regression or asymmetric endpoint mass might survive. | Checked the equality case and treatment-bound implications. | **SURVIVED ATTACK.** |
| `O/P` are original relative to the cited ancestry. | Closest sources do not already prove the same conclusion under the same interface. | Related asymmetric perturbation papers may contain an equivalent theorem under different notation. | Read the relevant primary theorem statements. | **SURVIVED ATTACK, bounded to checked sources.** |

## 3. Correctness assessment

### 3.1 Quantifiers and lower-bound assembly

The first likely failure mode is that the lower proof uses different public nuisance pairs for different terms. That would be invalid if the theorem fixed one pair or required one estimator across pairs and then added separate Bayes risks. It is valid for the paper's stated risk:

`sup_Gamma inf_{delta_Gamma Borel} sup_{P in P(Gamma)} E_P |delta_Gamma-beta(P)|`.

For each component, the proof supplies a legal public pair. The outer supremum can select the hardest pair after the pair-specific estimator mapping is specified. The paper then obtains a maximum of five component lower bounds. Since there are finitely many nonnegative components, their maximum is equivalent to their sum up to a constant. I checked that the manuscript does not silently sum Bayes risks from incompatible experiments. This attack failed.

The conclusion does depend on the exact interface. It should not be transported to a common-estimator or unknown-budget problem without a new theorem.

**Locator:** PDF p. 2, Eq. (4); p. 3, Theorem 1; Appendix C–F, pp. 19–29.

### 3.2 Deterministic rate algebra and branch selection

The upper proof derives two TAME-type branch remainders,

`T_mu = a(b+t)+(a+s)^2`,

`T_pi = b(a+s)+(b+t)^2`,

then uses a selector/fallback and deterministic comparison to the compact target. This is vulnerable at zero budgets, ties, and cells where one directional term changes regime.

I independently evaluated 28,561 boundary-grid points and one million seeded random quadruples. The checks included `V≤W≤4V`, `X_rate/5≤V≤6X_rate`, selected branch `≤2W`, and `S0≤X_rate≤2S0`. All passed. The worst observed ratios were inside the stated constants. This numerical attack is not a symbolic proof, but it directly targets branch boundaries and algebraic transcription errors; no such error was found.

**Locator:** PDF pp. 12–13, Appendix B.1–B.3; preserved output in `VERIFICATION_OUTPUT.txt`.

### 3.3 Upper-bound conditioning, editing, and measurability

The most fragile mathematical part is Appendix B. The proof edits or selects nuisance functions using split data and then applies conditional empirical-process bounds. A hidden dependence on the same residual would invalidate centering.

I traced the decisive steps in Eqs. (B.9)–(B.33). For the treatment-side edit, the revealed treatment-side variables do not destroy the outcome residual's conditional centering. For the reverse edit, the order of using outcome information and later treatment information preserves the sigma-field structure needed by the displayed process bound. The selector/fallback is defined using public quantities and countable approximants. The tail integrations around (B.18)–(B.20) and the reverse edit around (B.21)–(B.30) are compressed, but I found no circularity, leaked residual, or illegitimate random substitution.

The remaining qualification is epistemic: I did not formalize every universal constant in a proof assistant. Therefore this point is a low-probability **UNVERIFIED SUSPICION**, not a failure.

**Locator:** PDF pp. 15–19, Eqs. (B.9)–(B.33).

### 3.4 Sequential-M1 closure

Pointwise sequential approximation would be too weak without a common envelope or without a measurable way to choose an approximant. The paper supplies both. Bounded domination gives the needed `L2` passage, finite-sample objectives converge along the sequence, and the first index satisfying a tolerance is a countable Borel choice. This is a legitimate closure device.

This attack survived only on the stated sequential-M1 field; it does not establish the result for arbitrary uncountable nonseparable classes.

**Locator:** PDF pp. 2–3 and 11–12; p. 19, Eqs. (B.31)–(B.33).

### 3.5 Directional and inherited lower experiments

The directional lower bounds are the paper's most important and most attackable claims. I reconstructed representative six-atom raw-law instances for `P`, `O`, `ab`, and `M`. For each I checked:

- nonnegative masses and normalization;
- conditional treatment centering and exact variance;
- outcome centering;
- bounded support;
- equality of the intended mixture/reference law;
- nuisance budget behavior;
- target separation; and
- the stated Gram/chi-square control.

All assertions passed. The largest mixture-reference mismatch was `5.55e-17`, consistent with floating-point roundoff. The normalized target gaps had the correct directional or product order. The raw-law checks cannot replace the manuscript's symbolic all-budget inequalities, but they defeat several plausible sign, normalization, and role-swap errors.

**Locators:** `P`: PDF pp. 22–24, Appendix D, Eq. (D.4), Lemma 6. `O`: pp. 24–26, Appendix E, Eq. (E.3), Lemma 7. `ab/M`: pp. 26–29, Appendix F, Lemmas 8–9.

### 3.6 Saturation boundary

At `v_-=B0^2`, `|u|≤B0` and `E[u^2|X]=B0^2` force `|u|=B0` almost surely conditional on `X`. Conditional mean zero then forces equal probabilities on `±B0`. Because `T=pi0(X)+u` must remain within the same treatment bound, both endpoints can be admissible only when `pi0(X)=0`. The paper's simple moment estimator then has parametric risk, and the two-point lower submodel gives the matching order.

I tried the natural counterexamples—unequal endpoint probabilities and nonzero `pi0`—and both violate explicit assumptions. The phase transition is correct within this field.

**Locator:** PDF pp. 29–31, Appendix H, Eqs. (H.1)–(H.6).

### 3.7 Correctness conclusion

No confirmed theorem-level failure was found. The main theorem receives **4/5 for correctness**, not 5/5, because the entire stochastic proof was not mechanically formalized and because the compressed edit/tail constants remain the least independently certified part.

## 4. Originality and prior-work assessment

I checked the primary papers most capable of defeating the novelty claim.

- Gu (2025) states the bounded partially linear open problem and the earlier gap.
- Balakrishnan–Kennedy–Wasserman (2026) provides the two upper branches now used in the TAME closure.
- Gu–Liu–Han (2026) provides a lower expression corresponding to `AB+M`.
- Jin–Syrgkanis (2025/2026) develops related asymmetric minimax lower perturbations, but in an anchored/fixed-pilot setting for general linear functionals.
- Jin–Guo–Rothenhäusler (2025) gives a related binary-treatment anchored lower bound of a different form.
- Calibrated DML supplies a directional asymptotic neighbor, not the same nonasymptotic public-class theorem.

This attack partly changes the rhetoric: the paper should not be sold as a wholly new estimator architecture or wholly new lower-bound technology. The manuscript mostly avoids that overclaim. More explicit theorem-by-theorem differentiation from the asymmetric minimax papers would improve the positioning.

The attack does not eliminate the contribution. None of the checked sources states the same exact four-budget public-class result or supplies the `O/P` terms under the same information structure. Those terms can dominate in legitimate cells and thus change the minimax order, not merely a constant. My rating is **4/5 for originality**, explicitly not a global priority certificate.

**Locator:** PDF pp. 8–9, Section 11/Table 5; full source log in `forms/NOVELTY_CITATION_LOG.md`.

## 5. Independent dimension ratings

| Dimension | Rating | Judgment |
|---|---:|---|
| Correctness | 4/5 | No confirmed fatal flaw; decisive constructions and quantifiers survived attack; residual non-formalized proof risk remains. |
| Originality | 4/5 | Directional terms and exact theorem closure appear new relative to checked primary sources; upper architecture and `AB+M` are inherited. |
| Technical depth | 5/5 | Deep upper/lower constructions, careful all-budget treatment, measurable closure, and boundary analysis. |
| Scientific significance | 3/5 | Resolves a sharp theoretical question, but within a restrictive, information-theoretic interface. |
| Conceptual insight | 4/5 | Directional information loss and the saturation phase change are genuine explanatory contributions. |
| Empirical validity | N/A | No empirical claim is made; no false empirical inference is alleged. |
| Reproducibility | 3/5 | Proof is substantially self-contained; the named figure-generation script is missing from the archive. |
| Clarity | 3/5 | Precise and auditable, but exceptionally dense and notation-heavy. |
| Broader relevance | 3/5 | Relevant to semiparametric/minimax theory; practical reach is not yet demonstrated. |
| ICLR community value | 4/5 | Strong theory contribution for the relevant segment of the community, though not a broad methodological advance. |
| Assumption realism | 2/5 | Exact known budgets, boundedness, constant variance, and arbitrary pair-specific Borel rules are strong idealizations. |

These ratings are independent: technical correctness does not substitute for significance, and presentation quality does not alter the validity judgment.

## 6. Strengths

1. **Quantifier discipline.** The paper states exactly what is public, what may depend on `n` and budgets, and where the estimator infimum sits. This prevents a common class of false minimax claims.

2. **Rate-changing directional terms.** `O` and `P` expose information lost when one nuisance error is represented only by an estimation budget while the other is represented by approximation. They are not decorative refinements.

3. **Technically strong lower constructions.** The common-reference six-atom designs are delicate and, at the audited points, internally consistent.

4. **Honest ancestry.** The manuscript credits the inherited TAME upper structure and earlier fuzzy-hypothesis components instead of claiming all machinery as new.

5. **Boundary completeness.** Zero-budget cells, strict interior, empty regime, and saturation boundary are treated explicitly.

6. **Useful negative claims.** Appendix I reduces the risk that readers infer adaptation, efficiency, or broader variance robustness that was not proved.

## 7. Substantive concerns and classifications

### SC-1 — STRONG CONCERN: narrow theorem field

The main weakness is external and scientific scope. Exact budgets are public. Class pairs and lower dictionaries may depend on `n` and the budget cell. The estimator can be any pair-specific Borel rule. The conditional treatment variance is constant. The result gives no common computational learner, adaptation guarantee, confidence interval, or empirical validation.

This does not invalidate the theorem. It means the evidence supports the weaker conclusion “sharp information-theoretic rate for a precise experiment,” not “sharp practical rate for modern partially linear learning.” The paper is largely honest about this, but the limitation should be even more prominent because it is decisive for venue significance.

- **First failure of a broader inference:** Eq. (4)'s pair-specific estimator infimum.
- **Downstream impact:** limits broader relevance and operational use.
- **Minimal repair:** motivate a concrete use-case, foreground the interface in the abstract/conclusion, and add a fixed/common or adaptive corollary if possible.
- **Severity/confidence:** Moderate significance concern; high confidence.
- **Locator:** PDF p. 2, Eq. (4); p. 3; p. 9, lines 456–463; pp. 31–33.

### CF-1 — CONFIRMED FAILURE: missing figure script

The paper states that Figure 1 is generated by `figures/generate_theory_summary.py`, but the supplied ZIP does not contain that script. Exact figure reproduction from the artifact is therefore impossible.

- **Downstream impact:** minor; the figure is an analytic summary and the rate algebra was independently checked.
- **Minimal repair:** include script/environment details or qualify the statement.
- **Severity/confidence:** Minor; high confidence.
- **Locator:** PDF p. 9, Reproducibility Statement; input manifest.

### PA-1 — PLAUSIBLE ALTERNATIVE: interface closure versus foundational novelty

A reasonable skeptic can describe the paper as exact closure/proof engineering around TAME upper bounds and fuzzy/asymmetric lower-bound machinery. That interpretation is partly correct and should temper rhetoric. It does not fully explain away the paper: the two new directional terms alter the order, and the exact public-class closure was not found in the checked sources.

- **Minimal repair:** expand comparison to Jin–Syrgkanis and Jin–Guo–Rothenhäusler at the theorem/interface level.
- **Severity/confidence:** Minor-to-moderate positioning issue; medium-high confidence.
- **Locator:** PDF pp. 8–9, Section 11/Table 5.

### US-1 — UNVERIFIED SUSPICION: compressed stochastic constants

Appendix B's edit/tail bookkeeping is the first location I would formalize in a further audit. The conditioning structure survived review, but numerical tests do not certify universal empirical-process constants.

- **Most discriminating test:** a machine-checkable lemma with explicit sigma-fields, edit thresholds, and constants.
- **Severity/confidence:** low-probability residual risk; no evidence of an actual defect.
- **Locator:** PDF pp. 15–19, Eqs. (B.18)–(B.30).

### TP-1 — TASTE/PREFERENCE: presentation density

The audit-oriented style is defensible but costly. Moving some scope ledgers and negative claims to appendices would improve general-reader access. This is not a correctness issue.

- **Locator:** PDF pp. 1–10.

### NA-1 — NOT ASSESSABLE / not applicable: empirical validity

There is no empirical claim to falsify. I do not treat the absence of experiments as a technical failure, although it weakens evidence for practical importance.

## 8. Most discriminating author actions

1. Add a clear example showing a budget region in which `O` or `P` changes a concrete methodological conclusion relative to `AB+M`.
2. Give a fixed-class/common-estimator or unknown-budget result, even if it incurs a logarithmic or adaptation penalty.
3. Expand the comparison to the closest asymmetric minimax papers by aligning hypotheses, information structure, and target conclusion.
4. Consolidate Appendix B's conditional edit argument into a lemma with explicit constants and sigma-fields.
5. Include the figure-generation script.

## 9. Reviewer recommendation

I recommend **6/10 — Weak Accept**, confidence **4/5**.

The acceptance case rests on apparent correctness, very high technical depth, honest attribution, and a rate-changing directional minimax insight. The rejection case rests on narrowness, known-budget/pair-specific idealization, and lack of an operational learner. Since no theorem-level failure emerged and the new terms can dominate, I place the paper just on the acceptance side. This is not a strong accept because the scientific reach beyond the engineered theorem field remains limited.

---

# AC-style synthesis

## Strongest acceptance case

The paper appears to close a genuine minimax gap under a fully specified information structure. The technical work is substantial: two upper branches are closed over sequential-M1 classes with Borel selection, five lower components are established, directional common-reference constructions are introduced, and the support/variance boundary is handled separately. The core theorem survived independent attacks on its quantifiers, deterministic algebra, representative lower laws, conditioning structure, and saturation logic. Primary-source checks support the manuscript's claim that the upper architecture and `AB+M` are inherited while the exact `O/P` closure is not present in those sources.

## Strongest rejection case

The exactness is achieved for a restrictive theoretical experiment. The known budgets and pair-specific arbitrary Borel rules weaken its connection to one implementable learning method. The public pairs may depend on `n` and the budget cell, the variance is constant, and the ambient assumptions are chosen to support universal lower dictionaries. Thus the result may be viewed as an impressive closure of a specialized theorem field rather than a broadly consequential ICLR advance. Presentation density compounds the accessibility problem.

## Are the main issues real and decisive?

- **Correctness failure:** none confirmed; not a current basis for rejection.
- **Artifact failure:** missing figure script, real but minor.
- **Significance concern:** real and potentially decisive for venue judgment.
- **Novelty concern:** real as a framing issue, but the strongest alternative explanation did not eliminate the order-changing directional contribution.
- **Presentation concern:** partly taste; it should not be disguised as a theorem defect.

## What evidence would change the synthesis?

Toward rejection: a public primary theorem with the same estimator information and `O/P` lower conclusion; an explicit conditional-centering counterexample in Appendix B; an invalid raw mass or budget violation in an all-budget directional case; or a failure of the sequential-M1 measurable closure.

Toward stronger acceptance: a common or adaptive estimator result; a computationally explicit corollary; a concrete example showing scientific consequence of directional dominance; or machine-checkable verification of the delicate edit/lower-law algebra.

## Recommended disposition

**Lean Accept / Weak Accept**, confidence **4/5**. This is an advisory synthesis only and does not assert actual AC authority.

---

# Complete issue-status ledger

| Classification | Count | Items |
|---|---:|---|
| CONFIRMED FAILURE | 1 minor | Missing figure-generation script; no confirmed theorem failure. |
| STRONG CONCERN | 1 | Narrow external/operational scope and venue significance. |
| PLAUSIBLE ALTERNATIVE | 1 | Interface closure/proof engineering as a partial alternative novelty account. |
| UNVERIFIED SUSPICION | 1 | Compressed Appendix B constant/conditioning formalization risk. |
| SURVIVED ATTACK | 9 | Quantifier assembly; rate algebra; upper conditioning; M1 closure; `P`; `O`; `ab/M`; saturation; bounded novelty differentiation. |
| NOT ASSESSABLE | 2 | Global priority; empirical validity (not applicable). |
| TASTE/PREFERENCE | 1 | Dense audit-like exposition. |

Detailed per-item evidence, locators, impacts, and repairs are in `COMPLETE_ISSUE_LIST.md`; the claims that survived attack are fully recorded in `SURVIVED_ATTACKS.md`.

---

# Review limitations

- No proof assistant checked the entire proof.
- Numerical recomputation used double precision and representative lower-witness parameter points; the all-budget theorem still relies on the symbolic proof.
- A finite public-source search cannot prove priority.
- Exact empirical validity is not a meaningful dimension because no empirical claim was made.
- The referenced figure script was unavailable.
- Exact platform model snapshot, build, session ID, and instance ID were not exposed.

None of these limitations was converted into an unsupported accusation.

---

# External search and tool disclosure

The review used archive hashing/inventory, safe extraction, PDF text extraction and page rendering, high-resolution inspection of decisive proof pages, deterministic numerical recomputation, and public primary-source/metadata checks. Public papers checked included the PMLR open-problem paper and the relevant arXiv primary papers for TAME, fuzzy lower bounds, structure-agnostic limits, asymmetric minimax theory, binary-treatment lower bounds, and calibrated DML. Crossref and formal venue/arXiv metadata were used to check bibliography fields. No review page was opened. Full URLs, hashes, and purposes are in `EXTERNAL_SEARCH_AND_TOOL_LOG.md` and `forms/NOVELTY_CITATION_LOG.md`.

---

# Provider/model/version/session declaration

Provider: OpenAI  
Model: GPT-5 family; the platform did not expose a more specific model identifier for this session  
Exact model/version: Platform not provided  
Session or instance ID: Platform not provided  
Reviewer instance ID: Platform not provided; local label `blind_review_81dbcf0f` is not a platform ID  
Fresh session: Yes  
Prior exposure to this project: No substantive prior exposure before opening the supplied archive  
Review date, time, and timezone: 2026-08-26 19:23:00, UTC+08:00, Asia/Shanghai (`China Standard Time`)  
Network, computation, and file-processing capability: Network available and restricted to necessary public primary sources/metadata; deterministic computation available; ZIP/PDF/Markdown processing and raster inspection available; no formal proof assistant or human reviewer used  
Input ZIP SHA-256: `81DBCF0FD08FE219E590D22B5850E180E9E3F4D05F105222205C9E7E92728DA0`  
Candidate PDF SHA-256: `D8DD7EB9F01038D0AA863F78C3972950AD98B6B6225E4A69D3CF7F92E45E2259`  
Output ZIP SHA-256: supplied in the external post-creation sidecar and delivery message, because a ZIP cannot contain its own immutable final hash  

