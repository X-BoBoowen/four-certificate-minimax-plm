# Source, model, and session declaration

Reviewer type (AI or human): AI.

Provider: OpenAI.

Model: GPT-5 family; the platform did not expose a more specific model identifier for this session.

Version or build: Platform not provided.

Session or instance identifier: Platform not provided.

Fresh session status: Yes. This review was started as a new isolated session for the supplied archive.

Prior manuscript or project exposure: No substantive prior exposure in this conversation or workspace was available to the reviewer before opening the supplied archive. All project knowledge used in the decision came from the input archive and the public primary sources explicitly logged during this review.

Date: 2026-08-26, 19:23:00 (UTC+08:00).

Timezone: Asia/Shanghai; Windows identifier `China Standard Time`, UTC+08:00.

Network capability: Available and used only for review-necessary public primary-source and metadata checks. No other reviews, private sources, author identities, modification histories, or expected outcomes were sought or read.

Tools used: Read-only ZIP inventory and SHA-256 hashing; safe extraction to a new directory; PDF metadata/text extraction; raster rendering and visual page inspection; numerical recomputation with deterministic Python code; public web retrieval of primary papers and formal metadata; local Markdown completion; ZIP creation and post-creation integrity verification. No formal proof assistant or external human reviewer was used.

Files read: Every file in the input ZIP: root `README.md`, `AI_OR_HUMAN_REVIEW_NOTICE.md`, `CANDIDATE_SHA256.txt`, `PACKAGE_MANIFEST.tsv`; all eight Markdown forms; and `manuscript/anonymous_manuscript.pdf` (34 pages). Public primary-source PDFs/records read for necessary citation and novelty checks are fully enumerated in `EXTERNAL_SEARCH_AND_TOOL_LOG.md`. No filled form or other project material outside the supplied archive was read.

Context-isolation statement: Isolation holds. The current conversation contained no substantive history about this manuscript, no prior score, no internal audit, no expected conclusion, and no other reviewer output before the archive was opened. The input ZIP remained unchanged.

Human identity or credential claimed: None.

Reviewer instance ID: Platform not provided. Local directory label `blind_review_81dbcf0f` is only an audit-isolation label derived from the input hash prefix; it is not a platform instance identifier.

Input ZIP SHA-256: `81DBCF0FD08FE219E590D22B5850E180E9E3F4D05F105222205C9E7E92728DA0`.

Output ZIP SHA-256: Supplied after immutable ZIP creation in the external `.sha256` sidecar and delivery message. A ZIP cannot contain its own final hash without changing that hash.

Full unedited raw output included: Yes — `RAW_REVIEW_OUTPUT.md` and `VERIFICATION_OUTPUT.txt`. The former preserves the complete public audit record and does not purport to expose private hidden chain-of-thought, which the platform does not provide.

