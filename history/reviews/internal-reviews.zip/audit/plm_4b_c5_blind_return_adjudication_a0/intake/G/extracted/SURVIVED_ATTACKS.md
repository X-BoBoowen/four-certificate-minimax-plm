# Claims that survived attempted falsification

## 1. Main quantifier logic

**Claim.** Separate public class pairs can establish the five component lower bounds.

**Strongest interpretation.** The theorem does not require one pair to make every term hard; it requires that, for every estimator-selection strategy indexed by a public pair, the outer worst-case pair realizes the claimed order.

**Required condition.** The risk must be exactly the paper's per-pair pointwise risk, and the lower proof must take a maximum rather than add incompatible Bayes risks.

**Attack.** I expanded the quantifiers, tried to construct an incompatibility between the component dictionaries, and checked the max-to-sum step.

**Outcome.** **SURVIVED ATTACK.** The dictionaries may differ because of the outer supremum. The paper takes a maximum of legal component lower bounds and then uses a deterministic equivalence for a fixed finite number of nonnegative terms. It does not assert simultaneous hardness.

**Locator.** PDF p. 2, Eq. (4); p. 3, Theorem 1; Appendices C–F, pp. 19–29.

## 2. Upper-rate algebra and selector

**Claim.** The two branch remainders and fallback yield `q+X` up to universal constants.

**Required condition.** All deterministic comparisons must hold on the full nonnegative budget cube, including zeros, ties, and branch boundaries.

**Attack.** Evaluated 28,561 boundary-grid points and 1,000,000 seeded random quadruples. Checked `V≤W≤4V`, `X/5≤V≤6X`, selected branch `≤2W`, and `S0≤X≤2S0`.

**Outcome.** **SURVIVED ATTACK.** All assertions passed. The observed extreme ratios were `min V/X=0.25`, `max V/X≈1.5740`, `max W/V=3.4`, and `max X/S0≈2.0`, within the manuscript's constants.

**Locator.** PDF pp. 12–13, Appendix B.1–B.3; `VERIFICATION_OUTPUT.txt`.

## 3. Upper empirical-process conditioning

**Claim.** The `O`- and `R`-style edits preserve the conditional centering required for the tail bounds, despite nuisance estimates being random.

**Required condition.** Each edit and nuisance substitution must be measurable with respect to a sigma-field that does not expose the residual whose conditional mean-zero property is used.

**Attack.** Traced sample splits and sigma-fields through Eqs. (B.9)–(B.33), especially the tail integrations and the selector/fallback closure. Tried the failure scenario in which the edit depends on the same residual.

**Outcome.** **SURVIVED ATTACK.** In the `O` branch the edit uses the appropriate treatment-side data while outcome noise remains centered conditional on the revealed variables; in the `R` branch the substitution order likewise avoids conditioning on the residual before applying the process bound. No circular dependence was found.

**Locator.** PDF pp. 15–19, Eqs. (B.9)–(B.33).

## 4. Sequential M1 closure and Borel measurability

**Claim.** Sequential pointwise density is sufficient to close the upper bound over the public class without assuming an uncountable measurable selector.

**Required condition.** The approximants share a bounded envelope, the finite-sample objectives converge, and the “first acceptable index” rule is countable/Borel.

**Attack.** Checked the pointwise-to-`L2` passage under bounded domination and the finite-sample first-hit rule.

**Outcome.** **SURVIVED ATTACK.** Dominated convergence supplies the population closure, and a first index in a countable representation is measurable. The claim remains limited to the stated sequential M1 field.

**Locator.** PDF pp. 2–3 and 11–12; p. 19, Eqs. (B.31)–(B.33).

## 5. Directional `P` lower experiment

**Claim.** A treatment-side estimation budget and outcome-side approximation budget interact to force `P=s(b∧s)`.

**Required condition.** The raw six-atom laws must be positive and normalized, satisfy conditional centering and constant variance, stay within support bounds, share the promised reference distribution, meet the public budgets, and produce the target gap at controlled chi-square/Gram energy.

**Attack.** Independently regenerated representative laws and recomputed every listed moment and energy quantity.

**Outcome.** **SURVIVED ATTACK.** Positivity, normalization, centering, variance, common reference, target gap, and Gram checks passed. The common-reference mismatch was at floating-point noise (`≤2.78e-17`).

**Locator.** PDF pp. 22–24, Appendix D, especially Eq. (D.4) and Lemma 6.

## 6. Directional `O` lower experiment

**Claim.** The role-reversed obstruction forces `O=t(a∧t)`.

**Attack.** Recomputed the construction directly rather than accepting an informal symmetry argument.

**Outcome.** **SURVIVED ATTACK.** The raw-law, moment, reference, target-gap, and Gram checks passed; the largest reference discrepancy was `5.55e-17`.

**Locator.** PDF pp. 24–26, Appendix E, especially Eq. (E.3) and Lemma 7.

## 7. `ab` and overlap `M` blocks

**Claim.** The inherited product and overlap components remain legal under the paper's exact budget field.

**Attack.** Recomputed representative raw masses, nuisance projections, support, moments, target gaps, and Gram quantities.

**Outcome.** **SURVIVED ATTACK.** All numerical identities and inequalities passed.

**Locator.** PDF pp. 26–29, Appendix F, Lemmas 8–9.

## 8. Saturation phase transition

**Claim.** At `v_-=B0^2`, bounded support forces a parametric experiment.

**Required condition.** The support bound applies to `u`, conditional variance is exactly `B0^2`, conditional mean is zero, and the treatment is bounded by the same envelope.

**Attack.** Checked equality in the conditional second-moment bound, tried asymmetric endpoint probabilities, and tested whether a nonzero `pi0(X)` could remain compatible with bounded treatment.

**Outcome.** **SURVIVED ATTACK.** Equality forces `|u|=B0` almost surely; conditional mean zero fixes equal endpoint probabilities; treatment boundedness then forces `pi0=0`. The moment estimator and parametric lower submodel give the stated order.

**Locator.** PDF pp. 29–31, Appendix H, Eqs. (H.1)–(H.6).

## 9. Novelty boundary

**Claim.** The upper architecture and `AB+M` ancestry are prior, while the exact `O/P` public-class lower closure is new.

**Attack.** Read the relevant theorem statements of the cited TAME, fuzzy-hypothesis, structure-agnostic, asymmetric minimax, binary-treatment, and calibrated-DML primary papers.

**Outcome.** **SURVIVED ATTACK with a bounded conclusion.** The ancestry claims are accurate, and no checked source states the same result. This supports originality but does not establish global priority.

**Locator.** PDF pp. 8–9, Section 11/Table 5; `NOVELTY_CITATION_LOG.md`.

