# Complete issue list

The labels below deliberately distinguish demonstrated failure, strong concern, plausible alternative, unverified suspicion, survived attack, non-assessability, and taste. No item is silently promoted across those categories.

## SC-1 — STRONG CONCERN: narrow external and operational scope

- **Locator:** PDF p. 2, Eq. (4); p. 3, Theorem 1 and its quantifier paragraph; p. 9, lines 456–463; Appendix A, pp. 11–12; Appendix I, pp. 31–33.
- **First point at which a broader claim would fail:** the risk definition takes an outer supremum over public class pairs and then an infimum over a pair-specific Borel rule. The class pair may depend on `n` and the budget cell. This is not the information structure of a single unknown-budget, implementable learner.
- **Independent evidence:** direct expansion of the quantifiers; Appendix I's explicit negative claims; the upper construction's dependence on public budgets and public class dictionaries.
- **Downstream impact:** the theorem does not by itself establish adaptation, computational feasibility, a common learner across classes/budgets, heteroskedastic robustness, confidence-interval validity, or empirical performance.
- **Minimal repair:** sharpen the abstract/introduction/conclusion so that “sharp minimax closure” is not read as a practical adaptive guarantee; give one concrete scientific use-case; ideally add a fixed-class or unknown-budget corollary.
- **Severity:** Moderate for significance and broader relevance; none for the correctness of the stated theorem.
- **Confidence:** High.

## CF-1 — CONFIRMED FAILURE: minor artifact omission

- **Locator:** PDF p. 9, Reproducibility Statement, lines 473–478; input `PACKAGE_MANIFEST.tsv`.
- **First failure:** the manuscript names `figures/generate_theory_summary.py`, but the archive contains no such file.
- **Independent evidence:** complete archive inventory and manifest verification.
- **Downstream impact:** Figure 1 cannot be regenerated exactly from the supplied review artifact. This does not undermine the analytic theorem or the independently checked rate algebra.
- **Minimal repair:** include the script and its environment/seed declaration or rephrase the reproducibility statement to say that the script exists in an external source distribution not supplied here.
- **Severity:** Minor.
- **Confidence:** High.

## PA-1 — PLAUSIBLE ALTERNATIVE: contribution may be viewed as exact interface closure rather than a new estimation paradigm

- **Locator:** PDF pp. 6–9, especially Section 11/Table 5; Appendix B, pp. 12–19; Appendices D–E, pp. 22–26.
- **Alternative explanation:** the upper architecture is TAME, `AB+M` is inherited fuzzy-hypothesis machinery, and related papers already use asymmetric perturbations. The new work could therefore be characterized primarily as proof engineering and closure of a carefully chosen minimax interface.
- **Independent evidence:** Balakrishnan–Kennedy–Wasserman arXiv:2607.21541, Theorem 3.1/Corollary 3.2; Gu–Liu–Han arXiv:2606.06368, Theorem A.1; Jin–Syrgkanis arXiv:2512.17341, Theorem 2.1/Remark 7.1; Jin–Guo–Rothenhäusler arXiv:2507.02275, Theorem B.1.
- **Attack result:** the alternative only partly succeeds. The checked sources do not state the same four-budget public-pair theorem, and they do not supply the `O/P` rate conclusion under the same information structure. Because `O/P` can dominate and change the minimax order, the contribution is more than a constant refinement.
- **Downstream impact:** affects rhetoric and perceived originality, not current correctness.
- **Minimal repair:** explicitly compare theorem hypotheses, estimator information, and rate conclusions with the closest asymmetric lower-bound results.
- **Severity:** Minor-to-moderate.
- **Confidence:** Medium-high; global priority remains unproved.

## US-1 — UNVERIFIED SUSPICION: compressed upper-bound constant bookkeeping

- **Locator:** Appendix B, PDF pp. 15–19, Eqs. (B.9)–(B.33), with the most delicate tail-integration/edit steps around (B.18)–(B.20) and (B.21)–(B.30).
- **Weakest premise:** the conditional edit events and random nuisance substitutions must preserve the centering and sigma-field relationships needed for the empirical-process tails uniformly over all legal laws.
- **Attack performed:** traced which split supplies each nuisance and edit, checked that the relevant residual remains conditionally centered after conditioning, followed the random-substitution order, and checked selector/fallback measurability.
- **Result:** no missing dependence or conditioning error was found. The suspicion remains unverified because the full constant chain was not machine-formalized.
- **Downstream impact if real:** could affect a universal upper-bound constant and hence Theorem 1. No evidence currently warrants calling this a failure.
- **Most discriminating test:** formalize the conditional maximal/tail lemmas with explicit sigma-fields and verify the admissible threshold constants mechanically.
- **Minimal repair:** state one consolidated lemma with explicit constants and all conditioning variables.
- **Severity:** Low residual probability, potentially major consequence.
- **Confidence:** Low that a defect exists; high that the performed attack found none.

## TP-1 — TASTE/PREFERENCE: dense audit-like exposition

- **Locator:** PDF pp. 1–10, especially Sections 5 and 9–12.
- **Evidence:** the main text spends substantial space on quantifier exclusions, negative claims, scope ledgers, and proof logistics. This aids auditing but obscures the conceptual arc.
- **Downstream impact:** higher verification and accessibility cost, especially for a general ICLR audience.
- **Minimal repair:** move most negative-claim taxonomy to an appendix; add a one-page map from each new term to its obstruction; reduce notation overload.
- **Severity:** Minor presentation preference, not a technical error.
- **Confidence:** High.

## NA-1 — NOT ASSESSABLE / not applicable: empirical validity

- **Locator:** PDF p. 9, Figure 1 and Reproducibility Statement.
- **Reason:** the paper advances a theoretical minimax claim and no empirical performance claim. There is therefore no dataset, stochastic experimental protocol, or statistical significance analysis to validate.
- **Downstream impact:** none for theorem correctness; practical relevance is less demonstrated.
- **Minimal repair:** no experiment is logically required, though a simulation of directional dominance could improve accessibility.
- **Severity:** None.
- **Confidence:** High.

## Confirmed theorem-level failures

None found.

