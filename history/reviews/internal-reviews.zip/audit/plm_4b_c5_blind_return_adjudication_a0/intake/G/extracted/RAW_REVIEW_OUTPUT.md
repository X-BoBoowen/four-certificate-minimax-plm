# Complete public raw review output

## Preservation note

This file is the complete public-facing audit record produced for this review session: input validation, reading record, claim map, attacks, observed results, literature checks, issue classification, and final decision calibration. It is included without removing failed attacks or negative findings. It does not claim to expose private hidden chain-of-thought or provider-internal traces, which the platform does not provide. The polished report is separately preserved in full as `FINAL_REVIEW_FULL.md`.

## 0. Isolation gate

- Session began with no substantive manuscript history in the conversation.
- No prior score, expected conclusion, internal audit, modification history, author identity, or other review was present.
- Isolation conclusion: **holds**.
- Review proceeded from the supplied ZIP only, with the root `README.md` treated as the sole project-level instruction.

## 1. Input validation

Input archive:

`D:/29722/Desktop/弱小但是有梦想的BoBoo文/paper/paper/audit/handoff_c5/PLM4B_C5_GENERAL_ICLR_REVIEWER_BLIND_REGRESSION.zip`

Input ZIP SHA-256:

`81DBCF0FD08FE219E590D22B5850E180E9E3F4D05F105222205C9E7E92728DA0`

Archive entries read:

1. `AI_OR_HUMAN_REVIEW_NOTICE.md`
2. `CANDIDATE_SHA256.txt`
3. `PACKAGE_MANIFEST.tsv`
4. `README.md`
5. `forms/AC_STYLE_SYNTHESIS_FORM.md`
6. `forms/EXPERTISE_CONFLICT_FORM.md`
7. `forms/ICLR_STYLE_REVIEW_FORM.md`
8. `forms/NOVELTY_CITATION_LOG.md`
9. `forms/RETURN_CHECKLIST.md`
10. `forms/SOURCE_MODEL_SESSION_DECLARATION.md`
11. `forms/SURVIVED_ATTACKS_UNRESOLVED_ISSUES_FORM.md`
12. `forms/TECHNICAL_ISSUE_LOG.md`
13. `manuscript/anonymous_manuscript.pdf`

Candidate PDF SHA-256:

`D8DD7EB9F01038D0AA863F78C3972950AD98B6B6225E4A69D3CF7F92E45E2259`

The candidate hash matched both the supplied candidate-hash file and manifest. Archive paths were validated before extraction. Extraction was to a new review directory. The input ZIP and PDF were not modified.

## 2. Manuscript reading record

- PDF length: 34 pages.
- All pages were text-extracted page by page.
- All pages were raster-rendered and visually inspected in nine contact sheets.
- High-resolution inspection was additionally performed for PDF pages 15, 17, 18, 19, 23, 25, 30, and 31, which contain the most decisive upper-bound, directional-lower, and saturation formulas.
- No clipping, missing page, overlapping formula, or broken figure was observed.
- Text extraction garbled some mathematical symbols; the rendered pages, not the garbled extraction, were used at those locations.

## 3. Raw global understanding after full read

Manuscript title: “Four-Budget Minimax Rates for Bounded Partially Linear Models.”

Model:

`T=pi_0(X)+u`,

`Y=beta_0 T+mu_0(X)+epsilon`,

with conditional centering, exactly constant `E[u^2|X]=v`, public bounded nuisance classes, sequential-M1 countable representations, bounded variables, and public exact upper budgets `a,s,b,t`.

Risk interface:

`sup_Gamma inf_{delta_Gamma Borel} sup_{P in P(Gamma)} E|delta_Gamma-beta(P)|`.

The class pair may depend on `n` and the budget cell, but is fixed before data and the latent hard label. The estimator may be selected separately for each public pair.

Rate notation:

- `q=n^{-1/2}`
- `A=a+s^2`
- `B=b+t^2`
- `M=(s∧t)^2`
- `O=t(a∧t)`
- `P=s(b∧s)`
- `X_rate=AB+M+O+P`

Theorem regimes:

- `v_->B0^2`: empty experiment.
- `0<v_-<B0^2`: risk of order `q+X_rate`.
- `v_-=B0^2`: parametric order.

Upper architecture:

- Two TAME-derived branches:
  - `T_mu=a(b+t)+(a+s)^2`
  - `T_pi=b(a+s)+(b+t)^2`
- Public-budget selector plus a fallback.
- Sequential-M1 closure and a Borel first-within-tolerance rule.

Lower architecture:

- Separate public pairs for `q`, `ab`, `M`, `O`, and `P`.
- The proof takes the maximum over legal component experiments and then uses deterministic equivalence to the sum-rate expression.
- Directional `O/P` blocks use six-atom common-reference constructions.

Initial strongest contribution hypothesis:

- New: necessity of `O/P`, exact public-class all-budget closure, and saturation phase analysis.
- Inherited: TAME upper structure and `AB+M` lower ancestry.

Initial likely weakness hypothesis:

- Specialized information structure and limited operational relevance, rather than an obvious mathematical flaw.

## 4. Attack record: main theorem quantifiers

Attack question: Can lower bounds proved on different public pairs be combined, or is the paper adding risks from incompatible experiments?

Required condition for validity: the outer supremum over public pairs must precede the pair-specific estimator infimum in the relevant sense, and the paper must use a maximum across component lower bounds.

Check performed: expanded Eq. (4); followed each component pair through Appendices C–F; inspected the max-to-sum deterministic step.

Observed result: each component is legal under its own public pair. The outer supremum can choose that pair. The paper obtains a maximum and invokes a fixed finite-term equivalence. It does not sum Bayes risks from different experiments.

Attack result: **SURVIVED ATTACK**.

Residual boundary: the conclusion is specific to the stated per-pair risk and does not automatically transfer to a common learner.

## 5. Attack record: deterministic upper-rate algebra

Attack question: Do the branch comparisons fail on zero budgets, tie surfaces, or directional-transition cells?

Checks:

- `V≤W≤4V`
- `X_rate/5≤V≤6X_rate`
- chosen branch `≤2W`
- `S0≤X_rate≤2S0`

Input coverage:

- 28,561 boundary-grid quadruples.
- 1,000,000 seeded random quadruples.

Observed extrema:

- `min V/X_rate = 0.25`
- `max V/X_rate = 1.5740182061439176`
- `max W/V = 3.4`
- `max X_rate/S0 = 2.0000000000000004`

Every assertion passed.

Attack result: **SURVIVED ATTACK**.

## 6. Attack record: upper empirical-process edits

Attack question: Does an edit or random nuisance choice condition on the same residual whose mean-zero property is used?

Locations read at high resolution:

- PDF p. 15, Eqs. (B.9)–(B.11)
- p. 17, Eqs. (B.18)–(B.20)
- pp. 17–18, Eqs. (B.21)–(B.30)
- p. 19, Eqs. (B.31)–(B.33)

Check performed: tracked the data split supplying each nuisance, edit, and estimator; enumerated the variables revealed before conditional centering; checked tail-integration ordering; checked selector/fallback measurability.

Observed result: no edit was found to reveal the relevant residual before its conditional process inequality. The forward and reverse edits use different split information in a coherent order. Countable selection closes the rule.

Attack result: **SURVIVED ATTACK**, with a residual **UNVERIFIED SUSPICION** about the full universal-constant chain because it was not machine-formalized.

## 7. Attack record: sequential-M1 closure

Attack question: Is pointwise sequential approximation insufficient for the population and finite-sample objectives, or is the selected approximant nonmeasurable?

Check performed: verified common bounded envelope, dominated-convergence passage, finite-sample objective convergence, and countable first-hit rule.

Observed result: bounded domination supplies `L2` convergence; the finite-sample objective is continuous along the pointwise sequence at observed points; first acceptable index is Borel.

Attack result: **SURVIVED ATTACK**.

Boundary: no claim beyond sequential-M1 classes was inferred.

## 8. Attack record: lower raw laws

Representative channel used in recomputation:

`Channel(v0=1.0, B0=3.0, m_rho=0.015625, L=1.03125)`.

For `P`, `O`, `ab`, and `M`, recomputation covered:

- total mass;
- first and second treatment moments;
- outcome moment;
- treatment-outcome cross moment;
- minimum raw mass;
- common-reference equality;
- conditional-centering identities;
- target gap;
- Gram quantities;
- normalization by the predicted rate term.

Observed result:

- All raw masses positive at the test points.
- All total masses equal one to floating precision.
- Centering residuals were zero or at `5.42e-20` noise.
- Largest common-reference discrepancy: `5.55e-17`.
- Target gaps had the claimed `P`, `O`, `ab`, or `M` order.
- All asserted Gram bounds passed.

Attack results:

- `P`: **SURVIVED ATTACK**.
- `O`: **SURVIVED ATTACK**.
- `ab`: **SURVIVED ATTACK**.
- `M`: **SURVIVED ATTACK**.

Full numeric output is preserved verbatim in `VERIFICATION_OUTPUT.txt`.

## 9. Attack record: saturation

Attack question: At `v_-=B0^2`, can unequal endpoint probabilities or nonzero `pi_0(X)` avoid collapse?

Check:

1. `|u|≤B0` and `E[u^2|X]=B0^2` force `u^2=B0^2` almost surely.
2. `E[u|X]=0` forces equal conditional probabilities on `±B0`.
3. If `T=pi_0(X)+u` must also stay within the bound at both endpoints, `pi_0(X)=0`.
4. The remaining moment estimator has parametric variance.
5. A legal two-point submodel supplies a parametric lower order.

Observed result: the proposed counterexamples violate explicit support or centering assumptions.

Attack result: **SURVIVED ATTACK**.

## 10. Prior-work attack record

Public primary sources read:

- Gu (2025), PMLR open-problem paper.
- Balakrishnan–Kennedy–Wasserman (arXiv:2607.21541), TAME upper theorem/corollary.
- Gu–Liu–Han (arXiv:2606.06368), fuzzy lower Theorem A.1.
- Balakrishnan–Kennedy–Wasserman (arXiv:2305.04116), general structure-agnostic lower framework.
- Jin–Syrgkanis (arXiv:2512.17341), asymmetric minimax Theorem 2.1 and Remark 7.1.
- Jin–Guo–Rothenhäusler (arXiv:2507.02275), binary-treatment Theorem B.1.
- van der Laan–Luedtke–Carone (arXiv:2411.02771), calibrated-DML neighbor.

Bibliographic metadata for the remaining references was checked using formal DOI/arXiv/venue records.

Observed result:

- The TAME branch formulas match the manuscript's claimed upper ancestry.
- Gu–Liu–Han supplies the `AB+M` ancestry.
- Closest asymmetric lower work uses related ideas but different fixed-pilot/anchored information structures and different rate statements.
- No checked source states the same exact public-pair four-budget theorem or `O/P` conclusion.

Attack result: **SURVIVED ATTACK with bounded novelty claim**.

Important limitation: no finite search proves global priority. Non-hits were not converted into a priority statement. A search result that exposed an OpenReview link was not opened.

## 11. Reproducibility audit

Manuscript statement: Figure 1 can be generated by `figures/generate_theory_summary.py`.

Archive finding: the full ZIP inventory contains no `figures` directory and no such script.

Classification: **CONFIRMED FAILURE — minor artifact omission**.

Impact: exact figure rendering cannot be reproduced from the package; theorem correctness is unaffected; rate algebra was independently checked.

## 12. Scope and alternative-explanation audit

Confirmed scope facts:

- exact budgets known;
- class pairs may depend on `n` and budget cell;
- estimator may be arbitrary pair-specific Borel map;
- lower dictionaries can be tailored to the field;
- bounded variables;
- constant conditional treatment variance;
- fixed infinite standard Borel ambient space;
- no adaptation, common efficient procedure, confidence interval, or empirical claim.

Classification: **STRONG CONCERN** for scientific significance and broader relevance; not a correctness failure.

Plausible alternative novelty account:

“The paper mainly closes an engineered interface using inherited TAME and fuzzy/asymmetric machinery.”

Result of testing that alternative:

- Partly supported: upper architecture and much lower machinery are inherited.
- Not sufficient: `O/P` alter the rate order and are not stated in the checked same-neighborhood sources; exact closure has independent technical content.

Classification: **PLAUSIBLE ALTERNATIVE**, attack only partly succeeds.

## 13. Final independent dimension calibration

- Correctness: 4/5.
- Originality: 4/5, without global priority claim.
- Technical depth: 5/5.
- Scientific significance: 3/5.
- Conceptual insight: 4/5.
- Empirical validity: not applicable.
- Reproducibility: 3/5.
- Clarity: 3/5.
- Broader relevance: 3/5.
- ICLR community value: 4/5.
- Assumption realism: 2/5.

No dimension was used as a substitute for another.

## 14. Final decision record

Strongest acceptance reason: no confirmed theorem flaw after targeted attacks; `O/P` are order-changing directional insights; technical depth is exceptionally high.

Strongest rejection reason: the theorem field is restrictive and does not yield a common adaptive or computational learner; broader venue impact is therefore debatable.

Decisive issue: significance within ICLR, not demonstrated correctness failure.

Reviewer recommendation: **6/10 — Weak Accept**.

Reviewer confidence: **4/5**.

AC-style advisory synthesis: **Lean Accept / Weak Accept**.

Evidence that would reverse the decision: a same-interface prior theorem; an explicit invalid conditioning step in Appendix B; a symbolic budget violation in a directional raw law; or a failure of the M1 measurable closure.

Evidence that would strengthen acceptance: a common/adaptive learner, computational corollary, concrete use-case for directional dominance, or formal proof supplement.

## 15. Metadata record

Provider: OpenAI.

Model: GPT-5 family; exact model identifier not exposed.

Exact model/version: Platform not provided.

Session or instance ID: Platform not provided.

Reviewer instance ID: Platform not provided. `blind_review_81dbcf0f` is a local isolation label only.

Fresh session: Yes.

Prior substantive project exposure: No.

Review timestamp: 2026-08-26 19:23:00 UTC+08:00, Asia/Shanghai / China Standard Time.

Network: available; used only for necessary public primary sources and formal metadata.

Computation: available; deterministic numerical verification performed.

File processing: ZIP inventory/hash/extraction; PDF text/raster inspection; Markdown output; ZIP delivery.

Human identity or credential: none claimed.

Input ZIP SHA-256: `81DBCF0FD08FE219E590D22B5850E180E9E3F4D05F105222205C9E7E92728DA0`.

Candidate PDF SHA-256: `D8DD7EB9F01038D0AA863F78C3972950AD98B6B6225E4A69D3CF7F92E45E2259`.

Output ZIP SHA-256: supplied externally after immutable ZIP creation.

