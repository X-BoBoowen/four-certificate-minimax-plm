# 独立盲审完整原文

## Review setup

- **输入范围**：指定 ZIP 根目录 README、包内全部表格与声明文件、34 页匿名论文 `anonymous_manuscript.pdf`、36 页 Bartlett--Bousquet--Mendelson (2005) 原始论文。
- **审查边界**：只审查包内材料。未检索作者身份、其他审稿结果、修改历史、内部审计、旧评分或预期结论；未进行网络搜索。外部定理只使用包内 BBM 原始论文核验。
- **论文核心主张**：在一个预先固定的非空无限标准 Borel 协变量空间、顺序 M1 可测访问、已知四个预算和条件残差方差常数的有界 PLM 中，成对 Q1 minimax 绝对误差在严格内部层满足
  \[
  R_{n,\rho}^{\mathrm{pair}}(a,s,b,t)\asymp_\rho q+X,
  \quad q=n^{-1/2},
  \]
  其中
  \[
  X=(a+s^2)(b+t^2)+(s\wedge t)^2+t(a\wedge t)+s(b\wedge s).
  \]
  在 \(v_->B_0^2\) 时实验为空，在 \(v_-=B_0^2\) 时倾向函数被识别为零且速率退化为纯参数阶 \(n^{-1/2}\)。
- **可见证据链**：上界由顺序 M1 转移、局部 Rademacher 过程、初始拟合、O/R 两个校准分支、全尾积分、四格选择器和 Q1 提升组成；下界由 q、P、O、ab、M 五个有限实验、共同参考分布、Gram/χ²/TV 检验、最大值到求和代数组装组成；E/S 边界另证。
- **缺失材料**：就数学正确性而言没有必需材料缺失。创新性/优先权没有在本盲审中独立检索，故不作优先权结论。

## 总体数学判决

**通过。** 在规定的定理域内，我没有发现已证实的数学错误、结论级证明缺口、错误量词交换或失败的边界情形。论文的主要速率、五个下界分量、固定空间实现、M1/Q1 接口和 E/I/S 分层均经受住独立重算与主动反例攻击。

置信度：**高**。最强残余风险位于 PDF pp. 16--19 的 O/R 全尾不等式 (B.18)、(B.29) 及逐项 layer-cake 拼装；这些段落常数记账密集，但我逐项核对了所有保留单项、放大项、半径分母和积分尺度，未找到第一处失败蕴含。该残余风险不构成已确认问题。

分类结果：

- 已证实的数学错误：0。
- 需要补充才能成立的局部证明缺口：0。
- 只在额外条件下成立但正文未声明的结论：0。
- 已声明且确实必要的定理条件：固定无限标准 Borel 环境空间、顺序 M1 表示、固定 \(\rho\)、已知预算、同方差常数、成对 Q1 量词顺序。
- 表达/排版问题：3 个明显拼写错误，分别为 PDF p.13 “copntraction”、p.19 “clpipping”、p.32 “rapdius”；均不影响公式或证明。
- 尚未确认的风险：长篇 O/R 常数记账仍是最难人工复核的部分；没有发现矛盾或反例。
- 经受住独立重算和反例攻击的承重结论：见下文及独立推导记录。

## Reviewer 1（侧重技术正确性）

### Overall assessment

技术主张在其明确限定的模型与访问接口内成立。证明最值得怀疑的节点不是五个有限下界本身，而是：从全类到可数表示的转移、联合初始拟合的曲率、随机校准比较器的合法插入、O/R 分支尾积分，以及成对 minimax 量词提升。逐项重算后，这些节点均闭合。

### Who would be interested in the results, and why

对结构不可知半参数估计、正交学习、局部复杂度和 minimax 下界感兴趣的读者会关心该结果，因为它展示了把两个 nuisance learner 各压成单个误差量会丢失方向性信息；\(O=t(a\wedge t)\) 与 \(P=s(b\wedge s)\) 可在显式射线上把继承的 \(AB+M\) 下界提高一个非恒定因子。

### Major strengths

1. **量词域明确且闭合**。PDF pp.2, 11--12 的 (4) 与 Appendix A 固定了环境空间，然后才允许 \(n\)、预算、公开类对和协变量分布变化。上界先对每个固定 \(\Gamma\) 构造一个 Borel 规则并对 \(P\in\mathcal P(\Gamma)\) 一致，再取外层 \(\sup_\Gamma\)；下界每个分量只需向同一外层上确界插入一个合法类对，没有交换 \(\sup\inf\)。
2. **固定空间 Walsh 实现正确**。PDF p.21 先在可数不交并 \(\bigsqcup_m(\mathbb Z/2\mathbb Z)^m\) 上选取到固定 \(\mathcal X\) 的可测注入；每个有限块的非零字符在块内均值零、单位 \(L_2(P_X)\) 范数、两两正交，块外零延拓保持可测和包络。变化的是有限支持 \(P_X\) 与公开类对，不是环境空间。
3. **BBM 外部叶映射完整**。论文 Lemma 4（PDF pp.12--13, (B.2)）把 BBM Theorem 2.1（包内原始论文 PDF p.6；证明 p.30）应用于 \(\mathcal W\cup(-\mathcal W)\)，映射 \([a,b]=[-B,B]\)、\(r=\sigma^2\)、\(x=z\)、\(\alpha=1\)。系数分别成为 \(4\mathfrak R_n\)、\(\sqrt{2\sigma^2z/n}\) 与 \(8Bz/(3n)\)；对称类的一侧上确界正好是绝对上确界。原文概率 \(1-e^{-z}\)，正文写成失败概率 \(2e^{-z}\) 仅更保守。
4. **顺序 M1 转移足够强**。Lemma 6（PDF p.14）使用共同包络加支配收敛得到总体 \(L_2(P_X)\) 稠密性，使用有限评价向量的连续性得到经验目标转移；两条表示序列配对即可逼近全差分类。可数 Borel 目标的下确界是 Borel，正容差下“第一个达标索引”必然存在且 Borel。
5. **联合初始拟合没有隐藏的拓扑闭包**。PDF pp.14--15 的联合类
   \[
   \mathcal J_\mu=\{\gamma T+f(X):\gamma\in\mathbb Q\cap[-6,6],\ f\in\Delta\mathcal G_\mu^{\rm rep}\}
   \]
   是可数、有固定包络，并由正交恒等式
   \(\|\gamma T+f\|_2^2=v\gamma^2+\|\gamma\pi_0+f\|_2^2\)
   控制 \(|\gamma|\) 和 \(\|f\|_2\)。其局部复杂度由一个标量 Rademacher 项加公开差分类项控制，足以应用 Lemma 5。曲率 (B.8) 的常数可由二维 Gram 矩阵最小特征值下界重得。
6. **(B.7) 与 (B.9) 可独立重构**。倾向拟合的基本不等式是 (B.6)；统一 multiplier/square 过程和固定比较器 Bernstein 后吸收二次项，得到 \(b+t+\bar t+\sqrt{z/n}+\rho_n\) 阶。联合拟合对 \(j=(\hat\beta_0-\beta^\circ)T+(\hat\mu-g^\circ)\) 重复同一过程，再以 (B.8) 转回参数和 nuisance 范数，得到 (B.9)。拟合索引始终在统一事件之后插入。
7. **校准比较器合法**。O 分支的 \(a_0=u/P_1(Tu)\) 只是证明比较器。条件 \(E[f(X)u]=0\)、方差分母事件和 Lemma 5 给出 (B.12)；拟合分母投影保留 \(D_0\)，得到 (B.13)。校准目标先对可数表示差分类取统一上确界，再插入随机拟合差，故 (B.16) 没有随机索引漏洞。R 分支的 (B.25) 同样在统一事件上成立；D2 结局和 D1 协变量进入编辑时，D1 处理变量仍未被冻结。
8. **O/R 尾积分闭合**。在 O 分支，\(r=\bar s\ge C_{\rm rad}h_n\)、\(d\lesssim y+r+\rho_n\)、\(\lambda_O d^2\asymp r^2\)、\(\ell=\sqrt{\tau_n/\lambda_O}\asymp\rho_nd/r\)。因此 (B.18) 中线性 \(w_z\)、\((ad/r)w_z\)、\(w_z^2\)、\((d/r)w_z^2\)、\(w_z^3\)、\(\ell w_z\) 的积分尺度分别是 \(q,(ad/r)q,q^2,d/(nr),q^3,\ell q\)，均被 \(q+ay+x^2\) 吸收。R 分支是独立推导，尺度对应 \(q+bx+y^2\)。未发现漏掉的 \(\lambda^{-1}w_z^2\) 或三次放大项。
9. **选择器与 Q1 提升正确**。对 \(V=\min\{a+s^2,xy,T_\mu,T_\pi\}\)、\(W=T_\mu\wedge T_\pi\)，(B.31) 的 \(V\le W\le4V\) 与 \(X/5\le V\le6X\) 在零点和等号处也成立。公开选择方向满足 \(T_{\rm selected}\le2W\le48X\)。不安全格中，若半径地板已大则 \(q\) 为常数级；否则 \(s\) 或 \(t\) 迫使 \(M/P/O\) 至少为固定常数级，零回退的损失可被 \(q+X\) 吸收。
10. **下界通道一致**。三点处理通道 (C.5)--(C.7) 的三原子质量严格为正，均值为 \(m\)，二阶矩为 \(v_0+m^2\)，方差为 \(v_0\)。P/O/ab/M 四个通道的共同参考分布恒等式、中心似然系数和 Gram 能量均可直接由六原子质量相乘重得。\(p=\lceil e^{64N r^2}\rceil\) 抵消 \(N\)-重积的同坐标能量，给出远小于 \(1/2\) 的交叉标签 TV。
11. **最大值到和式的拼装没有混合不同先验**。每个分量都是同一标量风险的合法下界，所以先取五项最大值；再用最大值至少为和的五分之一以及 \(S_0\le X\le2S_0\) 得 (G.3)。没有把不同公开类对上的 Bayes 风险相加。
12. **E/S 和有限空间边界清楚**。\(|u|\le B_0\) 直接给 E 层空性。饱和时 \(u^2=B_0^2\) 且条件均值为零，故 \(u=\pm B_0\) 等概率；\(|T|\le B_0\) 进一步强制 \(\pi_0=0\)，从而 \(\beta_0=E(TY)/B_0^2\)。固定无限环境空间上的单点支持下界并不把环境空间变成有限空间；相反，Appendix I.1 明确给出真正单点环境空间上的配对差分 root-n 上界，说明为何内部匹配定理必须排除有限环境空间。

### Major concerns

没有已确认的 major concern。最强残余审查点是 (B.18)/(B.29) 的常数记账密度；独立重算未发现错误。

### Technical failings that need to be addressed before the case is established

无。就当前陈述的定理域而言，作者的技术论证已经建立。可选改进是把 (B.7)、(B.9) 的吸收代数和 (B.18)、(B.29) 的逐项积分整理成一张补充表，以降低复核成本；这不是成立性所必需的修复。

### Assessment against Nature-style criteria

- **Originality**：论文内部清楚区分继承的上界架构、q/ab/M 先例与所声称的 O/P 必要性；未进行外部优先权搜索，因此独立优先权不可判定。
- **Scientific importance**：若读者关心结构不可知半参数 minimax 理论，方向性四预算分解具有明确理论意义。
- **Interdisciplinary readership**：主要影响仍是理论统计与理论机器学习内部；对更广泛读者需要更直观解释为何公开预算而非实现误差是自然对象。
- **Technical soundness**：通过。
- **Readability for nonspecialists**：主文的相图和边界说明有帮助，但附录高度压缩，不适合非专业读者独立核验。

### Recommendation posture

数学正确性层面支持通过；不代替编辑对创新性、会议契合度或广泛影响的判断。

## Reviewer 2（侧重原创性与科学意义）

### Overall assessment

论文最有意义的内容不是又一个 product remainder，而是证明 \(O\) 与 \(P\) 在同一精确定理域内分别必要，并说明它们可比最近的 \(AB+M\) 下包络大无界倍数。该结论由不同统计通道而非变量重命名得到，避免了“对称性自动给出另一方向”的常见误判。

### Who would be interested in the results, and why

半参数 minimax、黑箱 nuisance 访问、局部复杂度与有限混合检验研究者会直接感兴趣；正交学习研究者也会关心“单个 nuisance error”何时不足以描述可达风险。

### Major strengths

- 贡献边界克制：正文明确不声称通用编辑器、未知预算自适应、计算效率、因果解释或优先权非碰撞。
- O 射线 \((a,t)=(r,r),b=s=0\) 与 P 镜像射线上，继承项为 \(r^3\)，方向项为 \(r^2\)，分离是阶数而非常数。
- 五个下界机制分别证成，随后只通过外层公开类对上确界与确定性代数结合，逻辑上干净。
- E/I/S 相变不是把内部常数连续延伸到边界，而是由包络饱和产生的识别结论。

### Major concerns

创新性与优先权不在本次盲审可确认范围，因为按任务约束没有搜索包外文献。这个限制不能被解释成新颖性反证或支持。

### Technical failings that need to be addressed before the case is established

无已确认技术失败。若用于更广泛受众，建议主文再解释“公开预算上证书”和“成对 Q1 规则”与常见统一算法/未知预算问题的区别，以防止过度外推。

### Assessment against Nature-style criteria

- **Originality**：从包内对比看，O/P 匹配必要性是明确主张；外部独立原创性未评估。
- **Scientific importance**：对理论半参数学习是实质性的精细化；是否达到跨领域突出重要性不由本审查裁定。
- **Interdisciplinary readership**：目前较窄。
- **Technical soundness**：通过。
- **Readability for nonspecialists**：摘要清楚列出结果，但 M1/Q1、公开预算与五机制需要领域背景。

### Recommendation posture

理论贡献在其专业领域内有清晰价值；广泛影响与优先权仍需独立编辑/文献评估。

## Reviewer 3（侧重跨领域可读性与边界表达）

### Overall assessment

论文在非主张事项、量词顺序和边界相变方面异常谨慎，这显著降低了误读风险。主要可读性障碍是附录中大量常数与压缩吸收步骤，而不是定义缺失。

### Who would be interested in the results, and why

除核心理论读者外，研究校准估计和黑箱 nuisance 学习的人会从“方向选择由公开预算决定而非由实现风险决定”这一设计原则受益。

### Major strengths

- 表 1、表 4、Appendix I 和依赖图明确区分公开输入、证明比较器、禁止的 oracle 与不声称的扩展。
- 单点分布、有限环境空间、零预算、等预算、\(n=1\)、\(n=16\)、\(s^2=q\)、\(t^2=q\)、饱和等号均被显式处理。
- 论文没有用计算实验替代证明；附录给出原始六原子质量和可复算常数。

### Major concerns

非专业读者很难仅凭 (B.18)/(B.29) 看出每个尾单项为什么可积并落入目标率。建议增加一张“单项--积分尺度--吸收项”表。另有三处无害拼写错误。

### Technical failings that need to be addressed before the case is established

无。上述建议是可读性增强，不是数学修复。

### Assessment against Nature-style criteria

- **Originality**：未独立评估包外优先权。
- **Scientific importance**：对精细 minimax 理论有意义。
- **Interdisciplinary readership**：当前表达主要服务本领域专家。
- **Technical soundness**：通过。
- **Readability for nonspecialists**：主文中等，证明附录低；边界声明则非常清楚。

### Recommendation posture

支持数学正确性；建议做轻量可读性增强。

## Cross-review synthesis

- **Consensus strengths**：量词闭合、固定环境空间实现、M1 转移、BBM 映射、O/R 上界接口、五分量有限下界、最大值拼装和 E/S 边界均成立。
- **Consensus technical risks**：唯一显著残余风险是 O/R 长尾常数记账的人工复核成本，而非已发现错误。
- **Where emphasis differs**：Reviewer 1 重技术承重点；Reviewer 2 重 O/P 的理论意义与优先权边界；Reviewer 3 重可读性和防止范围外推。
- **Broad-interest / significance readout**：对理论统计和理论机器学习有直接兴趣；跨学科广泛兴趣尚未由本盲审建立。
- **Most important issues to resolve before a strong broad-interest case is established**：不是正确性修复，而是更直观地解释四预算方向性为何在实际理论工作流中自然，以及增加尾积分记账表。

## Risk / unsupported claims

1. **外部原创性/优先权**：未评估；不得由“未搜索”推导任何结论。
2. **范围外推广**：论文不支持未知预算自适应、统一类对规则、异方差、有限环境空间匹配、计算效率、置信区间或因果解释。
3. **常数记账残余风险**：B.18/B.29 虽通过本次重算，但由于链条长，仍是未来人工复核最值得重复检查的节点。
4. **平台限制**：无法披露平台未提供的精确模型构建号和会话实例 ID；没有猜测这些字段。

## 最终结论

在 README 规定的全部最低范围以及额外承重节点上，论文经受住了独立推导、边界攻击和有限通道重算。最终数学判决为：**通过；没有已证实的实质数学问题。**

