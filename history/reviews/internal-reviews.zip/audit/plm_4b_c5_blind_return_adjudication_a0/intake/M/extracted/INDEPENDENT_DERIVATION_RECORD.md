# 独立推导记录

本文件记录可公开复核的数学推导与检查结论，不包含未表达的内部思维过程。页码均指匿名论文 PDF 页码；BBM 页码明确标注为包内原始论文 PDF。

## D1. 定理域与量词顺序

论文风险为（PDF p.2, (4)）
\[
R_{n,\rho}^{\rm pair}(a,s,b,t)
=\sup_{\Gamma\in\mathfrak G_{\rho,n}(a,s,b,t)}
\inf_{\delta_\Gamma\ \mathrm{Borel}}
\sup_{P\in\mathcal P(\Gamma)}
E_P|\delta_\Gamma-\beta(P)|.
\]
环境空间 \((\mathcal X,\mathcal A)\) 在 \(n\)、预算、\(\Gamma\) 和 \(P\) 之前固定，且不是 \(\Gamma\) 的坐标。上界只需证明：对每个固定合法 \(\Gamma\)，存在一个允许依赖 \(\Gamma,\rho,a,s,b,t\) 的 Borel 规则，使其对所有 \(P\in\mathcal P(\Gamma)\) 一致；然后才取 \(\sup_\Gamma\)。下界每个机制选取一个固定公开类对 \(\Gamma_j\)，故外层上确界分别支配每个固定类对的 minimax 风险。不存在 \(\sup\inf\) 交换。

结论：量词顺序正确。

## D2. 固定空间 Walsh 注入与零延拓

令
\[
\mathcal D=\bigsqcup_{m\ge1}(\mathbb Z/2\mathbb Z)^m.
\]
\(\mathcal D\) 可数，固定无限标准 Borel 空间中的单点均可测，故可预先选取单射 \(\iota:\mathcal D\to\mathcal X\)。对需要的 \(p\) 个方向取 \(m=\lceil\log_2(p+1)\rceil\)，因为非零 Walsh 字符数为 \(2^m-1\ge p\)。在第 \(m\) 个有限像块 \(S_m\) 上取均匀 \(P_X\)，则非零字符满足
\[
E\phi_j=0,\qquad E\phi_j^2=1,\qquad E\phi_j\phi_k=0\ (j\ne k).
\]
块外定义为零保持可测与点态包络；相对于该 \(P_X\)，均值、\(L_2\) 范数与 Gram 矩阵完全不变。所有块来自同一预选注入，因此改变 \(n\) 或预算不会改变环境空间。

结论：PDF p.21 Appendix C.4 的固定空间实现正确；单点或有限支持协变量分布不等于有限环境空间。

## D3. 顺序 M1 转移（Lemma 6）

若 \(g_k^{\rm rep}\to g\) 点态且所有函数被共同 \(B_G\) 包络，则
\[
|g_k^{\rm rep}-h|^2\le (B_G+\|h\|_\infty)^2
\]
给出支配收敛，故 \(\|g_k^{\rm rep}-h\|_{L_2(P_X)}\to\|g-h\|_{L_2(P_X)}\)。表示类是全类子集，所以两个总体下确界相等。

对任意固定有限样本，目标函数只依赖有限评价向量；平方、绝对值、乘积和有限和连续，故表示序列的经验目标收敛到全类目标。对差分类，分别取 \(g_k\to g\)、\(g'_k\to g'\)，再沿对角线配对，即得 \(g_k-g'_k\to g-g'\) 的有限向量收敛，所需校准上确界相等。

若 \(L_j(D)\) 为可数表示上的 Borel 目标，则 \(L_*(D)=\inf_jL_j(D)\) Borel。对 \(\tau>0\)，集合 \(\{j:L_j\le L_*+\tau\}\) 非空，取最小索引是 Borel。

结论：PDF p.14 Lemma 6 的四项转移均成立。

## D4. BBM Theorem 2.1 到 Lemma 4

BBM Theorem 2.1（包内原始论文 PDF p.6；证明 p.30）给出
\[
\sup_{f\in\mathcal F}(Pf-P_nf)
\le 2(1+\alpha)E R_n\mathcal F
+\sqrt{2rx/n}
+ (b-a)(1/3+1/\alpha)x/n
\]
，第一部分失败概率为 \(e^{-x}\)。

取 \(\mathcal F=\mathcal W\cup(-\mathcal W)\)，则范围 \([-B,B]\)，方差界 \(\sigma^2\)，且因 \(PW=0\)，
\[
\sup_{f\in\mathcal F}(Pf-P_nf)=\sup_{W\in\mathcal W}|P_nW|,
\quad ER_n\mathcal F=\mathfrak R_n(\mathcal W).
\]
令 \(\alpha=1,x=z\)，得到
\[
Z\le4\mathfrak R_n(\mathcal W)+\sqrt{2\sigma^2z/n}+8Bz/(3n).
\]
正文写失败概率 \(2e^{-z}\) 比原始 \(e^{-z}\) 更保守。可数性保证可测上确界。

结论：PDF pp.12--13 (B.2) 的外部定理使用无误。

## D5. 局部 multiplier/square 过程（Lemma 5）

令
\[
\delta_z=K_1(r_0\vee h_n)+\sqrt{z/n},\qquad h_n=\sqrt{\log(en)/n}.
\]
以 \(\|f\|_2\le\delta_z\) 为内球，并取半径 \(R_j=2^j\delta_z\) 的壳。包络 \(B\) 使壳数
\[
J\le\lceil\log_2(B/h_n)\rceil_+\lesssim\log(en),
\quad \sqrt{j/n}\lesssim h_n,
\quad j/n\lesssim h_n^2.
\]

对 multiplier 类，条件收缩给出未中心 Rademacher 均值 \(\lesssim L\mathfrak R_n(R_j;\mathcal H)\)，中心化至多再加 \(LR_j/\sqrt n\)，总均值为 \(O(\delta_zR_j)\)。方差为 \(O(R_j^2)\)，范围固定。对 square 类，\(u\mapsto u^2\) 在 \([-B,B]\) 上为 \(2B\)-Lipschitz，方差 \(\le B^2R_j^2\)，得到同阶均值。对第 \(j\) 壳分配 \(x_j=z+2j+\log8\)，失败概率形成几何和；BBM Lemma 4 的方差项为 \(O(\delta_zR_j)\)，范围项为 \(O(\delta_z^2)\)。内球令 \(R_0=\delta_z\)，外壳用 \(R_j<2\|f\|_2\)。

结论：PDF p.13 (B.2a)--(B.4) 覆盖 \(n=1\)、零预算、最大壳和内球等于全类的情形，不需要 star-shapedness。

## D6. (B.7)、差分核心、(B.8) 与 (B.9)

倾向初始拟合令 \(h=\hat\pi-g_\pi\)、\(k=g_\pi-\pi_0\)。近似经验最小化给出
\[
P_2h^2\le2P_2(uh)-2P_2(kh)+\tau_n.
\]
在统一 multiplier/square 事件上，第一项为 \(O(\delta\|h\|_2+\delta^2)\)；固定比较器的经验 \(L_2\) 范数为 \(O(b+\sqrt{z/n})\)。经验 Cauchy--Schwarz 与二次吸收给出
\[
\|\hat\pi-\pi_0\|_2\lesssim b+t+\bar t+\sqrt{z/n}+\rho_n,
\]
即 (B.7)。

联合拟合的随机差属于
\[
\mathcal J_\mu=\{\gamma T+f(X):\gamma\in\mathbb Q\cap[-6,6],\ f\in\Delta\mathcal G_\mu^{\rm rep}\}.
\]
若 \(\|\gamma T+f\|_2\le R\)，则
\[
R^2\ge v\gamma^2+\|\gamma\pi_0+f\|_2^2,
\quad |\gamma|\le R/\sqrt{v_-},
\quad \|f\|_2\le C_\rho R.
\]
故其局部复杂度由标量项 \(O(R/\sqrt n)\) 与 \(\mathfrak R_n(C_\rho R;\Delta\mathcal G_\mu)\) 之和控制，在正半径地板 \(C_\rho(s\vee h_n)\) 上满足 Lemma 5 假设。

曲率恒等式为
\[
P(\gamma T+f)^2=v\gamma^2+\|\gamma\pi_0+f\|_2^2.
\]
令 \(A=\|\gamma\pi_0+f\|_2\)。由 \(\|f\|_2\le A+B_0|\gamma|\)，
\[
\gamma^2+\|f\|_2^2\le2(1+B_0)^2(\gamma^2+A^2).
\]
又 \(v\gamma^2+A^2\ge\min(v,1)(\gamma^2+A^2)\)，结合 \(v\le B_0^2\) 可得到正文更保守的
\[
P(\gamma T+f)^2\ge \frac{v_-}{2(1+B_0)^2}(\gamma^2+\|f\|_2^2).
\]
对联合基本不等式重复 D5 的吸收并使用该曲率，得到 (B.9)。

结论：(B.7)、差分核心局部化、(B.8)、(B.9) 均成立。

## D7. O 校准比较器与随机拟合插入

在 O 分支，校准目标
\[
H_\mu(a)=\sup_{\gamma,f}
\{|P_1[(\gamma T+f)a]-\gamma|-P_1f^2\}
\]
有限当且仅当 \(P_1(Ta)=1\)；在该超平面上化为
\[
H_\mu(a)=\sup_f\{|P_1(fa)|-P_1f^2\}.
\]
因为 \(f\) 有统一点态包络，该上确界对有限向量 \(a\) 是统一 Lipschitz 的，故与正二次项之和连续、强制且可由 Borel 稠密图逼近。

取证明比较器
\[
D_0=P_1(Tu),\qquad a_0=u/D_0.
\]
在 \(D_0\ge v_-/2\) 事件上 \(P_1(Ta_0)=1\)。对任意 \(f\in\Delta\mathcal G_\mu\)，\(E[f(X)u]=0\)，故
\[
|P_1(fa_0)|\lesssim(\bar s+w_z)\|f\|_2+(\bar s+w_z)^2,
\]
而
\[
P_1f^2\ge\|f\|_2^2-C\{(\bar s+w_z)\|f\|_2+(\bar s+w_z)^2\}.
\]
最大化凹二次式得到
\(H_\mu(a_0)\lesssim\bar s^2+z/n\)，即 (B.12)。

拟合分母是对 \([v_-/2,\infty)\) 的投影，投影一维 1-Lipschitz 且保留 \(D_0\)。因此
\[
\|\tilde a-a_0\|_n\lesssim d_\pi+\sqrt{z/n}.
\]
比较目标后，只有范数界除以 \(\lambda_O\)，产生 (B.14) 的 \((d_\pi/\bar s)\sqrt{z/n}\)；校准值本身保持 (B.15)。由于 \(H_\mu(\hat a)\) 在随机 \(f\) 插入之前已对可数差分类统一取上确界，(B.16) 合法。

结论：比较器不是 learner oracle，随机拟合差的插入顺序正确。

## D8. O/R oracle identity与尾积分

O 原始估计的恒等式 (B.17) 由 \(P_1(T\hat a)=1\) 后加减 \(w=u/v\) 与一个固定近最佳 \(g_\mu\) 直接得到，共五项，没有遗漏。令
\[
r=\bar s,\ d=d_\pi,\ w_z=\sqrt{z/n},\ \ell=\sqrt{\tau_n/\lambda_O}.
\]
半径地板给 \(r\gtrsim h_n\)，安全格给 \(d\lesssim y+r+\rho_n\)，且 \(\lambda_Od^2\asymp r^2\)、\(\ell\asymp\rho_nd/r\)。因此 (B.18) 中各随机单项的 layer-cake 尺度为：

| 单项 | 积分尺度 |
|---|---|
| \(w_z\) | \(q\) |
| \((ad/r)w_z\) | \((ad/r)q\) |
| \(w_z^2\) | \(q^2\) |
| \((d/r)w_z^2\) | \(d/(nr)\) |
| \(w_z^3\) | \(q^3\) |
| \(\ell w_z\) | \(\ell q\) |

利用 \(d\lesssim y+r+\rho_n\)、\(h_n^2\le2q\)、\(q/r\lesssim1\) 以及按 \(h_n\le y\) / \(y<h_n\) 分裂，全部被 \(q+ay+x^2\) 吸收。区间 \(z<1\) 用 \(z=1\) 阈值；\(z>c_2n\) 用目标和估计器裁剪后的最大损失 6；点态而非嵌套尾事件已足够。

R 分支的 (B.28) 由分母事件后直接代数展开；\(m\)-校准 (B.25) 先统一后插入 \(f=\hat\pi-g_\pi\)。条件于 \(\mathcal F_2\) 时 \(e_\pi\) 对 D1 固定且有包络，(B.26) 的三个经验偏差由 Bernstein 控制，得 (B.27)。以 \(r=\bar t,d=d_{\rm all}\) 重复上述积分，得到 \(q+bx+y^2\)。

结论：(B.20) 与 (B.30) 成立。

## D9. 选择器代数与回退

定义 \(x=a+s,y=b+t\)、\(T_\mu=ay+x^2\)、\(T_\pi=bx+y^2\)、\(W=T_\mu\wedge T_\pi\)。当 \(x\le y\) 时
\[
T_\mu=ay+x^2\le xy+xy=2xy\le2T_\pi;
\]
镜像情形同理，所以选中的分支 \(\le2W\)。对
\[
V=\min\{a+s^2,xy,T_\mu,T_\pi\}
\]
按 \(a\) 与 \(t\)、\(b\) 与 \(s\) 的六个弱序格可得 \(V\le W\le4V\) 与 \(X/5\le V\le6X\)，从而 \(T_{\rm selected}\le48X\)。独立枚举 254,096 个点未发现反例，实际样本最大 \(T_{\rm selected}/X\) 约 2.495，远低于保守常数 48。

回退时令 \(\delta=\eta/C_{\rm rad}\)。若 \(h_n>\delta\)，则 \(q\ge\delta^2/2\)。否则 O 不安全意味着 \(s>\delta\)；若 \(t\ge s/2\)，则 \(M\ge s^2/4\)；若 \(t<s/2\)，由 \(x\le y\) 得 \(b>s/2\)，故 \(P>s^2/2\)。R 情形镜像。因 \(|\beta|\le3\)，零回退损失由 \(12\delta^{-2}(q+X)\) 覆盖。

结论：(B.31)--(B.33) 及 Q1 提升成立。

## D10. 有限检验工具

两点绝对损失检验：以参数中点阈值化估计器，错误时绝对损失至少 \(\Delta/2\)；两种错误概率之和至少 \(1-\mathrm{TV}\)，故最大风险至少 \(\Delta(1-\mathrm{TV})/4\)。

若每个标签有 \(2p\) 个坐标/符号分量，Gram 条目同坐标同号为 \(1+K\)，同坐标反号为 \(1-K\)，异坐标为 1，则展开均匀混合似然平方得到
\[
\chi^2(\widetilde P^N,Q^N)
=\frac{\{(1+K)^N+(1-K)^N\}/2-1}{p}.
\]
组合计数为 \(2p\) 个同号、\(2p\) 个反号、\(4p(p-1)\) 个异坐标有序对。

有限类 Massart 界由 log-sum-exp 与 \(\cosh x\le e^{x^2/2}\) 得到
\[
E_\epsilon\sup_{h\in\mathcal H}n^{-1}\sum_i\epsilon_ih(X_i)
\le R\sqrt{2\log M/n}.
\]

结论：Lemmas 7--8 正确。

## D11. q 与 P 下界

q 通道（PDF p.21）取 \(T=\pm\sqrt{v_0}\)，\(Y=(B_0/2)R\)，\(P_\theta(R=1\mid T=t)=1/2+\theta t/B_0\)，\(\theta=\pm d_\rho^*/\sqrt n\)。公共参考为四原子均匀分布，似然扰动 \(h=2r\delta_nt/B_0\)，
\[
K_q=E_Qh^2=4(d_\rho^*)^2v_0/(nB_0^2)\le1/(64n),
\quad NK_q\le1/32.
\]
因此两标签 TV 小于 \(1/4\)，得 \(c_{q,\rho}q\)。公开单例类对在任意声明预算格均合法。

P 通道（PDF pp.21--24）令 \(w=b\wedge s\)、\(\eta=m_\rho w/4\)、\(\gamma=\lambda_\rho s/256\)、\(\Delta=2\eta\gamma/v_0\)、\(\kappa=\gamma+\Delta\eta\)。标签为
\[
(0,z\eta,z\gamma),\qquad(\Delta,-z\eta,z\kappa).
\]
六原子符号平均共同参考成立的条件
\[
\Delta a_t=b_t(\kappa+\gamma)
\]
在 \(t=\pm L\) 化为 \(\Delta(v_0+\eta^2)=\eta(\kappa+\gamma)\)，等价于 \(\Delta v_0=2\eta\gamma\)；在 \(t=0\) 两侧均为零。中心似然系数能量满足 \(K_0\le s^2/225,K_1\le s^2/196\)。\(p=\lceil e^{64Ns^2}\rceil\) 给
\[
\chi^2\le e^{NK_\ell}/p<e^{-(64-1/196)Ns^2}\le e^{-511}.
\]
目标间隔为 \(\lambda_\rho m_\rho s(b\wedge s)/(512v_0)\)。

非参数支路要求 \(n\ge16,s^2\ge q\)。其余情况若 \(s^2<q\)，则 \(P\le q\)；若 \(n<16\)，则 \(P\le1\le4q\)；零预算目标项为零。与 q 下界取最大值即可闭合所有 \(n\)。

## D12. O 下界

令 \(w=a\wedge t\)、\(\gamma=\lambda_\rho m_\rho t/4\)、\(\eta=w/256\)、\(\Delta=\gamma\eta/(v_0+\gamma^2)\)。两个标签共享 \(\pi=z\gamma\)，结局对为 \((\beta,\mu)=(0,z\eta)\) 与 \((\Delta,0)\)。

标签零符号平均为 \(Q_0(u,r)=\{a_u+rb_u\eta/A\}/2\)，标签一平均为 \(Q_1(u,r)=a_u(1+r\Delta u/A)/2\)。共同参考条件 \(\Delta a_uu=b_u\eta\) 在边原子化为 \(\Delta(v_0+\gamma^2)=\gamma\eta\)，故成立。标签一似然系数中的 outcome 因子只在除以该共同参考后消去，得到 \(h_1=b_u/a_u\)，不是凭对称性假定。能量 \(K_0\le t^2/9,K_1\le t^2/256\)，TV 闭合。目标间隔下界为固定 \(\rho\)-常数乘 \(t(a\wedge t)\)。全样本量拼接与 P 镜像但使用独立 q 最大值。

结论：Appendix D 的 O 证书成立。

## D13. ab 下界

公开类对为 \(\mathcal G_\mu=\mathcal G_\pi=\{0\}\)，故两个 stochastic budget 的复杂度对所有正半径严格为零。令 \(S=a^2+b^2\)、\(\eta=m_\rho b/4\)、\(\gamma=a/512\)、\(\Delta=2\eta\gamma/v_0\)、\(\kappa=\gamma+\Delta\eta\)。真 nuisance 在公开类外但距离分别不超过 \(b,a\)。共同参考代数与 P 相同，能量 \(K_0\le S/32,K_1\le S/8\)。目标间隔 \(\Delta=m_\rho ab/(1024v_0)\)。当 \(n<16\) 时 \(ab\le1\le4q\)；当 \(n\ge16,S<q\) 时 \(ab\le S/2<q/2\)。

结论：Appendix E 的 ab 证书成立，且没有向 learner 暴露 Walsh 字典。

## D14. M 下界

令 \(w=s\wedge t\)、\(\gamma=\lambda_\rho m_\rho w/4\)、\(\eta=\lambda_\rho w/256\)、\(\Delta=\gamma\eta/(v_0+\gamma^2)\)。公开 \(\pi\) 和 \(\mu\) 字典分别含所需方向，两个标签近似误差均为零。Massart 界必须分别除以 \(s\) 与 \(t\)：
\[
\frac{\mathfrak R_n(r';\Delta\mathcal G_\mu)}{3r'}
\lesssim\frac{\eta w}{s}\lesssim c_{\rm rad}s,
\quad
\frac{\mathfrak R_n(r';\Delta\mathcal G_\pi)}{3r'}
\lesssim\frac{\gamma w}{t}\lesssim c_{\rm rad}t,
\]
使用 \(w\le s,t\) 和 \(m_\rho\le1/64\)。共同参考代数与 O 相同，Gram 能量 \(K_0<w^2/9,K_1<w^2/256\)。目标间隔为固定常数乘 \(w^2\)。若 \(w=0\) 目标项为零；非参数条件外由 q 最大值闭合。

结论：Appendix F 的 M 证书成立。

## D15. 最大值到求和与 \(S_0\)--\(X\)

五个公开类对可能不同，但都给同一风险的下界：
\[
R_{n,\rho}^{\rm pair}\ge
\max\{c_qq,c_{ab}ab,c_MM,c_OO,c_PP\}.
\]
令 \(S_0=ab+M+O+P\)。展开
\[
(a+s^2)(b+t^2)=ab+at^2+bs^2+s^2t^2.
\]
在预算位于 \([0,1]\) 时，
\[
at^2\le t(a\wedge t)=O,
\quad bs^2\le s(b\wedge s)=P,
\quad s^2t^2\le(s\wedge t)^2=M.
\]
故 \(S_0\le X\le2S_0\)。最大值至少为五项和的五分之一，因此
\[
R_{n,\rho}^{\rm pair}\ge c_{\min,\rho}(q+S_0)/5
\ge c_{\min,\rho}(q+X)/10.
\]

结论：Appendix G 未相加不同先验或不同样本上的 Bayes 风险。

## D16. E/S 边界

若 \(v_->B_0^2\)，由 \(|u|\le B_0\) 得 \(E(u^2\mid X)\le B_0^2<v_-\)，无法存在兼容律。

若 \(v_-=B_0^2\)，则 \(u^2=B_0^2\) 几乎处处，且 \(E(u\mid X)=0\) 强制条件概率各为 \(1/2\)。又 \(T=\pi_0(X)\pm B_0\) 两值都必须落在 \([-B_0,B_0]\)，两区间约束交集只有 \(\pi_0(X)=0\)。于是
\[
\beta_0=E(TY)/B_0^2.
\]
以 \(2n\) 个样本均值估计并裁剪，\(|TY|\le B_0^2\) 给
\[
E|\hat\beta-\beta_0|\le1/\sqrt{2n}.
\]
二点 Bernoulli 通道取 \(\delta_n=3/(32\sqrt n)\)，单观测 Hellinger affinity 为 \(\sqrt{1-4\delta_n^2}\)。张量化和 \(\mathrm{TV}^2\le1-\mathrm{affinity}^2\) 给
\[
\mathrm{TV}^2\le4(2n)\delta_n^2=72/1024<1/4,
\]
故风险至少 \(3/(128\sqrt n)\)。

结论：E 层空、S 层纯参数速率均正确；S 不是内部常数的连续极限。

## D17. 真正单点环境空间与单点支持的区别

下界中的 point-mass covariate law 仍定义在固定无限 \(\mathcal X\) 上，只是 \(P_X\) 的支持为一点，完全符合 Theorem 1。

若环境空间本身真的只有一点，则 nuisance 都为常数。配对两个独立半样本并令
\[
D_i=T_{1i}-T_{2i},\quad E_i=Y_{1i}-Y_{2i},\quad S_n=\sum_iD_i^2,
\]
差分消去两个 nuisance。条件于处理变量，残差分子方差至多 \(2B_0^2S_n\)；在 \(S_n\ge nv_-\) 上，比例估计的条件均方根误差不超过 \(B_0\sqrt{2/(nv_-)}\)。又 \(0\le D_i^2\le4B_0^2\)、\(E D_i^2=2v\ge2v_-\)，Hoeffding 给
\[
P(S_n<nv_-)\le\exp\{-nv_-^2/(8B_0^4)\}.
\]
裁剪损失至多 6，即得 (I.1)。固定预算格 \((0,1/2,0,1/2)\) 的 \(X=5/16\)，而该上界趋零，故有限环境空间不可能有内部匹配下界。

结论：有限空间排除是实质条件，且与单点支持硬实验不冲突。

## D18. 计算辅助结果

独立脚本没有替代上述推导，只用于攻击代数和边界。完整原始输出见 `COMPUTATIONAL_CHECKS.txt`，脚本见 `independent_math_checks.py`。结果包括：

- 4 组固定 \(\rho\)（含 \(v_-\downarrow0\)、\(v_-\uparrow B_0^2\)、很小 \(B_G,c_{\rm rad}\)）的三点通道正性与包络余量通过。
- 在 \(n=16\) 且 \(s^2=q,t^2=q,a^2+b^2=q,w^2=q\) 的等号支路上，P/O/ab/M 六原子质量、共同参考、矩、中心 Gram 能量和 χ² 指数均通过。
- 254,096 个预算点验证 (B.31)、选择器界和 \(S_0\le X\le2S_0\)。
- 256,512 个 \(n=1,\ldots,128\) 拼接情形验证所有非参数支路之外目标项不超过 \(4q\)。
- 饱和 Hellinger 常数在 \(n=1,16,10000\) 均为 \(72/1024\)。

最终计算状态：PASS。

