# Proof dependency and locator form

| Claim | Dependency or external leaf | Source theorem or internal locator | Assumptions checked | First unsupported implication | Location |
|---|---|---|---|---|---|
| Theorem 1 upper | Fixed-pair global upper | Proposition 2 | fixed \(\rho\), legal pair, known budgets, sequential M1 | None found | PDF pp.4,12--19 |
| Lemma 4 | BBM concentration | Bartlett--Bousquet--Mendelson Theorem 2.1 | range, variance, measurability, tuning and probability mapped exactly | None found | Manuscript pp.12--13; BBM pp.6,30 |
| Lemma 5 | Lemma 4 + contraction + shelling | (B.2a)--(B.2d) | positive radius, envelope, countability, z range, maximal shell | None found | PDF p.13 |
| M1 transfer | Pointwise represented sequences | Lemma 6 | common envelope, finite-vector continuity, countable Borel selection | None found | PDF p.14 |
| Propensity initial fit | Lemmas 5--6 + basic inequality | (B.6)--(B.7) | comparator before fit, fixed truth, positive radius floor | None found | PDF pp.14--15 |
| Outcome joint fit | Joint localized class + curvature | (B.8)--(B.9) | countability, scalar radius, public difference radius, residual variance | None found | PDF pp.14--15 |
| O calibration | Normalization + proof comparator | (B.10)--(B.16) | exact hyperplane, denominator event, uniform supremum before random insertion | None found | PDF pp.15--16 |
| O tail | Five-term identity + calibration | (B.17)--(B.20) | sigma-fields, amplified terms, all-z integration, clipping | None found | PDF pp.16--17 |
| R calibration | Two-sample objective | (B.21)--(B.25) | D2 outcomes, D1 covariates, D1 treatments not frozen, uniform insertion | None found | PDF pp.17--18 |
| R tail | Denominator event + signed identity | (B.26)--(B.30) | conditional-on-D2 fixed fit, empirical floor, all-z terms | None found | PDF pp.18--19 |
| Selector/Q1 | Deterministic budget algebra + Borel lift | (B.31)--(B.33) | zeros, ties, unsafe cells, fixed-pair uniformity | None found | PDF p.19 |
| Testing | Expected-loss test, χ²/TV, Gram count | Lemma 7 | common reference positivity, product independence, ordered-pair counts | None found | PDF pp.19--20 |
| Finite class complexity | Massart/log-sum-exp | Lemma 8 | empirical envelope and finite cardinality | None found | PDF p.20 |
| Three-point treatment | Raw atom calculation | (C.5)--(C.7) | positivity, normalization, exact variance, envelopes | None found | PDF p.20 |
| q lower | Two-point scalar channel | (C.8)--(C.9) | target cap, probabilities, residual envelope, product TV | None found | PDF p.21 |
| Walsh lower geometry | Fixed injection and zero extension | Appendix C.4 opening | fixed infinite standard Borel host, measurable singleton blocks | None found | PDF p.21 |
| P lower | Three-point channel + Lemmas 7--8 | (C.10)--(C.21) | public pair before latent choice, compensation, common reference, complexity, all n | None found | PDF pp.21--24 |
| O lower | Three-point channel + Lemmas 7--8 | (D.1)--(D.15) | common propensity, atomwise reference, Gram energy, all n | None found | PDF pp.24--26 |
| ab lower | Singleton public pair + fuzzy mixture | (E.1)--(E.13) | zero complexity, off-class approximation, hidden Walsh prior, all n | None found | PDF pp.26--27 |
| M lower | Two public dictionaries | (F.1)--(F.15) | separate s/t certificates, common reference, all n | None found | PDF pp.27--29 |
| Interior assembly | Outer supremum + deterministic algebra | (G.1)--(G.3) | no addition of different priors; fixed positive constants | None found | PDF pp.29--30 |
| E/S boundary | Envelope saturation | (H.1)--(H.6) | \(v_->B_0^2\), equality, pairwise upper vs one-pair lower | None found | PDF pp.30--31 |
| Finite-space exclusion | Paired differencing | (I.1) | true singleton host distinct from point-mass support | None found | PDF pp.31--32 |

