# Counterexample-attempt ledger

| Claim | Construction attempted | Result | Witness or first failed constraint | Location |
|---|---|---|---|---|
| Fixed covariate space | Different Walsh block for each n/budget | No counterexample | Blocks all lie in one preselected injected disjoint union; ambient space is unchanged. | PDF p.21, Appendix C.4 |
| Zero extension | Extend every finite character by zero | Survived | Under block-supported \(P_X\), mean/norm/Gram are unchanged. | PDF p.21 |
| Sequential M1 transfer | Replace sequence premise by finite-coordinate closure | Weaker premise fails, manuscript premise survives | Appendix I.2 class is finitely close to zero but stays \(L_2\)-distance at least \(1/\sqrt2\); no pointwise sequence. | PDF p.32, (I.2) |
| Joint curvature | Choose \(f=-\gamma\pi_0\) | No counterexample | Residual \(v\gamma^2\) remains and yields (B.8). | PDF p.14, (B.8) |
| Calibration random insertion | Insert fitted outcome/propensity difference | Survived | Uniform countable supremum is established before insertion. | PDF pp.16,18; (B.16), (B.25) |
| O/R tail | Track all radius-amplified monomials | Survived | Required \((d/r)w_z\) and \((d/r)w_z^2\) terms are present and integrable. | PDF pp.16--19 |
| Selector boundaries | Zeros, x=y, a=t, b=s, random/grid budgets | Survived | 254,096 points passed all inequalities; weak-order proof has no division. | PDF p.19, (B.31)--(B.33) |
| P compensation | Recompute variance/reference after \(\kappa\) shift | Survived | \(\Delta v_0=2\eta\gamma\) closes both moment and reference identities. | PDF pp.22--23 |
| O channel independence | Attempt to relabel P construction | No equivalence | O uses common propensity and reference condition \(\Delta(v_0+\gamma^2)=\gamma\eta\). | PDF pp.24--26 |
| ab singleton pair | Learner sees only {0} | Survived | Walsh coordinate/sign are latent laws, not public class members; TV covers every Borel learner. | PDF pp.26--27 |
| M separate budgets | s much larger than t and vice versa | Survived | (F.6) and (F.7) check the two normalized ratios separately. | PDF p.28 |
| χ² Gram count | Recount all ordered pairs | Survived | 2p same-sign, 2p opposite-sign, 4p(p-1) off-coordinate. | PDF p.20, (C.3) |
| All-n closure | n=1, n=16, equality branches | Survived | 256,512 cases passed; inactive interaction term never exceeded 4q. | PDF pp.24,26--29 |
| Saturation | Continue interior formula to equality | Attempt invalid | Interior constants may vanish; Appendix H gives a separate identification theorem. | PDF pp.30--31 |
| Finite host | Truly singleton covariate space | Matching lower fails outside theorem field | Paired difference estimator is root-n while a legal cell has X=5/16; validates the exclusion. | PDF pp.31--32, (I.1) |

Full ledger: `COUNTEREXAMPLE_AND_SURVIVAL_RECORD.md`.

