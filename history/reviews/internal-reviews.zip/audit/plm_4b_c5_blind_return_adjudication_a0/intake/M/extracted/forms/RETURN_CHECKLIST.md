# Return checklist

- [x] Every required role form is completed.
- [x] Every substantive issue has a page, theorem, lemma, or equation locator.
- [x] The source/model/session declaration is complete to the extent the platform exposes metadata; unavailable fields are explicitly marked “平台未提供”.
- [x] The complete unedited final review output is attached.
- [x] No other role's material or output was viewed.
- [x] No author identity was sought.
- [x] No human identity, credential, or signature was invented.
- [x] Literature non-hits were not converted into novelty or priority claims.

