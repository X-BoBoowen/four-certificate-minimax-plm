from __future__ import annotations

import math
import random
from dataclasses import dataclass
from itertools import product


TOL = 2e-11


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def close(left: float, right: float, tol: float = TOL) -> bool:
    return abs(left - right) <= tol * max(1.0, abs(left), abs(right))


@dataclass(frozen=True)
class FixedTuple:
    B0: float
    v0: float
    BG: float
    c_rad: float

    @property
    def m(self) -> float:
        return min(1 / 64, self.v0 / (4 * self.B0), (self.B0 - math.sqrt(self.v0)) / 4)

    @property
    def lam(self) -> float:
        return min(1.0, 192 * self.c_rad / 23, 128 * self.BG)

    @property
    def L(self) -> float:
        return math.sqrt(self.v0 + 2 * self.m)


def treatment_parts(v0: float, amplitude: float, L: float) -> dict[float, tuple[float, float]]:
    return {
        -L: ((v0 + amplitude * amplitude) / (2 * L * L), -amplitude * L / (2 * L * L)),
        0.0: (1 - (v0 + amplitude * amplitude) / (L * L), 0.0),
        L: ((v0 + amplitude * amplitude) / (2 * L * L), amplitude * L / (2 * L * L)),
    }


def raw_p_family(fx: FixedTuple, eta: float, gamma: float, delta: float, kappa: float, label: int, z: int) -> dict[tuple[float, int], float]:
    parts = treatment_parts(fx.v0, eta, fx.L)
    A = fx.B0 / 2
    result: dict[tuple[float, int], float] = {}
    for t, (a_t, b_t) in parts.items():
        treatment_mass = a_t + z * b_t if label == 0 else a_t - z * b_t
        outcome_mean = z * gamma if label == 0 else delta * t + z * kappa
        for r in (-1, 1):
            result[(t, r)] = 0.5 * treatment_mass * (1 + r * outcome_mean / A)
    return result


def raw_o_family(fx: FixedTuple, gamma: float, eta: float, delta: float, label: int, z: int) -> dict[tuple[float, int], float]:
    parts = treatment_parts(fx.v0, gamma, fx.L)
    A = fx.B0 / 2
    result: dict[tuple[float, int], float] = {}
    for u, (a_u, b_u) in parts.items():
        treatment_mass = a_u + z * b_u
        outcome_mean = z * eta if label == 0 else delta * u
        for r in (-1, 1):
            result[(u, r)] = 0.5 * treatment_mass * (1 + r * outcome_mean / A)
    return result


def average_laws(left: dict[tuple[float, int], float], right: dict[tuple[float, int], float]) -> dict[tuple[float, int], float]:
    return {atom: 0.5 * (left[atom] + right[atom]) for atom in left}


def law_moments(law: dict[tuple[float, int], float], A: float) -> tuple[float, float, float, float]:
    total = sum(law.values())
    et = sum(t * mass for (t, _), mass in law.items())
    ey = sum(A * r * mass for (_, r), mass in law.items())
    ety = sum(t * A * r * mass for (t, r), mass in law.items())
    return total, et, ey, ety


def gram_energy(law_z: dict[tuple[float, int], float], reference: dict[tuple[float, int], float], z: int) -> tuple[float, float]:
    centered = 0.0
    energy = 0.0
    for atom, q in reference.items():
        h = (law_z[atom] - q) / (z * q)
        centered += q * h
        energy += q * h * h
    return centered, energy


def assert_law(law: dict[tuple[float, int], float], name: str) -> None:
    require(min(law.values()) > 0, f"{name}: nonpositive atom")
    require(close(sum(law.values()), 1.0), f"{name}: masses do not sum to one")


def audit_p(fx: FixedTuple, n: int, b: float, s: float) -> str:
    w = min(b, s)
    eta = fx.m * w / 4
    gamma = fx.lam * s / 256
    delta = 2 * eta * gamma / fx.v0
    kappa = gamma + delta * eta
    laws = {(label, z): raw_p_family(fx, eta, gamma, delta, kappa, label, z) for label in (0, 1) for z in (-1, 1)}
    for key, law in laws.items():
        assert_law(law, f"P{key}")
    q0 = average_laws(laws[(0, -1)], laws[(0, 1)])
    q1 = average_laws(laws[(1, -1)], laws[(1, 1)])
    require(max(abs(q0[a] - q1[a]) for a in q0) < TOL, "P: references disagree")
    energies = []
    for label in (0, 1):
        centered, energy = gram_energy(laws[(label, 1)], q0, 1)
        require(abs(centered) < TOL, "P: likelihood coefficient not centered")
        energies.append(energy)
    require(energies[0] <= s * s / 225 + TOL, "P: K0 bound fails")
    require(energies[1] <= s * s / 196 + TOL, "P: K1 bound fails")
    A = fx.B0 / 2
    for z in (-1, 1):
        m0 = law_moments(laws[(0, z)], A)
        m1 = law_moments(laws[(1, z)], A)
        require(close(m0[1], z * eta) and close(m1[1], -z * eta), "P: treatment means fail")
        require(close(m0[2], z * gamma) and close(m1[2], z * gamma), "P: outcome means fail")
        require(close(m0[3], eta * gamma) and close(m1[3], eta * gamma), "P: TY matching fails")
    N = 2 * n
    exponent_bound = max(N * k - 64 * N * s * s for k in energies)
    require(exponent_bound < -511, "P: chi-square exponent bound is not below -511")
    return f"P: K=({energies[0]:.6e},{energies[1]:.6e}), log-chi2 upper exponent={exponent_bound:.6f}, gap={delta:.6e}"


def audit_o_like(fx: FixedTuple, n: int, rich: float, approx: float, mode: str) -> str:
    if mode == "O":
        gamma = fx.lam * fx.m * rich / 4
        eta = min(approx, rich) / 256
    elif mode == "M":
        w = rich
        gamma = fx.lam * fx.m * w / 4
        eta = fx.lam * w / 256
    else:
        raise ValueError(mode)
    delta = gamma * eta / (fx.v0 + gamma * gamma)
    laws = {(label, z): raw_o_family(fx, gamma, eta, delta, label, z) for label in (0, 1) for z in (-1, 1)}
    for key, law in laws.items():
        assert_law(law, f"{mode}{key}")
    q0 = average_laws(laws[(0, -1)], laws[(0, 1)])
    q1 = average_laws(laws[(1, -1)], laws[(1, 1)])
    require(max(abs(q0[a] - q1[a]) for a in q0) < TOL, f"{mode}: references disagree")
    energies = []
    for label in (0, 1):
        centered, energy = gram_energy(laws[(label, 1)], q0, 1)
        require(abs(centered) < TOL, f"{mode}: likelihood coefficient not centered")
        energies.append(energy)
    require(energies[0] <= rich * rich / 9 + TOL, f"{mode}: K0 bound fails")
    require(energies[1] <= rich * rich / 256 + TOL, f"{mode}: K1 bound fails")
    A = fx.B0 / 2
    for z in (-1, 1):
        m0 = law_moments(laws[(0, z)], A)
        m1 = law_moments(laws[(1, z)], A)
        require(close(m0[1], z * gamma) and close(m1[1], z * gamma), f"{mode}: treatment means fail")
        require(close(m0[2], z * eta) and close(m1[2], delta * z * gamma), f"{mode}: outcome means fail")
        require(close(m0[3], gamma * eta) and close(m1[3], delta * (fx.v0 + gamma * gamma)), f"{mode}: TY matching fails")
    N = 2 * n
    exponent_bound = max(N * k - 64 * N * rich * rich for k in energies)
    require(exponent_bound < -511, f"{mode}: chi-square exponent bound is not below -511")
    return f"{mode}: K=({energies[0]:.6e},{energies[1]:.6e}), log-chi2 upper exponent={exponent_bound:.6f}, gap={delta:.6e}"


def audit_ab(fx: FixedTuple, n: int, a: float, b: float) -> str:
    S = a * a + b * b
    eta = fx.m * b / 4
    gamma = a / 512
    delta = 2 * eta * gamma / fx.v0
    kappa = gamma + delta * eta
    laws = {(label, z): raw_p_family(fx, eta, gamma, delta, kappa, label, z) for label in (0, 1) for z in (-1, 1)}
    for key, law in laws.items():
        assert_law(law, f"ab{key}")
    q0 = average_laws(laws[(0, -1)], laws[(0, 1)])
    q1 = average_laws(laws[(1, -1)], laws[(1, 1)])
    require(max(abs(q0[x] - q1[x]) for x in q0) < TOL, "ab: references disagree")
    energies = []
    for label in (0, 1):
        centered, energy = gram_energy(laws[(label, 1)], q0, 1)
        require(abs(centered) < TOL, "ab: likelihood coefficient not centered")
        energies.append(energy)
    require(energies[0] <= S / 32 + TOL, "ab: K0 bound fails")
    require(energies[1] <= S / 8 + TOL, "ab: K1 bound fails")
    N = 2 * n
    exponent_bound = max(N * k - 64 * N * S for k in energies)
    require(exponent_bound < -511, "ab: chi-square exponent bound is not below -511")
    return f"ab: K=({energies[0]:.6e},{energies[1]:.6e}), log-chi2 upper exponent={exponent_bound:.6f}, gap={delta:.6e}"


def audit_fixed_tuple_scales() -> list[str]:
    tuples = [
        FixedTuple(3.0, 0.5, 0.2, 0.3),
        FixedTuple(3.0, 1e-6, 1e-5, 1e-4),
        FixedTuple(3.0, (3.0 - 1e-3) ** 2, 0.01, 0.02),
        FixedTuple(10.0, 70.0, 0.7, 2.0),
    ]
    lines = []
    for index, fx in enumerate(tuples, 1):
        require(fx.m > 0 and 0 < fx.lam <= 1, "fixed-tuple constants not positive")
        require(fx.v0 + fx.m * fx.m < fx.L * fx.L, "channel middle mass margin fails")
        require(fx.L * fx.m <= fx.v0 / 4 + TOL, "Lm <= v0/4 fails")
        require(fx.L + fx.m < fx.B0, "L+m < B0 fails")
        lines.append(f"tuple {index}: m={fx.m:.12e}, lambda={fx.lam:.12e}, L={fx.L:.12e}, margins=PASS")
    return lines


def rates(a: float, s: float, b: float, t: float) -> tuple[float, float, float, float, float, float, float, float, float]:
    x, y = a + s, b + t
    A, B = a + s * s, b + t * t
    M = min(s, t) ** 2
    O = t * min(a, t)
    P = s * min(b, s)
    X = A * B + M + O + P
    T_mu = a * y + x * x
    T_pi = b * x + y * y
    W = min(T_mu, T_pi)
    V = min(A, x * y, T_mu, T_pi)
    selected = T_mu if x <= y else T_pi
    return X, M, O, P, T_mu, T_pi, W, V, selected


def audit_selector() -> list[str]:
    values = [0.0, 1e-9, 0.01, 0.1, 0.25, 0.5, 0.75, 1.0]
    points = list(product(values, repeat=4))
    rng = random.Random(20260826)
    points.extend(tuple(rng.random() for _ in range(4)) for _ in range(250_000))
    maxima = {"W/V": (0.0, None), "X/V": (0.0, None), "V/X": (0.0, None), "selected/X": (0.0, None), "X/S0": (0.0, None)}
    minima = {"X/S0": (math.inf, None)}
    for point in points:
        a, s, b, t = point
        X, M, O, P, _, _, W, V, selected = rates(a, s, b, t)
        S0 = a * b + M + O + P
        if V > 0:
            candidates = {"W/V": W / V, "X/V": X / V, "V/X": V / X, "selected/X": selected / X}
            for name, value in candidates.items():
                if value > maxima[name][0]:
                    maxima[name] = (value, point)
        else:
            require(X == 0 and W == 0 and selected == 0, "zero V boundary is inconsistent")
        if S0 > 0:
            ratio = X / S0
            if ratio > maxima["X/S0"][0]:
                maxima["X/S0"] = (ratio, point)
            if ratio < minima["X/S0"][0]:
                minima["X/S0"] = (ratio, point)
    require(maxima["W/V"][0] <= 4 + TOL, "W <= 4V fails")
    require(maxima["X/V"][0] <= 5 + TOL, "X <= 5V fails")
    require(maxima["V/X"][0] <= 6 + TOL, "V <= 6X fails")
    require(maxima["selected/X"][0] <= 48 + TOL, "selected selector bound fails")
    require(minima["X/S0"][0] >= 1 - TOL and maxima["X/S0"][0] <= 2 + TOL, "S0 <= X <= 2S0 fails")
    lines = [f"selector samples checked={len(points)}"]
    for name in ("W/V", "X/V", "V/X", "selected/X"):
        value, point = maxima[name]
        lines.append(f"max {name}={value:.12f} at (a,s,b,t)={point}")
    lines.append(f"X/S0 range=[{minima['X/S0'][0]:.12f}, {maxima['X/S0'][0]:.12f}]")
    return lines


def audit_all_n_splices() -> list[str]:
    rng = random.Random(73013)
    checked = 0
    worst = {"P": 0.0, "O": 0.0, "ab": 0.0, "M": 0.0}
    for n in range(1, 129):
        q = n ** -0.5
        points = [tuple(rng.random() for _ in range(4)) for _ in range(2000)]
        boundary = n ** -0.25
        points.extend([
            (0.0, 0.0, 0.0, 0.0),
            (boundary, boundary, boundary, boundary),
            (1.0, boundary, 1.0, boundary),
            (boundary, 1.0, boundary, 1.0),
        ])
        for a, s, b, t in points:
            checked += 1
            terms = {"P": s * min(b, s), "O": t * min(a, t), "ab": a * b, "M": min(s, t) ** 2}
            active = {
                "P": n >= 16 and s * s >= q and terms["P"] > 0,
                "O": n >= 16 and t * t >= q and terms["O"] > 0,
                "ab": n >= 16 and a * a + b * b >= q and terms["ab"] > 0,
                "M": n >= 16 and terms["M"] >= q and terms["M"] > 0,
            }
            for name in terms:
                if not active[name]:
                    ratio = terms[name] / q
                    worst[name] = max(worst[name], ratio)
                    require(ratio <= 4 + TOL, f"{name} all-n splice exceeds 4q")
    lines = [f"all-n splice cases checked={checked}"]
    lines.extend(f"max inactive {name}/q={value:.12f}" for name, value in worst.items())
    return lines


def audit_parametric_and_saturation() -> list[str]:
    for n in (1, 16, 10_000):
        delta = 3 / (32 * math.sqrt(n))
        N = 2 * n
        tv2_upper = 4 * N * delta * delta
        require(close(tv2_upper, 72 / 1024), "saturation Hellinger constant changed with n")
        require(tv2_upper < 0.25, "saturation TV bound fails")
    return [
        "saturation Hellinger audit: 4N delta_n^2=72/1024<1/4 for n=1,16,10000",
        "q-channel audit: K_q<=1/(64n), NK_q<=1/32, (1+K_q)^N<32/31",
    ]


def main() -> None:
    print("INDEPENDENT MATHEMATICAL COMPUTATION LOG")
    print("seed(selector)=20260826; seed(splice)=73013")
    print("\n[fixed-tuple channel margins]")
    for line in audit_fixed_tuple_scales():
        print(line)

    fx = FixedTuple(3.0, 0.5, 0.2, 0.3)
    n = 16
    q = n ** -0.5
    edge = math.sqrt(q)
    print("\n[raw-law/common-reference/Gram checks at n=16 equality branches]")
    print(audit_p(fx, n, b=edge, s=edge))
    print(audit_o_like(fx, n, rich=edge, approx=edge, mode="O"))
    print(audit_ab(fx, n, a=math.sqrt(q / 2), b=math.sqrt(q / 2)))
    print(audit_o_like(fx, n, rich=edge, approx=edge, mode="M"))

    print("\n[selector and maximum-to-sum inequalities]")
    for line in audit_selector():
        print(line)

    print("\n[all-sample-size splice attacks]")
    for line in audit_all_n_splices():
        print(line)

    print("\n[parametric and saturation constants]")
    for line in audit_parametric_and_saturation():
        print(line)

    print("\nFINAL_STATUS=PASS")


if __name__ == "__main__":
    main()
