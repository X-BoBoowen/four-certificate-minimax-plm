# Theorem-by-theorem verdict form

Overall verdict: **PASS — no confirmed mathematical error or conclusion-level proof gap in the stated theorem field.**

Confidence: **High.**

Strongest correctness concern: The long O/R all-z bookkeeping in (B.18) and (B.29); independently reconstructed term by term with no failed implication.

| Claim | Verdict | Independent derivation or first failed implication | Location |
|---|---|---|---|
| Theorem 1, E stratum | Pass | \(|u|\le B_0\Rightarrow E(u^2\mid X)\le B_0^2\); no compatible law if \(v_->B_0^2\). | PDF pp.3,30; Thm.1(E), Appendix H |
| Theorem 1, I stratum | Pass | Upper Proposition 2 plus five native lower bounds, maximum-to-sum, and \(S_0\le X\le2S_0\) give (6). | PDF pp.3--6,12--30; (6), (B.1)--(G.3) |
| Theorem 1, S stratum | Pass | Saturation forces \(u=\pm B_0\), \(\pi_0=0\), then sample-moment upper and two-point Hellinger lower give (7). | PDF pp.3,30--31; (7), (H.1)--(H.6) |
| Proposition 2, fixed-pair upper | Pass | O/R branch bounds, public selector/fallback, Borel construction, then fixed-pair uniform law supremum. | PDF pp.4,12--19; Prop.2, (B.20), (B.30)--(B.33) |
| Lemma 3, conditional Bernstein | Pass | Standard conditional MGF proof; weighted form follows from conditional Hoeffding and Chernoff optimization. | PDF p.12; (B.1)--(B.1a) |
| Lemma 4, localized supremum concentration | Pass | Exact BBM Theorem 2.1 map with symmetric class, \([-B,B]\), \(r=\sigma^2\), \(x=z\), \(\alpha=1\). | Manuscript PDF pp.12--13; (B.2). BBM PDF pp.6,30 |
| Lemma 5, multiplier/square processes | Pass | Dyadic shells terminate by envelope; confidence allocation and variance/range terms give (B.3)--(B.4), including zero budgets and n=1. | PDF p.13; (B.2a)--(B.4) |
| Lemma 6, sequential M1 transfer | Pass | Dominated convergence gives population infima; finite-vector continuity gives empirical objectives/difference suprema; countable first-within-tolerance selection is Borel. | PDF p.14; Lemma 6 |
| Initial propensity fit (B.7) | Pass | Basic inequality (B.6), uniform multiplier/square bounds, fixed-comparator concentration, and quadratic absorption reconstruct the display. | PDF pp.14--15; (B.6)--(B.7) |
| Joint difference core and curvature | Pass | Local norm controls scalar and public difference directions; Gram curvature retains \(v\gamma^2\) against cancellation. | PDF pp.14--15; (B.8) and display following it |
| Joint initial fit (B.9) | Pass | Countable joint class is localized before fitted insertion; comparison and (B.8) give parameter/nuisance norm bound. | PDF p.15; (B.9) |
| O definition/calibration | Pass | Exact normalization hyperplane, proof-only \(a_0\), (B.12), denominator projection, objective comparison, and uniform calibration give (B.16). | PDF pp.15--16; (B.10)--(B.16) |
| O oracle inequality/expectation | Pass | Five-term identity is exhaustive; amplified terms in (B.18) integrate at the stated scales and are absorbed by \(q+ay+x^2\). | PDF pp.16--17; (B.17)--(B.20) |
| R calibration | Pass | Two-sample objective has a valid common comparator; uniform event precedes insertion \(f=\hat\pi-g_\pi\). | PDF pp.17--18; (B.21)--(B.25) |
| R denominator/oracle/expectation | Pass | Conditional-on-D2 denominator expansion, empirical floor event, exact signed identity, and termwise tails yield \(q+bx+y^2\). | PDF pp.18--19; (B.26)--(B.30) |
| Public selector, fallback, Q1 lift | Pass | Weak-order algebra gives (B.31)--(B.32); unsafe cells force q/M/P/O mass; one Borel fixed-pair rule precedes outer supremum. | PDF p.19; (B.31)--(B.33) |
| Lemma 7, testing/χ²/Gram mixtures | Pass | Midpoint testing, Cauchy--Schwarz TV, and exact \((2p)^2\) ordered-pair count reproduce all formulas. | PDF pp.19--20; (C.1)--(C.3) |
| Lemma 8, finite-class complexity | Pass | Log-sum-exp plus \(\cosh x\le e^{x^2/2}\); global envelope bound is valid for every localized subclass. | PDF p.20; (C.4) |
| Exact three-point channel | Pass | Direct masses are positive, normalized, and have mean m, second moment \(v_0+m^2\), variance \(v_0\). | PDF p.20; (C.5)--(C.7) |
| Native q lower | Pass | Likelihood perturbation has \(K_q\le1/(64n)\); product TV and target cap give positive fixed \(c_{q,\rho}\). | PDF p.21; (C.8)--(C.9) |
| Fixed-space Walsh embedding | Pass | One preselected injection supplies all finite blocks; zero extension preserves the required \(P_X\)-geometry. | PDF p.21; Appendix C.4 opening |
| P lower certificate | Pass | Compensation identity preserves variance/common reference; class complexity, Gram/TV, target gap and all-n splice all close. | PDF pp.21--24; (C.10)--(C.21) |
| O lower certificate | Pass | Common propensity, distinct outcome channel, reference identity (D.8), two Gram routes, target separation and splice close. | PDF pp.24--26; (D.1)--(D.15) |
| ab lower certificate | Pass | Public singleton pair has zero complexity; off-class truths meet approximation budgets; common reference and TV give ab. | PDF pp.26--27; (E.1)--(E.13) |
| M lower certificate | Pass | Both public dictionaries have zero approximation; stochastic budgets are checked separately using \(w\le s,t\); mixture TV gives \(w^2\). | PDF pp.27--29; (F.1)--(F.15) |
| Lower assembly | Pass | Same outer scalar risk dominates each component; take maximum, then deterministic \(S_0\)--\(X\) equivalence. | PDF pp.29--30; (G.1)--(G.3) |
| Singleton finite-space boundary | Pass | Point-mass support remains on fixed infinite host; genuinely singleton host has paired-difference root-n upper and is expressly excluded. | PDF pp.31--32; (I.1) |

