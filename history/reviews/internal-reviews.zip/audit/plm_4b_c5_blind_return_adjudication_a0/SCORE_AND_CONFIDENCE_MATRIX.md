# Score and confidence matrix

| Role | Overall | Confidence | Correctness reading | Significance reading | Adjudicated weight |
|---|---:|---:|---|---|---|
| M | PASS (no numeric venue score) | high, bounded by no proof assistant | No confirmed blocker; Appendix-B constants remain the likeliest residual risk. | Not its primary assignment. | correctness evidence only |
| S | 5/10 Weak Reject | 4/5 | No fatal model, quantifier, or calculation error found. | Theorem-field breadth and different-pair lower witnesses control rejection. | controlling significance critique |
| G | 6/10 Weak Accept | 4/5 | No confirmed theorem failure after targeted recomputation. | Technical depth narrowly clears its venue threshold. | usable after removing source-label errors |

No averaging is used. The score disagreement is explained by venue-value judgment. The next scientific allocation is justified only by S's concrete same-pair objection and the PI-frozen K0 target, not by majority voting.
