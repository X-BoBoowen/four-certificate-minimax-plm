# Source-claim adjudication

Audit date: `2026-08-26`. Public checks were restricted to primary arXiv/PMLR records and locally preserved primary full text. Search non-hits receive no novelty or priority credit.

## Determinations

### Gu--Yin--Cai--Fan, arXiv:2606.06368

The official record identifies Yihong Gu, Qishuo Yin, Tianxi Cai, and Jianqing Fan, submitted 4 June 2026, under the title *Optimally taming biases in black-box models for efficient semiparametric estimation*. The preserved primary text of Appendix A.1 states an expected-absolute-loss outer-family lower bound and exact constant conditional variance `E[u^2|X]≡v≥1/3`.

Candidate-C5 Table 5 instead says “squared loss” and “variance lower bound.” Disposition:

`CONFIRMED MANUSCRIPT ERROR — MUST FIX LATER.`

The correction narrows the differential to sequential M1/fixed infinite ambient space/O-P necessity and exact closure; it does not itself create a theorem collision.

### TAME, arXiv:2607.21541

The official record identifies Yihong Gu as sole author and the title *Optimal use of a black-box learner in semiparametric estimation*. Candidate-C5's attribution is consistent. G's attribution to Balakrishnan--Kennedy--Wasserman is a return-level source error and is not imported. The two-branch upper architecture is prior; this audit assigns no upper-architecture novelty.

### Calibrated DML, arXiv:2411.02771

The official record is *Doubly robust inference via calibration* by Lars van der Laan, Alex Luedtke, and Marco Carone: v1 on 5 November 2024, v2 on 27 June 2025, v3 on 20 August 2026. Candidate-C5's BibTeX combines `year=2025` with a v3/2026 note. S's enclosed source payload is byte-identical to v2 while its comparison uses the v3 date.

Dispositions:

- manuscript: `CONFIRMED METADATA INCONSISTENCY — MUST FIX LATER`;
- S payload: `AUDIT-PAYLOAD PROVENANCE MISMATCH — SCIENTIFIC NON-COLLISION JUDGMENT UNCHANGED`.

### Jin--Mackey--Syrgkanis, arXiv:2507.02275

The official record is *It's Hard to Be Normal: The Impact of Noise on Structure-agnostic Estimation* by Jikai Jin, Lester Mackey, and Vasilis Syrgkanis. Candidate-C5 is consistent. G's alternative authors/title are a return-level source error.

### Jin--Syrgkanis, arXiv:2512.17341

The official record is *Sharp Structure-Agnostic Lower Bounds for General Linear Functional Estimation* by Jikai Jin and Vasilis Syrgkanis. It is a strong adjacent anchored/fixed-pilot theorem line, not a direct derivation of the Candidate-C5 O/P public-class theorem.

### Liu--Mukherjee--Robins, arXiv:2606.22391

The official record studies asymptotic inadmissibility/minimax behavior under fixed-pilot structure-agnostic models, including expected conditional covariance. It does not state the Candidate-C5 four-public-budget PLM coefficient theorem. It is nevertheless directly relevant context for the limits of first-order/DML optimality.

Disposition: `REQUIRED CONTEXTUAL POSITIONING — NOT COLLISION`.

### Figure script

Candidate-C5 prints `figures/+generate_theory_summary.py`; that exact file exists in the protected Candidate-C5 tree. G's blind ZIP did not contain it because the G whitelist excluded source-tree scripts.

Disposition: `BLIND-PACKAGE LIMITATION — NO SCIENTIFIC DEFECT`.

## Bounded conclusion

No checked primary theorem directly supplies the same full O/P conclusion under Candidate-C5's exact information model. This is a bounded differential only. It is not a novelty, priority, or collision-free certificate.
