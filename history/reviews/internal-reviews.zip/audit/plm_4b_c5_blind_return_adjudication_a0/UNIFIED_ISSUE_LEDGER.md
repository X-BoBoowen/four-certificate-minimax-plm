# Unified Candidate-C5 blind-return issue ledger

| ID | Evidence | Independent disposition | Severity | Candidate action status |
|---|---|---|---|---|
| A0-I01 | M reports PASS and no theorem-level failure after auditing H1--H12 and the high-risk upper/lower nodes. | `NO CONFIRMED CORRECTNESS BLOCKER`; residual constant-heavy Appendix-B risk remains non-formalized. | residual verification risk | no edit authorized |
| A0-I02 | S scores 5/10 Weak Reject despite finding no fatal model, quantifier, or calculation error. | `SIGNIFICANCE/THEOREM-FIELD BREADTH`, not correctness, controls S's rejection. | major significance | active motivation for K0 |
| A0-I03 | G scores 6/10 Weak Accept and reports no theorem failure. | Correctness support is usable; several source names/titles in G are wrong and are excluded from source adjudication. | return-level attribution defect | no manuscript inference from bad labels |
| A0-I04 | Candidate Table 5 describes Gu--Yin--Cai--Fan A.1 as squared loss and variance lower bound. | `CONFIRMED MANUSCRIPT ERROR — MUST FIX LATER`: A.1 uses expected absolute loss and exact constant conditional variance `E[u^2|X]≡v≥1/3`. | major attribution/field correction | ledger only; Candidate-C5 protected |
| A0-I05 | Candidate bibliography gives Calibrated DML `year=2025`, note `v3, 20 Aug 2026`; S payload is v2. | Two distinct defects: manuscript metadata is internally inconsistent with the v3 revision date; audit payload provenance was v2 while labeled/compared as v3. | mandatory metadata/provenance correction | ledger only |
| A0-I06 | Candidate already has a Liu--Mukherjee--Robins BibTeX entry but does not cite it in the displayed related-work passage. | `REQUIRED CONTEXTUAL POSITIONING — NOT COLLISION`. | moderate positioning | ledger only |
| A0-I07 | G says the named figure script is absent from its blind archive. | `BLIND-PACKAGE LIMITATION — NO SCIENTIFIC DEFECT`: Candidate-C5 contains `figures/+generate_theory_summary.py`, exactly the path printed in the paper. | package-only | no Candidate repair required for existence |
| A0-I08 | M/G accept the old different-pair maximum-to-sum assembly as mathematically legal. | Correct for Candidate-C5's Q1 order, but it does not answer the significance criticism that the five terms are witnessed on different public pairs. | controlling significance gap | sole K0 target |
| A0-I09 | S requests same-pair/common-rule/adaptive evidence. | Only the same-public-pair lower is authorized. Unknown-budget adaptation and a common rule across all pairs remain closed. | scope boundary | enforced |
| A0-I10 | Search logs report no same-field O/P collision. | `BOUNDED NON-HIT ONLY`; no priority or global novelty conclusion. | epistemic boundary | no novelty credit |
| A0-I11 | Candidate uses fixed infinite standard Borel X, constant conditional variance, known budgets, sequential M1, and pair-specific Borel rules. | Real theorem restrictions, not editorial caveats. | major scope | unchanged |
| A0-I12 | M notes three typographical slips. | Non-scientific copy defects; outside the authorized theorem audit. | minor | not repaired |

## Consensus and conflict

Consensus: no return confirms a fatal or major correctness defect; the O/P lower mechanisms and all-budget closure are the surviving residual contribution; the operational theorem field is narrow; AI evidence is not human certification.

Conflict: S judges the narrow field below the ICLR bar (5/10), while G judges the technical contribution marginally above it (6/10). M is a correctness audit rather than a venue score. The conflict is therefore a significance judgment, not a disagreement over a certified mathematical failure.

Controlling unresolved issue: whether one common-support, untagged, single public pair can simultaneously host q/P/O/ab/M lower subfamilies without violating M1, envelope, approximation, localized-complexity, or information gates.
