# Controlling significance bottleneck

## Adjudicated bottleneck

Candidate-C5's lower envelope is mathematically valid for its printed Q1 order, but q/P/O/ab/M are witnessed by different public pairs and combined only after the outer `sup_Gamma`. Consequently the theorem does not show that one fixed public statistical problem simultaneously contains all five obstructions.

This is S's decisive Major Issue 2 and the cleanest explanation for the 5/10 versus 6/10 split. Correctness evidence from M/G cannot resolve it.

## Authorized uplift test

The only active scientific question is whether, for each fixed `(rho,n,a,s,b,t)`, one common pair and one component-independent covariate law can host the five hard subfamilies on common support without a component-revealing tag, while preserving every model, envelope, approximation, stochastic-complexity, distance, and arbitrary-estimator gate.

Success would remove the formal “five different public problems” objection. It would not prove adaptation, computation, heteroskedasticity, a common rule across all pairs, finite-space matching, causal interpretation, or naturality of the multiplexed pair.

## Impact threshold

- Tagged or disjoint-support direct sum: zero credit.
- Common support, common `P_X`, one public pair, no observable tag: minimum positive signal.
- Natural nested/common pair: stronger signal but not required.

Even a valid orthogonal-frequency construction remains artificial. It passes the Reviewer-impact gate only if the testing inequalities quantify over arbitrary rules knowing the entire common dictionary and if no public variable reveals the component. Under that standard it is a real simultaneous-hardness theorem, not a renaming; it may plausibly move the S-style assessment from 5/10 to 6/10, but no score or project percentage is automatically changed.
