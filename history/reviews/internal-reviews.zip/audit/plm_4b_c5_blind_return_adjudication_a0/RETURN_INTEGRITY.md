# Candidate-C5 M/S/G return integrity

Adjudication time: `2026-08-26T20:05:56.6765114+08:00`.

## Controlling identities

| Role | External return SHA-256 | Intake-copy status | Archive entries | Internal manifest | Candidate-C5 identity |
|---|---|---:|---:|---:|---:|
| M | `7AB1546BF93D19D28F21509FBD8DCC4C77A831D81D01447985D526DF3EB94584` | byte-identical | 16 | 15/15 non-manifest files match | `D8DD7EB9F01038D0AA863F78C3972950AD98B6B6225E4A69D3CF7F92E45E2259` |
| S | `0CFFABC2A79C41A80DC6A834C6D245574A07A19837FC1DF1BCA61DA85795E368` | byte-identical | 19 | 18/18 non-manifest files match | same controlling hash |
| G | `7A34B238F688F7AD66EC875BE7B3B21023F8B5048F76C741424A11278B1FEDEC` | byte-identical | 17 | 16/16 non-manifest files match | same controlling hash |

The project intake copies are at `intake/{M,S,G}/original_return.zip`; each was safely extracted under its own role directory. `RETURN_MANIFEST.tsv` contains 52 member rows (16/19/17) and has SHA-256 `E063CF8C732224C18DFBABAA37E6C1504DC92718FF67BFC7C86F183BA3E8289A`. Every extracted member matches its archive member in size and SHA-256. There are no duplicate or unsafe archive paths.

## Identity, declaration, and isolation audit

All roles supplied provider/model/session-or-unavailable declarations, a fresh-session declaration, review time and timezone, tool/access disclosure, and a Candidate identity. No return contains an old Candidate/Master hash, an internal project percentage, or another role's substantive return. G's declaration that no other reviewer output was available is a negative isolation statement, not leakage.

No replacement-character corruption was detected. Raw review outputs and completed role forms are present. The role archives remain unmodified; the extracted intake is evidentiary only.

## Credit boundary

These are fresh, mutually isolated AI red-team returns. They create:

- AI red-team evidence: three returns;
- independent-human review credit: zero;
- proof-complete credit: zero;
- novelty/priority credit from search non-hits: zero;
- submission-readiness credit: zero.

## Integrity verdict

`PASS — THREE AUTHENTICATED CANDIDATE-C5 AI RETURNS, WITH ROLE ISOLATION PRESERVED.`

This integrity verdict authenticates provenance, not the scientific correctness of every statement in a return. Source and scientific claims are separately adjudicated.
