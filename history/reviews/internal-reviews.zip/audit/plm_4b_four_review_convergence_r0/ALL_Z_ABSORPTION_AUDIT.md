# All-`z` absorption audit

## Scope and verdict

This is an independent source-level replay of the Master-R14/Candidate-C12
implications `(B.18) -> (B.20)` and `(B.29) -> (B.30)`.  The verdict is
`PASS` inside the frozen theorem field.  The proof uses a pointwise family of
exponential-tail events indexed by `z`; it does not claim one event that holds
simultaneously for every `z`.

## O branch

Write `r=bar s`, `d=d_pi`, `w_z=sqrt(z/n)`,
`ell=sqrt(tau_n/lambda_O)`, and `R_O=q+ay+x^2`.  The audited source states

`h_n^2 <= 2q`, `r >= C_rad h_n`, `d <= B_pi`,
`d <= C(y+r+rho_n)`, and `lambda_O d^2=r^2`.

| Tail monomial | Certified reduction |
|---|---|
| `ad` | two cases `h_n<=y` and `y<h_n` give `C(ay+q)` |
| `r^2`, `lambda_O d^2` | `C(x^2+q)` |
| `tau_n`, `ell(a+r)` | `C(q+ay+x^2)` using `rho_n=n^-6` and the radius floor |
| `(1+a+d+x+r)w_z` | layer cake gives `Cq` |
| `(ad/r)w_z` | `(ad/r)q <= C R_O` |
| `(1+d/r)w_z^2` | `q^2+d/(nr) <= Cq` |
| `w_z^3`, `ell w_z` | `C(q+ay+x^2)` |

The cap on `d`, the positive floor `r=C_rad(s vee h_n)`, the separate
zero-treatment branch, `z=1`, `z>c_2n`, and `c_2n<1` cover cap equality,
zero budgets, large tails, and `n=1`.  No standalone `(d/r)w_z` term is left
unpaid.

## R branch

Write `r=bar t`, `d=d_all`, `ell=sqrt(tau_n/lambda_R)`, and
`R_R=q+bx+y^2`.  The source gives the mirror identities
`r >= C_rad h_n`, `d <= B_all`, `d <= C(x+y+r+rho_n)`, and
`lambda_R d^2=r^2`.

| Tail monomial | Certified reduction |
|---|---|
| `bd` | `C(bx+y^2+q)` by the `h_n<=x` / `x<h_n` split |
| `r^2`, `lambda_R d^2` | `C(y^2+q)` |
| `tau_n`, `ell(b+r)` | `C(q+bx+y^2)` |
| `(1+b+d+y+r)w_z` | layer cake gives `Cq` |
| `(bd/r)w_z` | `(bd/r)q <= C R_R` |
| `(1+d/r)w_z^2` | `q^2+d/(nr) <= Cq` |
| `w_z^3`, `ell w_z` | `C(q+bx+y^2)` |

The R denominator is separately certified conditionally on `F_2`, and the
cap, positive radius floor, clipping, unsafe fallback, and the `c_3n<1`
branch close all finite `n` and zero-budget corners.

## Tail integration and failure accounting

For each fixed admissible `z`, the relevant finite event intersection has
failure at most `K exp(-z)`.  Each monomial is integrated through
`int_1^infty z^(p/2)e^{-z} dz < infinity`; below `z=1` the proof uses the
`z=1` threshold, and beyond the certified window it uses clipping.  This is
the exact level required for expected absolute loss.  The revised event ledger
includes both D1 transfer events and all O/R weighted and denominator events.

## Falsification record

The dedicated validator rejects deletion of either amplified monomial,
deletion of O/R finite-union accounting, and a mutation that replaces the
pointwise family by a simultaneous-in-`z` claim.  The exact rational grids
for O and R report worst normalized absorption ratio `1`, and the historical
upper K2 boundary suite passes all 11 tests.

**Final disposition:** no missing `d/r` term, zero-radius division, cap-boundary
gap, unsafe-cell gap, or large-`z` remainder was found.  A stronger simultaneous
high-probability statement would be a different theorem and is not claimed.
