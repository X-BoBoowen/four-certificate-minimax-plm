# Localized-Rademacher and Appendix A/L definition audit

## Scope and final status

This audit verifies the implemented Master-R14/Candidate-C12 repairs in Appendix A and Appendix L. It does not change the Q1 order, the sequential-M1 information interface, the statistical model, a lower-bound rate, or a proof constant. The auxiliary response support and the remaining formal definitions are now explicit in both byte-identical successor trees.

### Terminology ledger

| Canonical term | Meaning in this draft |
|---|---|
| public instance `Gamma` | the two full public classes together with their two supplied ordered representations and evaluation maps |
| full difference class | `Delta G = {g-g' : g,g' in G}` |
| represented difference core | `Delta G^rep = {g_j-g_k : j,k in N}` |
| localized Rademacher complexity | population-L2-localized, sample-and-sign averaged complexity defined below |
| `q` family | the common three-point-treatment, binary-response lower experiment |

## A. Exact localized Rademacher definition

### Implemented definition in Appendix A

For a public class `G` and a supplied representation `G^rep={g_j:j in N}`, write

\[
 \Delta\mathcal G=\{g-g':g,g'\in\mathcal G\},
 \qquad
 \Delta\mathcal G^{\rm rep}=\{g_j-g_k:j,k\in\mathbb N\}.
\]

For `r>=0`, define the population-L2-localized Rademacher complexity by

\[
 \mathfrak R_{n,P_X}(r;\Delta\mathcal G)
 :=\mathbb E_{X_{1:n}\sim P_X^n}\,
   \mathbb E_{\sigma_{1:n}}
   \left[
   \sup_{\substack{f\in\Delta\mathcal G\\
                    \|f\|_{L_2(P_X)}\le r}}
   \left|\frac1n\sum_{i=1}^n\sigma_i f(X_i)\right|
   \right],
\]

where `sigma_1,...,sigma_n` are independent Rademacher signs, independent of `X_{1:n}`. Define `\mathfrak R_{n,P_X}(r;\Delta\mathcal G^{\rm rep})` by the same display with `\Delta\mathcal G^{\rm rep}` in place of `\Delta\mathcal G`.

The budget conditions are imposed only at positive radii:

\[
 \sup_{r\ge s,\ r>0}
 \frac{\mathfrak R_{n,P_X}(r;\Delta\mathcal G_\mu)}{3r}
 \le c_{\rm rad}s,
 \qquad
 \sup_{r\ge t,\ r>0}
 \frac{\mathfrak R_{n,P_X}(r;\Delta\mathcal G_\pi)}{3r}
 \le c_{\rm rad}t.
\]

At `r=0`, the unquotiented complexity in the preceding definition is meaningful, but neither quotient is defined or used. In particular, a zero singleton difference class has zero complexity at every positive radius, including when its declared budget is zero.

### Why this is the safe formulation

The implemented empirical-process suprema range over the countable represented core. Since `\Delta\mathcal G^{\rm rep}\subseteq\Delta\mathcal G`, their complexity is bounded by the declared full-class complexity. Do not assert equality of the two *localized* complexities merely from sequential density. At a fixed population-L2 boundary, approximating represented functions can approach the boundary from outside it. No star-shapedness, scaling closure, or linear-span closure is assumed or needed.

This makes the sample law, sign law, absolute supremum, population-L2 localization, and access-level relation explicit while preserving the current theorem field.

## B. Public-instance tuple and Q1/M1

### Implemented formal convention

Replace the overloaded phrase “a public pair `\Gamma=(\mathcal G_\mu,\mathcal G_\pi)` carries representations” with:

> An M1 public instance is
> \[
> \Gamma=(\mathcal G_\mu,\mathcal G_\pi,
>           \mathcal G_\mu^{\rm rep},\mathcal G_\pi^{\rm rep}),
> \]
> where `\mathcal G_\mu^{\rm rep}=\{g_{\mu,j}:j\in\mathbb N\}` and
> `\mathcal G_\pi^{\rm rep}=\{g_{\pi,j}:j\in\mathbb N\}` are ordered countable subsets of the respective full classes, have measurable evaluation maps, satisfy the same pointwise envelope, and are pointwise-everywhere sequentially dense in their respective full classes. We call `(\mathcal G_\mu,\mathcal G_\pi)` the class-pair projection of `\Gamma`.

Then use “public instance `\Gamma`” wherever the estimator receives representations, and retain “class pair” when only the two full classes matter. The Q1 display remains exactly

\[
 \sup_{\Gamma\in\GammaSet_{\rho,n}(a,s,b,t)}
 \inf_{\delta_\Gamma\ {\rm Borel}}
 \sup_{P\in\mathcal P_{\rho,n,a,s,b,t}(\Gamma)}
 \mathbb E_P\left|\delta_\Gamma(Z_{1:2n})-\beta(P)\right|.
\]

This is a typing repair, not a quantifier change: the representations were already public inputs under M1, and `\delta_\Gamma` was already allowed to use them.

## C. Positive variance and uniqueness of the target

### Implemented sentence after the indexed compatible-law definition

> The target `\beta(P)` is unique. Indeed, if two PLM representations of the same law satisfy the stated conditional-centering conditions, their conditional-mean difference is affine in `T` given `X`. Since `\operatorname{Var}(T\mid X)=\operatorname{Var}(u\mid X)=v\ge v_->0` almost surely, its slope must vanish, and hence the two coefficients agree.

The condition is already present: `0<v_-` is fixed in the regularity tuple and every compatible law has `v\in[v_-,v_+]`. This sentence only records the consequence needed to make `\beta(P)` visibly well-defined.

## D. Appendix L: complete common-host `q` law

### Support and conditional response law

After defining `T`, `L`, and `\theta`, replace the current response display with:

> Conditional on `(X,T)=(x,t)`, let `R\in\{-1,+1\}` have probabilities
> \[
> \Pr(R=r\mid X=x,T=t)
> =\frac12\left(1+\frac{2r\theta t}{B_0}\right),
> \qquad r\in\{-1,+1\},
> \]
> and set `Y=B_0R/2`.

This one line completes the response-law support. It also gives

\[
 \mathbb E[R\mid X,T]=\frac{2\theta T}{B_0},
 \qquad
 \mathbb E[Y\mid X,T]=\theta T.
\]

Thus, for the `q` construction with zero nuisances and coefficient `\beta_0=\theta`,

\[
 \varepsilon=Y-\theta T,
 \qquad
 \mathbb E[\varepsilon\mid X,T]=0.
\]

### Validity, envelope, and energy transfer

Let `r_0=\sqrt{v_0}`. The defining bounds on `m_\rho` imply

\[
 L=r_0+2m_\rho
 \le \frac{B_0+r_0}{2}<B_0,
 \qquad
 \frac{L}{r_0}
 =1+\frac{2m_\rho}{r_0}
 \le 1+\frac{r_0}{2B_0}<\frac32.
\]

Because `|\theta|\le B_0/(16r_0)`,

\[
 \left|\frac{2\theta T}{B_0}\right|
 \le \frac{3}{16}.
\]

Therefore the displayed binary probabilities lie in `[13/32,19/32]`. Moreover,

\[
 |T|=|u|<B_0,
 \qquad |Y|=B_0/2,
 \qquad
 |\varepsilon|
 \le B_0/2+|\theta|L
 \le 19B_0/32<B_0.
\]

The correct transfer sentence is:

> With the displayed binary response channel held fixed, the treatment-marginal contribution to the original likelihood-energy calculation depends on the treatment law through `\mathbb E[T^2]=v_0`. Hence the original energy certificate
> \[
> K_q=\frac{4(d_\rho^\star)^2v_0}{nB_0^2}
> \]
> and its testing-rate consequence carry over. This statement concerns the treatment-marginal contribution; the full likelihood also uses the displayed conditional response channel.

This preserves the intended testing calculation without claiming that a second moment alone specifies the entire response likelihood.

## E. The `L^2/v_0` check

The proposed identity

\[
 \frac{L^2}{v_0}=1+\frac{2m_\rho}{v_0}
\]

is false and must be rejected. From `L=\sqrt{v_0}+2m_\rho`, the exact identity is

\[
 \frac{L^2}{v_0}
 =\left(1+\frac{2m_\rho}{\sqrt{v_0}}\right)^2
 =1+\frac{4m_\rho}{\sqrt{v_0}}
   +\frac{4m_\rho^2}{v_0}.
\]

The proof needs only the valid bound on `L/\sqrt{v_0}` above. If a conservative `L^2/v_0` bound is desired, it must be proved independently, not inferred from the false identity. In fact, using

\[
 \frac{m_\rho}{\sqrt{v_0}}
 \le \min\left\{\frac{1}{64\sqrt{v_0}},
                    \frac{\sqrt{v_0}}{4B_0}\right\}
 \le \frac{1}{16\sqrt{B_0}}
 \le \frac{1}{16\sqrt3},
\]

gives

\[
 \frac{L^2}{v_0}
 \le \left(1+\frac{1}{8\sqrt3}\right)^2
 <\frac76.
\]

Thus `L^2/v_0\le 7/6` is a valid optional coarse bound under the stated assumptions, but it is neither the erroneous identity nor necessary for the probability, centering, envelope, or energy argument.

## Final verification disposition

1. Expand the localized Rademacher definition in Appendix A and explicitly distinguish full and represented difference classes.
2. Make representations literal fields of the public instance `\Gamma`, while retaining the class-pair projection terminology.
3. Add the one-sentence positive-variance uniqueness statement for `\beta(P)`.
4. State `R\in\{-1,+1\}` in Appendix L.
5. Scope “uses only this second moment” to the treatment-marginal likelihood-energy contribution.
6. Reject the false `L^2/v_0` equality. Do not add it to the manuscript; use the correct `L/\sqrt{v_0}` bound, and include the optional `7/6` bound only if it serves an explicit audit purpose.

All six checks pass in Master-R14 and Candidate-C12.  The successor validator checks the sample/sign expectation, absolute supremum, population localization, represented-core relation, positive-radius convention, absence of star-shaped closure, represented-instance tuple, target uniqueness, binary response support, qualified second-moment sentence, correct ratio inequality, and absence of the false identity.  The two successor trees and rendered PDFs are byte-identical.
