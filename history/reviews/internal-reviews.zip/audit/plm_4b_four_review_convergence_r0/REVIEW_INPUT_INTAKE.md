# Review-input intake ledger

This ledger makes the eight-return ingestion step independently auditable.  It
does not elevate any return above external AI red-team evidence, and it does
not create human-review, novelty, priority, acceptance, or
submission-readiness credit.

All eight source files were read in full before the convergence dispositions
were finalized.  Each hash below was recomputed from the attachment bytes.
Review 4 contains two near-duplicate complete reports from one expert and is
therefore one return, not two votes.

| Return | Attachment ID | Bytes | SHA-256 | Intake/read disposition | Principal matrix use |
|---:|---|---:|---|---|---|
| 1 | `9a5592ad-36a0-428f-8d17-5f923ec87673` | 40470 | `97FAD16BC631A5FCE6DB663D1E087C75455C007CF22FCBD2C77A3FC8A8492CB9` | Hash matched; complete report read | theorem field, contribution hierarchy, prior-work risks |
| 2 | `66fa9cf8-4dfd-4183-856e-a4fcdad80a70` | 37850 | `F184CED7AFF4F0F0374F629706EBD6E10196107C36449ED335E368E4086BDD3C` | Hash matched; complete report read | C10/C11 repair provenance and bounded-positioning checks |
| 3 | `8fa76389-61fe-4865-9cc7-2175c47d3458` | 43181 | `71037F60BB684C1D64F9619D62200E61B2C18762C83483F5B76C32439EF51A52` | Hash matched; complete report read | theorem field, all-`z` risk, novelty boundary |
| 4 | `990993cc-7fbd-44a5-9c40-e6ed5c8c058e` | 98173 | `191C79AAF880D2831464F42A644B61F4DE106B4D8790C7556F544C98905BFDE6` | Hash matched; both near-duplicate reports read; counted once | independent source/definition review and positioning |
| 5 | `c43101fa-185c-4f6c-94c3-53e601758340` | 35757 | `3C9C60D1B24363D703CED825A52E991B6ED677305CE90B91249FC6CBD9D29012` | Hash matched; complete report read | D1/D2 event-interface defect and repair obligation |
| 6 | `7654cd1e-be3b-4d27-b465-a6d9d84e8f0b` | 36152 | `AEFE4A59FC7ECB5A7D7155B3DD8B8A9C85FB541880A77299257FE9E04DB10A78` | Hash matched; complete report read | second-stage D1/D2 repair verification |
| 7 | `41f6015d-b94c-4fe6-a43c-8e94e5a864db` | 43799 | `7B80F561B3E5D079898062D8B463D60262E009BE150BD6D88ED34908A78F179C` | Hash matched; complete report read | D1/D2 defect, definition audit, proposed Appendix-L identity |
| 8 | `fcab744f-551d-44bb-8445-8bee5e1744ec` | 37525 | `302BD4883B00C239E0C22EAB03AFA09BADC802D208687A21021D24C0C91F0F2F` | Hash matched; complete report read | second-stage repair verification and rejection of the false identity |

The claim-level accept/reject/clarify/expansion dispositions are recorded in
`strategy/plm_4b_four_review_convergence_r0/REVIEW_CONVERGENCE_MATRIX.md`.
They are based on source replay and primary-source verification, not vote
counting.  No attachment text is copied into the manuscript as authority.
