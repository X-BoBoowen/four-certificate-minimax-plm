# PLM-4B: D2-to-D1 event-transfer audit

**Status:** final source-level proof audit of Master-R14/Candidate-C12.  No manuscript conclusion is
changed here.  “Confirmed” means that the stated claim follows under the frozen theorem
model and estimator interface; it does **not** establish a stronger adaptive,
computable, heteroskedastic, or simultaneous-in-`z` statement.

## 1. Scope and fixed assumptions

Final source audited:

- `paper/iclr2027_candidate_c12/main.tex`;
- `paper/iclr2027_candidate_c12/appendices/B_upper_proof.tex`, especially
  (B.1a)–(B.5), (B.7), (B.9), (B.12)–(B.20), (B.21)–(B.30), and the
  event ledger at lines 1061–1195.

The model supplies two independent iid halves `D1,D2`,
\(
T=\pi_0(X)+u,\quad Y=\beta_0T+\mu_0(X)+\varepsilon,
\)
with
\(
E[u\mid X]=0,
E[\varepsilon\mid X,T]=0,
E[u^2\mid X]=v\in[v_-,v_+].
\)
All variables/residuals have a fixed `B0` envelope and public functions have
a fixed `BG` envelope.  The four budgets are declared pre-data upper
certificates in \([0,1]^4\), not realized errors.  Countable represented
cores and their common envelopes are essential for all empirical suprema and
Borel selections.

I use the source's conditioning fields:

\[
 \mathcal F_2=\sigma(\mathcal D_2),\qquad
 \mathcal F_X=\mathcal F_2\vee\sigma(X_{1:n}),\qquad
 \mathcal F_T=\mathcal F_X\vee\sigma(T_{1:n}).
\]

Thus, conditionally on `F_X`, the D1 residuals `u_i` remain independent and
centered; conditionally on `F_T`, the D1 response residuals `epsilon_i`
remain independent and centered.  This is the only sample-splitting fact
needed for the fitted D1 weighted events.

## 2. D2 fits, D1 empirical transfer, and event legality

### 2.1 Primitive uniform events are formed before any fit is inserted

**Claim: CONFIRMED.**

`B_upper_proof.tex` lines 205–247 first applies the localized multiplier and
square-process lemma to fixed countable represented cores.  Its seven calls
are:

| Call | half / object | fixed multiplier or process | downstream use |
|---|---|---|---|
| `P_{pi,2}^u` | D2, `Delta G_pi` | centered `u`, plus square | treatment fit (B.6)–(B.7) |
| `P_{mu,2}^{sq}` | D2, `Delta G_mu` | square | outcome empirical radius after (B.9) |
| `P_{J,2}^epsilon` | D2, joint `J_mu` | centered `epsilon`, plus square | joint fit (B.8)–(B.9) |
| `P_{mu,1}^u` | D1, `Delta G_mu` | centered `u`, plus square | O calibration (B.12)–(B.16) |
| `P_{pi,2}^xi` | D2, `Delta G_pi` | `xi=Y-m_0(X)`, centered given `X` | R calibration (B.21)–(B.22) |
| `P_{pi,2}^{m_0}` | D2, `Delta G_pi` | fixed `m_0(X)` | R calibration (B.21)–(B.22) |
| `P_{pi,1}^{m_0}` | D1, `Delta G_pi` | fixed `m_0(X)`, plus square | R calibration (B.21)–(B.25) |

For each call, Lemma B.3 works with a countable class containing zero,
a fixed envelope, and the public positive-radius local-Rademacher
certificate.  Its shell argument gives, for `1 <= z <= n`, uniform bounds

\[
 |(P_n-P)(\xi f)|,\ |(P_n-P)f^2|
 \lesssim \delta_z\|f\|_2+\delta_z^2,
 \qquad \delta_z=K(r_0\vee h_n)+\sqrt{z/n},
\]

with exponentially small failure.  The proof explicitly covers `n=1`, zero
stochastic budgets, and the positive-radius floor (B.2b–B.2d, lines
180–202).  The finite union gives
\(
P((E_z^{proc})^c)\le K_4e^{-z}
\)
at (B.5).  Because these are class-uniform events, later use at a fitted
function is a substitution into an already-formed event, not a fresh
pointwise concentration assertion at a random index.

**First mathematical obligation.**  Every fitted index used downstream must
belong to the represented class/difference core to which the event applies;
and the multiplier must be centered under the stated conditioning.  This is
satisfied: the M1 transfer makes represented and full objectives agree, while
the PLM equations give the relevant centering.  In particular,
\(
E[\xi\mid X]=E[\beta_0u+\varepsilon\mid X]=0.
\)

**Blocker if assumptions change.**  Losing countability/measurable
representation, conditional centering, or iid sample halves would invalidate
this step.  None is absent in C11.

### 2.2 D2 initial fits

**Claim: CONFIRMED.**

The treatment fit `hat pi` and joint fit `(hat beta_0,hat mu)` use D2 only.
The source first proves their exact tail inequalities and then defines
`E_{pi,z}^{fit}` and `E_{mu,z}^{fit}` by those inequalities, rather than by
an intersection over comparator slack; see B lines 461–475 and the ledger
lines 1117–1137.  Therefore both events are unconditional D2 events with
failure `K exp(-z)`, `1 <= z <= n`.

The fixed proof comparators are legitimate proof devices, not inputs to the
learner.  Letting their positive slack tend to zero through scalar tail
probabilities avoids an uncountable intersection.  The initial-fit outcomes
used later are:

\[
 \|\widehat\pi-\pi_0\|_2
 \lesssim b+t+\bar t+\sqrt{z/n}+\rho_n \tag{B.7}
\]
and
\[
 |\widehat\beta_0-\beta_0|+\|\widehat\mu-\mu_0\|_2
 \lesssim a+s+\bar s+\sqrt{z/n}+\rho_n. \tag{B.9}
\]

Their empirical-radius analogues are also included in the exact fit events.
No D1 outcome is used to form either initial fit.

### 2.3 O branch: D1 calibration and fitted weighted terms

**Claim: CONFIRMED.**

The O edit uses D1 `(X,T)` and D2 fits, but no D1 response before the final
weighted step.  The D1 uniform event `P_{mu,1}^u` is constructed before the
edit; with the scalar D1 denominator event it controls the proof comparator
`a_0` and then the edit objective, yielding (B.12)–(B.16), lines 559–653.
The normalization constraint `P_1(T hat a)=1` is exact, by the rational
dense hyperplane chart in (B.11), not an empirical approximation.

For the five-term identity (B.17), the first two weights,
`w=u/v` and `hat a-w`, are `F_T`-measurable.  Hence (B.1a), conditionally
on `F_T`, applies to `epsilon w` and `epsilon(hat a-w)`.  The fixed
comparator residual `r_mu=mu_0-g_mu` is deterministic (relative to the
data) and `r_mu w` has conditionally centered D1 summands given `F_X`.
This gives the three inequalities defining `E_{O,z}^{wt}` at lines 687–702.
Integrating the three conditional tail probabilities and union bounding gives
failure at most `6 exp(-z)`, rather than assuming conditional events from
different fields are literally the same event.

The full O event
\(
E_{O,z}=E_z^{proc}\cap E_{pi,z}^{fit}\cap E_{mu,z}^{fit}
\cap E_{D_0,z}\cap E_{O,z}^{cmp}\cap E_{O,z}^{wt}
\)
has failure `K_{O,0}exp(-z)` on its admissible range.  This is recorded both
at (B.18), lines 704–740, and in the ledger, lines 1144–1162.

### 2.4 R branch: the dependency-sensitive D1 transfer

**Claim: CONFIRMED.**

The key nontrivial point is that the R edit `hat m` uses D2 outcomes and D1
covariates, but not D1 treatments or responses.  It is therefore
`F_X`-measurable.  In (B.25) the empirical process is uniform in the
represented propensity difference core before substituting
`f=hat pi-g_pi`; see B lines 880–886.  This is legal despite `hat m` using
D1 covariates, because D1 treatment randomness has not been conditioned away.

For the denominator, `e_pi=hat pi-pi_0` is `F_2`-measurable.  Conditional
on `F_2`, the D1 variables
\(
W_i=(u_i-e_\pi(X_i))^2
\)
are iid, bounded in `[0,B_D^2]`, and have
\(
E(W_i\mid F_2)=v+\|e_\pi\|_2^2.
\)
The equality uses constant conditional treatment variance and
`E[u|X]=0`; it is not merely an unconditional calculation.  Conditional
Bernstein thus supplies `E_{R,z}^{den}` with conditional and unconditional
failure at most `2 exp(-z)`, (B.26)–(B.27), B lines 894–927 and ledger
lines 1164–1175.

In the R identity (B.28), `epsilon(u-e_pi)` is handled conditionally on
`F_T`; `r_m u` and `u e_pi` are handled conditionally on `F_X`.  The
required measurability is exactly as above and yields a `6 exp(-z)`
unconditional union failure (B lines 969–987).  The assembled R event has
failure `K_{R,0}exp(-z)` and supports (B.29); see ledger lines 1177–1194.

**First mathematical obligation.**  The edit must not use D1 treatment or
response.  If `hat m` were fitted on the whole D1 tuple, then conditioning
on `F_X` would not make it fixed while preserving centered `u_i`; the
weighted control of `P_1(r_m u)` would fail.  C11 satisfies the obligation.

## 3. Generic pointwise-tail-to-expectation rule

The source never needs one event that holds simultaneously for all `z`.
Instead, it has, for every individually selected `z` in `[1,cn]`, an event
`E_z` with `P(E_z^c) <= K exp(-z)` and an increasing nonnegative envelope
`G(z)` such that `Z <= G(z)` on `E_z`.  Thus
\(
P\{Z>G(z)\}\le Ke^{-z}.
\)
Layer cake/integration by parts bounds the contribution of each monomial
`C(z/n)^{p/2}` by a constant multiple of `C n^{-p/2}` because
\(
\int_1^\infty z^{p/2}e^{-z}dz<\infty.
\)
The source truncates at `cn`; clipping bounds the remaining event by
`6K exp(-cn)`.  This is a pointwise tail family, not a simultaneous-in-z
high-probability statement.  The ledger expressly says so (B lines
1061–1065).

## 4. O branch: (B.18) implies (B.20), monomial by monomial

Set `r=bar s`, `d=d_pi`, `w_z=sqrt(z/n)`,
`ell=sqrt(tau_n/lambda_O)`, and `R_O=q+ay+x^2`.  The O-safe condition is
`x<=y` and `bar s<=vartheta_rho`; it gives `r>0` even at `s=0` because
`r=C_rad(s vee h_n)`.

The deterministic facts in (B.19) are
\[
h_n^2\le2q,\quad r\ge C_{rad}h_n,\quad
d\le B_\pi,\quad d\lesssim y+r+\rho_n,\quad
\lambda_Od^2=r^2.
\]
Their consequences, including both zero and nonzero budget corners, are:

| B.18 monomial | integrated / deterministic scale | absorption into `R_O` |
|---|---|---|
| `ad` | deterministic | `d <= C(y+r+rho_n)`. If `h_n<=y`, then `ar <= C ay` because `s<=x<=y`; if `y<h_n`, then `a<=x<=y<h_n`, so `ar <= C h_n^2 <= Cq`. |
| `x^2` | deterministic | included in `R_O`. |
| `r^2` and `lambda_O d^2` | deterministic | `r^2=C_rad^2(s vee h_n)^2 <= C(x^2+q)`. |
| `tau_n` | deterministic | `n^{-12} <= q` for `n>=1`. |
| `ell(a+r)` | deterministic | `ell=rho_n d/r`; use `d<=C(y+r+rho_n)` and the preceding two-case split. The intentionally extreme `rho_n=n^{-6}` makes the remaining terms no larger than a fixed multiple of `q+ay+x^2`. |
| `(1+a+d+x+r)w_z` | `q` | On the O-safe cell `a,x,r` are bounded and `d<=B_pi`; `int w_z e^{-z} dz \asymp q`. |
| `(ad/r)w_z` | `(ad/r)q` | The preceding `ad` split plus `q/r <= C` gives `(ad/r)q <= C R_O`. |
| `w_z^2` | `q^2` | `q^2<=q`. |
| `(d/r)w_z^2` | `d/(nr)` | `d/(nr) <= B_pi/(C_rad sqrt(n log(en))) <= Cq`; this is the only potentially dangerous `d/r` term. |
| `w_z^3` | `q^3` | `q^3<=q`. |
| `ell w_z` | `ell q` | same `ell=rho_n d/r` split; absorbed by `R_O`. |

This is exactly the calculation summarized at B lines 749–780.  In
particular, there is no unaccounted standalone `(d/r)w_z` or
`lambda_O^{-1}w_z^2`: B lines 741–747 identify the only amplification terms
coming from (B.14), and they are both in the table above.

**Zero budgets / cap.**  At `s=0`, `r=C_rad h_n>0`, so division by `r`
is defined.  The cap in `d=min(B_pi,8(y+r+rho_n))` gives both a uniform
envelope for `d/(nr)` and the small-radius estimate used for `ad`; neither
case requires a truth-dependent cap choice.

**Large z and n=1.**  The tail inequality is only used for
`1<=z<=c_2 n`.  The range below `z=1` uses the `z=1` threshold.  Beyond
`c_2n`, clipping gives a loss at most six times the tail probability;
if `c_2n<1`, then `q>sqrt(c_2)` and the deterministic clipping bound is a
fixed multiple of `q`.  The O all-zero-treatment branch has probability at
most `exp(-p_rho n)` and contributes `O(q)` separately (B lines 541–557,
781–788).  Therefore the source obtains
\(
\sup_P E|\widehat\beta_O-\beta(P)|\lesssim R_O,
\)
which is (B.20).

**O conclusion:** CONFIRMED.  No unclosed monomial or denominator-zero
blocker was found.

## 5. R branch: (B.29) implies (B.30), monomial by monomial

Set `r=bar t`, `d=d_all`, `ell=sqrt(tau_n/lambda_R)`, and
`R_R=q+bx+y^2`.  The R-safe cell is `y<x`, `bar t<=vartheta_rho`, so
again `r=C_rad(t vee h_n)>0` when `t=0`.

The R counterparts of the O bounds are B lines 1027–1041:
\[
r\ge C_{rad}h_n,\quad d\le B_{all},\quad
d\lesssim x+y+r+\rho_n,\quad\lambda_Rd^2=r^2.
\]

| B.29 monomial | integrated / deterministic scale | absorption into `R_R` |
|---|---|---|
| `bd` | deterministic | if `h_n<=x`, send the `b h_n` piece to `bx`; if `x<h_n`, use `b<=y<x<h_n`, hence `b h_n<=h_n^2<=2q`. The remaining terms are `bx` or `y^2`. |
| `y^2` | deterministic | included. |
| `r^2`, `lambda_Rd^2` | deterministic | `r^2<=C(y^2+q)`. |
| `tau_n`, `ell(b+r)` | deterministic | `tau_n<=q`; `ell=rho_n d/r` and the same two-case split absorb its products. |
| `(1+b+d+y+r)w_z` | `q` | all coefficients are bounded on the R-safe cell (`d<=B_all`; budgets are in `[0,1]`). |
| `(bd/r)w_z` | `(bd/r)q` | source proves `(bd)/(r sqrt n)<=C R_R`; this is precisely `(bd/r)q`. |
| `w_z^2` | `q^2` | at most `q`. |
| `(d/r)w_z^2` | `d/(nr)` | `d/(nr)<=B_all/(C_rad sqrt(n log(en)))<=Cq`. |
| `w_z^3` | `q^3` | at most `q`. |
| `ell w_z` | `ell q` | absorbed by the displayed `ell` bound. |

These are the source's explicit three principal absorptions and termwise
layer-cake calculation at B lines 1027–1055.  They are not obtained by an
unjustified O/R symmetry: the R denominator and fitted calibration are
separately derived in (B.21)–(B.28).

**Zero budgets / cap / large z / n=1.**  The same positive floor handles
`t=0`; the cap `d<=B_all` handles `d/(nr)`; the `z=1`, `z>c_3n`, and
`c_3n<1` steps are repeated explicitly at B lines 1042–1049.  The
denominator floor is inactive on the good event by (B.27), and clipping
handles its complement.  Consequently (B.30) follows.

**R conclusion:** CONFIRMED.  No unclosed `d/r` term, zero-budget division,
or large-z remainder was found.

## 6. Unsafe cells and selector completion

Although the requested all-z calculation concerns safe branches, the
all-budget conclusion also needs the selector/fallback.  At B lines
1200–1256 the selector is public: it depends only on the certificates
`x=a+s`, `y=b+t` and frozen radii, not on data or nuisance truths.

For an unsafe O-oriented cell with `h_n<=delta_rho`, the failed O safety
test gives `s>delta_rho`.  If `t>=s/2`, then
`M=(s wedge t)^2>=s^2/4`; if `t<s/2`, `x<=y` forces
`b>s/2`, so `P=s(b wedge s)>s^2/2`.  The R argument swaps the roles and
forces either `M` or `O`.  If `h_n>delta_rho`, then
`delta_rho^2<h_n^2<=2q`.  Since the clipped zero output loses at most three,
this proves (B.33).  The six weak-order budget cells yield
`T_selected<=48X` in (B.31)–(B.32).  Thus safe-branch expected bounds and
unsafe fallback combine without an unmentioned asymptotic small-radius
assumption.

**Conclusion:** CONFIRMED for the stated known-certificate, pair-specific
Borel rule.  An adaptive/computational selector would be a scientific
extension, not a consequence of Appendix B.

## 7. Final audit disposition

| Check | disposition | exact boundary |
|---|---|---|
| D2 fits then D1 uniform/conditional transfer | CONFIRMED | relies on two independent iid halves, M1 countability, and the stated conditional centering. |
| O all-z `(B.18)->(B.20)` | CONFIRMED | pointwise-in-z exponential tails plus clipping; not a single event simultaneous in z. |
| R all-z `(B.29)->(B.30)` | CONFIRMED | additionally relies on constant conditional treatment variance for the denominator center. |
| zero budgets, cap, unsafe cells, n=1, and large-z tails | CONFIRMED | handled by `h_n` floor, caps, (B.33), clipping, and separate O zero-vector accounting. |
| common practical/adaptive selector | SCIENTIFIC EXPANSION | current proof assumes declared public upper certificates and arbitrary pair-specific Borel computation. |

No mathematical blocker was found within C12's stated theorem field.  The
smallest audit-facing improvement would be a one-paragraph generic
pointwise-tail/layer-cake lemma immediately before the two termwise
integrations, to preclude readers from mistaking “all-z” for event
simultaneity.  This is a clarity addition, not a repair required for the
displayed expected-absolute-risk result.
