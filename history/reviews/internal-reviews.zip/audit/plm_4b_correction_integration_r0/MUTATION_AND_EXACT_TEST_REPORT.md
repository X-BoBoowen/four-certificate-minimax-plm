# Mutation and exact-test report

## Registered source mutations

The integration validator was written test-first. Its initial test run failed
because the validator module did not yet exist. After implementation and a
production-LaTeX normalization test, all 16 tests pass. The suite detects the
eleven required old mutations and five coupled omissions.

| Mutation / positive gate | Detected issue |
|---|---|
| `c_rad=0` or nonpositive theorem field | C01 |
| literal zero-radius quotient | C02 |
| delete `lambda_rho` from P, O, or M separately | C03 |
| old uncapped scalar target | C04 |
| omit joint class | C05 |
| replace corrected B.9 chain by one-line invocation | C06 |
| old B.12 | C07-B12 |
| old B.14 | C07-B14 |
| false amplification explanation | C07-PROSE |
| mirror-only R proof | C08 |
| omit Hellinger square root | C09 |
| omit measurable base space | C10 |
| require one Gamma across all n/budgets | C11 |
| omit statistical/causal target boundary | C12 |
| equivalent production LaTeX (`frac`, `\(\)`, `v_-=v_0`) | accepted, not a false positive |
| complete corrected fixture | accepted |

The production scan reports `PASS issues=none` for both frozen Master-R4 and
Candidate-C2.

## Certified exact suites replayed

| Suite | Tests | Result |
|---|---:|---|
| K0 membership/rescaling | 9 | PASS |
| K1 scalar target cap and splice | 9 | PASS |
| K2 joint geometry and O/R absorption | 11 | PASS |
| R0 mutation suite | 16 | PASS |

Final accounting: 45/45 tests pass. The K0/K1/K2 suites use exact rational or
symbolic arithmetic where specified. They check certified identities,
boundaries, source-map membership, and falsifiers; they do not replace the
printed proofs.

