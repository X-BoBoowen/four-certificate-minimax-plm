# Theorem and claim consistency audit

## Statement propagation

Title, abstract, introduction, contribution paragraph, Theorem 1,
Proposition 2, discussion, limitations, related work, all tables, figure
caption, reproducibility statement, AI-use statement, Appendices A--K, and the
three external ledgers were checked against the frozen theorem field.

- The headline rate is unchanged.
- The theorem now says `c_rad>0`; all positive-radius and boundary qualifiers
  agree with it.
- The main risk display and Appendix A use the same Q1 order and the same
  n/budget-indexed admissible-pair semantics.
- The target is consistently statistical, not causal.
- The public represented pair and exact budgets are consistently described as
  strong learner information.
- The shared-envelope saturation result is consistently model-specific.
- No unknown-budget, common-estimator, efficient, practical, confidence-set,
  or uniform-in-rho theorem is stated.

## Attribution propagation

- Gu--Yin--Cai--Fan's q+AB+M statement is named in the contribution paragraph,
  assembly discussion, prior-work table, related work, and citation ledger.
- Neither the ab nor M rate is claimed new. The manuscript limits its role to
  the native bounded/M1/fixed-variance embeddings and matching assembly.
- TAME is credited for the editing/calibration and two-branch upper
  architecture. The manuscript claims an interface closure, not a generic new
  editor.
- O/P necessity and the full native matching assembly are presented as the
  principal possible increment, without `first`, priority, or collision-free
  language.
- The search non-hit is explicitly scoped and is not used as novelty evidence.

## Remaining judgment boundary

Fresh theorem-level collision review and ICLR significance remain independent
human judgments. The corrected source does not convert those open judgments
into claims. Verdict: PASS for consistency; no novelty certification.

