# Master-R4 / Candidate-C2 scientific equivalence

Master-R4 was completed and its 27-file scientific-source bundle was frozen at
`2026-08-24T17:14:52.2825276+08:00` before Candidate-C2 was created.
Candidate-C2 was then copied from that frozen tree. No Candidate change fed
back into Master.

Verification results:

- 27/27 frozen scientific files match their recorded Master-R4 SHA-256;
- the corresponding 27/27 Candidate-C2 files have the same SHA-256;
- both ordered source aggregates are
  `90622AE925D6DBE9A210426DAEC2B82BD739AF05222DF0FE5118ADEB63FF32AB`;
- `main.tex`, every appendix, canonical bibliography, template, figure, figure
  source, claim ledger, proof index, and citation index are byte-identical;
- Candidate-specific difference: QA filename/content and independently
  generated build artifacts only;
- rendered PDF comparison: 31/31 pages pixel-identical.

There is no scientific or presentational divergence. Candidate-C2 is an exact
conference derivative of the frozen Master-R4. Verdict: PASS.

