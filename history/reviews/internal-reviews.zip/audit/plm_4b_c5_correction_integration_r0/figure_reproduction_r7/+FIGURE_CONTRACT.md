# Theory-summary figure contract

- Core conclusion: O/P are order-changing terms on legal nuisance-dominated rays; envelope saturation is a separate identification stratum.
- Evidence logic: panel (a) plots only analytic formulas `r^3` and `r^2` and their exact ratio; panel (b) is categorical, not a fitted or continuous phase curve.
- Intended use: compact main-text mechanism summary after the theorem.
- Data status: no empirical or simulated observations.  `rate_ray_data.csv` is deterministically generated from displayed formulas.
- Required exports: PDF for LaTeX, SVG for editable inspection, PNG for visual QA.
- Reviewer risks controlled: the caption must state that `q` is suppressed in the nuisance-dominated ray comparison; no uniform behavior of constants near saturation is encoded; colors are redundant with labels and line styles.
- Backend: Python/matplotlib, following the saved project preference.

