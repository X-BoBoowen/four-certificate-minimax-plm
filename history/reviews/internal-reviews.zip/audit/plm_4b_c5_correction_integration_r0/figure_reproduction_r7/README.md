# Figure 1 reproduction

From the manuscript source-tree root, run:

```text
<PYTHON_EXECUTABLE> figures/+generate_theory_summary.py
```

The script requires Python with NumPy and Matplotlib. It writes the analytic
ray data and PDF/SVG/PNG figure files into `figures/`. The CSV and raster PNG
are expected to reproduce byte-for-byte in the audited environment. PDF
creation timestamps and automatically generated SVG element identifiers may
differ without changing plotted content.

The figure contains analytic formulas only. It contains no empirical
measurements or simulated performance evidence.
