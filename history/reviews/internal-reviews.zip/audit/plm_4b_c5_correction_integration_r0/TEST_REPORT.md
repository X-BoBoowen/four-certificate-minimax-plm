# PLM-4B-C5 correction-integration test report

Acceptance observation time: 2026-08-26T18:04:28.3083291+08:00.

## New X1/R1 gates

- Integrated source/protected/build/mirror and hostile mutation checks: 64/64 PASS.
- Exact fixed-host, Walsh, singleton-boundary, and sequential-transfer tests: 15/15 PASS.
- Robust PDF infinity extraction and mutation rejection: 3/3 PASS.
- Hostile mutations rejected: arbitrary standard-Borel matching, singleton admission, ambient reset, deleted R1 transfer lemma, unrepresented comparator, ambient space inside Gamma, rate drift, and infinity-to-one.

## Historical regression

- Core/correction suites: CRAD 9/9, scalar q 9/9, empirical upper 11/11, R0 integration 16/16, R1 correction 12/12; total 57/57 PASS.
- P/O/ab/M suites: P 7/7, O 9/9, ab exact/falsifier 11/11 + 5/5, M exact/falsifier 12/12 + 7/7; total 51/51 PASS.
- Source-integrity, R0 production, and R1 production validators are required on both R7 and C5 and pass after the final reproducibility-command repair.
- Bibliographies parse as 592 entries with zero duplicate keys in canonical, R7, and C5 copies.

## Diagnosed tooling events

- rg is unavailable; the frozen full-tree searches were executed with PowerShell Select-String.
- A production-validator failure R1-FIGURE-REPRO exposed a real omission of the portable reproduction command. The command was restored without scientific change.
- A long-path TeX underfull warning and a URL-rendered missing command space were separately reproduced and traced. Final source uses a breakable path plus two explicit command tokens; the final log has zero registered LaTeX defects and the rendered command is readable.
- Tectonic emits a host Fontconfig configuration message before TeX, but the engine exits 0; the retained LaTeX logs have zero warning/error/undefined/overfull/underfull hits.

Runner, rendering, and tool failures were never interpreted as mathematical evidence.
