# Figure reproduction audit

The final Master-R7 figure script was copied into an isolated acceptance directory and executed with Python 3.11, NumPy 2.4.6, and Matplotlib 3.11.

| Output | Verification |
|---|---|
| +rate_ray_data.csv | byte-identical; SHA-256 8424A385E5188AA79D143FE54445085980976AC72C97E4E96EDA1787B14CEBB9 |
| +theory_summary.png | byte-identical; SHA-256 5B84AE2D6CD5707C5F3FC934971935C86D3BC3E7C234E7524916F9105B45172D |
| theory_summary.pdf | 300-dpi raster byte-identical; raster SHA-256 047B00727ABFA425B70C57369F8AF03BD45DA958773C7BE5CC07A907B28F2795 |
| +theory_summary.svg | identical after normalizing only the timestamp and Matplotlib-generated internal IDs; 104 dynamic ID occurrences in each |

The figure is analytic and introduces no empirical or simulated-performance evidence. The manuscript renders a portable command with an explicit space between executable and script path.
