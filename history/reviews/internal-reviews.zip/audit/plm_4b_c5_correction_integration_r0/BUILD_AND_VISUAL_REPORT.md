# Master-R7 / Candidate-C5 build and visual report

## Clean builds

Both final sources compile with Tectonic 0.17 into fresh output directories.

| Artifact | In-tree PDF SHA-256 | Pages | Main / references / appendix | Final log defects |
|---|---|---:|---|---:|
| Master-R7 | 63A542B2D91A4C65F98044A74CAA99716CC2C8B1584B80AE10142097732E82A2 | 34 | 1--9 / 10 / 11--34 | 0 |
| Candidate-C5 | D8DD7EB9F01038D0AA863F78C3972950AD98B6B6225E4A69D3CF7F92E45E2259 | 34 | 1--9 / 10 / 11--34 | 0 |

Fresh-build PDFs have SHA-256 B4F9C00C42E96BA0275B3B88F953126D98D8D39B9E98180CC8F4714A8D4BFE5B and 74E62BDEBECFB88F794A778DD47194466D688FED0A854B44F9C4B2D8AFC6BD1D; their byte differences are creation metadata, while the rendered page pairs are identical.

No template, font-size, margin, negative-spacing, or crop change was made. Candidate-C5 retains the ICLR 2027 anonymous conference template.

## Visual QA

The full 34-page Master-R7 render was inspected. Pages 1, 2, 9, 11, 14, 21, 32, and 34 received original-resolution spot inspection for the revised front matter, theorem-domain statement, related-work table, R1 lemma, lower replay, boundary theorem, proof audit, and final appendix. After the final reproduction-command repair, all 34 pages were rerendered; only page 9 changed relative to the full inspection set, and page 9 was reinspected at original resolution.

Acceptance render comparison: 34/34 Master/Candidate page PNG hashes identical; clipping, overlap, truncated table, stranded heading, and unreadable command hits 0.

## Anonymity and leakage

PDF title and author metadata are blank. Extracted PDF text has zero hits for project identity, account identity, local absolute paths, PROJECT_STATE, DECISION_LOG, old candidate/master identifiers, and internal percentages. Scientific source text has zero unexplained local-path or account hits.
