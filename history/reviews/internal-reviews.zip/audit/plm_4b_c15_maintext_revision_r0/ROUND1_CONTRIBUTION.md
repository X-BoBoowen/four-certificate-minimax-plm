# C15 正文贡献与证据审查

这是 AI 辅助审查报告，不是作者自评，也不是完整正确性认证。我按正文先行方式完整阅读了 C15 `main.tex` 的正文，核对 `main.pdf` 的页序、正文九页边界及第 1、2、8、9 页文本；定向读取 `references.bib` 的相关条目与附录 C、D、G、L。未修改稿件。公开一手核验针对 TAME v1、Gu–Yin–Cai–Fan（GYCF）v1 和 JMS 的 NeurIPS 2025 正式论文；另委派一个只读子代理独立核查 JMS。没有开展穷尽历史检索、作者 GitHub 检索、H2 调查或新增自然类研究。

隔离限制必须披露：检查自己子代理状态时，我误用了未带路径筛选的全局 `list_agents`，工具被动返回了其他历史代理的完成摘要。此前关于 TAME、GYCF、乘积比较和主要推论的判断已经自主完成并发给主代理；这些历史摘要未用作本报告证据。由于发生过这次暴露，本报告不自称“完全盲审”或“完全隔离审查”。以下结论依据列明的一手原文、C15 和独立推导。

**核心判断。** 本稿最有说服力的正面表述是：在明确的有界、常条件残差方差、已知四预算公开类对实验中，证明 TAME-2 已有的两分支首项速率达到最优，并把已知的“欠平滑与难度失衡有利”解释提升为最优最坏类对风险改善的必要条件。O/P 是闭合该上下界的数学内容。当前正文把这一点埋在 M1/Q1、native、closure、Level-2 及反复的限制说明之后，降低了贡献的可辨认度。

我没有从这次有界核验中找到能直接引用一个现成定理、无需重做证书与模型嵌入便推出 C15 全部 O/P 结论的路径；这不等于证明不存在短约化。尤其不能把一般乘积/平方误差障碍、公开预算选方向或镜像思想本身当作新发现。已有定理与本稿之间真正要交代的是哪些硬族满足四个预算、两标签共同的精确方差及同一个公开字典。

**一手原文核对及其含义。**

1. **TAME。** Gu, *Optimal use of a black-box learner in semiparametric estimation*, arXiv:2607.21541v1：Condition 3.2 与式 (3.6) 已分开给两个学习器的 approximation/stochastic 预算，按总半径比较选择 O/R，并使用预算调参。Corollary 3.2、式 (3.7) 的 nuisance 首项精确对应
   \[
   W=\min\{a(b+t)+(a+s)^2,\ b(a+s)+(b+t)^2\}.
   \]
   原推论在总半径趋零条件下给高概率展开。Proposition 2.3 给共享学习类情形的 \(q+ab+h^2\) 下界。来源：[TAME 原文，§3.3、式 (3.6)–(3.7)](https://arxiv.org/html/2607.21541v1#S3.SS3)，[PDF，Proposition 2.3 第 12 页、Corollary 3.2 第 16 页](https://arxiv.org/pdf/2607.21541v1)。

   因而 C15 可以把“全预算、期望损失、可测实现”称为技术闭合；不能把分开预算、按 \(a+s\) 与 \(b+t\) 选方向、欠平滑原则另算为新方法。高概率到期望损失的差别也不宜单独充当显著新意。最强增量是对 \(W\) 的匹配下界。

2. **GYCF。** Gu–Yin–Cai–Fan, *Optimally taming biases in black-box models for efficient semiparametric estimation*, arXiv:2606.06368v1：式 (3.1) 已用 approximation 和 localized-Rademacher 预算定义可学习真值族；式 (A.1) 已要求 \(E[u^2\mid X]\equiv v\)，固定 \(P_X\)；式 (A.2) 是外层真值族、内层估计器的期望绝对损失风险。Theorem A.1 给
   \[
   q+AB+M\ \lesssim\ \mathfrak m\ \lesssim\ q+\min\{A,(a+s)(b+t)\}.
   \]
   来源：[GYCF 原文，§A.1](https://arxiv.org/html/2606.06368v1#A1.SS1)，[PDF，第 19–20 页](https://arxiv.org/pdf/2606.06368v1)。

   因而四预算框架、外层最坏类族、期望绝对损失、常条件方差都不是 C15 首创。本稿把公开表示及固定环境空间的含义写严谨是可取的，但应直接承认这是最邻近的下界前身。

3. **JMS。** Jin–Mackey–Syrgkanis, *It's Hard to Be Normal*, 正式 NeurIPS 2025 版，Theorem 3.1/式 (5)：二值 treatment、\(\operatorname{Var}(T\mid X)\ge\delta\)，围绕固定锚点 \((\widehat g,\widehat q)\) 的 \(L_2\) 半径，给固定分位风险下界
   \[
   c_\gamma\{A^{-1}\delta^{-1}(c_q\epsilon_1^2+\epsilon_1\epsilon_2)
             +\delta^{-1/2}n^{-1/2}\}.
   \]
   这里 \(g=E[T\mid X]\)、\(q=E[Y\mid X]\)，并非本稿的 \(\mu\)。Theorem B.1/式 (36) 是双二值加强版，nuisance 项的系数换为 \(c_\theta\)，该式本身没有 parametric 项。来源：[正式 proceedings PDF，Theorem 3.1 第 4 页，Appendix B](https://proceedings.neurips.cc/paper_files/paper/2025/file/f0156a82b6af6a4e838923ce9c124424-Paper-Conference.pdf)。

   C15 对 aggregate 平方/乘积障碍的承认方向正确。应补上 \(q=\mu+\beta\pi\) 这一实质映射，避免把 \(\epsilon_2\) 直接叫作本稿 outcome nuisance 的误差。固定正分位下界转为期望损失下界只损失常数，不能把风险度量不同当作主要阻挡。相关引用还放错了一处：当前 `jin2025hardnormal` 跟在“Jin–Syrgkanis is a distinct product-lower neighbor”之后，应移到 Jin–Mackey–Syrgkanis 句，双作者句只保留对应的双作者论文。

**哪些简单推出已经足够，哪些还需要本稿证据。**

先看最直接的 GYCF 专门化。在 O 射线 \((a,s,b,t)=(r,0,0,r)\) 上，旧下界为 \(q+r^3\)，而 C15 为 \(q+r^3+r^2\)。任何逐坐标缩小预算后的旧公式都不超过 \(q+r^3\)：因为仍有 \(s'=b'=0\)，仅剩 \(a'(t')^2\le r^3\)。因此“引用 A.1，再用预算单调性”不能填平此缺口。取 \(r_n=n^{-1/8}\)，\(q=r_n^4=o(r_n^3)\)，是完整风险的阶分离，不只是压掉 parametric 项后的形式比较。P 射线同理。这是一项严格、有限而明确的公式级结论，不是一般 non-reduction 证明。

但在同一 O 射线上，标准 aggregate-error product 基准
\[
D_n=q+(a+s)(b+t)
\]
已经是 \(q+r^2\)，TAME 的 \(q+W\) 也是 \(q+2r^2\)。因此图 1 与正文应表达“已知上界与旧下界之间的缺口被补齐”。第 8 页“a symmetric product ... amplified up to ...”容易被读成 O 超过 DML 乘积预计的误差，应删除或明确指的是 GYCF 的旧下界。一般地，\(O\le at\)、\(P\le bs\)，并不出现一个大于原始乘积基准的新错误机制。

对 JMS，不能仅把 anchored 半径改名为 stochastic 预算。一个最简单的反例说明两者信息不同：取大量等质量块上的全部符号函数 \(c h\Delta_\lambda\)，其中 \(c\le1/2\)、样本几乎不碰撞。每个函数距零的 \(L_2\) 误差只有 \(ch\)，但全符号差分类在半径 \(h\) 内的 Rademacher 复杂度为 \(\Theta(h)\)，并非 C15 要求的 \(O(h^2)\)。所以锚点误差为 \(h\) 不自动提供 critical-radius 证书 \(h\)。JMS Appendix B 的全块符号族若整族直接公开，正需要面对这个检查；这是对其构造的直接分析，不是对其定理的反例。

C15 的有限 Walsh 方案给了可审查的解决办法：振幅 \(O(h)\)，\(\log p=O(nh^2)\)，于是有限类上界是
\[
\mathfrak R_n\lesssim h\sqrt{\log p/n}=O(h^2),
\]
同时似然 Gram 的 \(K=O(h^2)\) 与 \(p\ge e^{CNh^2}\) 保持混合观测距离小。这些具体不等式，比“public four-certificate allocation”的名称有说服力。由无限锚点硬族改为满足四证书的有限公开族仍可能被视为对成熟混合技术的专门化；本稿应以匹配结论及清楚的嵌入计算证明其价值，而不预先宣布方法不可约。

**精确方差与镜像的边界。** JMS 的二值 treatment 假设只给方差下界；若取 \(\widehat g\equiv1/2\)，其原始扰动会使替代族方差在 \(X\) 上为常数，但锚点和替代族的常数仍不同。因此直接专门化并未给两标签共同的已知精确方差，尤其不能自动覆盖 C15 允许的 \(v_-=v_+\)。C15 通道
\[
P(T=\pm L\mid X)=\frac{v_0+m(X)^2\pm Lm(X)}{2L^2},\quad
P(T=0\mid X)=1-\frac{v_0+m(X)^2}{L^2}
\]
同时满足 \(E[T\mid X]=m(X)\)、\(\operatorname{Var}(T\mid X)=v_0\)，是应该在正文解释的具体工作。

也不宜把“P 不是 O 的变量更名”扩展成一般新颖性主张。由 C15 自己的 O 原始族，可以推导一个有边界的短镜像。原族 \(Y=\pm A\)，label 0 为 \((\beta,\mu,\pi)=(0,z\eta,z\gamma)\)，label 1 为 \((\Delta,0,z\gamma)\)，\(\Delta=\gamma\eta/(v+\gamma^2)\)。交换观测 \(T'=Y,Y'=T\) 后，因为新 treatment 二值，逆条件均值是仿射函数。新 label 1 系数为
\[
\beta'_1=\frac{\Delta v}{A^2-\Delta^2\gamma^2}\asymp\eta\gamma,
\]
新 propensity 为 \(z\eta\) 或 \(z\Delta\gamma\)，都可由 \(\{0\}\) 近似；新 outcome nuisance 为 \(z\gamma\) 或 \(z\gamma(1-\beta'_1\Delta)\)，可以放入同一个振幅 \(O(\gamma)\) 的有限字典。由此在容纳两种新方差的较宽模型中出现 P 型机制。问题在于两标签的新方差分别为
\[
A^2-\eta^2,\qquad A^2-\Delta^2\gamma^2,
\]
一般不相等。这是局部逆回归计算，未声称满足每一个 C15 固定 \(\rho\) 的所有包络；它足以说明镜像思想不应被包装成一般不可约创新，也说明 C15 共同精确方差的原始质量构造实际补了什么。

**最值得加入正文的推论：最优性及改善条件。** 不需要任何新增定理技术、自然类假设或自适应结果。

写 \(x=a+s,y=b+t\)。C15 已有 \(X/5\le W\le24X\) 和 \(W\le T_{\rm selected}\le2W\)。结合主定理，可立即得
\[
\mathcal R_{n,\rho}^{\rm pair}\asymp_\rho q+W.
\tag{R1}
\]
这精确说明“已知 TAME-2 首项速率在本实验中达到 minimax 最优”；不要由此声称原 TAME 原封不动的全部实现已满足 C15 的所有边界约定。

更有解释力的是，在所有 \(x\le y\) 的预算格上，有限样本地有
\[
c'_\rho(q+ay+x^2)\le\mathcal R_{n,\rho}^{\rm pair}
\le C'_\rho(q+ay+x^2).
\tag{R2}
\]
例如若主定理常数为 \(c_\rho,C_\rho\)，上述现成比较足以取 \(c'_\rho=c_\rho/48,C'_\rho=5C_\rho\)。证明只有三步：选中分支为 \(T_\mu=ay+x^2\)；其在 \(W\) 与 \(2W\) 之间；再代入主定理。镜像格给 \(q+bx+y^2\)。这包括大预算及零半径格；只有后续除法需要 \(xy>0\)。

以 \(D_n=q+xy\) 为**乘积误差基准**，而不是某个具体 DML 估计器的已证明下界，(R2) 给
\[
\frac{\mathcal R_{n,\rho}^{\rm pair}}{D_n}
\asymp_\rho
\frac{q}{q+xy}+\frac{xy}{q+xy}\left(\frac ax+\frac xy\right),
\qquad 0<x\le y.
\tag{R3}
\]
因此沿固定 \(\rho\)、\(0<x_n\le y_n\)、\(q=o(x_ny_n)\) 的任意序列，
\[
\mathcal R_{n,\rho}^{\rm pair}=o(x_ny_n)
\quad\Longleftrightarrow\quad
a_n=o(x_n)\ \text{且}\ x_n=o(y_n).
\tag{R4}
\]
前者表示容易侧以 stochastic 预算为主；后者表示两侧总半径严格失衡。镜像时为 \(b=o(y)\) 且 \(y=o(x)\)。TAME §3.3 在式 (3.7) 后已用比值 \(\delta_\mu^{\rm appr}/\delta_\mu+\delta_\mu/\delta_\pi\) 给充分改善条件；新增的下界使条件在这个最坏类对风险中也成为必要条件。来源：[TAME §3.3 式 (3.7) 后的两个解释段落](https://arxiv.org/html/2607.21541v1#S3.SS3)；必要性来自本报告对 C15 的推导，而非声称原文已证明必要性。

可直接写入正文的短段落：

> **When does calibration improve the product benchmark?** Let \(x=a+s\), \(y=b+t\), and \(q=n^{-1/2}\). Our theorem and the branch comparison imply \(\mathcal R_{n,\rho}^{\rm pair}\asymp_\rho q+\min\{ay+x^2,bx+y^2\}\). Thus, on \(0<x\le y\), the optimal risk is comparable to \(q+ay+x^2\). If \(q=o(xy)\), it improves in order over the aggregate-error product benchmark \(xy\) if and only if \(a=o(x)\) and \(x=o(y)\); the reverse orientation is symmetric. TAME already supplies these as sufficient conditions for its guarantee. The matching lower bound makes them necessary for improvement in this worst-public-pair experiment.

这里的英文替换段是本报告提出的正文文本，不是原文引语。它明确保留原有归属、解释本稿增量，并不证明某个 DML 估计器必付 \(xy\)。

还有两个可选的极短推论，但不必全塞入九页：

- 若 \(s=t=h\)，由 \(ab+M+O+P\asymp ab+h^2\)，得 \(\mathcal R\asymp_\rho q+ab+h^2\)。它在同量级 stochastic 预算下延续共享学习器的已知公式；不能再把同量级情形的 mixed terms 算作新主导机制。
- 最坏类对风险达到 \(O(q)\) 当且仅当 \(ab=O(q)\)、\((s\wedge t)^2=O(q)\)、\(t(a\wedge t)=O(q)\)、\(s(b\wedge s)=O(q)\)。这是速率条件，不能升级为置信区间或渐近正态结论。

正文已有相同 \((x,y)\) 但不同风险的例子，最适合紧跟 (R3)：\((r,0,1/2,0)\) 与 \((0,r,1/2,0)\) 的 \(X\) 分别是 \(r/2\) 和 \(3r^2/2\)，且都选 O。它现在可以承担一个清楚的科学解释：相同 aggregate 半径决定同一方向，但容易侧误差来自 approximation 还是 stochastic，决定是否能够改善乘积基准。无需再重复一段抽象“certificate allocation”。

**九页里需要展示的承重数学。** 建议把第 5 页的区别表和第 6 页的大量审计语言换成以下短计算。不要只列“membership、closeness、separation 全都已检查”。

- 给出两个公开类对：O 为 \(\mathcal G_\mu=\{0\},\mathcal G_\pi=\{\pm\gamma\phi_j\}\)；P 为 \(\mathcal G_\pi=\{0\},\mathcal G_\mu=\{\pm\gamma\phi_j,\pm\kappa\phi_j\}\)。读者立刻能看见哪一侧用 approximation 预算、哪一侧用 stochastic 预算。
- O 显示 \(E_0[TY\mid X]=\gamma\eta=\Delta(v_0+\gamma^2)=E_1[TY\mid X]\)。P 显示 \(\kappa=\gamma+\Delta\eta\)、\(\Delta v_0=2\eta\gamma\)。随后指出原子质量的 sign average 相等，而不仅是一个矩碰巧相等。C15 C.15/D.8 已给更强的原子级恒等式。
- 给一个通用的一行桥接：\(dP_{\ell,j,\sigma}/dQ=1+\sigma\phi_j h_\ell\)、\(K_\ell=E_Qh_\ell^2\lesssim h^2\)，由 Walsh 正交得到
  \[
  \chi^2(\overline P_\ell^N,Q^N)
  =\frac{[(1+K_\ell)^N+(1-K_\ell)^N]/2-1}{p}
  \le e^{NK_\ell}/p.
  \]
  与上面的 \(\log p\asymp Nh^2\) 同时展示，才可见“难以分辨”和“可学习字典”如何相容。确切常数留附录。

这些计算已在 C15 C/D 中存在，不要求作者新增研究。它们解释实际增量，比单说二者“not a relabeling inside a fixed experiment”更强，也更容易让熟悉 JMS 的读者评估。

**同一类对结果应降到正确的逻辑层级。** 仅仅
\[
\forall(n,a,s,b,t)\ \exists\Gamma:\ R_\Gamma\ge c(q+X)
\]
已从 \(\sup_\Gamma R_\Gamma\gtrsim q+X\) 推出：取近最大类对即可，常数最多再减半。而一个类对的总风险下界自动给每个单独的数值组件不等式。故“存在一个 pair 实现五个不等式”本身并不加强 minimax 速率，也不是额外的统计发现。

C15 L 真正额外证明的是更具体的构造性质：一个显式类对与同一 \(P_X\) 容纳所有指定 active native 硬族，且跨频带差分类仍满足预算。这个性质是有内容的，可叫作 **explicit simultaneous embedding of the native hard families**。不宜让 Level-2 的内部层级名及 repeated five-inequalities 叙述占据摘要、引言、setup、定理后、assembly、interpretation 和 conclusion。文献表中的“no same-pair closure”也应具体限定为本稿这项同时嵌入，或直接删除；已有单学习器下界本就可在固定类上成立。

**建议的正面贡献段与篇幅替换。**

可用下列文字替代引言中长串 closure/claim-boundary 说明：

> Gu–Yin–Cai–Fan establish the four-budget lower envelope \(q+AB+M\), while TAME-2 attains the two-branch leading rate \(q+W\). We close the remaining gap in a bounded, constant-variance public-class experiment by proving matching lower bounds for \(O=t(a\wedge t)\) and \(P=s(b\wedge s)\). Since \(W\asymp AB+M+O+P\), this establishes minimax optimality of the known two-learner rate in the stated experiment. Our finite public dictionaries certify the two directional costs while preserving the same exact residual variance across testing labels. The resulting characterization also identifies precisely when the optimal risk improves in order over the aggregate-error product benchmark.

JMS 邻近关系建议压为如下两句，并在后面用实际字典/方差计算支持：

> Jin–Mackey–Syrgkanis already establish squared-error and mixed-product obstructions for binary-treatment PLMs around fixed estimates of \((E[T\mid X],E[Y\mid X])\). Here the lower families additionally satisfy separate approximation and class-complexity certificates for \((\mu,\pi)\), with a common exact treatment residual variance in both testing labels; our contribution is the resulting matching four-budget characterization.

主张这些句子时不必说“no known reduction”或“not covered by any existing result”。对照公式、明确原文 nuisance、显示硬族证书已经足够。上面第一段的文献依据是 GYCF A.1、TAME 3.2/(3.7)，匹配判断来自 C15 主定理与确定性比较；第二段的原文依据是 JMS 3.1、Appendix B。

九页内的优先修改顺序：

1. **必须优先：** 首页把主贡献说成 TAME-2 首项速率的匹配最优性；在相关工作中承认原式 (3.6) 已是预算驱动的方向选择。把旧下界、TAME 上界、DML 乘积基准三个对象明确分开。
2. **必须优先：** 加入 (R2)/(R3) 或 (R4) 的短推论，使用现有相同 aggregate 例子作解释。它给出下界为什么值得读的直接答案。
3. **必须优先：** 把 O/P 的公开字典、共同精确方差、原子级混合相等与复杂度/距离同尺度关系写入正文；删去“no solver failure”“no hidden oracle”等与当前理论证据无关的审计叙述。
4. **可立即压缩：** 同一类对同时嵌入保留一段和附录指针。共同包络饱和现象保留 theorem 的边界项及 \(\pi=0\) 的短证明；它是准确的模型特定附加结果，不能替代两学习器最优性的科学主线。
5. **归属修复：** JMS 句直接引用三作者论文；注明其 \(q_0=E[Y\mid X]\)；文献表用“已有结论 / 本稿补足”两列短公式，避免用大量“没有 M1/Q1”制造字面差异。

上述建议只重组并提炼现有定理，不要求为了提高评价而增加自然类、自适应、计算实验、因果解释或不可约性研究。

**核验结论的边界。** 本报告确认了最邻近三篇一手原文的相关定理字段和公式，检查了 C15 O/P 证书的主要原始质量、公开类与混合距离路径，并给出 (R1)–(R4) 的独立确定性推导。我没有通审全部 upper empirical-process 证明、复核所有数值常数、构建 LaTeX 或验证所有参考文献。没有以未搜索到其他结果作为首创性证据。现有核验支持一个具体而有意义的“已知两学习器上界的四预算匹配最优性”贡献；并不支持新的通用校准原则、通用下界机制或一般 non-reduction 主张。是否达到会议录用门槛仍需结合完整证明可信度与整体创新标准，不能从作者希望录用或稿件使用的新术语推出。
