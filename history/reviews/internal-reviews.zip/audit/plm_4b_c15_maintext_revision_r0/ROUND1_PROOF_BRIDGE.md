# C15 ROUND 1：正文—承重证明桥接主审

本报告是 AI redteam 审查，不是人类同行评审或完整定理认证。结论只覆盖以下实际核验范围：先通读 `main.tex` 的全文正文（至 bibliography 前），检查 `main.pdf` 的前十页页界；随后核对 A 的完整模型/复杂度/M1 定义，C 的三点通道、P 六原子分布、预算及混合检验，D 的完整 O 证明，以及 B 中初始拟合定义、O/R 编辑目标、校准恒等式、期望吸收和四格 selector。B 的所有经验过程常数、E/F/L 的全证明以及外部优先权不在本轮认证范围内。没有读取旧审稿、项目历史、内部 audit、作者 GitHub 或 H2，没有改动稿件。本报告以控制树内的公式为数学来源，不另引入新自然类、适应性定理或替代实验。

**判断：最需要正文补充的是可重算的数学桥，而不是再增加“已 certified”的保证。** 已核验的 P/O 原子分布和共同参考恒等式没有显现矛盾；当前第 5 节却把这组最有贡献价值的推导压成了标签列表和“orthogonality”。第 4 节给出了选择哪个分支的规则，却没有展示任何一个实际编辑目标或估计量输出，独立读正文无法知道被选择的对象如何构造。五项建议按价值排列如下。

## 1. 展示 P/O 的共同参考分布恒等式，证明“隐藏系数”而不只宣告隐藏

**当前位置。** `main.tex:234–253`（PDF 第 5 页）列出两个标签的 `(beta,pi,mu)`，P 段在 `:240` 直接从补偿跳到 signed mixture 隐藏；O 段直接说“aligns the observable moment”。Table 2 基本重列这些标签，没有给观测分布为何相近的代数。

**科学问题。** 同样的几个矩并不足以保证 N 样本分布相近。本文真正能把目标间隔藏起来的性质是：对每个 treatment/response 原子，两标签的正负号平均分布精确相同，继而各个 signed likelihood 都能写成同一个 Q 上的一阶 Walsh 扰动。P 与 O 使用不同的等式，这恰好是应该展示的贡献差异。

**已核验来源。** C.13/C.15–C.19（`C_q_p_lower.tex:222–340`）；D.4/D.5/D.8–D.12（`D_o_lower.tex:35–151`）。P 不仅匹配 `E(TY|X)`，还匹配 `E(Y|X)`；O 只需此构造中的 `E(TY|X)` 匹配，不能把 P 的条件响应均值等式照搬给 O。

**建议压缩数学段落。** 先说明这里局部用 `A_Y=B_0/2`（即附录的 A；避免与正文 aggregate A 冲突），`z=±1`，`u∈{-L,0,L}`，`r∈{-1,1}`。取

```tex
\alpha_{\pm L}=\frac{v_-+d^2}{2L^2},\qquad
\alpha_0=1-\frac{v_-+d^2}{L^2},\qquad
b_u=\frac{du}{2L^2}.
```

P 取 `d=eta`，O 取 `d=gamma`。由附录原子分布直接展开，最有用的两行是：

```tex
\begin{aligned}
\text{P: }\quad
\Delta\alpha_u u=b_u(\kappa+\gamma)
&\ \Longleftrightarrow\ 
\Delta(v_-+\eta^2)=\eta(\kappa+\gamma),\\
\text{O: }\quad
\Delta\alpha_u u=b_u\eta
&\ \Longleftrightarrow\ 
\Delta(v_-+\gamma^2)=\gamma\eta.
\end{aligned}
```

这里 `u=0` 时两边各自为零；“Longleftrightarrow”的非平凡核验在 `u=±L`。P 第一式由 `kappa=gamma+Delta eta`、`Delta v_-=2eta gamma` 得到；O 第二式正是其 Delta 的定义。它们分别推出：

```tex
\frac{P_{0,+}+P_{0,-}}2
=\frac{P_{1,+}+P_{1,-}}2=Q,\qquad
Q(u,r)=
\begin{cases}
\frac12(\alpha_u+rb_u\gamma/A_Y),&\mathrm P,\\
\frac12(\alpha_u+rb_u\eta/A_Y),&\mathrm O.
\end{cases}
```

如篇幅只能容纳一个直观检查，再写 P 的
`E_1(TY|X)=Delta(v_-+eta^2)-eta kappa=eta gamma=E_0(TY|X)`；O 则写现成 D.5。不要以这些矩等式取代共同 Q 的逐原子等式。

**篇幅/优先级。** 约 10–14 排版行；可直接替代 Table 2 的重复文字与两段“certifies”句。科学价值极高：读者能亲手验证为何 target gap 的两个分母不同，并能明确判断这不是变量重命名。

## 2. 用同一个显示公式把“字典复杂度”与“观测距离”同时支付，并纠正混合/全 n 描述

**当前位置。** `main.tex:273–280`（PDF 第 5–6 页）。当前 “Orthogonality makes cross-direction likelihood inner products small” 未告诉读者是哪一个内积；“through sqrt(log p/N)” 漏掉字典振幅，因而读者无法看见指数大小的公开字典为何仍符合小 stochastic budget。

**正确承重链。** 令 `nu=s`（P）或 `nu=t`（O），`p=ceil exp(64N nu^2)`。第 1 项共同 Q 使

```tex
\frac{dP_{\ell,j,\sigma}}{dQ}
=1+\sigma\phi_j(X)h_\ell(T,R),\qquad
K_\ell=E_Qh_\ell^2,
```

成立。这里 Q 包括同一个 `P_X` 与相应 `(T,R)` 参考分布；非同方向原始似然内积**精确等于 1**，相应中心化扰动的内积才是 0。对单个观测，内积为 `1+sigma sigma' 1{j=j'} K_ell`。方向/符号在整个样本中固定，之后才对 N 样本法律做 prior 平均：

```tex
\overline P_\ell^N
:=\frac1{2p}\sum_{j,\sigma}P_{\ell,j,\sigma}^{\otimes N},\qquad
\chi^2(\overline P_\ell^N,Q^{\otimes N})
=\frac{\{(1+K_\ell)^N+(1-K_\ell)^N\}/2-1}{p}
\le\frac{e^{NK_\ell}}p.
```

P 有 `K_ell≤s^2/196`，O 有 `K_ell≤t^2/9`。这给出可核验的距离支付：`log p` 的 64 系数压过单样本 likelihood energy 的系数，而不是笼统“指数 p 足够大”。原稿 “The learner observes a mixture” 宜改为 “For testing, average the N-sample laws over the public directions and hidden signs”：真实每个 component 仍然是 iid PLM；不能把 `average(P^{tensor N})` 与 `(average P)^{tensor N}` 混淆，后者会让两标签严格相同并改变实验。

复杂度方面用与附录一致的全局 finite-class 控制，足够在正文写：

```tex
\begin{array}{c|c|c}
 &\text{public pair}&\mathfrak R_n(r';\Delta\mathcal G)\\ \hline
\mathrm P&\mathcal G_\pi=\{0\},\quad
 \mathcal G_\mu=\{\pm\gamma\phi_j,\pm\kappa\phi_j\}
 &<46\kappa s\le(23\lambda_\rho/64)s^2\\
\mathrm O&\mathcal G_\mu=\{0\},\quad
 \mathcal G_\pi=\{\pm\gamma\phi_j\}
 &<46\gamma t\le(23\lambda_\rho/128)t^2.
\end{array}
```

分别对所有 `r'≥s>0` 或 `r'≥t>0` 成立。除以 `3r'`，P 得 `(23lambda_rho/192)s≤c_rad s`，O 得 `(23lambda_rho/384)t≤c_rad t`。字典差分振幅与 `sqrt(log p/n)` 各支付一个 nu，所以 complexity 是 nu²，再除半径得到定义要求的 nu。近似误差则由另一侧 singleton 直接给 `eta≤b` 或 `eta≤a`。如果不用表，以上两行预算不等式配文字即可。

**需明确纠正的一句。** 正文 `:273` 的 “an all-n cap ... when the nominal separation is too large” 不是 C/D 的实际拼接逻辑。C 原生 P 支路要求 `n≥16,s²≥q,P>0`；D 要求 `n≥16,t²≥q,O>0`。其余非零情形是 `P≤s²<q` 或 `O≤t²<q`，或者 `n<16` 时 interaction≤1≤4q；因此由 q 已覆盖。建议直接替换为：

> The native mixtures are used when n≥16 and nu²≥q. Otherwise the directional term is at most q, or at most 4q for n<16, and the parametric witness supplies the bound.

这是具体文字校正，不意味着 C/D 的 all-n 证明失败。

**来源/篇幅。** C.3、C.14–C.20；D.6–D.13；C 末节、D 末节。约 11–16 行（完整 pair 表可与现 Table 2 合并）。科学价值极高：把“指数维度是否同时破坏 budget”的自然审稿疑问在正文闭合。

## 3. 第 4 节应展示真实编辑目标和输出，避免把 R 称为没有限定的 mirror operation

**当前位置。** `main.tex:189–215`（PDF 第 4 页）已有 `T_selected≤2W≤48X`，但没有定义任何 beta_hat，也没有说明 editing 具体约束哪个样本矩。`main.tex:196` 的 “R branch performs the mirror operation” 还会让人以为只交换 mu/pi 名字即可获得 R。附录 B 明确写 R 不是由 O 对称得到，并通过独立 ratio identity 证明。

**最低可理解实现。** 首先用一句话定义在 D2 上的近似 least-squares `pi_hat` 和 `(beta_hat_0,mu_hat)`，并令 P1/P2 表示两个样本半的平均。然后优先展示如下相容的紧凑版（以下 `w` 是优化向量，与附录的 a 逐项对应；与模型条件方差 v 无关）：

```tex
\widetilde a_i=
\frac{T_i-\widehat\pi(X_i)}
{(v_-/2)\vee P_1\{T(T-\widehat\pi)\}},\qquad
H_\mu(w)=\sup_{f\in\Delta\mathcal G_\mu^{\rm rep}}
\{|P_1(fw)|-P_1f^2\},
```

```tex
\widehat a\simeq\arg\min_{P_1(Tw)=1}
\{\lambda_O\|w-\widetilde a\|_n^2+H_\mu(w)\},\qquad
\widehat\beta_O=\Pi_{[-3,3]}P_1\{(Y-\widehat\mu)\widehat a\}.
```

这里 `simeq argmin` 必须在文中定义为附录的 first-within-`n^{-12}` 可测选择；`T_{1:n}=0` 时输出 0，不能把空超平面写成总有解。O 对任何 fitted difference `f` 自动保证

```tex
|P_1(f\widehat a)|\le P_1f^2+H_\mu(\widehat a).
```

这就是正文目前 “one-sided adversarial moment calibration” 隐藏的关键数学行为：把该 nuisance 类方向的一阶残差，控制在平方项和 objective slack，而不是只说“orthogonality”。

R 则编辑条件响应均值，在 D1 covariates 上设 `m_tilde=beta_hat_0 pi_hat+mu_hat`，展示

```tex
H_\pi(m)=\sup_{f\in\Delta\mathcal G_\pi^{\rm rep}}
\{|P_2(Yf)-P_1(mf)|-P_1f^2\},\qquad
\widehat m\simeq\arg\min_m
\{\lambda_R\|m-\widetilde m\|_n^2+H_\pi(m)\},
```

```tex
\widehat\beta_R=\Pi_{[-3,3]}
\frac{P_1\{(Y-\widehat m)(T-\widehat\pi)\}}
{(v_-/2)\vee P_1(T-\widehat\pi)^2}.
```

这能让读者看到 O 是严格归一化的 treatment weights，R 是跨两半样本校准的 conditional-mean edit；它们的估计器结构并不相同。

**不能继续藏在 certified 后的 public tuning。** 如果正文声称给出“the public rule”，最低还应给出 safe predicate。附录常数可引用，但条件要可见：

- `h_n=sqrt(log(en)/n)`，`bar s=C_rad(s vee h_n)`，`bar t=C_rad(t vee h_n)`，`theta_rho=(B_0+B_G)/8`；O safe iff `x≤y,bar s≤theta_rho`，R safe iff `y<x,bar t≤theta_rho`。
- 精确 tuning 是 `lambda_O=(bar s/d_pi)^2`，`d_pi=min{B_0+B_G,8(y+bar s+n^{-6})}`；`lambda_R=(bar t/d_all)^2`，`d_all=min{B_0+4B_G,8(x+y+bar t+n^{-6})}`。这些全是 public，可置于公式下方的一行/脚注；C_rad 的固定依赖照 B 开头引用。

“如何从 calibration 得 branch rate”的一句数学解释足够：O 中 `f=g_mu-mu_hat` 的项由上式支付平方半径，off-class residual 与 weight discrepancy 相乘支付 `ay`，其余噪声给 q；R 用独立 B.28 和 H_pi 支付 `bx+y²`。若余地允许，再点出 `bar s²≤C_rho(s²+q)` 及 `d/(n bar s)≤C_rho q`，说明 positive radius floor 与 all-z tail integration 如何在 s=0 时仍得到期望 L1，而不把高概率结论直接冒充期望结论。

**来源/篇幅。** B.10–B.17、B.19–B.20（`B_upper_proof.tex:672–1003`），R 定义/B.25/B.28（`:1005–1289`），selector（`:1448–1517`）。紧凑核心约 20–28 行；完整 public tuning 再 3–5 行。优先级高于现有 V/W 多常数比较过程，可把 `V≤W≤4V` 和六格代数解释移回附录，仅保留 `T_selected≤48X`。这不是要求新算法或计算保证，而是使现有信息论估计器在正文中成为具体对象。

## 4. 用三点通道公式解释 exact conditional variance 的真正限制和实现

**当前位置。** `main.tex:250–280` 只说明三点 treatment channel 和 `m_rho` “simultaneously enforces bounded envelopes and exact variance”。给出 `m_rho` 的 min 本身并未解释方差为什么恒定。

**建议正文数学。** 沿用现 `m_rho`，补 `L=sqrt(v_-)+2m_rho`。对于本构造中的 treatment mean `m(X)`（P 为 `±z eta`，O 为 `z gamma`），写

```tex
\Pr(T=\pm L\mid X)
=\frac{v_-+m(X)^2\pm Lm(X)}{2L^2},\qquad
\Pr(T=0\mid X)=1-\frac{v_-+m(X)^2}{L^2}.
```

```tex
E(T\mid X)=m(X),\qquad
E(T^2\mid X)=v_-+m(X)^2,\qquad
E\{(T-m(X))^2\mid X\}=v_-.
```

`|m|≤m_rho` 时正性来自 `Lm_rho≤v_-/4` 和 `v_-+m_rho²<L²`；shared law/residual envelopes 来自 `L+m_rho<B_0`。这些不是额外假设，全在 C.5–C.7。

**困难应准确表述。** 任意移动 propensity 却维持固定 second moment，会改变 residual variance；简单平移固定 residual 的 support 又可能把隐藏 label 编码进观测 support。三点概率允许在公共固定 support 上同时调一、二阶矩，且保留 likelihood 的公共支配测度。不要说“二点通道绝不可能做到”：本构造中 mean 的绝对振幅固定时可考虑别的二点选择；本文需展示的是所给合法通道确实同时做到 exact v、重叠支撑与残差 envelope，而不是提出不必要的不可能性命题。

**来源/篇幅。** C.5–C.7（`C_q_p_lower.tex:72–103`），C.13 与 D.4。约 6–9 行。科学价值很高，因为正文优先权残差中特别强调 exact-variance embedding，而当前读者只能接受作者断言。此段也自然解释 why strict lower-endpoint slack，而无需重复多段 I-to-S 边界声明。

## 5. s,t 的真正定义应直接在正文给出；不能以 M1 为由去掉 outer expectation

**当前位置。** `main.tex:90–105`（PDF 第 2 页）目前只用自然语言介绍 stochastic budgets。风险正是关于四个证书的 minimax law，却只有 a,b 在正文中有严格定义；未给 normalized complexity 的半径、sample-size、3 系数、zero boundary，读者不能自行判断 budget ray 是否 legal。

**建议直接替换原有描述的一段。** 令 `Delta G={g-g':g,g'∈G}`，对 `G_nu=G_mu,G_pi`，`r_nu=s,t` 写一个统一显示式：

```tex
\mathfrak R^*_{n,P_X}(r;\mathcal H)
:=E^*_{X_{1:n},\epsilon_{1:n}}
\sup_{\substack{h\in\mathcal H\\\|h\|_{L_2(P_X)}\le r}}
\left|\frac1n\sum_{i=1}^n\epsilon_i h(X_i)\right|,
\qquad
\sup_{r\ge r_\nu,\ r>0}
\frac{\mathfrak R^*_{n,P_X}(r;\Delta\mathcal G_\nu)}{3r}
\le c_{\rm rad}r_\nu.
```

正文随即保留三点，约两句即可：`E*` 是对 measurable majorants 的 outer expectation；证书按兼容 law 的 `P_X` 计算而 budget 在观测前公开给定；当 `r_nu=0` 时条件作用于每个正半径，不做 0/0。复杂度中的样本量是 n（一个半样本），lower likelihood 产品中的 N=2n，不能合并成未说明的同一 N。

M1 条件正文已有 everywhere pointwise sequential representation 与共同 envelope，可以保留并追加真正被 upper 用到的关系：

```tex
\mathfrak R_{n,P_X}(r;\Delta\mathcal G_\nu^{\rm rep})
\le\mathfrak R^*_{n,P_X}(r;\Delta\mathcal G_\nu).
```

左边是可测 countable supremum 的普通期望。M1 可以转移 population approximation infima 和有限样本连续拟合/校准目标，但**不自动保证固定 localized ball 上的 full/core complexity 相等**；正文不应把复杂度全换成普通期望，也不能删除 full-class 证书后说“等价”。这样只需几行即可把外层 legal-pair 定义的关键内容置于正文，不必复制整个 A。

**来源/篇幅。** A.1 和前后定义（`A_model_quantifiers.tex:54–127`）；B 的 core 调用（`B_upper_proof.tex:245` 附近）。约 7–10 行。科学价值：让四证书的模型本身在正文可判定，也明确了 M1 究竟解决了什么。

## 九页内的取舍与实际核验结论

五项合计约 1.1–1.5 页的毛增量，取决于公式换行，不能在没有重排后声称仍恰好九页。优先从现正文重复内容置换：Table 2 改为共同 Q/预算的数学表；第 4 节删减 V/W 常数链和重复 public/no-oracle 描述；第 9 节及其 Claim boundary 把与前文反复出现的“非因果、非适应性、无 common rule、非计算、非 uniform rho”收成一段；第 6 节保留 Level-2 正式量词与一条 assembly，不再在其前后重复 global Q1 不依赖它的同一句解释。不要以删除精确 M1/outer 条件、不同样本半依赖或原子正性条件来节省篇幅。

本轮手算重推了三点概率的一二阶矩、P 的 `Delta(v_-+eta²)=eta(kappa+gamma)`、O 的 `Delta(v_-+gamma²)=gamma eta`、共同 Q、单观测 Gram 与有限 signed mixture 二阶矩，并检查了 C/D 的 all-n 条件。另用 NumPy 对 72 个确定性参数组合复算 P/O 六原子概率、质量和、均值、条件方差、共同 Q 及 same-coordinate Gram：B0 为 3 或 5，v_- 为 0.01、1、0.95 B0²，lambda 为 0.02 或 1，三组合法振幅。所有原子为正，最大绝对方差残差约 7.11e-15，共同 Q 残差约 5.56e-17，Gram 残差约 3.34e-16。这是对有限取值代数/转写的交叉检查，不替代全参数证明，也没有实例化指数规模字典。未声称核验完 B 的全部过程界或 L 的 same-pair 全证明。

另由一个独立只读 explorer 对 O 的正文、D 及所需 C/A 定义进行了交叉复核；其确认 D.5、D.8、D.10–D.13、D.7 与正文相容，未发现 O witness 的实质数学错误。该复核不扩大上述认证范围。

最短可执行修订顺序：先补共同 Q 与 exact variance 两组等式，再用一个 mixture/complexity 显示段闭合 lower，随后把正文 selector 连接到 O/R 的实际目标和输出，同时在 setup 补 s,t 的严格定义。这样正文会真正承载本论文最关键的论证，而不是主要承担声明边界与认证状态。

