Original review of the initial 54-page C19 PDF, with common-partition histogram adaptation. The complete review below is retained unchanged.

My assessment is **weak accept on technical merit**, with moderate confidence in the overall recommendation and stronger confidence in the proof mechanisms checked. I found **no verified correctness-breaking issue** in the current PDF. The paper makes a focused theoretical contribution; its main limitations concern conceptual novelty and practical reach, rather than an apparent invalid theorem.

This is an independent AI review, not external human peer review. I read the text of all 54 PDF pages, including the entire main text and Appendices A–M. I examined the calibration proof in Appendix B and histogram proof in Appendix M closely, and followed the lower constructions, assembly, saturation argument, and fixed-marginal transport. Reading used in-memory PyMuPDF extraction; I did not inspect source files, historical reports, project notes, or internal conclusions, and created no files. I did not formally verify every numerical constant or visually inspect every rendered equation. A proposed independent subagent check could not start because the team had reached its thread limit.

The paper’s central contribution is legitimate and precisely delimited. It identifies the missing directional lower terms \(t(a\wedge t)\) and \(s(b\wedge s)\) in a public-class experiment with separate approximation and complexity certificates. The displayed rays demonstrate an actual change in lower-bound order, from \(r^3\) to \(r^2\). This establishes optimality of a previously known upper expression; it does not introduce that expression or a new general calibration algorithm. The distinction is made clearly in the abstract, introduction, and related work.

The literature checks support the manuscript’s attribution. TAME already gives public budget-based orientation and tuning in equation (3.6), and the two-branch expression in Corollary 3.2, equation (3.7). The present manuscript’s credit assignment is accurate. Its finite-sample, boundary, and measurable-selection implementation is additional technical work around that architecture. [TAME, version 1](https://arxiv.org/html/2607.21541v1)

The stated predecessor lower envelope is also accurate: Gu–Yin–Cai–Fan’s Theorem A.1 contains the parametric term, the product of approximation-plus-squared-stochastic terms, and the squared smaller stochastic term. [Gu–Yin–Cai–Fan, version 1](https://arxiv.org/html/2606.06368v1)

Jin–Mackey–Syrgkanis already establishes squared-radius and mixed-product obstructions for binary treatment under fixed nuisance estimates. Consequently, the present lower bounds should be valued as a construction that satisfies this particular four-certificate information structure, rather than as discovery of squared or mixed obstructions themselves. The manuscript explicitly acknowledges this distinction, including the difference between the PLM intercept and the conditional outcome mean. [Jin–Mackey–Syrgkanis, Theorem 3.1](https://proceedings.nips.cc/paper_files/paper/2025/file/f0156a82b6af6a4e838923ce9c124424-Paper-Conference.pdf)

My substantive correctness findings are:

1. **The directional lower constructions appear sound.** The main text gives actual finite observation laws, rather than only moment equations. The treatment channel preserves the required variance, and the response channel enforces the conditional PLM mean. The sign-averaged masses agree separately on every treatment–response atom. Expanding around the common reference leaves the stated sign-linear likelihoods. Walsh orthogonality then gives the requisite Gram entries, and mixing the component product laws yields the stated chi-square calculation. I found no label-dependent public-class disclosure or incorrect interchange of mixing and iid sampling.

2. **The complexity and testing requirements are compatible.** The dictionary amplitudes and logarithmic sizes satisfy the stochastic certificates while keeping the mixture close to its reference. The certificates are checked for all required positive radii. The zero-budget and small-sample branches use the scalar lower bound without adding unrelated Bayes risks. The simpler equivalence
   \[
   ab+M+O+P\le X\le2(ab+M+O+P)
   \]
   also makes the final assembly transparent.

3. **The general upper argument handles the important dependencies.** Joint fitting estimates the PLM intercept, addressing the fact that it differs from \(E[Y\mid X]\). The O weights avoid first-half outcomes, and the R edit avoids first-half treatments and outcomes. The conditional weighted-noise arguments respect these dependencies. Uniform process inequalities are formed before fitted indices are inserted. The amplified terms from small penalties are retained and absorbed after integration using the radius floors. I found no missing leading error term in the displayed O or R decomposition.

4. **The empirical-process foundation is credible.** The concentration statement in Lemma 8 maps correctly to Bartlett–Bousquet–Mendelson’s Theorem 2.1. The subsequent shell argument uses actual localized classes and does not silently assume star-shapedness. The distinction between full-class outer complexity and countable-core complexity is handled carefully. [Bartlett–Bousquet–Mendelson](https://www.stat.berkeley.edu/~bartlett/papers/bbm-lrc-05.pdf)

5. **The histogram adaptation theorem is a substantive separate result.** It fixes one rule for each represented pair before choosing the budgets, so its simultaneous quantifiers genuinely remove budget inputs on the stated subclass. The proof is not an application of the budget-dependent general selector. Full independent interval coordinates supply the damped sign cube in Lemma 17; its localized complexity controls the expected amplitude in singleton cells. Cauchy–Schwarz and bounded-envelope bounds then give the two directional minima. The denominator argument uses the restored diagonal bound \(A_{ii}\ge1/2\) and average residual variance, with conditional quadratic variance controlled explicitly. I found these steps internally consistent, including zero budgets.

6. **The translated-box extension also appears valid.** Recovering centers from the cores is justified by sequential M1. The primary denominator can be small because of approximation error, and the fallback proof accounts for that possibility through weighted bias bounds. It does not incorrectly assume independence between branch selection and the score.

7. **The supplementary scope claims are appropriately qualified.** The atomless-marginal transport computes likelihoods on the full observed covariate space, so extra observed digits do not create an omitted information channel. At envelope saturation, the restrictions on both treatment and residual force the propensity to vanish, explaining the parametric rate. The uniform envelope bound is expressly one-sided; the manuscript does not claim a matching joint transition rate.

The histogram result deserves particular credit relative to its classical mechanism. Projection-based partially linear estimation is established, and Cattaneo–Jansson–Newey impose a positive lower bound on projection diagonals in their assumptions. Here, keeping singleton observations restores that property by construction, while the certificate-based argument pays for the resulting bias. That is a meaningful additional argument, although my bounded literature check does not establish that this exact singleton treatment has never appeared elsewhere. [Cattaneo–Jansson–Newey, Assumption PLM](https://eml.berkeley.edu/~mjansson/Publications/Cattaneo-Jansson-Newey_2018_ET.pdf)

The principal reservations are about significance and presentation:

- **The conceptual advance is narrower than the quantity of technical material might suggest.** The upper expression, orientation principle, nuisance-imbalance interpretation, and general types of lower obstruction are inherited. The new result closes a precise minimax gap by making a suitable hard family satisfy the public certificates. This is useful theory, but not a new general principle for semiparametric learning.

- **Worst-public-pair optimality has limited implications for ordinary model classes.** The engineered dictionaries can be exponentially large and may change with sample size and budgets. The lower bound therefore does not establish the same difficulty for a fixed practical learner, a smoothness class, or the histogram subclass. The manuscript states these limitations correctly. They nevertheless constrain the result’s broader significance.

- **The adaptation result does not establish histogram minimax optimality.** It matches the general upper expression on a richer structured subclass and may be conservative for particular histogram pairs. The current statement and discussion are clear about this; I would retain that qualification prominently.

- **Several supplementary constructions have modest independent scientific weight.** Saturation follows fairly directly from the shared envelope, and atomless transport is a standard measurable-coordinate argument once the finite construction is available. Explicit simultaneous embedding is useful, but mere existence of one approximately worst pair already follows from the outer supremum. Page 6 commendably acknowledges the latter distinction.

- **The appendix is unnecessarily repetitive.** The event ledger, scope discussion, proof-navigation appendix, dependency index, and repeated assurances about internal proof material substantially increase the reading burden. Terms such as “Level-2,” “native,” “splice,” and “corrected” sometimes read like development terminology rather than final scientific exposition. Consolidating this material would improve credibility and readability without weakening the proofs.

For a reviewer restricted to the main text, the paper presents actual scientific content adequately. Pages 4–6 show the new cancellation and complexity mechanism; pages 6–7 explain the estimator and its dependence structure; page 8 states the adaptive rule and the singleton argument. The work is not hidden entirely in appendices, and the limitations are unusually explicit. I would not demand empirical experiments for this theorem paper.

One useful improvement would be a small analytic histogram example showing what ordinary deletion of singleton cells loses and how the proposed rule retains denominator information while paying a controlled bias. This would make the adaptation contribution easier to appreciate than another general scope paragraph. It is a presentation improvement, not a condition for mathematical validity.

I would support acceptance as a careful completion of a defined theoretical problem, strengthened by a correct-looking restricted adaptation theorem. I would not describe it as a broad algorithmic breakthrough or claim general unknown-budget minimax adaptation. There is no verified blocker from this review that requires changing the theorem.

## Targeted followup: distinct partitions and arbitrary Borel centers

The strengthening appears correct and materially improves the adaptation contribution. **My recommendation remains weak accept, with greater confidence and a stronger significance assessment.** I found no new verified blocker or substantive regression.

This is a targeted follow-up AI review, not a fresh independent review of the entire revised manuscript. I read revised pages 1–2, 8–9, 28–29, and 50–54, including the complete new Appendix M, and scanned the PDF for stale partition wording. A separate AI verifier independently checked page 2 and Appendix M. Neither review involved external human referees. The original review file remains unchanged, and no files were created or edited during this follow-up. I did not repeat the previous literature search or the complete general minimax proof audit.

The two-partition extension addresses a meaningful restriction. Each nuisance class can now use its own partition without taking a common refinement that would fail to preserve full independent coordinate structure. The proof uses \(B=A_\pi A_\mu\) in the correct order: propensity residuals occur on the left and outcome residuals on the right.

The important new steps check out:

1. **The product matrix is treated correctly.** Its operator norm is at most one, and its diagonal is at least \(1/4\), because both factors have nonpositive off-diagonal entries. The proof does not infer positive semidefiniteness from these facts. As an independent check, crossing groups \(\{1,2\}\) and \(\{2,3\}\), with remaining observations singleton, produce a symmetric part with eigenvalues \(-1/8,3/8,1,1\). The indefinite quadratic form is therefore a real issue, and the revised proof explicitly accommodates it.

2. **The primary score preserves the four bias terms.** Factoring the public residuals through their respective projections yields the same bounds \(ab\), \(t(a\wedge t)\), \(s(b\wedge s)\), and \((s\wedge t)^2\). The bounded-coordinate argument uses the valid inequality \(\|A_\nu z\|_\infty\le2\|z\|_\infty\). The two projections need not commute, and the proof does not assume that they do.

3. **The cross-denominator argument is sound.** Symmetrizing \(B\) inside \(u'Bu\) is legitimate. The displayed conditional variance bound controls the quadratic and linear terms without assuming zero third moments. On the stated good event, failure of the primary threshold implies
   \[
   d_X<v_-/8,\qquad \operatorname{tr}(B\Omega)/N\ge3v_-/16.
   \]
   Consequently the deterministic propensity contribution must have magnitude at least \(v_-/16\). Its norm bound gives the claimed containment in
   \[
   \{b_X\ge\kappa\}\cup\{G_\pi\ge\kappa\}.
   \]
   This is the essential link between a small denominator and an error term that the certificates can control.

4. **The fallback bias is charged correctly.** The four weighted expectations on page 54 recover precisely the approximation product and the three directional/stochastic terms. Dropping event indicators for absolute noise bounds is valid and avoids an unjustified independence assumption about branch selection. The exceptional-event constants are consistent with the stated Chebyshev bounds.

5. **Arbitrary public centers are supported by the construction.** Recovering each center through the core’s pointwise extrema is justified by sequential M1 and the full interval-box assumption. Grouping the *centered* core is crucial: it recovers the perturbation cells even when the center varies within a cell. Merged zero-width cells cause no difficulty because the centered public functions vanish there. The result still concerns a public class fixed before observing the estimation sample; it does not license unrestricted reuse of a center fitted on that same sample.

The separate verifier found no counterexample or failure in the assigned matrix, conditional variance, and fallback calculations. Its finite-array checks supplement the algebraic review; they are not empirical performance evidence or a formal proof certification.

The new singleton example is valid and useful. The global difference complexity is at most \(2h\); with \(h\le c_{\rm rad}r^2\), this satisfies the required positive-radius certificate. The collision probability follows from a union bound. On the no-collision event, positive widths let M1 distinguish the observed cells, so both matrices equal the identity. The displayed zero-nuisance, zero-noise law satisfies the model bounds, and the estimator recovers the legal coefficient exactly. Deleting all singleton observations would remove that information.

This example does what the paragraph promises: it explains the mechanism. It does not establish histogram minimax sharpness or general practical superiority, and the manuscript does not present it as doing so. Using a common partition in this particular example is appropriate even though the theorem now permits different partitions.

The presentation is improved. The abstract and introduction clearly advertise the broader histogram result. Page 8 states the actual estimator and explains the nonsymmetric denominator issue, rather than leaving the strengthening entirely to the appendix. The scope still distinguishes the simultaneous adaptive upper guarantee from a matching histogram minimax characterization and from general-class adaptation. The partition-wording scan revealed no stale common-partition restriction outside the deliberately common-partition example.

Moving the allocation proof to Appendix B.9 causes no substantive loss. The main text retains the relevant bounds, endpoint allocations, and proof pointer; the mathematical content remains available.

My significance assessment is stronger because the adaptation theorem now covers two independently specified histogram perturbation classes and arbitrary public centers. It is a more useful structural result than the original shared-partition theorem, and the fallback handles a genuine additional mathematical difficulty. The remaining reservations from the original review still apply: the general upper expression is inherited, the worst-public-pair lower construction has limited implications for fixed practical learners, and the appendix remains repetitive. Those reservations support a measured acceptance recommendation rather than a strong-accept assessment.

I see no mathematical change required by this follow-up review.
