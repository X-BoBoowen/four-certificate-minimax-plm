# C21 independent manuscript review and separately labeled followups

Primary reviewer: gpt-6-astra / ultra, fresh context. This first report concerns the 62-page C21 geometry draft BEFORE the new general-M1 approximation-adaptation theorem and Appendix P were integrated. It does not review that later result. This is an AI red-team report, not human verification. The following original response is retained without retrospective rewriting.

## Original geometry-draft review

本轮 AI 技术审查发现三处正文条件遗漏；目前均已在源文件中修正。新增 Appendix O 的数学论证未发现实质缺口。原 PDF 的结论完整位于第 9 页；尚未复核重建后的 PDF。

1. **Hilbert 包络代价必须明确 signed containment。** 原 `main.tex:478–480` 只写包含 \(p\) 个正交 sign functions，无法推出任意 affine ball 的半径至少 \(h\sqrt p\)：\(p=1\) 时取中心 \(h\phi_1\)、半径零即可反驳。Appendix O:161–162 的原始条件 \(\{0,\pm h_j\phi_j\}\subset c+RB_{\mathcal H}\) 正确。当前引言及正文均已明确包含正负函数，这一问题已解决。

2. **Box 残差阶数必须带期望。** 原 `main.tex:433` 把残差平方范数直接写成 \(O_\rho(r^4+N^{-1})\)，而 M:198–203 证明的是
   \[
   \mathbb E\|\mathsf A z_X\|_N^2\lesssim_\rho r^4+N^{-1}.
   \]
   确定性步骤只有 \(\|\mathsf A z_X\|_N^2\le H^2/\alpha^2\)，其中 \(H\) 随样本变化。当前改成 “expected squared norm”，与证明一致。

3. **Hilbert trace 不等式需要大样本条件。** 原 `main.tex:457` 的确定性 trace 上界只适用于 \(N\ge16B_0^2/v_-\)。例如 \(N=2,B_0=3,v_-=1\)，两个零半径类中心分别为 \(1,x\)，样本取到两个不同 \(x\) 时中心矩阵满秩，故 \(A_c=0\)、\(\operatorname{tr}(I-A_c)=2>1/18\)。这不损害实际估计器，因为小样本分支输出零。当前已加 “In this large-sample branch”，问题解决。

对新结果的具体判断：

- **凸包与线段并集下界继承有效。** O:82–104 使用
  \[
  \Delta\operatorname{conv}(D)=\operatorname{conv}(D-D)
  \]
  的全局支撑函数恒等式，把新增类的局部复杂度控制在原有限差分类的**全局**复杂度以内。L 的计算本来就覆盖跨频带差分，因此没有误用“局部复杂度在凸化下不变”。所引 [Bartlett–Mendelson Theorem 12(2)](https://jmlr.org/papers/volume3/bartlett02a/bartlett02a.pdf) 与此用途匹配。
- 有理系数/线段参数提供 M1 cores；包络不增加；原在类真函数保留；离类真函数与新增跨度正交；零预算对应零类。原观察分布和混合测试距离没有改变，公开更多函数评价也不产生隐藏标签信息。同一公开类对和预指定 atomless marginal 的继承链可闭合。
- **精确 Hilbert enclosure lemma 有效。** 正负残差的半差消去任意中心，得到 \(h_j\phi_j\) 属于归一化单位球；Riesz representers 与两次有限 Bessel 不等式给出 \(\int\ell(x,x)d\nu\ge\sum_jh_j^2\)。零中心核 \(\ell_0=\sum_jh_j^2\phi_j\otimes\phi_j\) 达到两条界。独立 explorer 对这段证明及 N 的包络接口也得到相同结论。
- **N 的上界机制成立。** 核恢复、中心投影、trace 控制、公共函数残差控制以及只用平均残差方差的分母计算彼此一致；处理未达到的 approximation infima 时也明确使用固定近似比较函数再取极限。

正文的科学解释总体成立：相同四项**上证书**下，凸性仍允许许多难辨方向；full boxes 利用独立坐标结构控制 singleton residuals；full Hilbert balls 额外提供受包络控制的核 trace。正文明确比较 restricted outer worst risks，并允许字典大小随 \(n\) 和预算增长，没有把结论升级成每个固定字典的下界。

两项可选文字改进：

- 摘要第一次陈述 \(q+X\) 时即可说明处于 strict interior，避免读到后文才得知 saturation 例外。
- 结论 “The enclosure cost explains this geometry distinction” 可更准确地限定为：说明为何不能在相同 \(B_{\mathcal G}\) 下通过 Hilbert enclosure 转移字典下界。该 lemma 没有给出三类几何速率差异的必要充分刻画。

我还核对了 [TAME Corollary 3.2、(3.6)–(3.7)、Condition 2.1(b)](https://arxiv.org/html/2607.21541v1)，以及 [Gu–Yin–Cai–Fan Theorem A.1、SADE Theorem 2.1/Remark 2.1](https://arxiv.org/html/2606.06368v1)。正文对已知方向选择、领先上界和单类无预算适应的归属与这些原文一致。

实际阅读范围：PDF 正文第 1–9 页全文文本，并渲染查看第 9 页；正文 `main.tex`；完整 A、L、N、O；M 中与 singleton、trimming、残差矩和几何下界接口相关的段落。没有重审 B–M 的全部原始证明，没有读取历史审稿结论、分数或内部记录，也未修改或创建文件。这是 AI red-team 审查，不是人工验证或全篇正确性认证。


## Appendix P: independent O/Borel source review

Configuration: gpt-6-astra / ultra. Targeted actual-source review following a research-note review; not a fresh PDF-only review. Original response:

**实际 Appendix P 的 O 分支、Borel 实现、可行性及 single-core 简化通过复核，未发现数学回归。** 已直接检查源码，未沿用笔记结论代替审查。

- 取 \(h_j=\widehat\pi\) 时成本确为零；取 \(h_j=h_0\) 时，在 \(b\le t+h\) 的好事件上成本不超过 \(A_t/2\)。严格余量和有理逼近仍推出同一个 \(\min\|z\|_n^2\) 程序的两条比较。
- 单一核心差分满足 \(\|(\widehat h-\widehat\pi)_X\|_n^2<A_t\)，足以替代此前所有 O 分析中的 mixture/Jensen 步骤。
- 常数冻结、\(K_A\ge12C_{\rm cmp}\)、\(\widehat\eta=0\) 的失败约定，以及去掉 \(1_{G_\eta}\) 后的二阶矩说明均正确落实。
- 主样本 outcome 未进入残差选择；条件噪声、随机索引、O 误差吸收及产品界均成立。
- 主文实际算法和定理的输入、约束、目标、回退及 \(q+W\) 保证与 P 对应；没有扩展到未知 \(s,t\) 或有限查询计算。

主文最后需修准一句：目前第 394 行虽已增加好事件限定，但 **“two strictly feasible real-vector comparisons”仍无条件声称两个都可行**。第二个只在 \(b\le t+h\) 时可行，建议写：

> supplies a strictly feasible real-vector comparison, with rational approximations; a second comparison is available when \(b\le t+h\).

后文已正确说明该条件。此次通过范围为上述 O/Borel/可行性与主文对应；完整 pilot 和 R 分支由另一位独立复核覆盖。

## Appendix P: independent pilot/R source review

Configuration: gpt-6-astra / ultra. Separate technical branch; targeted actual-source review following its independent research-note audit. Original response:

**实际源码复核通过：未发现单 core 版本的数学失败步骤。** 我直接检查了新附录全部 649 行及主文第 5 节（303–416 行），没有以 note14 的结论代替源码审查。

- **Pilot，附录 105–178 行：完整。** 固定锚点平方风险证明正确覆盖两个 fallback 情形；条件于内部训练块再积分得到同一个 pilot 的双 MSE。\(R_k\le(n/k)R_n\) 的条件 Jensen 转移合法；联合 outcome fit 的局部化只改变固定常数。使用较小容差 \(n^{-12}\le k^{-12}\)、单置信度取矩及小样本零输出均闭合。

- **成本与常数，180–240 行：完整。** 条件于 \(\mathcal D_2\) 后，对 \(f=\widehat\pi-h_0\) 的平方作标量 Bernstein，无随机主样本索引误用。期望转移正确。\(K_A\ge12C_{\rm cmp}\) 配合 \((b+t)^2+h^2\le6(t^2+h^2)\) 给出半 cap 余量。\(L=8B_0\) 满足 \(\sqrt8B_0\le L/2\)。\(R,M,K,K_A,n_\rho\) 的选择无循环。

- **同一程序的两次比较，324–479 行：单 core 简化有效。** \(j=\widehat\pi\) 虽是随机索引，但确为程序已经枚举的 represented core 索引，成本恒为零。固定 \(j=h_0\) 在 \(b\le t+h\) 时满足 cap。两者在 \(G\) 上拥有所有严格余量；固定该样本上的索引后，对自由向量作有理逼近即可推出两条目标比较。删去 mixture 没有删去任一必要 benchmark，也没有引入未知预算输入。

- **R 分支，544–649 行：逐项成立。** 现在 \(f_1=\widehat h-\widehat\pi\) 本身就是 represented difference，故 574–576 行的
  \[
  2A_t+2B_{\rm cmp}+3\kappa_\pi
  \]
  直接来自两次 outcome 校准；599–602 行的
  \(A_t+B_{\rm cmp}+2\kappa_\pi\) 来自两次 propensity 校准。选择 \(\widehat h\) 可以依赖第一半样本 treatments，因为所代入的不等式已经对全部 core 同时成立。两条 scalar 约束分别控制 \(\widehat\pi^c,\widehat z\)，pilot 的两条 MSE 分别控制 \(hE|c|\) 与 \(E|c|\|r_\pi\|_n\)，没有遗留裸 \(b\)、\(t(a+s)\) 或 \(h\) 项。大 \(b\) 分区确实仅使用同一规则的 product bound。

- **零预算完整。** 没有除以 \(s,t,a,b\)。正 \(h\) 保留严格 cap 与容差；\(\zeta\)-comparators 覆盖未达到的零 approximation infimum。尤其 \(a=s=0\) 得 \(C_\rho q\)，\(b=t=0\) 得 \(C_\rho q\)，\(a=b=0\) 得 \(C_\rho[q+\min(s^2,t^2)]\)。不需要条件 residual variance 下界。

有三处**非证明缺口的表述建议**：

1. 附录 335–336 行说向量 \(\eta_0\) “random only through \(c\)”不够精确：它也随机于主样本 \(X_i\)。应说函数 \(\mu_0+c\pi_0\) 的拟合随机性只来自 \(c\)。其后 \(\mathcal F_X\) 条件化正确，因此不影响证明。
2. 主文 394–398 行的“两种 feasible 表示”应明确限定为**在 good event 上、对实向量并在有理逼近之前**；附录 427–458 行已经这样处理。
3. 主文 390–392 行“preserves … centering of treatment and outcome noise”可更精确：treatment noise 的条件中心化用于 \(\mathcal F_X\)-可测方向；selected residual 对 outcome noise 使用 \(\mathcal F_T\) 条件化。不能把前者读成 \(u\) 对所有 treatment-adapted selected directions 自动中心化；附录没有犯这个错误。

通过范围是该源码对**已知 \(s,t\)、未知 \(a,b\)** 的统计风险证明及对应主文陈述；不支持四预算全未知或有限查询、有效计算的推广。

## Supplementary manuscript review after Appendix P integration

Same primary reviewer as the original geometry report. This is a separately retained followup, not another fresh blind review. Original response:

这是针对新增 Appendix P 的补充审查，承接此前 C21 审查；不是新盲审，也不以此前结论作为通过依据。

在实际核查范围内，我没有找到新增“已知 \(s,t\)、未知 \(a,b\)”定理的反例或实质证明缺口。本轮发现一处正文概率条件遗漏及一处量词说明歧义；当前源文件均已修正。新增结果不支持省略 \(s,t\)，正文也没有这样声称。

1. **经验邻域的第二个比较需要高概率限定。** 最初正文写“当 \(b\le t+h\)，固定近似函数 \(g_0\) 也满足已知 cap”，但 Appendix P 的结论依赖共同事件 \(G\)，尤其依赖 \(B_{\rm cmp}\) 的经验上界。仅由总体近似预算不能确定性推出经验 cap：例如 propensity 类为 \(\{0,d\}\)、\(\pi_0=0\)，极端训练噪声可能令初始拟合选择常数 \(d\)，使 \(g_0=0\) 的经验距离为 \(d^2\)，超过随 \(n\) 缩小的 cap。当前 `main.tex:395–400` 已明确共同高概率事件、严格可行性与有理近似，和 P 的证明一致。

2. **基准风险与适应性定理应区分预算知识。** 最初 Section 2 仍直接说四预算已知，容易与新定理混读。当前 `main.tex:101` 已限定为 baseline risk；Theorem 4 则清楚写出固定 \((\Gamma,\rho,n,s,t)\) 后，同一规则同时覆盖所有 \(a,b\)。该修改解决了说明上的歧义，不需要改变原 minimax 风险定义。

新增证明中，我重点检查了以下环节：

- **标量 pilot 的两条二阶矩界可闭合。** 对固定、独立验证的 anchors，主分支偏差是近似误差乘积；fallback 发生时，要么 propensity anchor 误差已有固定下界，要么属于概率 \(O_\rho(m^{-1})\) 的分母偏离事件。因此
  \[
  \mathbb E|\delta_{g,h_0}-\beta_0|^2
  \lesssim_\rho m^{-1}+a_0^2b_0^2.
  \]
  anchors 有界进一步给出两种误差的最小值。内部样本拆分不增加观察数；\(k\) 子样本的复杂度通过 \(\mathfrak R_k\le(n/k)\mathfrak R_n\) 转移，只改变固定常数。

- **同一程序确实未使用 \(a,b\)。** 两个校准容差及 propensity 邻域半径仅依赖 \(\rho,n,s,t\)。比较 \((\widehat\pi,\pi_0-\widehat\pi)\) 在 \(G\) 上始终可用；\((h_0,\pi_0-h_0)\) 在 \(b\le t+h\) 时提供更强的同一目标函数比较。算法没有检测这个条件，也没有据此切换估计器。

- **可行性与 Borel 选择相容。** 固定 represented index 后，校准函数由共同包络保证对向量连续；严格约束和 \(+\tau\) 留出有理近似余量，包括零方向。可数可行性判断、可数 infimum 和首个严格近似最优点给出 Borel 规则。这是存在性保证，正文准确保留了没有有限查询优化保证的限制。

- **条件噪声处理没有把被选择事件当作独立事件。** 第一校准只用 \(\mathcal D_2\) 和第一半 covariates；第二校准可用第一半 treatments，但不使用其 outcomes。证明先在适当条件信息下控制噪声，再从非负绝对值中去掉 \(1_G\)，并用确定性的分母下界；没有错误地假设噪声在 \(G\) 条件下仍居中。

- **同一规则的两个方向界确实共同成立。** Outcome 分析得到
  \[
  q+a(b+t)+a^2+s^2.
  \]
  Propensity 分析在小 \(b\) 区域利用较小 free residual，在大 \(b\) 区域利用同一规则的 product bound，得到
  \[
  q+b(a+s)+(b+t)^2.
  \]
  两个区域只划分证明。取两界最小值不需要预算驱动的算法选择，并且第一界不大于相应的 \(T_\mu\)，故推出 \(q+W\)。

- **没有直接把 \(h\) 当作 \(q\)。** Proof 保留 product bound 中的 \(h\)，随后按区域吸收混合项。两条 pilot 界分别控制所需的 \(h\mathbb E|c|\) 和 \(\mathbb E|c|\|r_\pi\|_n\)。最后使用的是 \(h^2\le2q\)。小样本输出零、零预算正容差以及未达到的 approximation infima 也都有对应处理。

科学定位方面，新增贡献清楚地加强了估计器量词：四项证书仍用于描述风险，而一般类的同一估计规则只需其中 \(s,t\)。原几何比较因此仍有内容：full boxes 和 Hilbert balls 进一步省去全部预算，并在相应预算区域给出更小的风险阶。正文没有把新结果描述为一般类的完全预算适应。

一手文献核查支持目前的归属。Liu–Xinbo Wang–Yuhao Wang v4 §4.1 确有 PLM double-calibration 构造和校准 correction direction；其 Theorem 6 是稀疏 GLM 条件下的渐近结果，还包含初始估计和设计等条件。当前 P 将其作为方法先例，并明确不调用其定理来证明一般 M1 结果，是准确的。[原文 §4.1、Theorem 6](https://arxiv.org/html/2305.04174v4)

实际阅读范围是当前完整 `main.tex` 正文、完整 `P_approximation_adaptation.tex`、B 中被 P 调用的 localized-process 条件与初始拟合/顺序密度转移接口，以及本次 68 页 PDF 的正文第 1–9 页。另渲染查看了第 7、9 页：新增算法与解释可读，结论完整位于第 9 页。独立 explorer 另核对了上述文献的 v4 HTML/PDF §4.1 与参考文献条目。

限制：这不是 B–M 全部证明的重新审查，也不是形式化证明或人工验证；本轮没有声称完成 exhaustive novelty search。审查过程中源文件持续修订，最终构建仍适合再做一次限定的文字与排版复核。我未读取历史审稿分数或内部结论，也未修改或创建文件。

## Integration note, separate from reviewer responses

The final source distinguishes the baseline known-budget risk from Theorem 4; main Section 5 specifies the common high-probability event and the additional b≤t+h condition for the second real-vector comparison. It separates treatment-noise conditioning on F_X from outcome-noise conditioning on F_T. Appendix P clarifies the randomness of the comparison function and its evaluated vector. K_A≥12 C_cmp, failure conventions and unconditional bounded moment control are explicit. The geometric review's signed containment, expected-square wording, large-sample trace condition, strict-interior abstract and limited enclosure interpretation were also adopted. Root read the full new O/P sources, rederived the main inequalities, and checked the final PDF. None of these AI reviews certifies the entire manuscript formally or replaces author responsibility or independent human review.
