# C15 正文优先复审：独立读者报告（第一轮）

审查日期：2026-09-07。

材料边界：只读取指定 `iclr2027_candidate_c15/main.pdf` 第 1–9 页；页码均指 PDF 页码。未读取该稿附录、参考文献页、旧报告、项目状态、作者仓库或其他代理意见；未修改稿件。为核对最接近的先前工作，有限查阅了 TAME 与 Jin–Mackey–Syrgkanis 的公开一手文本。没有进行全领域优先权检索。

模型披露：本报告由当前 Codex 独立子代理完成；父任务指定主审配置为 gpt-6-astra / ultra，本分支未独立核验服务端实际模型路由。没有向其他代理索取审稿意见。

核验边界：对正文中的几个代数关系、预算射线、饱和识别论证进行了独立检查；对正文未给出的条件分布、局部复杂度定义、分支引理、混合距离计算及同对字典拼接，不视为已经核验。以下区分“正文缺少足以判断的证据”和“定理本身被反例推翻”；本轮没有得到后者。

## 1. 总体判断

这九页足以让我复述论文想解决的 minimax 问题、风险量词和方向性项的阶数意义，但不足以让我精确定义它宣称解决的四预算实验，也不足以独立检查最主要的新下界。问题不在于没有把所有附录证明搬进正文，而在于正文将核心定义和唯一真正新增的概率计算留成了口头保证，同时反复解释量词合法性、贡献边界和不作何种主张。

如果必须仅凭这九页作录用判断，我目前倾向弱拒，主要理由是承重证据与贡献规模仍难判断，而非已证实结论错误。若补齐下文前两项，判断有实质改变的可能；增加审计标签、再重复一遍贡献边界或再加合法性清单不会改变判断。

最有力的接收理由是：若四预算定义与测试构造成立，本文在一个明确的公共类实验中把已知可达上界闭合成所有预算的精确阶。O/P 在合法序列上使此前下界从 r³ 增到 r²，具有非恒定因子的内容；第 7 页相同总误差半径、不同精确风险的例子尤其能说明为什么四项信息值得分别保留。这可以是一项集中的理论贡献，无需强行附加实验优越性或新通用技术的叙事。

最有力的拒收理由是：目前读者看到的是“新增下界的结论与校验项目”，而不是足以相信新增下界的构造与计算。上界的主导形式已明确来自 TAME；有平方半径和混合项的障碍也已有近邻。剩余增量是否达到足够的概念和技术深度，取决于公共四预算分配、精确条件方差和 O/P 两通道到底怎样同时实现。这正是第 5–6 页尚未展示的部分。此时工程化同对共存和 E/I/S 术语占据较多篇幅，不能补足主要科学论证。

## 2. 只读正文后，我能准确复述什么

| 问题 | 可复述程度 | 正文支持与剩余缺口 |
| --- | --- | --- |
| 科学问题 | 基本可以 | 给定两个已公开的 nuisance 类及各自近似和随机复杂度上界，估计有界 PLM 的系数，刻画对最坏合法公共类对的风险。不是固定一套先导预测函数后只看其实际误差。 |
| 目标参数与样本 | 可以 | 第 2 页式 (2)：两半样本各 n 个观测，目标为条件均值模型中的统计系数 β；E[u∣X]=0、E[ε∣X,T]=0，且 E[u²∣X]=v 为区间中的常数。 |
| a、b | 大致可以 | 第 2 页式 (3) 给出两个类的 L² 近似上界；应顺手明确范数依据每一兼容律的 P_X。 |
| s、t | 不能精确定义 | 只知道它们是差分类在“所有更大正半径”上的局部 Rademacher 证书。没有复杂度公式、右端归一化、n 的使用方式或 c_rad 出现位置，不能判定一个给定类是否属于预算单元。 |
| 风险量词 | 可以，且已解释得过多 | 式 (4) 是 sup_Γ inf_{δ_Γ} sup_P 的期望绝对误差。Γ 可依赖公开 n 与预算，估计器知道 Γ；类不能依赖潜在标签或数据。不能由该标量风险推出所有固定自然类都支付该阶。 |
| 主贡献 | 可以辨认 | 主要是 O=t(a∧t)、P=s(b∧s) 的匹配必要性；上界的主导两分支形式继承自 TAME。全预算可测闭合及工程化同对共存是次要增量。 |
| 承重依据 | 不充分 | 能检查选择器和式 (9) 的代数，也能检查饱和支持论证；不能从正文重建 O/P 的观测律、混合似然二阶矩或公开字典的全部预算。 |

必须特别分清三种“product”：近似乘积 ab、此前下界里的 AB=(a+s²)(b+t²)，以及两个总 L² 半径的乘积 xy=(a+s)(b+t)。它们承担不同角色。沿 O 射线 a=t=r、b=s=0，AB=r³，但 xy=r²，而新增 O 也等于 r²。因此图 1 说明的是先前下界的缺口被闭合，并不说明这一射线上传统总误差乘积上界出现错误或被改进。第 7 页固定 (x,y) 而改变预算分配的例子，才更直接支撑开篇“一项误差不能概括每个 learner”的说法。

## 3. 最多五项实质优先改进

### 优先 1：在正文完整定义随机预算，顺带把共享包络写成一个明确条件

位置：第 2 页，第 2 节，式 (3) 后；第 3 页 Theorem 1。

原句：“The budgets s, t bound, at all positive radii above themselves, outer-expectation localized Rademacher complexities of the public difference classes.” 另有：“A fixed B0 ≥ 3 bounds the variables, target, nuisances, and residuals ... as detailed in Appendix A”。

为什么影响科学判断：四预算是标题和主定理的自变量，但当前只正式定义了其中两个。局部复杂度条件若右端为 c_rad·r·s，或 c_rad·r²，或只在某临界点成立，会定义不同的类集合；是否采用 star hull、是否有额外 n 的下限项，也会影响 s=0 和极小预算。读者不能靠“localized Rademacher”这个词自行补全。E/S 又同时依赖 |T| 和 |u| 的共同 B0 约束，而不是仅依赖残差有界。

可执行改法：正文给出差分类与外期望复杂度的完整公式，随后写出该稿实际使用的两条不等式及半径量词，明确 s=0/t=0 的含义和 n 的约定；不要从常见定义推测替换。将 L²(P_X) 和一个紧凑包络条件直接列出。P(Γ) 可以再用一句话定义为满足这些条件与式 (2)–(3) 的所有观测律，其余可测性技术保留附录。这里需要新增约半页数学内容，不需要新增“证书已校验”的标签。

### 优先 2：让一个方向性下界在正文真正成为可检查的统计构造

位置：第 5–6 页，第 5 节及 Table 2。

原句：“A bounded three-point treatment channel with binary response aligns the observable moment ...”；“The exact mixture second moment gives the required observation-distance certificate”；“Each construction independently certifies model membership, target separation ... observation distance, and all-n closure.”

相关公式：P 的两标签 (0,zη,zγ) 与 (Δ,−zη,zκ)，Δ=2ηγ/v_-；O 的目标差 γη/(v_-+γ²)。

为什么影响科学判断：给定 (β,π,µ) 只给出了条件均值，尚未给出 (T,Y)∣X 的观测分布。许多分布共享这些均值，测试难度却完全不同。匹配一个 observable moment 不足以推出混合观测律接近；Walsh 正交也不会自动使任意似然内积受控。这里是文章主张的主要新增下界，却没有一个读者能够代入验证的概率表，也没有一条实际二阶矩不等式。表 2 的“distinct observable-moment cancellation”仍是解释待证明内容的描述。

可执行改法：择 O 或 P 中技术上最能体现增量的一支，正文给出有限 X 支持与字典、两标签下 (T,Y) 的条件概率，以及同一公开类对的定义。明确混合随机变量只属于证明，所有类先于标签固定。随后展示一条真正由该构造算出的似然内积/二阶矩公式，再推出 TV 上界与目标分离。保留另一支的均值表和它不能通过单纯交换变量得到的具体原因；幅度常数、所有小预算拼接和逐项包络检查可以留附录。正文无需复印两套长证明，但必须包含至少一条“为什么观测看不见而 β 改变”的计算。

### 优先 3：给出估计器的统计核心和公开安全条件，别仅给选择器代数

位置：第 4 页，第 4 节、式 (8)、Proposition 2。

原句：“The branch lemmas give CO(q + Tµ) and CR(q + Tπ) on their certified cells.”；“invokes a bounded zero fallback if the selected branch’s public small-radius certificate fails.”

为什么影响科学判断：x≤y 的选向和 T_selected≤2W≤48X 解释了如何选择一个已存在的好估计器，但不定义该估计器。正文没有任何最终估计 β 的 score/moment 公式，没有分支校准目标，也没有实际安全谓词。读者因此无法看出“全预算、期望 L¹、公共预算调参”的闭合究竟解决了哪个非平凡问题。尤其 µ 是 PLM 的截距函数，不是 E[Y∣X]，笼统说“empirical minimizers produce initial fits”会留下怎样学习 µ 的实质疑问。

可执行改法：用一个短算法给出初始联合 PLM 拟合和 treatment 拟合、至少一支的校准目标/最终系数公式，以及公开调参和安全阈值的数学形式；另一支可引用明确的镜像公式位置。把从原高概率分支结论到全 n 期望界的关键一步说明白，包括极小随机预算时怎样处理。保留式 (8) 的简短代数和一行 unsafe⇒q+X≥c_ρ。可测的 first-within-tolerance 枚举细节仍放附录。不需要增加实现或计算效率主张。

### 优先 4：把“旧下界缺口”“总误差乘积”“近邻障碍”三者的关系放在引言中说明

位置：第 1 页摘要/引言，第 4 页图 1，第 8 页统计解释，第 9 页 Table 4 与相关工作。

原句：“Black-box semiparametric theory often summarizes two nuisance learners by one error each and a product remainder. We show that this summary is incomplete ...”；第 9 页：“The residual here is public four-certificate allocation ... exact-variance embedding ... matching sequential-M1/Q1 closure”。

为什么影响科学判断：本文的非恒定因子分离相对于 q+AB+M 的已有下界，而不是相对于所有使用 xy 的程序。若这层区别不先讲清，读者可能把“新增必要项”理解为纠正 DML 上界，或者把许多接口字段当作与最近工作无关的证据。第 9 页虽然克制地承认近邻，却主要列字段，没有显示哪项变量转换真正失败。

有限一手核对：TAME 的 Corollary 3.2/(3.7) 确实具有本文 Tµ∧Tπ 的主导形式，并带有趋零和高概率条件；该文自己还定义了随机误差的 n 相关下限，因此零预算/全预算闭合不是简单逐字转引。[TAME 原文，§2.1 与 §3.3](https://arxiv.org/html/2607.21541v1)

Jin–Mackey–Syrgkanis 的 Theorem 3.1 使用已给定的 (ĝ,q̂)，其中真 nuisance 是 (E[T∣X],E[Y∣X])，并给出平方半径与混合项的障碍。本文的第二坐标却是 µ，满足 E[Y∣X]=µ+βπ；故将该定理直接替换成四个公共类证书需要实际论证，不能只重命名 ε。其定理约束条件方差下界，也没有本文的精确常数条件方差要求。[Jin–Mackey–Syrgkanis 原文，§2–3.1](https://arxiv.org/html/2507.02275v3)

可执行改法：引言先给一个合法 O 射线，明确“已知上界为 r²、已知下界为 r³、本文证明下界 r²”。再把第 7 页相同 x,y 但不同风险的例子前移，以解释四预算为何有额外内容。相关工作保留三条最关键的公式级对比：TAME 给什么；Gu–Yin–Cai–Fan 还差什么；最近 anchored-nuisance 下界为何不能直接得到当前结论。后一条应展示 nuisance 坐标关系、公开类和锚点的区别，以及 exact-variance 构造需要解决的具体限制。不要把“检查过的定理字段不同”升级为新颖性证明，也不必声称一种此前未知的通用下界机制。

### 优先 5：同对共存应给出实际复杂度桥梁，或者降为简短次要命题并释放正文空间

位置：第 1–2 页贡献段，第 6 页 Proposition 3，第 8 页 Claim boundary，第 9 页结论。

原句：“Disjoint Walsh bands multiplex active families, and finite unions preserve the certificates.”；以及 Proposition 3 的“∃(Γ⋆,P_X⋆)”与相同全率风险不等式。

为什么影响科学判断：如果只看“存在一个 Γ⋆ 达到 c(q+X)”这条风险不等式，它已几乎由外层 supremum 的全局下界推出：取一个在常数因子内逼近 supremum 的 Γ 即可。真正额外的内容是明确的单个有限字典、相同 P_X 和所有原生难例族共存，并仍满足四个预算。正文恰恰没有显示这个难点。

“有限并保留证书”也不是无需条件的一般事实。例：G1={0}、G2={1} 的各自差分类均为 {0}，Rademacher 复杂度为零；它们的并的差分类含 ±1，在半径至少 1 时复杂度为 E|n^{-1}Σ ε_i|>0。这个例子不是对本文特殊拼接的反例，而是说明必须处理跨字典差函数；“Walsh bands”与“finite unions”本身不足以构成理由。

可执行改法：若坚持把它作为第二主结果，正文至少给出一次跨 band 的差分类复杂度界和幅度/预算余量如何支付并集代价，说明固定 P_X 在风险子族中究竟如何使用。若不承担这部分正文成本，就把工程化同对共存压缩为一个短段和附录命题，主文仅保留组件下界经 max-to-sum 汇总。摘要无需介绍 active/inactive/q splice 的全部内部术语。所释放篇幅优先给前两项，而不是继续扩展“同对但非同律”的免责声明。

## 4. 哪些内容值得保留，哪些应删除或移附录

值得保留的正文内容：第 2 页式 (4) 及一次朴素的量词解释；第 3 页主定理；图 1(a) 的合法非参数射线；第 7 页相同 (x,y) 不同 X 的例子；至少一个完整方向性难例；式 (8) 与式 (9) 的短代数；第 7 页饱和识别的支持论证。它们分别回答“问题是什么”“结论有多少内容”“为什么能成立”。

可以合并的重复内容：

- 摘要后半、第 2 页贡献段、第 6 页命题前后、第 8 页 Claim boundary、第 9 页结尾都重复 global Q1 不需要同一公共对、active/inactive 家族和 max-to-sum 的关系。在定义风险处解释一次，在同对命题处补一句就够。
- 无 causal/common-rule/adaptive/computational/uniform-in-ρ 主张在摘要、表 1、第 2/4/7/8/9 页多次出现。保留一处精确 limitations 段；将本文实际可用的信息写清楚，就不必在每次谈算法时重新列禁止查询对象。
- 第 4、7、8 页重复 public orientation、安全 fallback、全 n 闭合的口头描述。应合成一处带实际公式的算法和论证。
- 第 3 页“One valid lower constant is one tenth ...”和第 6 页详细五与二的系数损失可缩为绝对常数因子。此处的具体 1/10 不是科学卖点。
- 第 6 页“no grid approximates ...”“Solver failure or search non-hit plays no role”，第 9 页“collision-free claim”等与正文统计论证没有直接关系，可以删除。
- E/I/S 三字母不是额外科学证据。保留结构性边界，但不用在摘要、图、主定理解释、第 8 页和结论反复强调不能从 I 连续外推到 S。饱和支持证明很清楚，紧邻定理用短段呈现即可。

不建议通过要求额外实证实验来修补这些问题。这是一篇信息论理论论文；当前最缺的是可核查的定义和论证，不是实验表格。

## 5. 更清楚的九页顺序

以下是篇幅分配建议，不是额外研究项目：

1. 第 1 页：约 150–180 词摘要；引言以四预算科学问题、旧下界与已知上界之间的 O/P 缺口为主。尽早给一个射线。
2. 第 2 页：PLM、明确包络、四预算完整定义、表示条件、式 (4)。将“知道什么、何时选择什么”写成一段。
3. 第 3 页：主定理、两种预算分配例子、简短三层贡献定位；边界结果可紧随定理，以支持证明收尾。
4. 第 4–5.5 页：主要新下界。一个完整有限观测通道与二阶矩计算；另一个方向突出不同的消去关系。核心图表展示构造关系，不重复结论标签。
5. 第 5.5–7 页：继承上界如何在本实验中落地；定义估计器、公开调参/安全阈值、期望风险闭合，最后给选择器代数。
6. 第 7–8 页：其他组件和全局汇总、简短同对加强；保留真正解释四预算意义的例子。若同对是第二卖点，此处须出现它的复杂度桥梁。
7. 第 8–9 页：与三个最近前驱的公式级对比，限制和一个简短结尾。无需再按章节重述全部结论。

引言可以用下列逻辑顺序：读者只有两个公共类及各自近似/随机证书；此前方法给出怎样的上界；现有下界在哪个合法预算配置留下多项式缺口；两个方向性测试将它闭合；精确风险还显示两个相同总误差半径的单元可以有不同难度。此后再陈述有界、常数条件方差和公共表示的适用范围。

摘要可参考以下压缩结构，最终术语需与补全后的随机预算定义一致：

> We study estimation of a bounded partially linear coefficient when two public nuisance classes come with separate approximation and stochastic complexity certificates. For known budgets (a,s,b,t), we characterize expected absolute error under a worst-public-pair minimax risk. Under strict slack between the residual-variance lower endpoint and the shared squared envelope, the rate is n^{-1/2}+(a+s²)(b+t²)+(s∧t)²+t(a∧t)+s(b∧s), up to constants depending on fixed regularity parameters. The new lower bounds establish necessity of the two directional terms: each can raise the previously established lower order from r³ to r² on a legal budget sequence. The matching upper bound completes the TAME-derived two-branch construction for this represented-class experiment. At envelope saturation, the treatment mean is identified and the rate is parametric. The result is an information-theoretic characterization for known class certificates.

这个示例不增加优先权、通用方法、因果或实践性能主张。若最终同对构造确有独立科学价值，可以增加一句具体成果；不宜恢复一串内部拼接术语。

## 6. 独立数学检查与未核验事项

已检查的代数：令 S0=ab+M+O+P。因为预算在 [0,1]，at²≤t(a∧t)=O、bs²≤s(b∧s)=P、s²t²≤M，所以 AB≤S0，进而 S0≤X≤2S0。式 (9) 是正确的。选向 x≤y 时，Tµ=ay+x²≤2xy≤2Tπ，因此 T_selected≤2W 的说明成立。对包含零和极小值的 6,561 个预算格点，额外数值检查了正文列出的 V/W/X 比较，未见反例；该检查不代替其完整解析证明。

已检查的射线：a=t=r、b=s=0 给 AB+M=r³、O=r²；r=n^{-1/8} 时 q=o(r³)。第 7 页两组预算给 X=r/2 和 3r²/2，计算正确。这两项是正文里最清楚的非恒定因子现象。

已检查的饱和结论：|u|≤B0 与 E[u²∣X]=B0² 推出 u=±B0 条件等概率；再结合两个处理支持点均满足 |T|≤B0，推出 π=0。于是 E[TY]=βB0²；|TY/B0²|≤1 给出 2n 样本均值的期望绝对误差上界 1/√(2n)。这个论证是正文中完成度较高的一段。显式下界常数 3/128 未核验。

未核验：四预算随机复杂度原始定义；P/O 条件观测概率的合法性及其混合距离；q/ab/M 原生族的完整构造；分支 oracle 不等式及其全 n 期望化；所有零预算与小预算拼接；表示接口的完整 Borel 实现；同对联合字典的跨 band 复杂度；Gu–Yin–Cai–Fan 原定理的全部条件及其嵌入。网络核对只支持上述两个直接前驱的有限比较，不构成原创性认证，也没有用检索未命中支持优先权。

本轮结论是：主问题和新增阶数已经可读；四预算实验的可定义性，以及新增阶数的统计证据，应当成为下一版九页正文的核心。接受与否应随后依据补出的定义、通道计算和真实前驱差异重新判断。
