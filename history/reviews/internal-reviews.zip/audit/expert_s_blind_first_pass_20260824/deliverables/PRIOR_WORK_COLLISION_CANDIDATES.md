# Prior-work collision candidates

## Collision conclusion

No **DIRECT COLLISION** with the complete `q+AB+M+O+P` outer minimax theorem was found in the searched public record through 2026-08-24. Two works create **STRONG OVERLAP at the component level**:

1. Gu–Yin–Cai–Fan Theorem A.1 already gives the inherited `q+AB+M` four-budget lower envelope.
2. Solo Gu's TAME paper already gives the two calibration/editing branches and their two-learner upper algebra.

Because neither source supplies separate matching O/P lower certificates under the manuscript's full public interface, each is **PARTIAL OVERLAP for the paper as a whole**, not a full collision. The novelty conclusion remains conditional: search incompleteness, recent 2026 indexing, and nonpublic concurrent work prevent an absence proof.

## Candidate classification

| Candidate | Same model? | Same estimand/loss? | Same rate/theorem? | Earliest public date | Classification | Reason |
|---|---|---|---|---|---|---|
| Gu, Yin, Cai & Fan, arXiv:2606.06368, Theorem A.1 | Closely related outer public-class PLM; different covariate law, envelopes, and access formalization. | Yes, PLM coefficient and expected absolute error. | Contains `q+AB+M`, not O/P in the displayed lower theorem. | 2026-06-04 | STRONG OVERLAP for inherited lower; PARTIAL OVERLAP overall | Three of five lower mechanisms/rate blocks already explicit. |
| Gu, arXiv:2607.21541, TAME | Closely related two-learner PLM; different theorem conditions/interface. | Yes. | Contains two upper branches matching the manuscript's `T_mu,T_pi`; no full O/P lower theorem. | 2026-07-23 | STRONG OVERLAP for upper; PARTIAL OVERLAP overall | Generic editor/branch idea is prior; manuscript adds Borel/boundary closure and lower matching. |
| Gu, COLT 2025 open problem | Same target problem at problem-statement level. | Yes. | Poses rather than solves the four-budget problem. | 2025 proceedings | CONTEXTUAL | Confirms importance and that the problem predates this paper. |
| Balakrishnan, Kennedy & Wasserman, arXiv:2305.04116 | Broader structure-agnostic nonlinear functional framework, not exact PLM/public interface. | Related functional risk. | Product/fuzzy lower mechanisms, not the full directional rate. | 2023-05-06 | PARTIAL OVERLAP | Methodological and inherited product component. |
| Jin & Syrgkanis, arXiv:2512.17341 | General linear-functional structure-agnostic lower bounds. | Related; theorem field broader/different. | No located exact O/P four-budget PLM theorem. | 2025-12-19 | PARTIAL OVERLAP | Relevant lower-bound framework, no exact rate collision located. |
| Jin, Mackey & Syrgkanis, arXiv:2507.02275 | Structure-agnostic estimation with noise-law focus. | Related. | Different noise phenomenon and theorem field. | 2025-07-03 | CONTEXTUAL | Does not eliminate the O/P increment. |
| Robins et al. (2009) | Semiparametric nonlinear functionals, missingness/covariance examples. | Related methodology. | Two-mixture affinity theorem, no four-budget PLM phase diagram. | 2009-12-04 publication | CONTEXTUAL | Source of fuzzy/two-mixture method, not the conclusion. |
| Robinson (1988) | Classical partially-linear regression. | Same coefficient family. | Root-`n` semiparametric result under classical smoothness, not public four-budget minimax. | 1988 | FALSE LEAD for collision / CONTEXTUAL background | Surface model match but different question. |

## Strong-overlap comparison 1 — Gu et al. A.1

| Dimension | Gu et al. A.1 | Manuscript | Collision effect |
|---|---|---|---|
| Outer order | `sup_{F_mu,F_pi} inf_est sup_P`. | `sup_Gamma inf_{delta_Gamma} sup_P`. | Essentially same public-pair order. |
| Public information | Classes and black-box learners tailored to them; budgets known. | Countably represented classes, budgets/rho known. | Manuscript formalizes access more sharply. |
| Statistical restrictions | `X~nu_d`, bounded `T,Y,beta,v`, exact constant `v>=1/3`. | General `P_X`, broader shared envelopes, `v in [v_-,v_+]`. | Not literal containment either way. |
| Lower rate | `q+[a+s^2][b+t^2]+(s wedge t)^2`. | Same plus `O+P`. | Strong overlap covers the inherited base only. |
| Directional O/P lower | Absent from displayed Theorem A.1. | Separate finite witnesses. | Preserves plausible main increment. |
| Boundary E/I/S | Not the displayed theorem's contribution. | Separate envelope phase split. | Additional but narrow/artifactual. |

Stable source: [arXiv:2606.06368](https://arxiv.org/abs/2606.06368).

## Strong-overlap comparison 2 — TAME

| Dimension | Solo Gu TAME | Manuscript | Collision effect |
|---|---|---|---|
| Algorithmic idea | Transductive editing plus adversarial moment calibration; O and R branches. | Same architecture, explicitly called TAME-derived. | Generic upper technique is not new. |
| Two-learner upper algebra | Cor. 3.2 gives `[a(b+t)+(a+s)^2] wedge [b(a+s)+(b+t)^2]`. | Defines the same two branch quantities and selects by public orientation. | Strong theorem-level upper overlap. |
| Conditions | High-probability oracle result with small/consistent nuisance conditions and remainders. | Expected-risk all-budget closure with clipping/fallback. | Manuscript contributes technical interface coverage. |
| Measurability | Does not provide the same full M1 countable-Borel dossier. | First-within-tolerance enumeration/rational parameterization. | Incremental formal closure. |
| Lower characterization | Three-budget Proposition 2.3 and other lower context; no full matching O/P theorem. | Five mechanisms and outer assembly. | Main lower increment remains. |

Stable source: [arXiv:2607.21541](https://arxiv.org/abs/2607.21541).

## Candidate exclusion principles

- A paper was not called a collision merely because it uses a PLM, orthogonal score, or product remainder.
- Method overlap was separated from theorem overlap: standard Le Cam/fuzzy testing lowers technical novelty but does not erase a new sharp rate.
- Later/concurrent work was not used retroactively. All strongest overlaps above were public before the supplied manuscript's 2026-08-24 PDF date.
- Search-result snippets were used only to locate sources; classifications rely on supplied or opened primary PDFs and official metadata.

## Confidence

**MEDIUM.** Exact-title and theorem-structure searches found no full collision, and the closest primary papers were read. Confidence is not high because the paper and nearest works are only weeks old, citation graphs may not yet be indexed, and nonpublic ICLR 2027 submissions are outside the permitted evidence base.

