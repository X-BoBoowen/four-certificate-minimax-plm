# Auditor S — source, attribution, and model-scope form

Name: Expert S (AI-assisted independent model, literature and novelty audit)  
Institution/affiliation: N/A—AI reviewer; no human institution or affiliation claimed  
Relevant expertise: semiparametric estimation, orthogonal/debiased learning, nuisance estimation, minimax lower bounds, empirical processes, statistical learning theory, and primary-source attribution  
Date audit began: 2026-08-24 (Asia/Shanghai)  
Date audit completed: 2026-08-24 14:09:49 +08:00 (China Standard Time / Asia/Shanghai)  

## Scope covered

- [x] Primary-source field verification
- [x] BBM Theorem 2.1 transfer
- [x] Public-class and M1/Q1 model description
- [x] Closest-work comparison
- [x] Novelty/significance language
- [x] Citation completeness and attribution
- [x] Collision search methodology and limits

## Overall determination

- [ ] PASS
- [ ] FAIL
- [x] NEEDS CLARIFICATION

Material findings and exact locators:

1. **FAIL, repairable:** the root-`n` lower witness can leave the stated target space. Appendix C.3, manuscript PDF p. 17, (C.8), takes `d_rho=min{B_0/16,B_0/(16 sqrt(v_0))}` and `theta_omega=omega d_rho/sqrt(n)`. For legal `B_0>48`, `v_0=1`, `n=1`, this gives `|beta|>3`, contradicting Appendix A (p. 10) and the projection argument (p. 26), which require `beta_0 in [-3,3]`. Cap `d_rho` by a fixed value at most 3. This changes constants, not the rate.
2. **Conditional pass:** Appendix A, p. 10, defines the localized condition with `sup_{r>=s} R(r)/(3r)` while allowing `s=0`; the `r=0` term is `0/0`. State `r>0` or define the quotient at zero. This affects formal model definition but not the proved rate after repair.
3. **Conditional pass:** M1 and Q1 are described as an access convention and an outer minimax order rather than numbered statistical models; the covariate measurable space is not declared. Public classes may depend on `n` through `R_n` and through lower-bound dictionaries, although this dependence is implicit. See Appendix A, p. 10, and Section 2, pp. 2–3.
4. **Pass with positioning caveat:** the Q1 order `sup_Gamma inf_delta sup_P` is preserved. It grants every learner the full represented public pair and declared budgets before `P` is chosen; it is not the common-estimator risk `inf_delta sup_Gamma sup_P` and is more information-rich than an adaptive/computational formulation.
5. **PASS:** the BBM Theorem 2.1 transfer in Lemma 4, p. 11, has correct coefficients after setting `[a,b]=[-B,B]`, `r=sigma^2`, `x=z`, `alpha=1` and adjoining negatives. The paper's `2e^{-z}` failure probability is conservative relative to the source's `e^{-z}`.
6. **Attribution:** Gu–Yin–Cai–Fan Theorem A.1 already contains the inherited lower envelope `q+AB+(s wedge t)^2`; solo Gu's TAME theorem already supplies the two upper calibration branches. The paper properly signals both sources, but `ab`, `M`, and the generic upper architecture are adaptations rather than new conclusions. The strongest plausible new part is the pair of matching directional lower certificates `O` and `P` and their assembly in the frozen Q1 model.
7. No earlier exact collision for the full `q+AB+M+O+P` theorem was located in the recorded search. Because very recent literature and non-indexed material may be missing, this supports only a conditional novelty conclusion.
8. Independent ICLR-level significance conclusion: **BORDERLINE**. The directional lower bounds are technically substantive and answer a published four-budget open problem, but breadth and practical meaning are limited by known budgets, a fully public represented class, constant variance, arbitrary Borel estimators, `n`-dependent hard dictionaries, and a saturation boundary driven by a shared envelope.

Unresolved questions:

- The manuscript's actual ICLR submission time is unavailable; the PDF says “under review at ICLR 2027,” but its metadata date precedes the public paper deadline. Novelty is therefore dated conditionally to 2026-08-24.
- Whether an unindexed or concurrent paper already proves the same two directional lower mechanisms could not be established conclusively.
- A fully independent line-by-line verification of every appendix constant was outside this S-audit; the identified model-membership counterexample is exact, while the remainder of the proof was audited at the model/attribution/interface level.

Limits of this review:

Public web search, arXiv, PMLR, publisher/official pages, Crossref metadata, and supplied primary PDFs were used. Google Scholar's complete citation graph, subscription databases, nonpublic submissions, and possibly later 2026 indexing were unavailable. “No collision found” is not a proof of absence.

Typed name: Expert S (AI-assisted independent model, literature and novelty audit)  
Signature: /s/ Expert S — AI reviewer; not a human signature  
Date: 2026-08-24 14:09:49 +08:00 (China Standard Time / Asia/Shanghai)  
