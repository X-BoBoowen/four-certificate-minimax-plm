# Auditor credential and scope record

Auditor name: Expert S (AI-assisted independent model, literature and novelty audit)  
Role requested: [ ] Auditor M  [x] Auditor S  [ ] Both roles  
Institution/affiliation: N/A—AI reviewer; no human institution or affiliation claimed  
Position or professional status: Codex AI assistant, GPT-5-based; exact deployment version not provided by the system  

Relevant training and experience:

Capability scope used in this audit: formal reconstruction of statistical experiments and quantifiers; semiparametric identification and orthogonality analysis; nonasymptotic minimax and testing reductions; empirical-process inequalities; primary-source/metadata cross-checking; and conference-level novelty/significance assessment. No human degree, appointment, publication record, or prior reviewing service is claimed.

Experience with empirical processes / learning theory:

Applied knowledge of symmetrization, localized Rademacher complexity, Bernstein-style supremum bounds, measurable countable representations, sample splitting, and selector measurability. The BBM transfer was recomputed field by field from Theorem 2.1.

Experience with minimax lower bounds / information theory:

Applied knowledge of Le Cam and fuzzy-hypothesis testing, mixture affinity/chi-square controls, hypercube and finite-dictionary constructions, minimax quantifier order, submodel lower bounds, and max-to-sum assembly.

Experience with semiparametric or causal estimation:

Applied knowledge of partially linear models, nuisance-product remainders, orthogonal/debiased scores, cross-fitting, constant conditional residual variance, identification, and the distinction between a statistical PLM coefficient and a causal estimand. This manuscript does not formally posit potential outcomes, so no causal identification was imputed.

Experience with primary-source and attribution audits:

The supplied primary PDFs, publisher/official pages, Crossref records, arXiv version pages, and PMLR proceedings were checked. Claim–source mappings were reconstructed for BBM, Gu et al., TAME, and every bibliography entry at the level relevant to the manuscript's claims.

Agreed packet scope:

H1 (model, M1/Q1 interface, and main-theorem quantifiers), H2 (BBM transfer), the full anonymous manuscript and appendices, all supplied bibliography/source files, fixed-variance and public-information audits, `ab`/`M` attribution, open prior-work collision search, novelty, and ICLR relevance.

If one person covers both M and S, explain why both competency sets are covered:

N/A—only Auditor S scope is claimed. Mathematical spot checks were performed solely insofar as model membership, theorem quantifiers, source transfer, and attribution required them.

Auditor confirmation: I confirm the scope and capability boundaries above and do not represent this AI audit as a human professional credential.  
Date: 2026-08-24 14:09:49 +08:00 (China Standard Time / Asia/Shanghai)  
