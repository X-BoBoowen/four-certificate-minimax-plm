# Actual local-file and external-source log

## Isolation record

The ZIP central directory was inspected before extraction. File names were classified from the directory structure and README. No entry named or described as an answer, solution, internal audit, completed audit, reference report, or other review was opened. After the README confirmed the two assigned packets and source directory were first-pass materials, only the listed permitted files were used. The input ZIP and anonymous manuscript were not modified.

All extracted packet files were checked against `MANIFEST.tsv`; their SHA-256 values matched the manifest.

## Local files actually read

Base directory: `audit/expert_s_blind_first_pass_20260824/`.

| File | Scope read | Evidentiary use |
|---|---|---|
| `README.md` | Complete | Routing, allowed/prohibited material, derivative status. |
| `MANIFEST.tsv` | Complete | File inventory and hash verification. |
| `PROVENANCE.tsv` | Complete | Source-to-derivative provenance. |
| `REPLACEMENTS.tsv` | Complete | Confirmed no scientific-content replacement entries. |
| `guides/AUDIT_INSTRUCTIONS.md` | Complete | First-pass audit procedure; treated as workflow guidance, not scientific evidence. |
| `guides/DEFINITIONS_AND_SYMBOLS.md` | Complete | Navigation only; every substantive claim was rechecked in the manuscript. |
| `forms/AUDITOR_S_FORM.md` | Complete, blank original | Required template. |
| `forms/AUDITOR_CREDENTIAL_SCOPE.md` | Complete, blank original | Required template. |
| `forms/INDEPENDENCE_AND_CONFLICT_FORM.md` | Complete, blank original | Required template. |
| `packets/H1_MODEL_M1_Q1_MAIN.md` | Complete | Assigned checklist, read after README permission. |
| `packets/H2_BBM_TRANSFER.md` | Complete | Assigned checklist, read after README permission. |
| `manuscript/anonymous_manuscript.pdf` | All 28 pages, text and rendered-page inspection | Primary manuscript/model/proof/attribution evidence. |
| `sources/bartlett_bousquet_mendelson_author_version.pdf` | Bibliographic front matter and Theorem 2.1, source PDF pp. 6–7 | BBM constant/probability transfer. |
| `sources/gu_yin_cai_fan_2606.06368.pdf` | Abstract/model plus Appendix A.1, Theorem A.1, source PDF pp. 19–20 | Closest inherited four-budget lower envelope. |
| `sources/gu_blackbox_2607.21541.pdf` | Abstract; Prop. 2.3; Sections 3.1–3.3; Algorithm 1; Thm. 3.1; Cor. 3.2, source PDF pp. 12–16 | TAME attribution and upper overlap. |
| `sources/gu_colt_2025.pdf` | Complete short open-problem paper | Problem priority and importance. |
| `sources/balakrishnan_kennedy_wasserman_2305.04116.pdf` | Front matter, abstract/introduction, relevant lower-bound overview | Collision/method lineage. |
| `sources/chernozhukov_et_al_2018_author.pdf` | Front matter, abstract/theorem overview | DML/background role. |
| `sources/foster_syrgkanis_orthogonal_arxiv.pdf` | Front matter, abstract/theorem overview | Orthogonal-learning background. |
| `sources/jin_mackey_syrgkanis_2507.02275.pdf` | Front matter, abstract/contribution overview | Noise-law collision screening. |
| `sources/jin_syrgkanis_2402.14264.pdf` | Front matter, abstract/contribution overview | PLM/structure-agnostic lineage. |
| `sources/jin_syrgkanis_2512.17341.pdf` | Front matter, abstract/theorem overview | General lower-bound collision screening. |
| `sources/crossref_bartlett_2005.json` | Complete | DOI/title/authors/journal fields. |
| `sources/crossref_chernozhukov_2018.json` | Complete | DOI/title/authors/journal fields. |
| `sources/crossref_foster_syrgkanis_2023.json` | Complete | DOI/title/authors/journal fields. |
| `sources/crossref_robins_2009.json` | Complete | DOI/title/authors/journal fields. |
| `sources/crossref_robinson_1988.json` | Complete | DOI/title/authors/journal fields. |
| `sources/robins_et_al_2009_oa_manifest.xml` | Complete metadata manifest | Open-access identity/provenance lead. |
| `tmp/pdfs/robins_2009_publisher.pdf` | Abstract/introduction, Theorem 2.1, applications, proof/theorem context, testing appendix | Primary verification of fuzzy/two-mixture attribution. Downloaded from the VU publisher-version endpoint during audit. |

Temporary manuscript page renders and contact sheets were visually inspected for all pages but are not scientific sources and are not included in final deliverables.

## External sources actually opened or queried

| Source | URL | Use |
|---|---|---|
| ICLR 2027 Reviewer Guidelines | https://iclr.cc/Conferences/2027/ReviewerGuidelines | Conference evaluation criteria. |
| ICLR 2027 Author Guidelines | https://iclr.cc/Conferences/2027/AuthorGuidelines | Submission calendar/time boundary. |
| ICLR 2027 AI Policy for Authors | https://iclr.cc/Conferences/2027/AIPolicyForAuthors | Context for the manuscript's AI disclosure; not used to judge theorem novelty. |
| Gu open problem, PMLR | https://proceedings.mlr.press/v291/gu25b.html | Official proceedings metadata/content. |
| arXiv 2305.04116 | https://arxiv.org/abs/2305.04116 | Version history/primary record. |
| arXiv 2402.14264 | https://arxiv.org/abs/2402.14264 | Version history/primary record. |
| arXiv 2507.02275 | https://arxiv.org/abs/2507.02275 | Version history/primary record. |
| arXiv 2512.17341 | https://arxiv.org/abs/2512.17341 | Version history/primary record. |
| arXiv 2606.06368 | https://arxiv.org/abs/2606.06368 | Gu et al. v1 date and primary record. |
| arXiv 2607.21541 | https://arxiv.org/abs/2607.21541 | TAME v1 date and primary record. |
| BBM DOI | https://doi.org/10.1214/009053605000000282 | Stable publication identity. |
| DML publisher page | https://academic.oup.com/ectj/article/21/1/C1/5056401 | Official publication identity. |
| Robins et al. DOI | https://doi.org/10.1214/09-EJS479 | Stable publication identity. |
| Robins et al. publisher-version PDF | https://research.vu.nl/ws/portalfiles/portal/2540546/230873.pdf | Primary full text. |
| Robinson JSTOR record | https://www.jstor.org/stable/1912705 | Stable publication identity. |
| Robinson issue record | https://www.jstor.org/stable/i332734 | Volume/issue/page verification. |

## Files deliberately not read

No prohibited file was present in the handoff ZIP under a suspicious answer/solution/internal-audit/reviewer-report name. Material elsewhere in the broader repository—including other audit stages, completed forms, reviewer opinions, staging folders, and internal reports—was not opened or used. Directory names seen incidentally while resolving the workspace were not treated as evidence.

