# M1/Q1 model cards and relation

## Executive finding

The paper does not define two distinct data-generating models called M1 and Q1. Reconstructed from Section 2 (PDF pp. 2–3) and Appendix A (p. 10), **M1 is a represented public-class/access convention for a fixed public pair**, while **Q1 is an outer minimax functional over M1-admissible pairs**. Their relation is therefore functional, not a reduction or equivalence between two observational experiments:

```text
fixed rho, n, budgets
        |
        v
represented nonempty public pair Gamma_n = (G_mu,n, G_pi,n)  [M1 access]
        |
        +--> compatible PLM laws P_rho(Gamma_n; budgets)
        |           |
        |           v
        +--> Gamma-specific Borel decision rules delta_Gamma
                    |
                    v
sup_Gamma inf_delta_Gamma sup_P E_P |delta_Gamma - beta(P)|  [Q1 risk]
```

The notation should be upgraded to numbered definitions, including the measurable covariate space and explicit `n`-dependence.

## M1 model card — represented public-pair PLM access

| Field | Independent reconstruction | Locator / finding |
|---|---|---|
| Observed unit | `Z=(X,T,Y)`; only these variables are observed. | PLM equation (1), PDF p. 2; Appendix A, p. 10. |
| Sample | `2n` i.i.d. copies split into two independent halves of size `n`. | Section 2, p. 2; Appendix A, p. 10. |
| Sample space | Formally should be `(mathcal X x [-B_0,B_0]^2, mathcal A tensor B^2)`. The paper never declares `(mathcal X,mathcal A)`. | First under-specification: equation (1), p. 2; full boundedness restatement, p. 10. |
| Latent/derived variables | `u=T-pi_0(X)` and `epsilon=Y-beta_0 T-mu_0(X)`. These are residuals, not potential outcomes. | Equation (1), p. 2. |
| Factorization | `P_X(dx) P_{T given X}(dt given x) P_{Y given X,T}(dy given x,t)` subject to the displayed conditional moments. No stronger factorization is stated. | Eq. (1), p. 2. |
| Conditional restrictions | `E[u given X]=0`, `E[epsilon given X,T]=0`, and `E[u^2 given X]=v` a.s. for one constant `v in [v_-,v_+]`. | Eq. (1), p. 2; Appendix A, p. 10. |
| Independence | Units are i.i.d.; the sample halves are independent after splitting. No `u independent epsilon`, `u independent X`, or homoskedastic outcome-noise assumption is made. | Sections 2–3 and Appendix B. |
| Bounds | Wherever present, `abs(Y),abs(T),abs(beta_0),abs(mu_0(X)),abs(pi_0(X)),abs(u),abs(epsilon)<=B_0`, with the target additionally treated as `beta_0 in [-3,3]`. | Appendix A, p. 10; projection argument p. 26. The duplicate `abs(beta_0)<=B_0` is compatible because `B_0>=3`. |
| Target | The statistical partially-linear coefficient `beta(P)=beta_0`, under absolute-error loss. | Eq. (4), p. 2. No causal potential-outcome estimand is defined. |
| Nuisances | `mu_0:mathcal X->R`, `pi_0:mathcal X->R`, plus the unrestricted law of `X` and residual distributions satisfying the moments/bounds. | Eq. (1), p. 2. |
| Public function classes | `Gamma=(G_mu,G_pi)`, each supplied through a countable pointwise-dense Borel representation used for measurable near-minimization. | Section 2, p. 2; Appendix A, p. 10; Section 6, p. 6. |
| Approximation budgets | `inf_{g in G_mu} norm(g-mu_0)_2<=a` and `inf_{g in G_pi} norm(g-pi_0)_2<=b`. | Eq. (2), p. 2. |
| Stochastic budgets | Localized Rademacher conditions at scales `s,t` with fixed constant `c_rad`; the conditions use `R_n` and hence depend on `n`. | Eq. (3) and Appendix A, p. 10. The `s=0,r=0` quotient is undefined as written. |
| Known to estimator | `Gamma` including its representation, `rho=(B_0,v_-,v_+,c_rad)`, `n`, and declared `(a,s,b,t)`, plus the observed sample. | Section 2, pp. 2–3; Appendix A, p. 10. |
| Unknown to estimator | `P`, `beta_0`, nuisance truths, constant `v`, best approximants, residuals, and the adversary's lower-bound mixing index. | Section 2, p. 2. |
| Asymptotic/nonasymptotic parameters | Theorem is nonasymptotic for every `n>=1`; total sample `N=2n`; all budgets lie in `[0,1]`; constants depend only on fixed `rho`. | Theorem 1, pp. 2–3. |
| Does the model depend on `n`? | Yes. Class admissibility is stated through `R_n`, and lower witnesses use dictionaries whose cardinalities depend on `n` and budgets. It is best written `Gamma_n` and `P_{rho,n}`. | Appendix A, p. 10; finite dictionaries in Appendices C–F. |
| Loss/risk for a fixed pair | `inf_{delta_Gamma Borel} sup_{P compatible with Gamma} E_P abs(delta_Gamma-beta(P))`. | Inner part of Eq. (4), p. 2. |
| Nonemptiness | The outer domain retains only represented pairs with a nonempty compatible law class. Singleton and finite-dictionary examples show existence. | Section 2, p. 2; Appendix constructions. |

### M1 statistical reasonableness

- Identification is statistical, not causal. Since `E[u^2]=v>=v_->0`, the partially-linear coefficient is identified from conditional treatment variation. Positivity, SUTVA, and no-unmeasured-confounding are not needed for this coefficient; they would be needed only for an unstated causal interpretation.
- The upper construction uses honest sample splitting; it does not reuse observations to fit and score on the same half. Thus neither cross-fitting nor Donsker assumptions are silently required for the announced nonasymptotic bound.
- The public representation is substantive oracle information: it supplies a search space, enumeration, complexity budgets, and approximation budgets. This makes the result a structure-agnostic **conditional-on-public-interface** theorem, not adaptation to unknown structure.
- Constant conditional treatment-residual variance is a model restriction. It is not a harmless normalization; see `FIXED_VARIANCE_AUDIT.md`.

## Q1 model card — outer public-pair minimax problem

| Field | Independent reconstruction | Locator / finding |
|---|---|---|
| Statistical data/model | Same observations and compatible laws as M1; Q1 introduces no new random variables. | Eq. (4), p. 2. |
| Outer domain | All nonempty represented public pairs satisfying the four declared budgets for fixed `rho,n`. | Section 2, p. 2; Appendix A. |
| Decision class | For each public pair separately, all Borel maps of the two half-samples and the allowed public information. | Eq. (4), p. 2. |
| Criterion | `R_{rho,n}(a,s,b,t)=sup_Gamma inf_delta_Gamma sup_{P in P_{rho,n}(Gamma;a,s,b,t)} E_P abs(delta_Gamma-beta(P))`. | Eq. (4), p. 2. |
| Information order | `Gamma,rho,n,budgets` are public before the rule is selected; the rule is fixed before the unknown `P`; data are then generated and passed to the rule. | Formal consequence of Eq. (4), not fully narrated in the manuscript. |
| Main theorem | In the interior `0<v_-<B_0^2`, `R` is comparable to `q+AB+M+O+P`; above saturation the model is empty; at saturation the outer risk is root-`n`. | Theorem 1, pp. 2–3. |
| Pairwise vs outer | Upper bounds are uniform for each fixed pair. Lower bounds need only exhibit one hard pair per mechanism, possibly different pairs. No pairwise lower theorem is claimed. | Proposition 2, p. 4; Section 5 and Appendix G, pp. 25–26. |
| Alternative not proved | `inf_delta sup_Gamma sup_P`, where one estimator must work without knowing `Gamma`, and any computationally constrained/adaptive problem. | Explicitly excluded in Introduction p. 1 and Section 6 p. 6. |

## Relation audit

| Preservation question | Verdict | Reason |
|---|---|---|
| Observable distribution preserved? | PASS | Q1 uses the same M1-compatible law; no synthetic observation is added. |
| Parameter-space membership preserved? | CONDITIONAL PASS | Yes after making the measurable covariate space, `n`-dependence, and zero-radius convention explicit. The (C.8) `q` witness itself violates the target range for some legal inputs. |
| Estimand/loss/risk preserved? | PASS | The target remains `beta(P)` and the loss remains expected absolute error. |
| Nuisance/public conditions preserved? | PASS | The outer domain is explicitly the set of nonempty public pairs satisfying the same budgets. |
| Extra information added? | YES, by design | Q1 gives the estimator the entire represented pair and the exact four budgets. This is public oracle structure, not data-derived adaptation. |
| One-way containment used as equivalence? | PASS | No M1–Q1 equivalence is needed; the paper should simply avoid model-language suggesting one. |
| Quantifier order changed? | PASS | No hidden exchange was found. The outer lower assembly correctly exploits `sup_Gamma`. |

## Formal repairs

1. Declare a measurable covariate space `(mathcal X,mathcal A)`, the product observation space, and joint evaluation measurability of the represented functions.
2. Name the fixed-pair experiment **M1** and the outer functional **Q1** in numbered definitions.
3. Write the admissible public domain as `mathfrak G_{rho,n}(a,s,b,t)` and state explicitly that triangular arrays `Gamma_n` are allowed.
4. Replace `sup_{r>=s} R(r)/(3r)` by `sup_{r>=s, r>0} R(r)/(3r)` (or define its zero extension).
5. Cap the Appendix C.3 constant by 3 (preferably by a smaller fixed interior value) so every root-`n` hard law has `beta in [-3,3]` for all legal `n,rho`.
