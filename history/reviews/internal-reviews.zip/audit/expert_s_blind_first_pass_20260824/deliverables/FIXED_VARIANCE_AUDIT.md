# Fixed-variance audit

## Finding

The model assumes an **unknown but covariate-invariant conditional treatment-residual variance**:

`E[u^2 | X] = v` almost surely for a scalar `v in [v_-,v_+]`.

The learner knows the interval endpoints, not `v`. This restriction belongs to the model definition (Eq. (1), PDF p. 2; Appendix A, p. 10), not merely to a proof. Upper and lower statements are compared in this same model: lower bounds may validly fix `v=v_-` as a submodel.

## Checklist

| Audit question | Answer | Verdict / locator |
|---|---|---|
| Known or unknown variance? | `v` is unknown; `[v_-,v_+]` is known. | PASS, pp. 2 and 10. |
| Fixed constant or just bounded? | Exactly constant in `X`, with fixed known bounds. | PASS. |
| May it vary with `x,n,d`, or nuisance? | Not with `x`; the theorem fixes `rho`, while lower constructions can choose a scalar allowed by `rho`. | PASS, but generality is limited. |
| Is homoskedasticity only temporary? | No; it defines every compatible law. | PASS. |
| Is an upper theorem silently extended to heteroskedasticity? | No explicit heteroskedastic claim was found. | PASS. |
| Does the lower construction satisfy exact variance? | The three-point channels in Appendix C are designed to preserve it exactly; O/P/`ab`/`M` constructions inherit that channel. | PASS at the model-interface level. |
| Is a fixed-variance submodel used for a larger-model lower bound? | The theorem itself is fixed-variance, so no invalid enlargement occurs. | PASS. |
| Same variance model for upper and lower? | Yes. | PASS. |
| Does fixing variance reduce difficulty? | Yes: it removes heteroskedastic weighting/estimation and enables exact finite-channel witnesses. | MAJOR significance qualification. |
| Is known variance exploited? | The exact scalar is not known, but its bounds and constancy are exploited; the paper should distinguish this from known-`v`. | CONDITIONAL PASS in positioning. |

## Why “set `v=1` WLOG” would be false

The manuscript does not make that assertion; independently, it would not be harmless. If one rescales treatment by

`T'=T/sqrt(v)`, `u'=u/sqrt(v)`, `pi'_0=pi_0/sqrt(v)`,

then `E[(u')^2|X]=1`, but

`Y = (beta_0 sqrt(v)) T' + mu_0(X) + epsilon`.

Thus the new target is `beta'_0=beta_0 sqrt(v)`, absolute-error loss rescales, treatment/nuisance envelopes change, and the `b,t` budgets scale by `1/sqrt(v)`. If `Y` is also rescaled, the outcome envelope, `a,s`, and residual distribution change. Therefore normalization changes the estimand, loss, parameter space, and rate expression unless a complete equivariance theorem is supplied.

## Boundary regimes

- If `v_->B_0^2`, boundedness `|u|<=B_0` makes the model empty. This is correct.
- If `v_-=B_0^2`, equality forces `|u|=B_0` a.s. Conditional mean zero forces a symmetric two-point residual conditional on `X`; together with `|T|<=B_0`, this forces `pi_0=0`. The root-`n` estimator follows. This is correct but is an artifact of using the same hard envelope for both `u` and `T`.
- In the strict interior, the margin `m_rho` used in exact channels is positive. Constants can deteriorate as `v_-` approaches the boundary, so no uniform passage to saturation is justified or claimed.

## Prior-work comparison

Gu–Yin–Cai–Fan's Appendix A also assumes constant `E[u^2|X]` (with a different numerical normalization and envelopes). Hence exact-variance preservation is a legitimate technical aspect of this manuscript's constructions, but constant variance is not itself a new model idea. A safe novelty statement is that the manuscript builds finite lower witnesses that preserve its **particular** bounded exact-variance interface.

## Overall verdict

**PASS for internal fixed-variance logic; CONDITIONAL PASS for contribution positioning.** Severity of the positioning limitation: **MAJOR**. Confidence: **HIGH**. Evidence: **PRIMARY VERIFIED**.

