# BBM, Gu et al., and TAME citation verification

## Summary verdicts

| Citation | Manuscript claim | Verdict | Severity | Confidence | Evidence |
|---|---|---|---|---|---|
| Bartlett–Bousquet–Mendelson (BBM) | Theorem 2.1 yields Lemma 4's two-sided expected-Rademacher deviation bound with the displayed constants. | PASS | MINOR | HIGH | PRIMARY VERIFIED |
| Gu–Yin–Cai–Fan | The closest inherited four-budget lower envelope is `q+AB+M`. | CONDITIONAL PASS | MAJOR | HIGH | PRIMARY VERIFIED |
| Gu, TAME | The editing objectives and two upper branches are inherited; this paper contributes a measurable Q1/M1 interface closure rather than a new generic editor. | PASS | MAJOR | HIGH | PRIMARY VERIFIED |

The condition on Gu et al. is not a rate disagreement: Theorem A.1 does contain the stated algebra. The condition is that its model is similar but not identical, so “inherited” requires an explicit model/notation map rather than citation alone.

## Bibliographic identity and versions

| Short name | Verified source identity | Version/theorem used | Stable source |
|---|---|---|---|
| BBM | Peter L. Bartlett, Olivier Bousquet, and Shahar Mendelson, “Local Rademacher Complexities,” *The Annals of Statistics* 33(4):1497–1537 (2005), DOI `10.1214/009053605000000282`. | Supplied author version dated 14 May 2004, Theorem 2.1, source PDF pp. 6–7 / journal pp. 1503–1504. | [DOI](https://doi.org/10.1214/009053605000000282) |
| Gu et al. | Yihong Gu, Qishuo Yin, Tianxi Cai, and Jianqing Fan, “Optimally Taming Biases in Black-Box Models for Efficient Semiparametric Estimation” (2026). | arXiv `2606.06368` v1, 4 June 2026; Appendix A.1, Theorem A.1, PDF pp. 19–20. | [arXiv record](https://arxiv.org/abs/2606.06368) |
| TAME | Yihong Gu, “Optimal Use of a Black-Box Learner in Semiparametric Estimation” (2026). | arXiv `2607.21541` v1, 23 July 2026; Algorithm 1, Theorem 3.1, Corollary 3.2, PDF pp. 13–16; Proposition 2.3, PDF p. 12. | [arXiv record](https://arxiv.org/abs/2607.21541) |

The acronym TAME belongs to the solo Gu paper: **Transductive Adversarial Moment-calibrated Editing**. The June Gu–Yin–Cai–Fan paper uses a related estimator but is not the source that formally names Algorithm 1 “TAME.” The manuscript's bibliography distinguishes them correctly.

## BBM claim–source audit

| Field | Manuscript | Primary source | Audit |
|---|---|---|---|
| Manuscript locator | Appendix B, Lemma 4, Eq. (B.2), PDF p. 11. | N/A | Directly located. |
| Source result | Theorem 2.1 for a class `F subset [a,b]` with variance at most `r`. | Same. | Accurate. |
| Probability form | Paper states failure at most `2e^{-z}`. | Source gives failure at most `e^{-x}` for the one-sided supremum. | Paper is conservative. |
| Rademacher coefficient | `4R`. | `2(1+alpha) E R_nF`; set `alpha=1`. | Exact. |
| Gaussian/Bernstein term | `sqrt(2 sigma^2 z/n)`. | `sqrt(2rx/n)`; set `r=sigma^2,x=z`. | Exact. |
| Range term | `8Bz/(3n)`. | `(b-a)(1/3+1/alpha)x/n`; with `[-B,B]`, width `2B`, `alpha=1`. | Exact. |
| Absolute supremum | `sup_w abs(P_nW(w))`, with `PW=0`. | Source is one-sided `sup_f(Pf-P_nf)`. | Adjoin `-W`; one application suffices. |
| Expected vs empirical complexity | Expected over sample and signs. | The theorem field uses expected Rademacher complexity. | Match. |
| Measurability | Countable class. | Source requires measurable suprema. | Countability suffices; no hidden fixed-point condition. |
| Classification | Accurate theorem transfer. | — | **PASS.** |

## Gu et al. claim–source audit

### What the manuscript says

- Abstract/introduction, PDF p. 1: `O` and `P` exceed the closest inherited lower envelope.
- Section 6, Eq. (9), PDF p. 5: `q`, `ab`, and `M` are the other three lower mechanisms.
- Table 5, PDF p. 9: “Gu et al. A.1: `q+AB+M`.”

### What Theorem A.1 actually states

For the source's outer structure-agnostic minimax risk (A.2), with two public classes and approximation/stochastic budgets, Theorem A.1 gives

- an upper bound equal to the minimum of a one-sided tamed rate and the ordinary product/DML rate; and
- a lower bound

`n^{-1/2} + [delta_mu^appr+(delta_mu^stoc)^2][delta_pi^appr+(delta_pi^stoc)^2] + [delta_mu^stoc wedge delta_pi^stoc]^2`.

Under `a=delta_mu^appr`, `s=delta_mu^stoc`, `b=delta_pi^appr`, and `t=delta_pi^stoc`, this is exactly `q+AB+M`.

### Assumption/quantifier differences

| Field | Gu et al. A.1 | Manuscript | Consequence |
|---|---|---|---|
| Covariate law | Fixed uniform `nu_d`. | General unspecified `P_X`. | Manuscript is broader on this field. |
| Envelopes | `abs(beta),v<=3`, `abs(T),abs(Y)<=3`; exact `v>=1/3`. | General fixed `B_0`, interval `[v_-,v_+]`, and bounds also on nuisances/residuals. | Neither model is a literal superset without a map. |
| Public interface | Black-box models tailored to the public classes in an outer `sup_F inf_est sup_P`. | Countably represented public pairs, exact Borel access, declared budgets. | Similar quantifier philosophy, different access formalization. |
| Loss | Expected absolute error. | Expected absolute error. | Match. |
| Sample | `2n` observations. | `2n` observations. | Match. |
| Result type | Nonasymptotic rate comparison up to constants. | Nonasymptotic all-budget/all-`n` theorem up to `rho` constants. | Close but not identical theorem fields. |

**Verdict:** The rate attribution is accurate. It becomes a full PASS if the paper supplies a formal restriction/rescaling map showing which Gu hard submodels lie inside the new parameter space and clearly says only the **algebraic lower envelope**, not the whole theorem, is inherited. Without that map: **CONDITIONAL PASS, MAJOR**.

## TAME claim–source audit

### Manuscript claims and locators

- Abstract and contribution statement, PDF p. 1: the selector uses a “TAME-derived two-branch architecture,” and the paper does not claim a new generic editor.
- Section 3, PDF p. 3, and Section 4, PDF p. 4: the two oriented branches and public selection.
- PDF p. 4, lines 174–177: TAME supplies editing objectives and the one-sided oracle view; the claimed increment is measurable interface closure, unsafe-cell fallback, all boundaries, and Q1-compatible uniformity.
- Table 5, PDF p. 9: upper mechanism comparison.

### Source evidence

Algorithm 1 in solo Gu defines O and R editing branches. Theorem 3.1 gives branchwise oracle inequalities. Corollary 3.2 specializes to two learners and gives the nuisance remainder

`[a(b+t)+(a+s)^2] wedge [b(a+s)+(b+t)^2]`,

which is the manuscript's pair `T_mu=ay+x^2` and `T_pi=bx+y^2` after `x=a+s`, `y=b+t`.

### Differences

| Field | TAME | Manuscript's added work |
|---|---|---|
| Primary goal | Generic editing method and high-probability oracle bounds under consistency/small-error conditions. | Expected-risk fixed-pair theorem across the full budget cube. |
| Branch choice | Uses known upper error budgets to choose the easier side. | Same public orientation, made deterministic and tied explicitly to four declared budgets. |
| Measurability | Algorithmic argmins/oracle statement; not written as the manuscript's full countable Borel interface. | Countable first-within-tolerance fits, rational parameterizations, clipping, and public fallback. |
| Unsafe/boundary cells | Not the manuscript's four-cell all-budget closure. | Adds max-radius fallback and boundary bookkeeping. |
| Lower bounds | Proposition 2.3 handles a three-budget `q+ab+s^2` setting; no matching O/P four-budget theorem. | Adds separate O/P lower witnesses and full outer assembly. |

**Verdict:** The citation supports the claimed inheritance, and the manuscript's contribution statement is unusually explicit about what is not new. **PASS.** Novelty must nevertheless be credited to interface closure and new lower mechanisms, not to the generic two-branch calibration idea.

## Remaining bibliography field audit

| Reference | Metadata/result role checked | Verdict / evidence |
|---|---|---|
| Chernozhukov, Chetverikov, Demirer, Duflo, Hansen, Newey & Robins (2018), “Double/Debiased Machine Learning for Treatment and Structural Parameters,” *Econometrics Journal* 21(1):C1–C68, DOI `10.1111/ectj.12097`. | Background for orthogonal scores, sample splitting/cross-fitting, product-rate heuristics. Supplied author PDF and Crossref metadata agree. | PASS, PRIMARY + METADATA VERIFIED. [DOI](https://doi.org/10.1111/ectj.12097) |
| Foster & Syrgkanis (2023), “Orthogonal Statistical Learning,” *Annals of Statistics* 51(3):879–908, DOI `10.1214/23-AOS2258`. | Background for orthogonal learning and second-order nuisance effects. Supplied arXiv/author PDF and Crossref record agree. | PASS, PRIMARY + METADATA VERIFIED. [DOI](https://doi.org/10.1214/23-AOS2258) |
| Gu (2025), “Open Problem: Structure-Agnostic Minimax Risk for Partial Linear Model,” COLT/PMLR 291:6220–6224. | Establishes that the four-budget PLM minimax structure was publicly posed as an open problem. | PASS, PRIMARY VERIFIED. [PMLR](https://proceedings.mlr.press/v291/gu25b.html) |
| Jin & Syrgkanis (2026), “Sharp Structure-Agnostic Lower Bounds for General Linear Functional Estimation,” arXiv `2512.17341` v2. | General structure-agnostic lower-bound context, not an exact four-budget PLM theorem. | PASS as contextual citation, PRIMARY VERIFIED. [arXiv](https://arxiv.org/abs/2512.17341) |
| Jin, Mackey & Syrgkanis (2025), “It's Hard to Be Normal: The Impact of Noise on Structure-Agnostic Estimation,” arXiv `2507.02275` v3; NeurIPS 2025. | Noise-law/lower-bound context; not a directional O/P collision. | PASS as contextual citation, PRIMARY VERIFIED. [arXiv](https://arxiv.org/abs/2507.02275) |
| Robins, Tchetgen Tchetgen, Li & van der Vaart (2009), “Semiparametric Minimax Rates,” *Electronic Journal of Statistics* 3:1305–1321, DOI `10.1214/09-EJS479`. | Supports two-mixture/fuzzy-hypothesis lower-bound methodology for nonlinear semiparametric functionals. Theorem 2.1 bounds affinity between two mixtures; source applications concern missing response and expected conditional covariance. | PASS as methodological attribution, PRIMARY VERIFIED. [DOI](https://doi.org/10.1214/09-EJS479) |
| Robinson (1988), “Root-N-Consistent Semiparametric Regression,” *Econometrica* 56(4):931–954, DOI `10.2307/1912705`. | Classical partially-linear/root-`n` background. Crossref and JSTOR issue metadata agree. | PASS as background citation, METADATA VERIFIED. [DOI](https://doi.org/10.2307/1912705) |

No cited source was found to support a broader causal interpretation, and the manuscript does not formally make one.
