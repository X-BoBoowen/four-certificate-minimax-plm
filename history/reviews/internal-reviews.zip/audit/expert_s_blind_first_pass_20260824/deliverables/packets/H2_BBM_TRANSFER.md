# H2 — Bartlett–Bousquet–Mendelson Theorem 2.1 transfer

## Claim under audit

For a countable centered class `W` with `|W(w)|<=B` and `E W(w)^2<=sigma^2`, define `R=E_{data,epsilon} sup_w |n^{-1} sum_i epsilon_i W_i(w)|` and `Z=sup_w |P_n W(w)|`. The manuscript claims

`P{ Z > 4R + sqrt(2 sigma^2 z/n) + 8Bz/(3n) } <= 2 exp(-z)`

for the stated range of `z`, by transfer from Bartlett–Bousquet–Mendelson Theorem 2.1.

## Quantifiers, assumptions, and dependencies

- Every `n>=1`, every `z>0`, one iid sample, a countable class, uniform centering/range/variance.
- No clipping, conditioning, fixed-point equation, critical-radius assumption, or hidden lemma may enter unless explicitly justified.
- Dependency: only the cited source theorem plus enlargement of the class by negatives.

## Locations and sources

- Candidate/Master Appendix B, p. 11, Lemma 4, equation (B.2), label `lem:supremum-bernstein`.
- Source: `source_material/bartlett_bousquet_mendelson_author_version.pdf`, Theorem 2.1 (author-version PDF pp. 6–7; journal pp. 1503–1504). See the separate field dossier after first pass only after submitting an independent issue list.

## Step-by-step audit checklist

- [x] Transcribe source `[a,b]`, variance `r`, confidence `x`, tuning `alpha`, Rademacher definition, probability, and measurability conditions.
- [x] Set `[a,b]=[-B,B]`, `r=sigma^2`, `x=z`, and `alpha=1`; recompute every coefficient.
- [x] Enlarge by negatives and prove the source one-sided supremum equals the paper's absolute supremum.
- [x] Compare the source expectation with the paper's `R`, including normalization and outer expectations.
- [x] Recompute `(b-a)(1/3+1/alpha)z/n` and the Rademacher coefficient.
- [x] Check that countability supplies the source measurability requirement.
- [x] Decide whether changing failure probability from `exp(-z)` to `2exp(-z)` is conservative.
- [x] Check whether any fixed-point, clipping, conditioning, or separability assumption has been silently introduced.

## Boundary cases and likely failure points

Check `B=0`, `sigma=0`, a singleton class, `z` small/large, and a class not closed under negation before enlargement. Likely failures are a factor-of-two range error, confusion between expected and empirical Rademacher terms, or a one-sided/two-sided mismatch.

## Falsifier / exact checks

For a singleton centered Rademacher variable and for the symmetric two-function class, calculate both sides exactly or numerically at small `n`. Such checks may falsify constants but cannot establish the theorem transfer.

## Verdict table

| Source field | PASS | FAIL | NEEDS CLARIFICATION | Auditor comment |
|---|---|---|---|---|
| Function range and variance | X |  |  | Source Theorem 2.1 assumes `f in [a,b]` and `Var(f)<=r`. For the centered symmetric enlargement, `[a,b]=[-B,B]` and `r=sigma^2`. |
| Rademacher term | X |  |  | With source normalization `R_nF=sup_f n^{-1} sum epsilon_i f(X_i)`, `2(1+alpha) E R_nF` becomes `4R` at `alpha=1`; adjoining negatives makes it the paper's expected absolute supremum. |
| One-/two-sided supremum | X |  |  | Apply the source to `F union (-F)`. `sup_{g}(Pg-P_ng)=sup_f abs((P-P_n)f)`; centering gives the manuscript's `Z`. |
| Constants and probability | X |  |  | `sqrt(2rz/n)=sqrt(2 sigma^2 z/n)` and `(b-a)(1/3+1)z/n=(2B)(4/3)z/n=8Bz/(3n)`. Source probability is at least `1-e^{-z}`; the paper's `1-2e^{-z}` is weaker and hence valid. |
| Measurability and hidden conditions | X |  |  | Countability makes the suprema measurable. No fixed point, clipping, conditioning, or critical-radius assumption is used in this transfer. Degenerate `B=0` or `sigma=0` cases remain valid. |

## Auditor questions

1. **Does the theorem need a union bound for two tails?** No. Closing the class under negatives turns the absolute deviation into the source's one-sided supremum in one application. The displayed factor 2 in the failure probability is merely conservative.
2. **Is the paper using empirical rather than expected Rademacher complexity?** No. Both the source term used here and the manuscript's `R` are expectations over data and signs; the normalizations match.
3. **Any missing range factor?** No. The source uses `b-a`; the symmetric range has width `2B`, producing exactly `8B/3` at `alpha=1`.
