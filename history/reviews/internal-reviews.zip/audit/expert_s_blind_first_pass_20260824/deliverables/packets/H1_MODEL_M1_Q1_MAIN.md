# H1 — Model, M1/Q1 interface, and main-theorem quantifiers

## Claim under audit

For every fixed `rho=(B_0,v_-,v_+,c_rad)`, the paper defines legal nonempty public pairs `Gamma`, compatible PLM laws, and the Q1 risk `sup_Gamma inf_{delta_Gamma Borel} sup_P E|delta_Gamma-beta(P)|`. It claims: emptiness if `v_->B_0^2`; a two-sided rate `q+AB+M+O+P` for all `n>=1` and all budgets in the strict interior `0<v_-<B_0^2`; and a root-`n` outer minimax law at exact saturation `v_-=B_0^2`.

## Quantifiers, assumptions, and dependencies

- Fix `B_0>=3`, `0<v_-<=v_+`, and `c_rad`; constants may depend on this fixed tuple only.
- For each budget tuple in `[0,1]^4`, the outer supremum ranges only over nonempty represented public pairs.
- The estimator may use data, the pair, fixed regularity constants, and declared budgets, but not `P`, nuisance truths, best approximants, or realized errors.
- Dependencies: bounded PLM, constant conditional treatment-residual variance, countable representation, component upper and lower certificates, and the boundary support argument.

## Locations and sources

- Anonymous Candidate and technical Master: pp. 2–3, equations (2)–(5), Theorem 1; Appendix A, p. 10.
- Labels: `eq:plm`, `eq:approx`, `eq:risk`, `eq:terms`, `thm:main`, `app:model`.
- External context: primary works in `source_material/`; no external theorem is asserted to supply the full result.

## Step-by-step audit checklist

- [x] Verify every bounded variable and residual is defined where used, with no inconsistent envelope.
- [x] Verify the localized-complexity condition is meaningful at zero budgets and all radii.
- [x] Verify countable representations make every announced selector Borel without assuming attainment.
- [x] Verify the order `sup_Gamma inf_delta sup_P` is preserved in every upper and lower invocation.
- [x] Verify interior constants are pointwise in `rho`, and no limit to saturation is used.
- [x] Verify the saturation lower is an outer-supremum witness, not a pairwise claim.
- [x] Verify all `n>=1`, zero-budget, tie, empty, and singleton-variance cases are covered.

## Boundary cases and likely failure points

Inspect `v_->B_0^2`, `v_-=B_0^2`, `a=s=b=t=0`, `n=1`, nonattained class infima, and an uncoded nonseparable class. The most likely failures are a hidden minimax-order exchange, an unobservable selector input, or an implicit pairwise interpretation of a one-pair lower bound.

## Falsifier / exact checks

Attempt to exhibit two legal public pairs for which a purported common estimator is required, or a legal represented class for which the announced first-within-tolerance rule is nonmeasurable. Check the E/S support implications directly on the two-point support.

## Verdict table

| Item | PASS | FAIL | NEEDS CLARIFICATION | Locator / comment |
|---|---|---|---|---|
| Model and envelopes |  | X |  | PDF p. 17, (C.8): for `B_0>48`, `v_0=1`, `n=1`, the chosen `abs(beta)=d_rho` exceeds the p. 10 target range `[-3,3]`. Cap `d_rho` by at most 3. The p. 10 zero-budget localized quotient also needs repair. |
| M1 measurability |  |  | X | PDF p. 10, Appendix A: countable representations support first-within-tolerance selectors, but `(X,A)` and joint evaluation measurability are not declared; `n`-dependence of admissibility is implicit. |
| Q1 minimax order | X |  |  | PDF pp. 2–3, (4), and p. 26, (G.1): upper and lower arguments preserve `sup_Gamma inf_delta sup_P`; lower witnesses may use different `Gamma` because the claim is outer, not pairwise. |
| Main theorem quantifiers |  |  | X | The declared all-`n`, all-budget theorem is repairable, but as written its root-`n` lower certificate is outside the model for some legal `rho,n`, and the zero-budget class condition is undefined. Constants remain pointwise in fixed `rho`; saturation is handled separately. |

## Auditor questions

1. **What exactly are M1 and Q1?** They are not two observational experiments. M1 is a represented-public-class access/measurability convention for a fixed pair; Q1 is the outer minimax functional built over those M1-compatible pairs and laws. This should be stated as a numbered definition.
2. **May `Gamma` depend on `n`?** The definition uses `R_n`, and the lower dictionaries explicitly have `n`-dependent cardinality. The theorem therefore permits a triangular array `Gamma_n`; this should be explicit.
3. **Is a common estimator required across pairs?** No. The formal order chooses a pair-specific Borel rule after `Gamma` is public. Any `inf_delta sup_Gamma sup_P` interpretation would be a different and unproved problem.
4. **Does an uncoded nonseparable class belong?** No under M1. The paper correctly excludes it, but the restriction is substantive public information rather than a purely cosmetic measurability device.
5. **Are E and S sound?** E follows from `E[u^2|X]<=B_0^2`; S follows because equality plus `|u|<=B_0` forces `|u|=B_0` a.s. and `|T|<=B_0` forces `pi_0=0`. The S lower is only an outer one-pair witness and is used that way.
