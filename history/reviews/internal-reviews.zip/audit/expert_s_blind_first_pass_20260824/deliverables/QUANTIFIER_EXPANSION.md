# Key quantifier expansion

Let `G_{rho,n}(a,s,b,t)` be the set of nonempty represented public pairs and `P_{rho,n}(Gamma;a,s,b,t)` their compatible laws. This notation makes implicit `n`-dependence explicit.

## Q1 risk

The displayed risk on PDF p. 2, Eq. (4), is

`sup_{Gamma in G} inf_{delta in D(Gamma)} sup_{P in P(Gamma)} E_P L(delta,data;beta(P))`.

In words:

`for every fixed rho,n,budgets, the outer adversary may choose Gamma; after Gamma is public the decision maker chooses one Gamma-specific Borel rule; then the inner adversary chooses any compatible P; risk is evaluated under P.`

It is **not**

`inf_delta sup_Gamma sup_{P in P(Gamma)} E_P L`,

and it is **not**

`sup_{Gamma,P} inf_delta E_P L`, which would allow the estimator to know `P`.

## Upper theorem

Proposition 2 (PDF p. 4) has the uniform fixed-pair form

`exists C_rho < infinity, for all n,budgets, for all Gamma in G_{rho,n}, exists one explicitly constructed delta_Gamma, for all P in P_{rho,n}(Gamma), E_P|delta_Gamma-beta(P)| <= C_rho(q+X).`

Because `C_rho` and the formula are uniform over admissible `Gamma`, taking `sup_Gamma` is valid. The estimator depends on `Gamma,rho,n,budgets`, not on `P` or the nuisance truths.

## Component lower bounds

For each component `j in {q,ab,M,O,P}` the required outer statement is

`exists Gamma_j in G_{rho,n}, exists a fixed hard prior/testing pair Pi_j (possibly depending on rho,n,budgets,Gamma_j), for every Borel delta_{Gamma_j}, BayesRisk(delta_{Gamma_j};Pi_j) >= c_{rho,j} L_j.`

Hence

`sup_Gamma inf_delta sup_P risk >= c_{rho,j} L_j`.

The hard mixture is fixed before the evaluated decision rule; it does not depend on the realized data or on a revealed unknown `P`. Different components may use different public pairs because the target is an outer supremum.

## Max-to-sum assembly

Appendix G, PDF pp. 25–26, establishes lower bounds for each component, so

`R >= c_rho max{q,ab,M,O,P}`.

Equation (10), PDF pp. 5–6, gives `X` comparable to `ab+M+O+P`; for five nonnegative terms,

`max{q,ab,M,O,P} >= (q+ab+M+O+P)/5`.

This is a valid outer-minimax assembly. It does not establish one public pair that is simultaneously hard for all mechanisms, and the manuscript does not need such a pair for Eq. (4).

## Boundary regimes

| Regime | Expanded statement | Audit |
|---|---|---|
| `v_->B_0^2` | `for every represented Gamma, P_{rho,n}(Gamma)=empty`, because `abs(u)<=B_0` implies `E[u^2 given X]<=B_0^2`. | PASS. |
| `0<v_-<B_0^2` | `exists 0<c_rho<=C_rho<infinity` uniform over `n,budgets,Gamma,P`, with outer risk comparable to `q+X`. | CONDITIONAL PASS after the zero-radius and (C.8) target-range repairs. |
| `v_-=B_0^2` | Upper: for every legal `Gamma` a root-`n` estimator exists. Lower: there exists one public pair for which every rule has root-`n` risk. | PASS as an outer theorem; not a pairwise claim. |

## Quantifier hazards tested

| Hazard | Result |
|---|---|
| `exists estimator for all P` changed to `for all P exists estimator` | Not found. The upper rule is built from public inputs only. |
| Public pair selected after the true law | Not in the formal game. `Gamma` is outer and public; the inner `P` must be compatible. |
| Constants depend on budgets or `n` | No such dependence was found in the theorem statement; constants are pointwise in fixed `rho`. |
| Hard law depends on the evaluated algorithm | The testing priors are fixed constructions; standard testing inequalities then quantify over every rule. |
| Function class depends on the sample values | No. It may depend on `n` and budgets, but not on realized observations. |
| “For every pair” promoted to one common estimator | Not found. The paper consistently allows `delta_Gamma`. |
| Pairwise lower inferred from an outer witness | Not found; saturation and component certificates are used only for the outer risk. |
