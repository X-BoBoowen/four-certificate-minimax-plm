# `ab` and `M` proof attribution

## Bottom line

- The **rates/conclusions** `ab` and `(s wedge t)^2` are prior art: both are explicit in Gu–Yin–Cai–Fan Theorem A.1 after notation substitution, and product lower mechanisms predate that paper.
- The manuscript supplies **native finite exact-variance re-embeddings** under its own bounded, represented-public-pair interface. Those proofs may be new technical adaptations, but they do not make the rate terms new.
- The manuscript's text is largely honest: PDF p. 1 says product/common-stochastic mechanisms are attributed to prior work, and p. 5 calls them “other mechanisms,” not new headline phenomena.

## `ab` attribution graph

```text
prior nonlinear-functional/product lower-bound tradition
  Robins et al. (2009) two-mixture methodology
  Balakrishnan–Kennedy–Wasserman (2023) structure-agnostic functional limits
  Gu et al. (2026), Theorem A.1: AB contains ab explicitly
                           |
                           v
manuscript Section 6, Eq. (9), PDF p. 5: R >= c_ab,rho ab
                           |
                           v
Appendix E, PDF pp. 22–23
  singleton public classes {0}
  off-class Walsh truths at radii a,b
  exact three-point treatment variance channel
  compensating response mixture
  chi-square/TV testing + root-n all-n splice
                           |
                           v
native bounded-M1 certificate, same known rate term
```

| Attribution field | Finding |
|---|---|
| First manuscript appearance | Rate (1), PDF p. 1, through expansion of `AB`; separate lower certificate in Eq. (9), PDF p. 5. |
| Formal proof | Appendix E, “Complete Approximation-Product `ab` Certificate,” PDF pp. 22–23; (E.1)–(E.13). |
| Internal dependencies | Testing inequality (C.1), finite-mixture Gram identity (C.3), exact treatment channel (C.6), binary outcome channel (C.12), and parametric splice (C.9). |
| External conceptual dependencies | Standard fuzzy/two-mixture testing; known structure-agnostic product lower terms; Gu et al. A.1 already includes `ab`. |
| Independently completed here | Exact model membership under the manuscript's shared envelopes and exact variance; singleton public classes; explicit all-`n` constants. |
| Merely adapted | The target-separation/testing template and the rate conclusion. |
| Classification | **3 — existing theorem/result's technical adaptation**, with elements of **5 — combination** and **6 — standard method instantiation**. |
| Novelty effect | No independent theorem-level novelty for the term `ab`; moderate verification value in proving it inside the exact frozen model. |

## `M` attribution graph

```text
Gu et al. (2026), Theorem A.1
  lower term [delta_mu^stoc wedge delta_pi^stoc]^2
                           |
                           v
manuscript M=(s wedge t)^2, Section 6 Eq. (9), PDF p. 5
                           |
                           v
Appendix F, PDF pp. 23–25
  two finite public Walsh dictionaries
  zero approximation error
  common propensity channel
  separate localized-complexity certificates
  finite-mixture chi-square/TV testing + all-n splice
                           |
                           v
native bounded-M1 certificate, same known rate term
```

| Attribution field | Finding |
|---|---|
| First manuscript appearance | Rate (1), PDF p. 1; definition in Eq. (5), PDF p. 2; lower in Eq. (9), p. 5. |
| Formal proof | Appendix F, “Complete Common-Stochastic `M` Certificate,” PDF pp. 23–25; (F.1)–(F.15). |
| Internal dependencies | Lemma 7 finite-class Rademacher bound, exact channel (C.6), outcome channel (D.3), mixture identity (C.3), testing inequality (C.1), parametric splice (C.9). |
| External result | Gu et al. Theorem A.1 explicitly gives the same common-stochastic lower term. |
| Independently completed here | A common finite public pair, zero approximation, separate `s` and `t` budget certificates, exact variance/envelopes, and explicit all-`n` closure. |
| Merely adapted | Walsh/sparse-dictionary testing logic and the rate conclusion. |
| Classification | **3 — existing result's technical adaptation**; the conclusion is close to **4 — direct prior result under notation**, while model membership work prevents calling the proof a purely direct corollary. |
| Novelty effect | No independent theorem-level novelty for `M`; the proof provides model-specific closure. |

## Relation to O/P and the full theorem

`ab` and `M` are not derived by algebraically relabeling O/P; the manuscript correctly gives distinct hard geometries. Conversely, proof distinctness does not make their **rate terms** novel. The overall minimax characterization can still be new as a combination if O/P are genuinely necessary and the upper/lower interface closes a previously open gap.

## Verdicts

| Item | Verdict | Severity | Confidence | Evidence | Minimum repair |
|---|---|---|---|---|---|
| `ab` conclusion attribution | CONDITIONAL PASS | MAJOR | HIGH | PRIMARY VERIFIED | In every contribution matrix, label the rate as prior and the Appendix E work as a native technical re-embedding. Add the closest specific theorem/corollary, not only a general prior-work paragraph. |
| `M` conclusion attribution | CONDITIONAL PASS | MAJOR | HIGH | PRIMARY VERIFIED | State explicitly that Gu et al. A.1 already proves the same algebraic term; reserve novelty for exact-interface adaptation. |
| Independence from O/P | PASS | MINOR | HIGH | PRIMARY VERIFIED | No repair needed. |

