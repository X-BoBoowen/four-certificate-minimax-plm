# Expert S issue register

## Summary

| ID | Item | Verdict | Severity | Confidence | Evidence |
|---|---|---|---|---|---|
| S-001 | Zero-budget localized-complexity definition | CONDITIONAL PASS | MAJOR | HIGH | PRIMARY VERIFIED |
| S-002 | Root-`n` hard witness leaves target space | FAIL | MAJOR | HIGH | PRIMARY VERIFIED |
| S-003 | Covariate/sample-space measurability omitted | CONDITIONAL PASS | MAJOR | MEDIUM | PRIMARY VERIFIED |
| S-004 | M1/Q1 status and `n`-dependence implicit | CONDITIONAL PASS | MAJOR | HIGH | PRIMARY VERIFIED |
| S-005 | Public class is substantive oracle information | CONDITIONAL PASS | MAJOR | HIGH | PRIMARY VERIFIED |
| S-006 | Q1 minimax quantifier order | PASS | MAJOR | HIGH | PRIMARY VERIFIED |
| S-007 | Fixed-variance logic and positioning | CONDITIONAL PASS | MAJOR | HIGH | PRIMARY VERIFIED |
| S-008 | BBM Theorem 2.1 transfer | PASS | MINOR | HIGH | PRIMARY VERIFIED |
| S-009 | Gu et al. A.1 attribution/model mapping | CONDITIONAL PASS | MAJOR | HIGH | PRIMARY VERIFIED |
| S-010 | TAME attribution | PASS | MAJOR | HIGH | PRIMARY VERIFIED |
| S-011 | `ab` proof/result attribution | CONDITIONAL PASS | MAJOR | HIGH | PRIMARY VERIFIED |
| S-012 | `M` proof/result attribution | CONDITIONAL PASS | MAJOR | HIGH | PRIMARY VERIFIED |
| S-013 | O/P novelty and collision search | CONDITIONAL PASS | MAJOR | MEDIUM | PRIMARY VERIFIED |
| S-014 | Saturation theorem breadth/significance | CONDITIONAL PASS | MAJOR | HIGH | PRIMARY VERIFIED |
| S-015 | Submission/public-priority date | CONDITIONAL PASS | MINOR | MEDIUM | METADATA VERIFIED |
| S-016 | ICLR-level significance | CONDITIONAL PASS | MAJOR | MEDIUM | PRIMARY VERIFIED |
| S-017 | Statistical versus causal identification | PASS | MINOR | HIGH | PRIMARY VERIFIED |

## Detailed records

### S-001 — zero-budget localized-complexity condition is undefined

- **Task:** M1 definition / zero-budget boundary.
- **Verdict / severity / confidence / evidence:** CONDITIONAL PASS / MAJOR / HIGH / PRIMARY VERIFIED.
- **PDF locator:** p. 10, Appendix A, lines 512–516 in extracted text; localized constraints immediately after the definition of `R_{n,P_X}(r;Delta G)`.
- **First possible failure:** the supremum is written over `r>=s` of `R(r)/(3r)` while the theorem permits `s=0`; then `r=0` is in the index set and gives the undefined quotient `0/0`.
- **Original claim:** the public-pair model and theorem cover all budgets in `[0,1]^4`, including zero stochastic budgets.
- **Independent analysis:** later proofs treat zero dictionaries/zero complexity as legal, so the intended convention is clear, but it is not mathematically encoded. This is the earliest formal failure; later “ratio is zero” statements do not cure the definition.
- **External source:** N/A—the issue is internal. Standard localized-complexity definitions take positive radii.
- **Closest prior-work difference:** Gu et al./TAME formulate hypothesis-class stochastic budgets differently; they do not validate this exact zero-radius quotient.
- **Impact:** the parameter space is undefined on boundary faces used in Theorem 1 and Appendices E/F. It is a definition failure, not evidence that the rate is wrong.
- **Minimum repair:** write `sup_{r>=s, r>0}`, or define the quotient at zero by its right-limit/zero for a zero class.
- **Does repair change theorem/rate/model?** It clarifies the model but does not change the theorem range or rate.
- **Unconfirmed:** whether the authors intended a standard positive-radius convention in an omitted source file.

### S-002 — Appendix C.3 root-`n` witness can violate `beta in [-3,3]`

- **Task:** Main lower bound / model membership / all-`n` closure.
- **Verdict / severity / confidence / evidence:** FAIL / MAJOR / HIGH / PRIMARY VERIFIED.
- **PDF locator:** p. 17, Appendix C.3, Eq. (C.8); target range p. 10, Appendix A; confirmation p. 26, projection argument.
- **First possible failure:** `d_rho=min{B_0/16,B_0/(16 sqrt(v_0))}` and `theta_omega=omega d_rho/sqrt(n)` are chosen without a `[-3,3]` cap.
- **Original claim:** the root-`n` hard experiment is compatible for every legal fixed `rho` and every `n>=1`, and supplies the `q` component used in all lower splices.
- **Independent analysis/counterexample:** choose legal `B_0=64`, `v_-=v_+=v_0=1`, `n=1`. Then `d_rho=4` and `|theta_omega|=4>3`. This law is outside the stated target space, even if its other envelopes are legal.
- **External source:** N/A—exact internal counterexample.
- **Closest prior-work difference:** ordinary Le Cam root-`n` submodels cap local alternatives to the parameter space; prior methodology does not justify this missing cap.
- **Impact:** the displayed `q` certificate, and therefore branches that invoke (C.9) for small `n`/small interactions, are not proved for the full stated fixed-tuple range.
- **Minimum repair:** replace `d_rho` by `min{3,B_0/16,B_0/(16 sqrt(v_0))}` (a smaller fixed cap such as `1` is cleaner) and rerun the divergence constant.
- **Does repair change theorem/rate/model?** Only lower constants; not the rate, model scope, or theorem form.
- **Unconfirmed:** independent full recalculation of the best numerical constant after capping; existence of a positive `rho`-dependent constant is immediate.

### S-003 — measurable covariate space and class evaluation are under-specified

- **Task:** M1 model completeness/measurability.
- **Verdict / severity / confidence / evidence:** CONDITIONAL PASS / MAJOR / MEDIUM / PRIMARY VERIFIED.
- **PDF locator:** first occurrence Eq. (1), p. 2; Appendix A, p. 10, lines 518–522.
- **First possible failure:** `X`, function domains, conditional expectations, and Borel decision maps are used before a measurable space `(mathcal X,mathcal A)` and product observation sigma-field are declared.
- **Original claim:** countable representations make every announced fit/selector Borel.
- **Independent analysis:** measurability of the coordinate sequence `(g_j)` is asserted, but it is unclear whether this means each `g_j` is measurable, whether joint evaluation is measurable, and on what base space. A standard Borel covariate space plus measurable evaluations is sufficient.
- **External source:** [BBM DOI](https://doi.org/10.1214/009053605000000282) illustrates explicit measurable-class conditions but does not define this model.
- **Closest prior-work difference:** Gu et al. fixes `X~nu_d`, giving a concrete Borel domain.
- **Impact:** conditional laws, `L_2(P_X)` classes, empirical argmins, and “Borel estimator” lack a fully declared domain.
- **Minimum repair:** add a numbered sample-space definition and joint/measurable evaluation assumptions for the representation.
- **Does repair change theorem/rate/model?** It narrows the model to a well-defined measurable category; no rate change.
- **Unconfirmed:** whether arbitrary non-standard measurable covariate spaces were intended.

### S-004 — M1/Q1 are not formally defined and triangular-array classes are implicit

- **Task:** M1/Q1 reconstruction and relation.
- **Verdict / severity / confidence / evidence:** CONDITIONAL PASS / MAJOR / HIGH / PRIMARY VERIFIED.
- **PDF locator:** pp. 2–3, Eqs. (2)–(5); p. 10, Appendix A; p. 6, Section 8.
- **First possible failure:** M1 is introduced as an “access convention” and Q1 through prose/risk notation, while admissibility uses `R_n` and lower dictionaries use `p=ceil(exp(64N s^2))` or its analogues.
- **Original claim:** the theorem holds over the stated public-pair model for every `n` and budget tuple.
- **Independent analysis:** the class domain is a triangular array even though written `Gamma`; M1 and Q1 are not distinct statistical experiments. This is reconstructible but avoidably ambiguous.
- **External source:** Gu et al. Eq. (A.2) gives a similar outer order in a concrete model: [arXiv](https://arxiv.org/abs/2606.06368).
- **Closest prior-work difference:** the manuscript adds countable represented access but does not formalize it as a standalone definition.
- **Impact:** readers may incorrectly require one fixed class across all `n`, or misread Q1 as a reduction/equivalence.
- **Minimum repair:** define `mathfrak G_{rho,n}` and state that `Gamma_n` may depend on `n` and budgets but not realized data; separately define M1 access and Q1 risk.
- **Does repair change theorem/rate/model?** Clarifies and arguably enlarges explicit scope to the already-used triangular arrays; no rate change.
- **Unconfirmed:** whether the intended public classes must remain nested/fixed asymptotically.

### S-005 — public class gives oracle structure and exact budgets

- **Task:** public-information audit and contribution positioning.
- **Verdict / severity / confidence / evidence:** CONDITIONAL PASS / MAJOR / HIGH / PRIMARY VERIFIED.
- **PDF locator:** abstract p. 1; Eq. (4) p. 2; Appendix A p. 10, lines 518–527.
- **First possible failure:** any broad reading of “structure-agnostic” that omits the fact that the entire represented pair and exact `(a,s,b,t)` are public before estimator selection.
- **Original claim:** a class-pair-specific selector attains the rate; no unknown-budget/adaptive/computational claim is made.
- **Independent analysis:** the formal theorem is honest, but the information can reveal a dictionary, support, representation, smoothness, and complexity scales. This is a conditional oracle-interface problem, easier than learning structure or budgets.
- **External source:** closest information-order comparison is Gu et al. (A.2), [arXiv](https://arxiv.org/abs/2606.06368).
- **Closest prior-work difference:** information orders are similar; envelopes/access and black-box assumptions differ.
- **Impact:** limits breadth and ICLR significance; affects claims of adaptivity or general PLM minimaxity, not internal correctness.
- **Minimum repair:** put “known-budget, represented-public-pair outer minimax” in title/abstract theorem descriptors and add a formal information timeline/comparison.
- **Does repair change theorem/rate/model?** Only contribution positioning.
- **Unconfirmed:** rate under a common estimator, unknown budgets, or data-dependent class.

### S-006 — Q1 quantifier order is preserved

- **Task:** minimax-order audit.
- **Verdict / severity / confidence / evidence:** PASS / MAJOR / HIGH / PRIMARY VERIFIED.
- **PDF locator:** Eq. (4), p. 2; Proposition 2, p. 4; Eq. (G.1), p. 25.
- **First possible failure:** N/A—no exchange found. The earliest vulnerable step is the lower assembly, which correctly inserts each hard pair into the same outer scalar.
- **Original claim:** `sup_Gamma inf_delta_Gamma sup_P`; different mechanisms may use different pairs.
- **Independent analysis:** upper bounds construct one rule per fixed pair uniformly over compatible `P`; lower bounds exhibit hard pairs and then take a maximum. This matches Q1 exactly.
- **External source:** N/A—internal logical audit.
- **Closest prior-work difference:** Gu et al. uses a related outer public-class order.
- **Impact:** supports correctness of assembly, but does not prove a common-estimator or pairwise lower result.
- **Minimum repair:** no theorem repair; add explicit logical expansion to prevent misreading.
- **Does repair change theorem/rate/model?** No.
- **Unconfirmed:** the different `inf sup` problem is unstudied here.

### S-007 — fixed variance is internally consistent but materially restrictive

- **Task:** fixed-variance special audit.
- **Verdict / severity / confidence / evidence:** CONDITIONAL PASS / MAJOR / HIGH / PRIMARY VERIFIED.
- **PDF locator:** Eq. (1), p. 2; Appendix A p. 10; exact channels Appendices C–F; boundary pp. 7 and 26–27.
- **First possible failure:** any implication that constant `v` can be normalized to one without changing target, loss, budgets, or envelopes.
- **Original claim:** unknown scalar `v in [v_-,v_+]`, constant in `X`; no explicit WLOG normalization claim.
- **Independent analysis:** lower bounds validly fix `v=v_-`; upper/lower share the model. Rescaling treatment changes `beta`, loss, envelopes, and propensity budgets. The saturation result is driven by exact equality to a shared hard envelope.
- **External source:** Gu et al. A.1 also assumes exact constant conditional residual variance, [arXiv](https://arxiv.org/abs/2606.06368).
- **Closest prior-work difference:** numeric envelopes differ; constancy itself is not new.
- **Impact:** no internal invalidity found, but heteroskedastic generalization and novelty cannot be inferred.
- **Minimum repair:** emphasize model-specificity and include the scaling calculation; avoid “WLOG variance one.”
- **Does repair change theorem/rate/model?** Positioning only; a heteroskedastic extension would be a new theorem.
- **Unconfirmed:** whether O/P remain necessary with heteroskedastic treatment residuals.

### S-008 — BBM transfer is exact

- **Task:** specified citation verification.
- **Verdict / severity / confidence / evidence:** PASS / MINOR / HIGH / PRIMARY VERIFIED.
- **PDF locator:** manuscript p. 11, Lemma 4, Eq. (B.2); source PDF pp. 6–7, Theorem 2.1.
- **First possible failure:** N/A—range-width and one/two-sided conversion were recomputed.
- **Original claim:** threshold `4R+sqrt(2sigma^2z/n)+8Bz/(3n)` with failure at most `2e^{-z}`.
- **Independent source analysis:** set `[-B,B]`, `r=sigma^2`, `x=z`, `alpha=1`, and enlarge by negatives. Source failure `e^{-z}` is stronger.
- **External source:** [BBM DOI](https://doi.org/10.1214/009053605000000282).
- **Closest prior-work difference:** none; this is a direct valid invocation.
- **Impact:** supports the empirical-process interface used by the upper proof.
- **Minimum repair:** optional citation to exact source pages.
- **Does repair change theorem/rate/model?** No.
- **Unconfirmed:** none material.

### S-009 — Gu et al. supports the rate but not literal model inheritance without a map

- **Task:** specified citation / closest-work comparison.
- **Verdict / severity / confidence / evidence:** CONDITIONAL PASS / MAJOR / HIGH / PRIMARY VERIFIED.
- **PDF locator:** manuscript p. 5 Eq. (9), p. 9 Table 5 and reference; source Gu et al. PDF pp. 19–20, Eq. (A.2), Theorem A.1.
- **First possible failure:** treating `q+AB+M` as a theorem directly inside the manuscript's model without reconciling fixed `nu_d`, envelopes, exact variance, representation, and parameter ranges.
- **Original claim:** Gu et al. A.1 is the closest inherited lower envelope.
- **Independent source analysis:** algebraic mapping is exact, but theorem fields are only close, not identical.
- **External source:** [arXiv:2606.06368](https://arxiv.org/abs/2606.06368).
- **Closest prior-work difference:** manuscript adds O/P, general `P_X`, access closure, envelopes, and boundary; Gu et al. already supplies the base lower terms.
- **Impact:** attribution is directionally honest; model-containment language would be unsupported.
- **Minimum repair:** add an assumption-by-assumption restriction/rescaling table and call only the envelope inherited.
- **Does repair change theorem/rate/model?** Positioning and possibly proof citation; no rate change if native Appendices E/F stand.
- **Unconfirmed:** exact theorem containment under one common numerical parameter restriction.

### S-010 — TAME attribution is accurate

- **Task:** specified citation / upper-proof ownership.
- **Verdict / severity / confidence / evidence:** PASS / MAJOR / HIGH / PRIMARY VERIFIED.
- **PDF locator:** manuscript p. 1, p. 4 lines 174–177, p. 9 Table 5; source TAME PDF pp. 13–16, Algorithm 1, Theorem 3.1, Cor. 3.2.
- **First possible failure:** N/A—the paper explicitly disclaims a new generic calibration principle.
- **Original claim:** TAME supplies the editing objectives and two branches; this paper closes M1/Q1 measurability, fallback, and boundaries.
- **Independent source analysis:** Cor. 3.2 matches the manuscript's two branch polynomials under notation substitution.
- **External source:** [arXiv:2607.21541](https://arxiv.org/abs/2607.21541).
- **Closest prior-work difference:** interface/all-budget expected-risk closure and matching directional lower bounds.
- **Impact:** generic upper-method novelty is unavailable, but attribution is honest.
- **Minimum repair:** retain and strengthen the existing theorem-field comparison.
- **Does repair change theorem/rate/model?** No.
- **Unconfirmed:** whether every optimization/measurability step is the only new upper difficulty; mathematical auditor review remains needed.

### S-011 — `ab` is a native adaptation of a known conclusion

- **Task:** proof attribution.
- **Verdict / severity / confidence / evidence:** CONDITIONAL PASS / MAJOR / HIGH / PRIMARY VERIFIED.
- **PDF locator:** p. 5 Eq. (9); Appendix E pp. 22–23, (E.1)–(E.13).
- **First possible failure:** calling the `ab` lower rate itself new rather than the exact-interface embedding.
- **Original claim:** the witness is distinct from O/P; product mechanisms are attributed to prior work.
- **Independent analysis:** singleton classes, exact variance, and all-`n` bookkeeping are manuscript-specific, but Gu et al. A.1 already contains `ab`, and fuzzy/product lower logic is older.
- **External sources:** [Gu et al.](https://arxiv.org/abs/2606.06368), [Robins et al.](https://doi.org/10.1214/09-EJS479).
- **Closest prior-work difference:** native bounded channel and access certificate, not rate.
- **Impact:** technical depth remains; theorem-level novelty is limited.
- **Minimum repair:** label as “new model-specific proof of a prior rate component.”
- **Does repair change theorem/rate/model?** Positioning only.
- **Unconfirmed:** priority of the exact finite channel construction.

### S-012 — `M` is a native adaptation of a known conclusion

- **Task:** proof attribution.
- **Verdict / severity / confidence / evidence:** CONDITIONAL PASS / MAJOR / HIGH / PRIMARY VERIFIED.
- **PDF locator:** Eq. (5) p. 2; Eq. (9) p. 5; Appendix F pp. 23–25, (F.1)–(F.15).
- **First possible failure:** presenting `(s wedge t)^2` as a new minimax term.
- **Original claim:** two finite public dictionaries provide a distinct common-stochastic witness; prior mechanism attributed.
- **Independent analysis:** Gu et al. A.1 explicitly has the same lower term. The exact bounded dictionary proof is a technical adaptation.
- **External source:** [Gu et al.](https://arxiv.org/abs/2606.06368).
- **Closest prior-work difference:** zero-approximation finite M1 pair, exact variance, separate localized budgets, all-`n` closure.
- **Impact:** no independent rate novelty, but model-specific verification value.
- **Minimum repair:** separate “known conclusion” from “new native proof.”
- **Does repair change theorem/rate/model?** Positioning only.
- **Unconfirmed:** whether an earlier source contains the identical dictionary embedding.

### S-013 — O/P are plausible real increments, not proven collision-free

- **Task:** open prior-work collision search / novelty.
- **Verdict / severity / confidence / evidence:** CONDITIONAL PASS / MAJOR / MEDIUM / PRIMARY VERIFIED.
- **PDF locator:** p. 1; Section 5 pp. 4–5; Appendices C/D pp. 17–22; Table 5 p. 9.
- **First possible failure:** the universal novelty implication “absent from the closest theorem” could outrun the finite search record.
- **Original claim:** O/P have separate finite witnesses and are absent from Gu et al. A.1's displayed lower field.
- **Independent analysis:** source comparison confirms that narrow claim. No earlier exact O/P lower theorem was located through multi-path searches. The P and O channels are structurally different, not a mere label swap.
- **External sources:** nearest papers [Gu et al.](https://arxiv.org/abs/2606.06368) and [TAME](https://arxiv.org/abs/2607.21541).
- **Closest prior-work difference:** TAME has corresponding oriented upper behavior; it does not provide matching two-learner O/P lower necessity.
- **Impact:** this is the main support for novelty and significance.
- **Minimum repair:** phrase as “not present in the closest located theorem and, to our knowledge, new,” with a transparent search/citation scope.
- **Does repair change theorem/rate/model?** Positioning only unless a collision emerges.
- **Unconfirmed:** unindexed/concurrent 2026 results and forward citations not yet populated.

### S-014 — saturation is correct but driven by an artificial shared envelope

- **Task:** model innovation / significance.
- **Verdict / severity / confidence / evidence:** CONDITIONAL PASS / MAJOR / HIGH / PRIMARY VERIFIED.
- **PDF locator:** Theorem 1 p. 3; Section 7 p. 6–7; Appendices H/I pp. 26–27.
- **First possible failure:** interpreting the E/I/S phase change as a broad semiparametric phenomenon rather than the equality case of `|u|,|T|<=B_0` and `E[u^2|X]=B_0^2`.
- **Original claim:** exact saturation identifies the propensity and leaves the parametric rate.
- **Independent analysis:** equality forces `|u|=B_0` and then `pi_0=0`; the theorem is correct. But decoupling residual and treatment envelopes or allowing heteroskedasticity can remove the phenomenon.
- **External source:** N/A—elementary support argument.
- **Closest prior-work difference:** not found as the same named boundary; the mechanism is elementary and model-specific.
- **Impact:** modest conceptual insight, limited breadth.
- **Minimum repair:** describe it as an envelope-extremality corollary and discuss sensitivity to separate envelopes.
- **Does repair change theorem/rate/model?** Positioning only; realism extensions would change the model.
- **Unconfirmed:** boundary behavior under separate residual/treatment bounds.

### S-015 — public/submission priority is unverified

- **Task:** version control and novelty timeline.
- **Verdict / severity / confidence / evidence:** CONDITIONAL PASS / MINOR / MEDIUM / METADATA VERIFIED.
- **PDF locator:** header every page; PDF creation metadata 2026-08-24 01:58:53 China Standard Time; AI statement p. 9.
- **First possible failure:** treating “under review at ICLR 2027” as evidence of a submission date or public priority.
- **Original claim:** review-template status only; no explicit priority claim.
- **Independent analysis:** official ICLR 2027 paper deadline is later in September 2026. No public copy of this exact title was located.
- **External source:** [ICLR 2027 Author Guidelines](https://iclr.cc/Conferences/2027/AuthorGuidelines).
- **Closest prior-work difference:** Gu et al. and TAME were public in June/July 2026, before the only verifiable manuscript-artifact date.
- **Impact:** they are prior work under the current record; actual earlier priority remains unknown.
- **Minimum repair:** record first public/posting/submission date and archive the submitted version.
- **Does repair change theorem/rate/model?** Could change novelty chronology, not mathematics.
- **Unconfirmed:** actual submission and any earlier manuscript versions.

### S-016 — ICLR significance is borderline

- **Task:** conference-value audit.
- **Verdict / severity / confidence / evidence:** CONDITIONAL PASS / MAJOR / MEDIUM / PRIMARY VERIFIED.
- **PDF locator:** abstract/contributions p. 1; theorem pp. 2–3; limitations p. 6; related work/table p. 9.
- **First possible failure:** equating closure of an open minimax gap with broad ML impact without accounting for the information-rich model and inherited upper technique.
- **Original claim:** matching rate, directional necessity, measurable interface closure, boundary phase change; no computation/adaptation/practical superiority.
- **Independent analysis:** O/P lower necessity is a credible technical contribution, but the paper's breadth, realism, and algorithmic impact are modest; two formal proof/model repairs remain.
- **External source:** [ICLR 2027 Reviewer Guidelines](https://iclr.cc/Conferences/2027/ReviewerGuidelines).
- **Closest prior-work difference:** real increment concentrated in O/P lower bounds and exact assembly.
- **Impact:** independent overall conference conclusion is **BORDERLINE**, not CONVINCING.
- **Minimum repair:** fix S-001/S-002, narrow positioning, add exact prior-model mapping, and demonstrate robustness beyond constant-variance/known-budget public classes.
- **Does repair change theorem/rate/model?** Basic repairs do not; evidence that would materially improve significance likely requires a broader theorem.
- **Unconfirmed:** full mathematical correctness and community valuation.

### S-017 — no causal identification claim should be imputed

- **Task:** statistical reasonableness / causal scope.
- **Verdict / severity / confidence / evidence:** PASS / MINOR / HIGH / PRIMARY VERIFIED.
- **PDF locator:** Eq. (1), p. 2; target/risk Eq. (4), p. 2.
- **First possible failure:** N/A—the paper targets a statistical PLM coefficient and introduces no potential outcomes.
- **Original claim:** estimate `beta_0` in the partially-linear conditional-mean model.
- **Independent analysis:** `v_->0` supplies conditional treatment variation and coefficient identification. Positivity, SUTVA, consistency, and no unmeasured confounding would be required only for an additional causal interpretation.
- **External source:** DML background [DOI](https://doi.org/10.1111/ectj.12097), which treats both treatment and structural parameters under explicit assumptions.
- **Closest prior-work difference:** no conflict; the manuscript uses causal-learning language only contextually.
- **Impact:** correctness is not weakened by absent potential-outcome assumptions, but applications must not overclaim causality.
- **Minimum repair:** one sentence: “`beta_0` is a statistical PLM coefficient; causal interpretations require separate assumptions.”
- **Does repair change theorem/rate/model?** No.
- **Unconfirmed:** intended downstream causal application.

