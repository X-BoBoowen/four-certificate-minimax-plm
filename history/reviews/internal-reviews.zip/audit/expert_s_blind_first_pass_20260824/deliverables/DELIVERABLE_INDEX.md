# Deliverable index

| Path | Purpose |
|---|---|
| `EXPERT_S_AUDIT_REPORT.md` | Complete independent Expert S report and final declarations. |
| `ISSUE_REGISTER.md` | Full issue list with verdict, severity, confidence, evidence level, locators, first failure, impact, repairs, and unknowns. |
| `M1_Q1_MODEL_CARDS_AND_RELATION.md` | Independently reconstructed M1/Q1 model cards and relation diagram. |
| `QUANTIFIER_EXPANSION.md` | Explicit `exists/forall/sup/inf` logic and boundary quantifiers. |
| `PUBLIC_CLASS_INFORMATION_TIMELINE.md` | Public-information meaning, game timeline, and alternative interpretation analysis. |
| `FIXED_VARIANCE_AUDIT.md` | Fixed-variance model, exact lower submodels, scaling analysis, and boundary audit. |
| `BBM_GU_TAME_VERIFICATION.md` | Primary-source claim verification for BBM, Gu et al., TAME, and the remaining bibliography. |
| `AB_M_ATTRIBUTION.md` | `ab`/`M` proof ownership graphs and classification. |
| `CONTRIBUTION_PRIOR_ART_INCREMENT_MATRIX.md` | Contribution claims, closest prior art, and actual increment on six novelty axes. |
| `PRIOR_WORK_COLLISION_CANDIDATES.md` | Candidate classification and detailed strong-overlap comparisons. |
| `LITERATURE_SEARCH_LOG.md` | Search date, platforms, queries, candidates, exclusions, and limitations. |
| `TIMELINE.md` | Public-version/publication/submission timeline and conditional priority conclusions. |
| `ICLR_NOVELTY_SIGNIFICANCE.md` | ICLR 2027 criteria-based novelty/significance assessment. |
| `MISSING_AND_UNCONFIRMED.md` | Missing materials, unconfirmed mathematical/scholarly matters, and access limits. |
| `READ_AND_SOURCE_LOG.md` | Exact local files and public sources actually read, plus prohibited-material isolation record. |
| `DECLARATIONS_AND_SIGNATURE.md` | Qualification scope, conflict, independence, search limits, AI identity, and signature. |
| `COMPLETION_CHECKLIST.md` | Required pre-delivery self-check. |
| `forms/AUDITOR_S_FORM.md` | Filled original Auditor S form with structure retained. |
| `forms/AUDITOR_CREDENTIAL_SCOPE.md` | Filled original credential/scope form with structure retained. |
| `forms/INDEPENDENCE_AND_CONFLICT_FORM.md` | Filled original independence/conflict form with structure retained. |
| `packets/H1_MODEL_M1_Q1_MAIN.md` | Filled original H1 packet and verdict table. |
| `packets/H2_BBM_TRANSFER.md` | Filled original H2 packet and verdict table. |
| `SHA256SUMS.txt` | SHA-256 checksums for every final deliverable other than the checksum file itself. |

The adjacent archive `Expert_S_Blind_First_Pass_Audit_20260824.zip` contains this tree. Its own hash is recorded in `Expert_S_Blind_First_Pass_Audit_20260824.zip.sha256` outside the ZIP.

