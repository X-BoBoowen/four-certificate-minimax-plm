# Manuscript and prior-work timeline

The priority rule used here is the earliest date on which the relevant technical content was publicly available; formal publication dates are recorded separately when verified.

| Date | Work/event | Technical content relevant here | Status relative to supplied manuscript |
|---|---|---|---|
| 1988 | Robinson, “Root-N-Consistent Semiparametric Regression,” *Econometrica* 56(4):931–954. | Classical PLM/root-`n` lineage. | Prior. |
| 2004-05-14 | Supplied BBM author version. | Theorem 2.1 field already present in the author version. | Prior. |
| 2005 | BBM formally published, DOI `10.1214/009053605000000282`. | Local Rademacher deviation source. | Prior. |
| 2009-12-04 | Robins et al., *EJS* 3:1305–1321. | Two-mixture affinity/testing method; semiparametric minimax examples. | Prior. |
| 2018 | Chernozhukov et al., *Econometrics Journal* 21(1):C1–C68. | DML/product-rate and orthogonal-score context. | Prior. |
| 2023 | Foster & Syrgkanis, *Annals of Statistics* 51(3):879–908. | Orthogonal statistical-learning context. | Prior. |
| 2023-05-06 | Balakrishnan–Kennedy–Wasserman arXiv:2305.04116 v1. | Structure-agnostic functional lower-bound framework. | Prior. |
| 2024-02-22 | Jin–Syrgkanis arXiv:2402.14264 v1. | Structure-agnostic PLM/functional lineage; later COLT 2025. | Prior. |
| 2025 | Gu open problem, COLT/PMLR 291:6220–6224. | Publicly poses the four-budget PLM minimax problem. | Prior. |
| 2025-07-03 | Jin–Mackey–Syrgkanis arXiv:2507.02275 v1. | Noise-law effects in structure-agnostic estimation. | Prior. |
| 2025-11-07 | Same paper v3 / NeurIPS 2025 version. | Version cited by manuscript. | Prior. |
| 2025-12-19 | Jin–Syrgkanis arXiv:2512.17341 v1. | General sharp structure-agnostic lower bounds. | Prior. |
| 2026-01-05 | Same paper v2. | Version cited by manuscript. | Prior. |
| 2026-06-04 | Gu–Yin–Cai–Fan arXiv:2606.06368 v1. | Theorem A.1 contains `q+AB+M`; this is the cited and first located version. | Prior. |
| 2026-07-23 | Solo Gu arXiv:2607.21541 v1. | TAME Algorithm 1, Theorem 3.1, Cor. 3.2, and two upper branches; first located version. | Prior. |
| 2026-08-24 01:58:53 China Standard Time | Supplied anonymous PDF creation metadata. | First verifiable date for this exact manuscript artifact; no earlier public record located. | Audit-time manuscript date; public priority unverified. |
| 2026-08-24 | This independent audit/search. | Public-source cutoff. | Current. |
| 2026-09-18 / 2026-09-25 AOE | ICLR 2027 public abstract/paper deadlines on the official author calendar. | The PDF build predates the submission deadline. | Future at audit date. |

Official ICLR date source: [ICLR 2027 Author Guide](https://iclr.cc/Conferences/2027/AuthorGuidelines).

## Conditional priority conclusion

The supplied artifact says “under review as a conference paper at ICLR 2027,” but on 2026-08-24 the official paper deadline had not yet occurred. The actual submission time and any earlier public posting are absent. Consequently:

- Gu et al. v1 and TAME v1 are unquestionably public prior work relative to the supplied PDF date.
- No exact public copy of the manuscript was located, so its earliest public date is **unverified**; PDF creation time is not publication.
- Work appearing after an eventual submission deadline must be treated as concurrent/later, but none is used here to negate novelty.
- If the authors can document an earlier public manuscript version preceding June/July 2026, the priority labels for Gu et al. and TAME would need reevaluation; the current packet supplies no such evidence.

