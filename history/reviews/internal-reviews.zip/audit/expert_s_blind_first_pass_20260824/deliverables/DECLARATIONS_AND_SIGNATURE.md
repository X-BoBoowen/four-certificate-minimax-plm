# Declarations and verifiable signature

## Qualification-scope statement

This audit covers statistical-model reconstruction, semiparametric/orthogonal-learning assumptions, minimax quantifier order, public-information structure, fixed-variance restrictions, empirical-process source transfer, lower-bound attribution, prior-work collision screening, novelty, and ICLR relevance. Methods included complete manuscript reading, formula/quantifier reconstruction, exact counterexample testing, primary-source theorem comparison, version/metadata checks, and multi-path public literature search.

This is an AI-assisted audit. It does not claim a human degree, academic appointment, institutional affiliation, publication record, professional license, or prior reviewing service. It is not a substitute for an independent human line-by-line proof audit.

## Conflict-of-interest statement

No conflict with the anonymous authors, their institutions, funders, competing work, or cited authors was discovered from permitted materials. As an AI system, the reviewer has no employment, financial holding, supervision, personal relationship, or competing submission. Identity-dependent conflicts cannot be checked without breaking blinding and remain unknown.

## Independence statement

The conclusions come from this round's independent reconstruction and public-source verification. No author-internal audit report, reference answer, completed audit form, solution, other expert report, reviewer opinion, or nonpublic review record was read or used. The two assigned first-pass packets were read only after the README identified them as permitted workflow materials; their claims were independently checked against the manuscript and primary sources.

## Search-limit statement

Internet access was available. The search covered public web search, arXiv, PMLR, Crossref metadata, publisher/official pages, the supplied primary PDFs, and an institutional publisher-version PDF. Complete Google Scholar/commercial citation graphs, paywalled full text not supplied, nonpublic manuscripts, private submissions, and later indexing were unavailable. Search cutoff: 2026-08-24. Therefore “no direct collision found” is a medium-confidence search result, not proof of absence.

## Verifiable signature

- Reviewer: **Expert S (AI-assisted independent model, literature and novelty audit)**
- Execution identity: **Codex AI assistant**
- Model/version: **GPT-5-based Codex; exact deployment version not provided by the system**
- Human identity/institution: **N/A—not claimed**
- Session/task ID: **Not exposed to the reviewer**
- Completion date/time: **2026-08-24 14:09:49 +08:00 (China Standard Time / Asia/Shanghai)**
- File hashes: **See `SHA256SUMS.txt` inside the deliverables. The final ZIP hash is stored in the adjacent `.zip.sha256` file because an archive cannot contain its own final hash without changing it.**
- Typed signature: **/s/ Expert S — AI reviewer; not a human signature**
