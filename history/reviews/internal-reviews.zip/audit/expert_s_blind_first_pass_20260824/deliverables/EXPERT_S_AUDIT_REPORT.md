# 专家 S 独立盲审报告

**论文：** “Four-Budget Minimax Rates for Bounded Partially Linear Models”  
**审计角色：** Expert S（AI-assisted independent model, literature and novelty audit）  
**审计日期：** 2026-08-24（Asia/Shanghai）  
**完成时间：** 2026-08-24 14:09:49 +08:00（China Standard Time / Asia/Shanghai）  
**证据截止：** 2026-08-24  
**总体审计结论：** **CONDITIONAL PASS**  
**独立 ICLR 意义结论：** **BORDERLINE**

## 1. 核心结论

本文不是简单换符号，也不是把一个现成定理直接搬到 PLM。若 O/P 两个有限 hard-family 证明在完整数学复核后成立，论文确实揭示了一个有意义的方向性现象：当每个 nuisance learner 分别由 approximation 和 stochastic budget 描述时，传统的 `q+AB+M` lower envelope 并不足够，还必须支付

`O=t(a wedge t)` 与 `P=s(b wedge s)`。

这是本文最有力、也几乎承担全部主要原创性的部分。它回应了 Gu (COLT 2025) 明确提出的 four-budget PLM minimax open problem，并且与最近的上界现象相匹配。

但是，论文的实际增量比完整 theorem package 窄：

- Gu–Yin–Cai–Fan (2026) Theorem A.1 已给出 `q+AB+M` lower envelope；
- solo Gu (2026) 的 TAME Algorithm 1、Theorem 3.1 和 Corollary 3.2 已给出两条 editing/calibration 上界分支及同样的 branch algebra；
- `ab` 与 `M=(s wedge t)^2` 的**结论**并非本文原创；本文新增的是在自身 exact-variance、bounded、represented-public-pair 模型中的技术性重嵌入；
- E/I/S saturation theorem 逻辑正确，但主要是同一个 hard envelope 同时约束 `u` 和 `T` 的极值后果，普适意义有限。

数学上，当前稿件还不能直接获得无条件 PASS。我定位到两个精确、可修复但影响正式 theorem support 的问题：

1. Appendix A 的 localized-complexity 条件在 `s=0,r=0` 时出现 `0/0`，所以声称覆盖全部零预算边界的模型定义未完成；
2. Appendix C.3 的 root-`n` hard alternative 在一部分完全合法的 `rho,n` 下会使 `|beta|>3`，因而不属于论文自己声明的目标空间。

第二项是一个严格 counterexample，而非措辞问题：取 `B_0=64,v_-=v_+=1,n=1`，(C.8) 的 `d_rho=4`。把 `d_rho` 再截断到 3 以内即可恢复一个正的 `rho`-dependent Le Cam 常数；预计不改变 rate。

## 2. 材料隔离与审计独立性

我先检查了 ZIP 的 central directory，只依据文件名、目录和 README 做路由。README 将 manuscript、两份 assigned packets、blank forms 和 source PDFs 指定为 first-pass 材料。包内没有以 solution、answer、internal audit、reference report 或 completed review 命名的文件。

我完整阅读了 README、说明、定义导航、三份空白表、H1/H2 packet、28 页论文及附录；随后核对了 supplied primary PDFs、Crossref/版本信息和公开原始来源。未打开或利用更大仓库中的其他审计阶段、已填表、内部报告、参考答案或其他审稿意见。详见 [READ_AND_SOURCE_LOG.md](READ_AND_SOURCE_LOG.md)。

## 3. M1/Q1 的独立重建

论文实际上没有定义两个不同的数据生成模型叫 M1、Q1。我的重建是：

- **M1** 是 fixed public pair 的 access/measurability convention；
- **Q1** 是在所有 M1-compatible public pairs 上取 outer supremum 的 minimax functional。

观测单位为 `Z=(X,T,Y)`，总样本 `N=2n`，i.i.d. 后分为两个独立半样本。模型为

`T=pi_0(X)+u`, `Y=beta_0 T+mu_0(X)+epsilon`,

满足 `E[u|X]=0`、`E[epsilon|X,T]=0`、`E[u^2|X]=v` a.s.，其中未知标量 `v in [v_-,v_+]`。没有假设 `u` 与 `epsilon` 独立，也没有 potential outcomes。目标是统计 PLM coefficient `beta(P)`，loss 为 expected absolute error。

估计器知道整个 countably represented `Gamma=(G_mu,G_pi)`、`rho`、`n` 和精确 budgets `(a,s,b,t)`；不知道 `P`、真实 nuisance、best approximants、`v` 或 residuals。public-class admissibility 使用 `R_n`，lower dictionaries 的维度也依赖 `n`，故严格记号应是 `Gamma_n` 和 `mathfrak G_{rho,n}`。

正式风险是

`sup_Gamma inf_{delta_Gamma Borel} sup_{P compatible with Gamma} E_P |delta_Gamma-beta(P)|`。

这允许在 `Gamma` 公布后选择 pair-specific rule，但不允许看见 `P` 后再选 estimator。它也不是 `inf_delta sup_Gamma sup_P`。我没有发现 upper 或 lower assembly 把这些量词交换。每个 lower mechanism 使用不同 hard pair 是合法的，因为最终对象是同一个 outer supremum；max-to-sum 转换也是正确的。

完整模型卡和逻辑展开见 [M1_Q1_MODEL_CARDS_AND_RELATION.md](M1_Q1_MODEL_CARDS_AND_RELATION.md) 与 [QUANTIFIER_EXPANSION.md](QUANTIFIER_EXPANSION.md)。

### 3.1 模型定义的首个歧义

Eq. (1) 首次使用 `X`、条件期望和函数时没有声明 `(mathcal X,mathcal A)`。Appendix A 又声称所有 fits/selectors 都是 Borel，但没有完整写出 observation product sigma-field 或 class evaluation 的 joint measurability。这不是已经构造出的反例，却使正式模型不完整。一个 standard Borel covariate space 加 measurable evaluations 足以修复。

### 3.2 统计合理性

- `v_->0` 提供 treatment residual variation，所以 `beta` 作为统计 PLM coefficient 可识别。
- positivity、SUTVA、consistency 和 no-unmeasured-confounding 不是这个统计 coefficient 的必要条件；若作者要赋予 causal effect 解释，则必须另加这些假设。
- upper proof 使用 honest sample splitting；并非默默依赖同样本拟合与评分。localized Rademacher 条件承担 complexity control，因此没有额外未声明的 Donsker 要求。
- 模型可能随 `n` 变化，并且允许指数大的 public dictionaries；这对 information-theoretic lower bound 合法，但削弱算法和应用解释。

## 4. Public-class 信息审计

public class 是 substantive information，不只是解决不可测 supremum 的技术装置。它可以公开 representation、dictionary、support/smoothness structure、复杂度刻度及 approximation/stochastic budgets。正式信息顺序为：

1. 固定 `rho,n,budgets`；
2. outer adversary 选 `Gamma_n`；
3. learner 知道整个 public object 后选 Borel map；
4. inner adversary 选 compatible `P`；
5. 生成数据并把数据送入已固定的 map；
6. 计算风险并按 `sup_P`、`inf_delta`、`sup_Gamma` 聚合。

这种问题是合法且干净的 information-theoretic benchmark，但它不是 unknown-class adaptation，也不是 common estimator 问题。论文对此已有较诚实的免责声明；仍建议标题/主定理描述始终保留 “known-budget, countably represented public-pair outer minimax” 限定。详见 [PUBLIC_CLASS_INFORMATION_TIMELINE.md](PUBLIC_CLASS_INFORMATION_TIMELINE.md)。

## 5. 固定方差专项结论

方差不是已知精确值，而是未知常数 `v`，其区间 `[v_-,v_+]` 已知。固定方差属于模型本身。lower bound 取 `v=v_-` 是在同一模型内选 submodel；upper/lower 没有混用 homoskedastic 和 heteroskedastic model。

不能把 `v` 直接设为 1 并称 WLOG。若 `T'=T/sqrt(v)`，则新系数变为 `beta'=beta sqrt(v)`，absolute loss、`b,t` budgets 及 treatment envelope 都改变。论文没有犯这个错误，但贡献讨论应明确 constancy 是实质限制。

E/S boundary 的逻辑成立：`v_->B_0^2` 与 `|u|<=B_0` 矛盾；当 `v_-=B_0^2`，等号迫使 `|u|=B_0` a.s.，再结合 `|T|<=B_0` 得到 `pi_0=0`。这是一项正确的 outer theorem，却高度依赖 shared envelope。详见 [FIXED_VARIANCE_AUDIT.md](FIXED_VARIANCE_AUDIT.md)。

## 6. 指定引用核验

### 6.1 BBM

BBM Theorem 2.1 的 transfer 是准确的。对 source class 加入 negatives，取 `[a,b]=[-B,B]`、`r=sigma^2`、`x=z`、`alpha=1`，即可得到

- Rademacher 项 `4R`；
- 方差项 `sqrt(2sigma^2 z/n)`；
- range 项 `(2B)(4/3)z/n=8Bz/(3n)`。

source failure probability 是 `e^{-z}`；稿件使用 `2e^{-z}` 更保守。countability 足以解决 supremum measurability。判定：**PASS / HIGH / PRIMARY VERIFIED**。

### 6.2 Gu et al.

Gu–Yin–Cai–Fan, arXiv:2606.06368 v1 (2026-06-04), Appendix A.1 Theorem A.1 的 lower bound 在记号替换后就是 `q+AB+M`。引用的 rate claim 准确。但其 `X~nu_d`、envelopes、variance normalization、class access 与本文不完全相同，不能只凭一句 “inherited” 当作 literal theorem containment。判定：**CONDITIONAL PASS / MAJOR / HIGH / PRIMARY VERIFIED**。

### 6.3 TAME

solo Gu, arXiv:2607.21541 v1 (2026-07-23), Algorithm 1/Theorem 3.1/Corollary 3.2 的两条上界分支与本文 `T_mu=ay+x^2`、`T_pi=bx+y^2` 一致。本文明确只主张 Borel/public-interface/boundary closure，而不主张新 generic editor；归属准确。判定：**PASS / HIGH / PRIMARY VERIFIED**。

完整 claim–source–assumption 表及全部参考文献核验见 [BBM_GU_TAME_VERIFICATION.md](BBM_GU_TAME_VERIFICATION.md)。

## 7. `ab` 与 `M` 的证明归属

### `ab`

正式证明位于 Appendix E，PDF pp. 22–23。本文独立完成的是 singleton public classes、off-class truths、bounded exact-variance channel、mixture-distance certificate 和 all-`n` splice。rate conclusion `ab` 已包含在 Gu et al. A.1 的 `AB` 中，product/fuzzy testing 谱系更早。归类：**类别 3（已有结果在新模型中的技术性适配）**，并带有类别 5/6 的组合与标准方法实例化。

### `M`

正式证明位于 Appendix F，PDF pp. 23–25。本文新增的是 exact M1 finite dictionaries、zero approximation、separate stochastic certificates、exact variance/envelopes 和 all-`n` closure。结论 `(s wedge t)^2` 已由 Gu et al. A.1 明确给出。归类：**类别 3**；若只看 rate statement 接近类别 4（直接先前结果），但 native model-membership work 使其不只是 substitution。

二者与 O/P 的 hard geometry 确实不同；“证明不是 O/P 的改名”不等于“rate 本身是新”。详见 [AB_M_ATTRIBUTION.md](AB_M_ATTRIBUTION.md)。

## 8. Prior-work collision 搜索

我使用 exact title、术语同义词、rate algebra、directional phrases、PLM/functional/minimax 组合、近邻工作 backward/forward lineage、arXiv 版本和官方 proceedings/publisher 路径搜索。截止 2026-08-24：

- 未找到完整 `q+AB+M+O+P` theorem 的 DIRECT COLLISION；
- Gu et al. A.1 对 inherited lower 是 STRONG OVERLAP，但对整篇只是 PARTIAL OVERLAP；
- TAME 对 upper architecture 是 STRONG OVERLAP，但对整篇只是 PARTIAL OVERLAP；
- Balakrishnan et al. 与 Jin/Syrgkanis 系列提供 lower-bound framework 或相邻现象，没有定位到 exact O/P theorem。

由于这些文献非常新、citation graph 尚未充分形成，也无法检索 nonpublic concurrent submissions，novelty 只能给 **CONDITIONAL PASS / MEDIUM confidence**。逐项对比和排除理由见 [PRIOR_WORK_COLLISION_CANDIDATES.md](PRIOR_WORK_COLLISION_CANDIDATES.md)，完整 queries 见 [LITERATURE_SEARCH_LOG.md](LITERATURE_SEARCH_LOG.md)。

## 9. 时间边界

Gu et al. v1（2026-06-04）和 TAME v1（2026-07-23）早于 supplied PDF 的可验证 creation time（2026-08-24）。稿件 header 写 ICLR 2027 under review，但官方 deadline 尚在 2026 年 9 月；因此 header 不能证明 actual submission date。没有找到本稿更早 public record。

本审计在当前证据下把两篇 Gu work 视为 prior work。若作者能给出早于 2026 年 6/7 月的公开技术版本，priority 应重评。详见 [TIMELINE.md](TIMELINE.md)。

## 10. 贡献、真实增量与开放调查

### 真正可能的新内容

1. O/P 的 separate necessity；
2. 两者可以在合法 rays 上以无界因子超过 inherited lower envelope；
3. 将这两项与已知 `q,ab,M` 拼成 exact Q1 outer minimax theorem；
4. 在 countable Borel public interface 上把 TAME-derived rule 闭合到 all-budget expected risk。

### 不应单独主张为新

1. generic TAME editing/calibration；
2. `ab` 或 `M` rate terms；
3. standard Le Cam、chi-square、Walsh dictionary、fuzzy testing 方法本身；
4. 仅因拥有 upper+lower bounds 就称 “new minimax theory”；
5. saturation 作为一般 semiparametric phase transition。

### 开放调查发现

- 论文并非把一个普通 unknown-structure problem 解得更强，而是研究一个 public oracle interface；这应被视为模型选择，而不是自动的缺陷。
- hard dictionaries 可随 `n` 指数增长，learner 完全知道它们；这在 information-theoretic outer risk 中合法，却让 practical/reconstruction 价值有限。
- saturation 是 model-envelope artifact，而非从 interior constants 连续得到；论文这一点表述正确。
- 摘要/引言的 positioning 相对诚实，尤其主动披露 TAME、prior lower mechanisms、无 computation/adaptation claim。这提高了 positioning honesty，但不能替代正式 closest-theorem mapping。

完整矩阵见 [CONTRIBUTION_PRIOR_ART_INCREMENT_MATRIX.md](CONTRIBUTION_PRIOR_ART_INCREMENT_MATRIX.md)。

## 11. ICLR 意义

依据 ICLR 2027 公开 reviewer criteria，我给出 **BORDERLINE**：

- **最强优点：** O/P lower necessity 若完全正确，是一个清楚的新理论现象，且解决已公开 open problem。
- **最关键缺点：** 新意集中度过高；upper 来自 TAME，三项 lower rate 已知，而模型依赖 known budgets、public representations、constant variance、arbitrary Borel rules 和 artificial saturation envelope。
- **技术深度：** 较强；exact finite channels 和 lower assembly 不是平凡 substitution。
- **广度/现实性：** 偏弱；没有 heteroskedastic、unknown-budget、common-estimator、computational 或 empirical implication。
- **正确性：** 当前有两个可修复 formal defects，尚不能称 fully verified。

若能完成修复并证明 O/P 在更自然的信息结构或 heteroskedastic model 下仍必要，判断可升为 CONVINCING；若出现等价 O/P prior theorem，或 directional hard family 在完整模型检查中失败，则会降为 NOT YET CONVINCING。详见 [ICLR_NOVELTY_SIGNIFICANCE.md](ICLR_NOVELTY_SIGNIFICANCE.md)。

## 12. 最小修复清单

1. 在 Appendix A 将 localized condition 改成 `r>0`，明确零预算 convention。
2. 在 (C.8) 把 `d_rho` 截断到 3 以内，并更新 lower constant。
3. 正式声明 `(mathcal X,mathcal A)`、observation sigma-field、represented evaluation measurability。
4. 给 M1/Q1 编号定义，显式写 `Gamma_n` 可以依赖 `n,budgets`、不能依赖 realized sample。
5. 在 headline theorem 前明示 public information：整个 represented pair 和四个 exact budgets。
6. 为 Gu et al. A.1 加 assumption-by-assumption mapping，区分 algebraic envelope inheritance 与 literal model containment。
7. 对 `ab`、`M` 统一表述为已知 rate components 的 native exact-interface proofs。
8. 把 E/I/S 定位为 shared-envelope extremality result，并说明 separate envelopes/heteroskedasticity 未覆盖。

前两项改变 formal proof/model definition，但不预期改变 rate 或 theorem scope；第 3–8 项主要改变严谨性和贡献定位。

## 13. 最终判定

- **问题定义：CONDITIONAL PASS。** 可重建，但 M1/Q1、base measurable space、zero radius 和 `n`-dependence需正式化。
- **主要 theorem correctness：FAIL as written, likely repairable。** 精确失败在 Appendix C.3 (C.8) 的 target-space membership；修复预计仅改常数。
- **量词与 outer assembly：PASS。** 未发现 `sup/inf` 交换。
- **BBM citation：PASS。** 常数、概率和 measurability transfer 正确。
- **Gu et al. citation：CONDITIONAL PASS。** rate 支持准确，模型映射不足。
- **TAME citation：PASS。** 归属准确，上界真实增量是 interface closure。
- **`ab`/`M` attribution：CONDITIONAL PASS。** native proof 可有技术新意，结论归 prior art。
- **O/P novelty：CONDITIONAL PASS。** 当前未找到 collision；search completeness MEDIUM。
- **论文整体原创性：CONDITIONAL PASS。** 有真实但窄的增量。
- **ICLR significance：BORDERLINE。** 技术深度与 open-problem value 足够进入认真讨论，但 breadth/assumption realism/correctness status 尚不足以称 CONVINCING。

## 14. 声明与署名

### 资历范围声明

本审计覆盖统计模型重建、semiparametric/orthogonal estimation、minimax 量词与 lower-bound 归属、empirical-process source transfer、public-information 结构、固定方差、prior-work collision、创新性和 ICLR 意义。方法包括全文/附录阅读、显式逻辑重写、精确 counterexample、原始定理对照、版本核查和公开多路径搜索。本报告是 AI-assisted audit，不虚构或声称任何人类学位、任职、机构、发表或审稿经历，也不替代独立人类完整 proof audit。

### 利益冲突声明

在允许的匿名材料和公开文献中未发现与作者、机构、资助方、竞争工作或引用作者的潜在冲突。AI 系统没有就业、财务、监督、私人关系或竞争投稿。需要去匿名化才能判断的身份相关冲突保持未知，未主动搜索作者身份。

### 独立性声明

未读取或利用作者内部审计报告、参考答案、已完成审计表、solution、reference report、其他专家/审稿人意见或非公开审稿记录。H1/H2 assigned packets 在 README 确认其 first-pass 性质后读取，但其中主张均由论文原文和原始文献独立复核。

### 检索限制声明

联网可用；覆盖公开 web search、arXiv、PMLR、Crossref、publisher/official pages、supplied primary PDFs 及 Robins et al. publisher-version PDF。未能穷尽 Google Scholar/商业数据库的完整 citation graph、付费墙材料、未公开投稿和未来索引。检索截止 2026-08-24；“未找到 collision”不等于不存在。

### 可验证署名

- Reviewer：**Expert S（AI-assisted independent model, literature and novelty audit）**
- 执行身份：**Codex AI assistant**
- 模型及版本：**GPT-5-based Codex；系统未提供精确 deployment version**
- 会话或任务 ID：**系统未向 reviewer 暴露**
- 完成日期和时间：**2026-08-24 14:09:49 +08:00（China Standard Time / Asia/Shanghai）**
- 文件 SHA-256：**见 `SHA256SUMS.txt`；最终 ZIP hash 见相邻 `.zip.sha256` 文件**
- 署名：**/s/ Expert S — AI reviewer；不是人类手写签名**
