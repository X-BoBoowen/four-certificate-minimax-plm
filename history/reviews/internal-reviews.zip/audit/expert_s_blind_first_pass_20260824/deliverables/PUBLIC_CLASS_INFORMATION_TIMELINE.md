# Public-class information audit and timeline

## What “public class” means here

The public object is not merely an abstract nuisance class. It includes a countable pointwise-dense Borel representation of each class, the exact four budgets, and the fixed regularity tuple. This supplies a searchable dictionary/representation and quantitative oracle bounds. The statistical truth need only be close to these classes; it is not revealed.

## Formal information timeline

1. **Problem specification:** fix `rho=(B_0,v_-,v_+,c_rad)`, half-sample size `n`, and budgets `(a,s,b,t)`.
2. **Outer public-pair choice:** the outer adversary selects a nonempty represented pair `Gamma_n=(G_mu,n,G_pi,n)` satisfying the budget/complexity conditions. The pair can depend on `rho,n,budgets`, but not on the realized sample.
3. **Rule design:** because the minimax order is `sup_Gamma inf_delta`, the learner may choose a Borel map `delta_Gamma` after seeing the entire representation and declared budgets, but before knowing the inner law.
4. **Inner law choice:** the adversary selects `P in P_{rho,n}(Gamma_n;a,s,b,t)`, including nuisance truths, `beta`, the constant `v`, covariate law, and residual distributions.
5. **Data generation:** `2n` i.i.d. triples are generated and split into two independent halves.
6. **Rule evaluation:** the already fixed map sees the public objects and realized data and returns an estimate; `E_P|delta_Gamma-beta(P)|` is computed.
7. **Minimax aggregation:** take `sup_P`, then the best rule for the fixed pair, then `sup_Gamma`.

## Two interpretations and consequences

| Interpretation | Criterion | Does the paper prove it? | Consequence |
|---|---|---|---|
| Represented-public-interface (the formal one) | `sup_Gamma inf_{delta_Gamma} sup_P` | Yes, conditionally on the two technical repairs. | Each pair may have a tailored estimator; lower witnesses may use different pairs. |
| Unknown-class/common-rule | `inf_delta sup_Gamma sup_P` | No. | Would require adaptation to an unknown representation and likely a different rate/complexity penalty. |

## Checklist

| Question | Finding | Verdict |
|---|---|---|
| Who chooses the class? | The outer minimax adversary. | PASS. |
| When is it fixed? | Before the rule and before the inner law/data. | PASS, but the narrative should say so explicitly. |
| May it depend on unknown truths or sample? | The admissible set is defined by existence of compatible truths, but the chosen public representation is fixed independently of realized data. It may depend on `n` and declared budgets. | CONDITIONAL PASS; clarify triangular-array status. |
| What does the learner know? | The full represented pair, `rho`, `n`, and exact `(a,s,b,t)`. | PASS; substantive oracle information. |
| Deterministic/random/data-dependent? | Deterministic in the formal risk; no data-dependent class is covered. | PASS. |
| Do all algorithms receive the same information? | Every candidate rule for a fixed pair receives the same public inputs; different pairs allow different rules. | PASS. |
| Is the lower adversary constrained by the same public information? | Yes; hard laws must be compatible with the announced pair and budgets. | PASS, except the (C.8) target-range violation. |
| Does it reveal support/dictionary/smoothness? | It can reveal all of these through the countable representation and budgets. | MAJOR significance limitation. |
| Is claimed adaptivity genuine? | No adaptivity claim is made; the Introduction explicitly excludes unknown-budget/computational goals. | PASS for honesty. |
| Are prior-work comparisons information-aligned? | Broadly aligned with Gu et al.'s outer public-class order, but not identical in envelopes, exact variance, representations, loss, and budget parameterization. | CONDITIONAL PASS; add a formal mapping table. |

## Independent judgment

The public-class convention is mathematically legitimate and useful for isolating statistical from computational difficulty. It nevertheless makes the model easier than ordinary unknown-structure learning. Any headline phrased as the minimax rate “for bounded PLMs” without the represented-public-pair qualifier would overgeneralize. The strongest safe language is: **a sharp outer minimax characterization conditional on a fully public, countably represented nuisance interface and known four budgets**.

