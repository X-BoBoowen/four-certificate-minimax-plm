# Literature search log

## Search boundary

- Search date: **2026-08-24**.
- Time range considered: earliest relevant classical work through 2026-08-24.
- Purpose: locate exact/near collisions for the model, rate, directional terms, upper architecture, lower constructions, and boundary phenomenon; verify citation versions and publication order.
- Exclusions: leaked reviews, author-internal materials, nonpublic submissions, identity/de-anonymization searches, blogs/AI answers as final evidence.

## Platforms and primary-source endpoints

| Platform | Use | Coverage/result |
|---|---|---|
| Web search (Bing-backed) | Phrase, synonym, theorem-structure, and DOI discovery. | No exact manuscript-title hit or exact O/P rate hit. |
| arXiv | Version dates and primary PDFs. | Verified `2305.04116`, `2402.14264`, `2507.02275`, `2512.17341`, `2606.06368`, `2607.21541`. |
| PMLR/COLT | Official open-problem paper. | Verified Gu (2025), PMLR 291:6220–6224. |
| Crossref | Bibliographic fields/DOIs. | Verified BBM, DML, Foster–Syrgkanis, Robins et al., Robinson records supplied in the packet. |
| Publisher/official pages | Stable publication evidence. | Project Euclid/VU publisher PDF for Robins et al.; Oxford Academic for DML; JSTOR issue metadata for Robinson; ICLR official criteria/calendar. |
| Supplied primary PDFs | Theorem-level comparison. | Read BBM Theorem 2.1; Gu et al. A.1; TAME Algorithm 1/Theorem 3.1/Cor. 3.2/Prop. 2.3; abstracts/theorem fields of other candidates. |

## Query log

| ID | Query/search path | Goal | Result |
|---|---|---|---|
| Q01 | exact title: `"Four-Budget Minimax Rates" partially linear models` | Find exact manuscript/public duplicate. | No exact public hit. |
| Q02 | `structure-agnostic partial linear model approximation stochastic minimax rate` | Older/alternate terminology. | Led to Gu open problem, Gu et al., TAME, Jin/Syrgkanis literature. |
| Q03 | exact algebra/phrases: `t(a∧t)`, `s(b∧s)`, and text equivalents | Find directional-term duplicates. | No exact earlier theorem located. |
| Q04 | `directional nuisance minimax semiparametric partially linear model` | Find differently named orientation phenomenon. | Related black-box/TAME work, no matching lower pair. |
| Q05 | `structure-agnostic minimax risk partial linear model lower bound` | Find model/risk matches. | Gu 2025, Gu et al. 2026, Jin/Syrgkanis candidates. |
| Q06 | `TAME semiparametric estimation two learner O branch R branch` | Identify ambiguous acronym/source. | Identified solo Gu arXiv:2607.21541 as the TAME source. |
| Q07 | citation-chain review of Gu et al., TAME, Gu open problem | Backward/forward neighborhood. | Balakrishnan et al.; Jin et al.; Jin/Syrgkanis; no exact O/P theorem found. |
| Q08 | `10.1214/09-EJS479 PDF`, title/DOI search | Obtain primary Robins et al. source. | Publisher-version PDF obtained via VU research portal; Theorem 2.1 and applications read. |
| Q09 | `ICLR 2027 reviewer guidelines` and official author dates | Select time-appropriate conference criteria. | Official review criteria and Sep. 2026 deadline located. |

## Candidate reading and exclusion log

| Candidate | Parts inspected | Why retained/excluded |
|---|---|---|
| Gu et al. 2026 | Full abstract/model; Appendix A.1, Theorem A.1, refs. | Retained as strongest inherited-lower overlap. |
| Gu TAME 2026 | Abstract; Prop. 2.3; Sections 3.1–3.3; Algorithm 1; Thm. 3.1; Cor. 3.2. | Retained as strongest upper overlap. |
| Gu COLT 2025 | Official PMLR paper. | Retained as problem-priority evidence, not a solution collision. |
| Balakrishnan et al. 2023/2025 | Abstract, model/contribution overview, citation context. | Retained as partial methodological overlap; excluded as exact PLM theorem collision. |
| Jin & Syrgkanis 2024/2025 PLM work | Abstract/theorem overview and version metadata. | Retained as public-lineage context; no exact directional four-budget theorem located. |
| Jin, Mackey & Syrgkanis 2025 | Abstract/contribution overview and version history. | Contextual noise-law work, not the same lower geometry. |
| Jin & Syrgkanis 2025/2026 general linear-functional lower bounds | Abstract/theorem overview. | Partial framework overlap; excluded as exact collision. |
| Robins et al. 2009 | Abstract, Theorem 2.1, applications, testing appendix. | Method source, not rate collision. |
| BBM 2005 | Theorem 2.1 in supplied author version. | Citation transfer, not novelty collision. |
| Robinson 1988; DML 2018; Foster–Syrgkanis 2023 | Bibliographic/primary overview. | Background/context, different theorem question. |

## Search limits

- Google Scholar's complete forward/backward graph and some commercial databases were not programmatically available.
- Semantic Scholar/OpenAlex were not exhaustively crawled; arXiv, PMLR, publisher, and supplied-source coverage was prioritized.
- Very recent July–August 2026 papers may not be indexed or cited yet.
- Paywalls limited full-text access to some classical papers, although stable metadata and the sources needed for the core claims were available.
- The manuscript has no located public record; nonpublic or simultaneous ICLR submissions cannot be searched and were not sought.
- Phrase searches cannot prove theorem absence under different notation.

## Completeness assessment

Confidence that the **identified closest works are genuinely close**: HIGH.  
Confidence that **no omitted direct collision exists anywhere**: MEDIUM.  
Therefore all positive novelty findings are **CONDITIONAL PASS**, never unconditional PASS.

