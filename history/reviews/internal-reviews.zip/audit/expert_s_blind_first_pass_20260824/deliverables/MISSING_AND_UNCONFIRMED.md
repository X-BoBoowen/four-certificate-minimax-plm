# Missing materials and unconfirmed items

## Missing from the permitted packet

| Missing item | Effect on audit |
|---|---|
| Actual submission timestamp / OpenReview identifier | Prevents definitive prior/concurrent/later classification relative to submission. The PDF date is used only as an artifact cutoff. |
| Earlier public manuscript versions or version history | Earliest public priority of this paper is unverified. |
| Source code referenced for Figure 1 | Not needed for the theorem/citation audit; prevents independent regeneration of the analytic figure from this packet. |
| A formal theorem mapping the new model to Gu et al. A.1 | Prevents unconditional attribution/model-containment PASS. |
| Independent complete mathematical proof report | This S-audit found exact model/proof defects and audited interfaces, but did not certify every constant in all appendices. |
| Human auditor identity/credentials | Intentionally absent; this report is explicitly AI-assisted and makes no human qualification claim. |

The packet did include the full anonymous manuscript/appendices, bibliography, blank forms, assigned H1/H2 packets, provenance/manifest files, and the primary PDFs needed for the central citation audit.

## Unconfirmed scholarly matters

- No exact earlier O/P lower theorem was located, but absence cannot be proven.
- Very recent or non-indexed 2026 work may not appear in search/citation graphs.
- Whether the exact finite O/P channels have appeared under different notation remains uncertain.
- Exact priority between a possible unpublished manuscript draft and June/July 2026 Gu sources is unknown; current evidence treats those sources as prior to the supplied artifact.

## Unconfirmed mathematical matters outside S scope

- Full independent verification of every likelihood-ratio/Gram/chi-square constant in Appendices C–F.
- The full Borel measurability proof after a proper covariate sample space is declared.
- Exact optimized constants after capping the Appendix C.3 root-`n` alternative.
- Extensions to heteroskedastic treatment residuals, unknown budgets, data-dependent classes, common estimators, or computationally constrained rules.

## Search/access limits

- Public internet access was available.
- arXiv, PMLR, official conference/publisher pages, Crossref, supplied primary PDFs, and an institutional publisher-version PDF were used.
- Google Scholar's complete citation graph, subscription databases, nonpublic peer-review systems, and private author records were not available and were not sought.
- Search was completed on 2026-08-24; later indexing or literature can change the collision assessment.

