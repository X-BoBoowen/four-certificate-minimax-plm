# Contribution–prior art–real increment matrix

## Standardized contribution claims

| ID | Problem/model/estimand | Assumptions/method | Claimed result | Searchable novelty statement |
|---|---|---|---|---|
| C1 | Bounded PLM coefficient under two public nuisance classes with four budgets | Constant treatment-residual variance; known budgets; countable representations; arbitrary Borel rules | Sharp outer minimax rate `q+AB+M+O+P` | four-budget structure-agnostic PLM minimax directional approximation/stochastic interactions |
| C2 | Same model | Finite Walsh mixtures and exact bounded channels | Necessity of `O=t(a wedge t)` and `P=s(b wedge s)` separately | directional lower bounds for nuisance approximation versus opposite stochastic resolution |
| C3 | Same model | TAME-derived O/R editing branches; deterministic public selector; fallback; countable near-minimization | Uniform fixed-pair upper bound over the full budget cube | measurable TAME interface closure for outer public-class minimax |
| C4 | Shared residual/treatment envelope | Support argument at `v_->B_0^2` and equality | Empty/interior/saturation phase split; root-`n` at saturation | variance-envelope saturation identifies propensity in bounded PLM |
| C5 | Lower-bound package | Native finite exact-variance witnesses for `q`,`ab`,`M`,`O`,`P` | Matching lower assembly under `sup_Gamma` | five independent public-pair lower mechanisms, max-to-sum outer assembly |

## Matrix

| Contribution | Closest prior art | What was already known | Real increment | Problem | Model | Theory | Technique | Concept | Practical value | Audit verdict |
|---|---|---|---|---|---|---|---|---|---|---|
| C1 full rate | Gu open problem (COLT 2025); Gu et al. A.1 (2026); TAME (2026) | Four-budget question publicly posed; `q+AB+M` lower and two upper branches publicly available before 2026-08-24. | Addition and matching necessity of O/P plus formal outer-interface assembly. | Medium-high | Medium | High if O/P proofs stand | Medium | Medium-high | Low-medium | CONDITIONAL PASS; strongest contribution. |
| C2 O/P lower | No exact earlier theorem located; TAME gives corresponding upper-direction algebra but not matching lower terms. | Directional upper benefits and generic fuzzy/dictionary methods. | Two different finite hard channels show each oriented term can dominate inherited lower envelope by unbounded ratios. | High within the narrow problem | Medium | High | Medium-high | High | Medium (informs which budget interactions matter) | CONDITIONAL PASS because collision search cannot prove absence. |
| C3 upper/interface | Solo Gu TAME Algorithm 1, Theorem 3.1, Cor. 3.2 | Editing/calibration, O/R branches, branch selection from known error bounds, and matching branch algebra. | Borel countable representation, first-within-tolerance fits, unsafe-cell fallback, all-zero/tie boundary closure, expected-risk uniformity. | Low | Medium | Medium | Low-medium | Low-medium | Low without computational construction | PASS attribution; incremental technical closure, not generic algorithm novelty. |
| C4 E/I/S boundary | Elementary support extremality; related papers use ordinary overlap/noise regimes | Variance bounded by squared envelope is classical. | Explicitly notices equality forces `pi_0=0` under the same `abs(u),abs(T)<=B_0` envelope and derives outer root-`n`. | Low | Low-medium | Medium | Low | Medium but model-artifactual | Low | CONDITIONAL PASS for significance, PASS for logic. |
| C5 `q`,`ab`,`M` native proofs | Gu et al. A.1; Robins et al.; Balakrishnan et al.; standard Le Cam/fuzzy/sparse dictionaries | All three rate mechanisms are known. | Exact-variance, bounded-envelope, public-pair-specific finite embeddings and explicit all-`n` splices. | Low | Medium | Low-medium | Medium | Low | Low | CONDITIONAL PASS; technical adaptation only. |

## Six-axis novelty assessment

1. **Problem novelty:** Medium. The exact four-budget PLM problem was explicitly open in Gu (2025), so the paper solves rather than invents it.
2. **Model novelty:** Low-to-medium. Countable public access and exact-envelope stratification are explicit, but known budgets and representations add oracle information; constant variance is inherited.
3. **Theoretical novelty:** High for O/P if correct and collision-free; low for `q`, `ab`, `M`; medium for the full matching phase diagram.
4. **Technical novelty:** Medium. Exact finite channels and directional cancellations are nontrivial, but the global toolkit is standard testing, Walsh dictionaries, localized Rademacher control, and a TAME upper method.
5. **Conceptual novelty:** Medium-high. The result refutes the sufficiency of “one error per nuisance plus product” within this model and exposes orientation.
6. **Practical/method significance:** Low-to-medium. It can guide theoretical budget bookkeeping, but gives no unknown-budget adaptation, computation, experiment, or heteroskedastic extension.

## Safe contribution statement

The defensible headline is:

> Conditional on a known four-budget, countably represented public nuisance interface and constant treatment-residual variance, the paper closes the previously open outer minimax characterization by adding two direction-specific lower mechanisms to the inherited `q+AB+M` envelope and matching them with a TAME-derived measurable upper construction.

The phrases “new minimax theory for bounded PLMs,” “new TAME estimator,” or “new `ab`/`M` lower bounds” would be too broad.
