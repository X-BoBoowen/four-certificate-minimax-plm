# Source-diff audit

Audit target: Master-R13 and Candidate-C11 against the immutable Master-R12 and Candidate-C10 parents.

## Result

PASS. Each successor has the same 34-file non-build inventory as its parent. The two successors are byte-identical over all 34 non-build files, with aggregate SHA-256 `22615E597F5B629471F76DAD8528A245D21F40520382BD5C156E3CB16B7A9038`.

Exactly 14 non-build paths differ from each parent:

- `main.tex`;
- `appendices/A_model_quantifiers.tex`;
- `appendices/C_q_p_lower.tex` under Amendment 3's exact one-sentence cross-reference repair;
- `appendices/G_lower_assembly_constants.tex`;
- `appendices/I_assumptions_measurability.tex`;
- `appendices/J_proof_audit.tex`;
- `appendices/K_proof_location_index.tex`;
- `appendices/L_same_pair_lower.tex`;
- `ASSUMPTION_LEDGER.md`;
- `CITATION_LOCATION_INDEX.md`;
- `MANUSCRIPT_CLAIM_LEDGER.md`;
- `MASTER_R8_QA.md`;
- `PROOF_LOCATION_INDEX.md`;
- `references.bib`, only within `jin2025hardnormal`.

The Appendix C difference is exactly the registered replacement of the stale “other four subfamilies” cross-reference by active-native/common-q wording. Its formulas, laws, rates, constants, and proof steps are otherwise byte-identical.

## Preserved boundaries

Theorem 1's complete block, headline rate, Proposition 2 and Proposition 3 inequalities, Q1/M1 quantifier order, model and variance field, learner information, estimator and tuning, Appendix B, native lower formulas, boundary result, title, figures, data, and approved AI-use statement pass exact token or byte-preservation checks. The canonical bibliography differs from its frozen baseline only inside `jin2025hardnormal`; the cite key, authors, and title bytes remain unchanged.

The targeted validator passes `181/181` after having produced the preregistered red result `9/65` on Candidate-C10.
