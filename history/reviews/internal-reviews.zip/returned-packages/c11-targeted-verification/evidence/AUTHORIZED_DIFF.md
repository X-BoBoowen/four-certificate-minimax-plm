# Authorized diff

Frozen `2026-08-29T17:23:50.8426845+08:00`.

## Manuscript text

Only these existing files may differ scientifically from each R12/C10 parent, and only for the six listed repairs or necessary ledger synchronization:

- `main.tex`
- `appendices/A_model_quantifiers.tex`
- `appendices/C_q_p_lower.tex`
- `appendices/G_lower_assembly_constants.tex`
- `appendices/I_assumptions_measurability.tex`
- `appendices/J_proof_audit.tex`
- `appendices/K_proof_location_index.tex`
- `appendices/L_same_pair_lower.tex`
- `ASSUMPTION_LEDGER.md`
- `MANUSCRIPT_CLAIM_LEDGER.md`
- `PROOF_LOCATION_INDEX.md`
- `CITATION_LOCATION_INDEX.md`
- `MASTER_R8_QA.md`
- `references.bib`, but only the `jin2025hardnormal` entry

Build products may change through a clean rebuild. No source inventory change is authorized.

## Canonical bibliography

`literature/references.bib` may change only inside `jin2025hardnormal`. The cite key, authors, and title identity are preserved; proceedings fields follow the official NeurIPS export. Every byte outside this entry is frozen.

## Forbidden diff

All other manuscript sources, especially `macros.tex`, Appendix B, native lower Appendices D--F, Appendix H, templates, figures, scripts, and data, must remain byte-identical to the parents. Historical manuscript trees and historical evidence are immutable.

## Amendment 3 — 2026-08-29T17:41:21.9648971+08:00

The independent pre-build hostile audit found one surviving unqualified cross-reference in Appendix C: it said that Appendix L embeds a P witness and “the other four subfamilies,” although the frozen repair requires inactive component inequalities to reuse the common q splice rather than asserting five distinct law families. The original six-part authorization explicitly applies the active/inactive/common-q distinction across all TeX and ledgers. Accordingly, one exact sentence in `appendices/C_q_p_lower.tex` is added to the authorized surface solely to state that active native families are embedded while inactive component inequalities reuse the common q splice before the fixed-pair maximum. No formula, construction, rate, constant, theorem, assumption, or proof step in Appendix C may change.
