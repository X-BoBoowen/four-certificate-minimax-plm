# Regression report

## Successor-specific gate

The C11 validator passes `181/181`. It covers both successor trees, their parent diffs, pairwise source/PDF identity, centralized indexed-law definition, active/inactive/common-q semantics, exact q mass and moment certificate, fixed `rho` constant dependency, bounded Gu/TAME positioning, budget terminology, bibliography-entry isolation, theorem/formula preservation, and the author-approved AI disclosure.

## Frozen historical suites

Fresh execution gives:

- historical aggregate: `299/301`;
- C8 event/source/mutation suite: `140/141`;
- selector integration suite: `81/82`;
- constant-DAG parser: `3/3`, with live R13 and C11 DAGs both acyclic;
- exact-boundary diagnostics: `0` failures;
- submission-compliance suite: `45/45`;
- C10 author-sign-off finalization: PASS.

Applied directly to the successor with its version-specific page/format mode, the frozen submission validator passes `31/33`: every format, page-10-start, PDF, anonymity, and equivalence gate passes. Its only two failures are the obsolete pre-author-sign-off assertions that require the superseded “independent human verification pending” sentence. The C10 author-sign-off validator and the C11 successor validator instead require and pass the PI-approved responsibility statement.

The four raw failures are one repeated version-lock diagnostic: frozen historical scripts require the pre-revision canonical bibliography SHA-256 `B2E428B79BC5E8C6F2984BFE747E7583DE0DDAA787A3C3C7B865097DF8CC0B37`, while this authorized successor has `1B689A58645CC258B552B5C815E33CC4B69C16183ED4BCFD210A7F54A6847D41`. No frozen script was edited or waived. Every non-bibliography historical gate passes, and the successor validator independently proves that only `jin2025hardnormal` changed and that its authorized metadata fields are exact.

Tests are corroborating evidence and do not replace the source, proof, claim-boundary, or visual audits.
