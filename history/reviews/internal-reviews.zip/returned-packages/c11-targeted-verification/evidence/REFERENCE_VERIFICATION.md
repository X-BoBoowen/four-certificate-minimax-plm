# Official reference verification

Frozen `2026-08-29T17:23:50.8426845+08:00`.

The official NeurIPS paper record identifies Jin, Mackey, and Syrgkanis, the title *It’s Hard to Be Normal: The Impact of Noise on Structure-agnostic Estimation*, volume 38 Main Conference, and DOI `10.52202/085713-5477`:

- `https://proceedings.nips.cc/paper_files/paper/2025/hash/f0156a82b6af6a4e838923ce9c124424-Abstract-Conference.html`
- official BibTeX export: `https://proceedings.nips.cc/paper_files/paper/32142-/bibtex`

The official export supplies booktitle `Advances in Neural Information Processing Systems`, volume `38, Main Conference`, pages `164176--164245`, publisher `Curran Associates, Inc.`, and the official paper URL. These fields control the authorized entry update. The arXiv identifiers may remain auxiliary.

Audit caveat: the Curran DOI landing page currently displays a different pagination (`182086--182155`). This record does not claim cross-source agreement; it follows the PI-specified and NeurIPS-exported pagination.
