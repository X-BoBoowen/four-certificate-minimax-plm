# Targeted Review Scope

This package authorizes only a main-reviewer verification of the following six Candidate-C11 revisions:

1. Corrected same-public-pair wording and mechanism accounting.
2. Centralized definition of `\mathcal P_{\rho,n,a,s,b,t}(\Gamma)`.
3. Appendix L three-point `q` law.
4. Bounded Gu/TAME prior-work positioning.
5. Terminology: “known pre-data upper certificates”.
6. NeurIPS 2025 metadata for `jin2025hardnormal`.

It does not authorize a full-manuscript re-review, new research, new theorems, submission, upload, or public release. No expected verdict is supplied.

- Controlling commit: `483cf004283dc38ca92fed2daf96a4d2c46d0e58`
- Parent commit: `bc081497c8adb9c5534248948c828c8a6b142999`
