# Project Claim Ledger

## PLM-MIXED-LB-P1 claims

| Claim | Status | Evidence boundary |
|---|---|---|
| Frozen asymmetric Core lower `rho^2/512` | **Validated** | Exact public-class membership, legal binary PLM family, two exact mixture derivations and Le Cam/minimax audit |
| Matching rate `n^-1/2+rho^2` on the certified range | **Validated** | P1 lower plus source-exact Appendix A.1 upper and source parametric lower; lower bounds combined by maximum |
| Material distinction from inspected anchored/shared-radius theorems | **Certified for this audit** | No executable reduction without a new public-class/`H_n` interface lemma |
| A new fuzzy-hypothesis method | **Withdrawn / unsupported** | Fuzzy latent-sign/product-error mechanisms have clear primary-work ancestors |
| Direct or routine prior-work collision | **Not established** | Field-level reduction attempts fail for specific access, budget and quantifier reasons; search non-hit is not evidence |
| Mirror mixed face | **Unproved and unauthorized** | No construction, theorem or proof created in P1 |
| Full four-budget characterization | **Unsupported** | P1 controls one orientation only |
| General anchored-neighborhood to public-`H_n` reduction | **Unsupported** | P1 gives one explicit family, not a general reduction theorem |
| Standalone ICLR paper floor | **Failed in this round** | One oriented face plus inherited proof architecture lacks a unified structural contribution |
| Idea, Program, abstract or paper status | **None** | All counts and credits remain zero |

The words `first`, `novel`, `unprecedented`, `ICLR-ready`, and `full
characterization` are not authorized descriptions of P1.

## PLM-4B-CHAR-K2 claims — superseding active allocation record

| Claim | Status | Evidence boundary |
|---|---|---|
| Global O cross lower `t(a wedge t)` | **Validated** | exact public classes, PLM law, two second-moment derivations, TV/minimax embedding |
| Global P cross lower `s(b wedge s)` | **Validated** | independent propensity-approximation construction with residual-variance safety factor |
| Unified lower `q+AB+M+O+P` | **Validated** | source and oriented lower bounds combined through maximum, then finite nonnegative sum |
| Global algebra `V asymp AB+M+O+P` | **Validated** | analytic constants `1/5` and `6`; six exhaustive regimes and boundary audit |
| Global four-budget minimax characterization | **Not promoted; upper proof superseded by R1** | lower package and algebra remain valid, but the frozen R1 exact-score selector has a certified denominator-degenerate D counterexample |
| Positive-thickening robustness | **Validated** | unchanged families on `(a,epsilon;0,t)` and `(0,s;b,epsilon)` with explicit positive sequences |
| Direct/routine collision | **Not found in directed theorem audit** | executable field-level reductions fail; upper ancestry is explicitly credited; search non-hit gives no novelty credit |
| New estimator or new fuzzy method | **Not claimed** | TAME supplies the upper; fuzzy/Walsh/Le Cam architecture is inherited |
| Formal Idea/Program | **Formal Idea approved at 55%; Program not approved** | PI approved the Idea, conditional on a complete global upper; R1 did not satisfy that condition |
| Abstract, manuscript or paper | **Unauthorized / none** | K2 did not write or authorize these artifacts |

Authorized description: `capacity-truncated four-budget characterization
signal`. The words `first`, `novel`, and `priority` remain unauthorized.

## PLM-4B-UPPER-R1 claims — controlling upper-proof audit

| Claim | Status | Evidence boundary |
|---|---|---|
| Appendix-to-HCS threshold bridge | **Validated at rate level** | exact all-radii inequality; threshold enters quadratically as `O(q)` |
| Uniform initial ERM lemma | **Conditional only** | analytic proof needs a measurable-class/selector interface not stated by Appendix A.1 |
| TAME O/R global expected-L1 reductions | **Conditional statement-level reductions** | exact Theorem-3.1 substitution and tail integration; public v1 generic proof/explicit tuning interval absent |
| O-versus-R budget branch | **Validated** | factor-two deterministic inequality |
| Frozen A/D/O/R selector | **Refuted** | rational singleton class pair uniquely selects D with identically zero moment and constant coefficient error |
| Global minimax characterization false | **Not established** | the counterexample is estimator-specific; A is constant-factor safe on the exhibited cell |
| Formal Idea | **Approved and retained at 55%** | PI decision D-0196; R1 does not revoke Idea status |
| Program | **Not approved** | complete publication-grade global upper remains missing |
| New estimator, experiment, abstract, manuscript, paper | **Unauthorized / none** | outside R1 scope |

## PLM-4B-UPPER-R2 claims — controlling TAME-only audit

| Claim | Status | Evidence boundary |
|---|---|---|
| `V<=W<=4V` and A/D rate redundancy | **Validated** | complete analytic case proof; grid is falsifier only |
| Public O/R selector | **Validated** | selected target at most `2W` on the full budget cube |
| Constant fallback | **Validated** | explicit, exhaustive O and R partitions using `q`, `M`, `O`, or `P` |
| Appendix-to-HCS bridge | **Validated** | repaired radius `4(r vee h_n)`, quadratic threshold accounting |
| Initial-fit lemma | **Conditional on declared source-compatible measurable oracle** | localized basic inequality, joint curvature, nonconvex classes and tolerance audited |
| TAME O/R expected-L1 rate | **Valid conditional on Theorem 3.1 statement** | exact Layer-S substitutions and independent tail lift |
| Independent restricted O/R proof | **Incomplete** | structural proof reconstructed, but frozen numerical 64/`1/64` constants not closed uniformly |
| R1 counterexample safety | **Validated at branch/regression level** | R2 routes to O, never D; exact singleton calculation and automated regression |
| Exact counterexample to R2 selector/fallback | **Not found; not inferred absent** | non-hit gives no theorem credit |
| Global four-budget minimax characterization | **Not promoted** | missing unconditional Layer-I upper theorem |
| Formal Idea/Program | **Formal Idea retained at 55%; Program not approved** | Terminal B does not meet the Program gate |
| Experiment, abstract, manuscript, paper | **Unauthorized / none** | outside R2 scope |

Authorized R2 description: `TAME-only global rate reduction conditional on
the public oracle theorem`. The words `fully proved`, `validated global
characterization`, `first`, and `novel` are not authorized.

## PLM-4B-UPPER-R3 claims — controlling final O/R completion record

| Claim | Status | Evidence boundary |
|---|---|---|
| Symbolic constant DAG | **Validated** | finite topological recursion; no constant depends on budgets, `P` or a class instance; no backward choice |
| Independent O oracle proof | **Validated under M1** | exact normalization, separate outcome-class calibration, conditional noise and expected-risk lift; no TAME-Theorem-3.1 proof substitution |
| Independent R oracle proof | **Validated under M1** | two-sample comparator, conditional independence, propensity calibration and denominator expansion separately proved |
| Measurable estimator | **Validated under M1** | countable first-within-tolerance ERMs and continuous finite-dimensional rational programs are Borel |
| M1 equivalent to literal arbitrary set-valued classes | **Not established** | arbitrary classes need not be separable or analytically coded; outer probability does not create a selector |
| Global upper `q+X` | **Validated only under explicit M1 restriction** | O/R, selector, fallback, tail and minimax chain close for M1 class pairs |
| Original unrestricted four-budget characterization | **Not promoted** | upper does not cover the literal arbitrary-class outer quantifier |
| K2 lower package | **Unchanged / validated** | finite lower families remain M1 and no K2 file was modified |
| Formal Idea/Program | **Formal Idea retained at 55%; Program not approved** | Terminal B fails the frozen original-model coverage gate |
| Experiment, abstract, manuscript, paper | **Unauthorized / none** | outside R3 scope |

Authorized R3 description: `analytic matching upper and characterization
under an explicit pointwise-measurable/separable class convention`. An
`unconditional original-model characterization`, novelty, priority, Program,
or paper claim is not authorized.

## PLM-4B-PROGRAM-F0 claims — controlling Program and paper-floor record

| Claim | Status | Evidence boundary |
|---|---|---|
| M1 four-budget minimax law `m_M1 asymp q+AB+M+O+P` | **Validated** | R3 M1 upper and K2 finite M1 lower families match under the same native model and quantifiers |
| O/P capacity-truncation mechanisms | **Validated and directionally independent** | Separate lower constructions; dropping O or P causes an explicit polynomial rate error; positive thickening excludes a zero-face artifact |
| M1 is the formal model convention | **Adopted and disclosed** | Fixed countable pointwise-dense measurable representation and Borel approximate selectors; no equivalence claim for uncoded nonseparable classes |
| Direct or routine primary-theorem collision through 2026-08-14 | **Not identified** | Full-text theorem-field comparison covers the source paper, TAME, anchored structure-agnostic lower bounds, and adjacent semiparametric work; non-hit gives no priority credit |
| ICLR paper floor | **Cleared** | Complete matching characterization, non-obvious regime transition, ML interpretation and no unresolved reject-level flaw under the frozen F0 criteria |
| Formal Idea / Formal Program | **1 / 1** | PI approved the Program at 65%; F0 advances the post-terminal state to 70% |
| Novelty priority, `first`, or uniqueness | **Not claimed; credit 0** | Collision audit is not a priority proof |
| Adaptive budget selection or unknown-budget guarantee | **Not established** | Budgets/class indices are public in the formal model |
| Literal arbitrary-class theorem | **Not established** | M1 is a real, explicitly adopted convention |
| Experiment, figure, abstract, manuscript or paper | **Unauthorized / none** | F0 is a formalization, novelty-audit and paper-floor review only |

Authorized F0 description: `matching M1 four-budget minimax characterization
with two direction-specific capacity truncations`. Controlling terminal:
`PROGRAM CLEARS NOVELTY AND ICLR PAPER FLOOR`.

## PLM-4B-PAPER-ARCH-A0 claims — controlling paper-architecture record

| Claim | Status | Evidence boundary |
|---|---|---|
| One paper-level scientific claim | **Frozen** | matching M1 four-budget minimax characterization; no second headline contribution |
| Controlling story | **Frozen as phenomenon-first** | product-rate intuition misses an opposing-capacity barrier; O/P threshold laws precede the full formula |
| Unique claim hierarchy | **Validated for architecture** | matching law -> capacity phenomenon -> native O/P lower evidence -> measurable upper closure -> bounded consequence/limits |
| TAME/Gu attribution | **Required before contribution inflation can occur** | Gu owns the native four-budget formulation/inherited bracket; TAME owns the closest O/R upper architecture |
| Theorem presentation | **Frozen** | two truncation laws first, named components second, full characterization third; O and P have independent theorem/proof roadmaps |
| Official target-cycle layout | **Verified for ICLR 2027** | 9-page main-text cap; references excluded; appendix not required reading; double-blind scope includes supplementary text |
| Figure/table package | **Architecture-approved only** | main-text mechanism schematic, regime table and prior-work table; Figure 2 appendix by default; no artifact produced |
| CPU synthetic experiment | **NOT NEEDED** | an experiment would only evaluate the proved analytic rate and is not an evidence gate for the exact theorem |
| Architecture reviewer red team | **Passed** | theorem, novelty/attribution and readability reviewers plus Area Chair identify no architecture-level blocker |
| Paper architecture terminal | **Terminal A** | `PAPER ARCHITECTURE CLEARS CLAIM, ATTRIBUTION, AND ICLR READABILITY GATES` |
| Formal Idea / Formal Program / frozen Architecture | **1 / 1 / 1** | A0 advances the controlling state to 75%; architecture is complete and inactive |
| Novelty priority, `first`, uniqueness or new-upper credit | **Not claimed; credit 0** | F0/A0 collision work is not priority proof; inherited methods remain ceded |
| Abstract, Introduction prose, manuscript, LaTeX, proof prose, figure, experiment or submission artifact | **Unauthorized / none** | A0 designed architecture only; all active and artifact counts remain zero |

Authorized A0 description: `phenomenon-first architecture for the matching M1
four-budget minimax characterization, centered on two native
opposing-capacity lower mechanisms`. Controlling progress:
`75% — PAPER ARCHITECTURE FROZEN; MANUSCRIPT DRAFTING MAY BE AUTHORIZED BY PI`.
No manuscript drafting begins automatically.

## PLM-4B-FULL-MASTER-M0 claims — controlling manuscript record

| Claim | Status | Evidence boundary |
|---|---|---|
| M1 four-budget minimax law `m_M1 asymp q+AB+M+O+P` | **Proved and fully integrated** | Theorem 3.1 and Appendix B; complete lower Appendices D--F and upper Appendix C in the compiled master |
| O term `t(a wedge t)` | **Proved** | independent native finite hard family, exact mixture/testing audit, boundary branches and positive thickening |
| P term `s(b wedge s)` | **Proved independently** | separate class placement, label-dependent contraction and residual-variance legality; not a symmetry corollary |
| Source `q+AB+M` lower | **Attributed dependency** | Gu et al. Appendix Theorem A.1; not re-proved or credited as a manuscript contribution |
| Matching O/R upper | **Proved under M1; architecture ceded** | complete O/R calibrations, selector, fallback, tail lift and Borel implementation; TAME owns the closest editing architecture |
| Complete technical manuscript | **Validated** | 19-page anonymous English master, full appendices, analytic figure, two tables, AI-use and reproducibility statements |
| Proof, claim, citation and notation traceability | **Validated** | dedicated master ledgers/indices and append-only proof-import verification |
| Four hostile/internal manuscript reviews | **Passed** | technical, attribution, readability and Reviewer-2 reports identify no M1 reject-level scientific flaw |
| Official ICLR 2027 archive use | **Not claimed / unavailable at audit time** | advertised archive returned 404; latest official 2026 style is transparently used as a temporary basis and must be replaced before a cut |
| Novelty priority, `first`, uniqueness or new-upper credit | **Not claimed; credit 0** | cutoff-relative noncollision is not priority evidence; fresh literature audit required before submission |
| Unknown-budget adaptation, arbitrary uncoded classes, polynomial time, practical superiority or general functional theorem | **Not established and not claimed** | explicit limitations in main text and manuscript claim ledger |
| CPU synthetic experiment | **NOT NEEDED / not run** | figure evaluates the analytic rate only |
| Formal Idea / Program / architecture / full master | **1 / 1 / 1 / 1** | M0 closes at 80%; no conference cut or submission artifact is active |

Authorized M0 description: `full technical master for the matching M1
four-budget minimax characterization, with two independent opposing-capacity
lower mechanisms and a TAME-attributed matching upper closure`.

Controlling terminal:
`FULL TECHNICAL MASTER COMPILED AND SCIENTIFICALLY AUDITED`.
Controlling progress:
`80% — FULL TECHNICAL MASTER COMPLETE; ICLR DISTILLATION MAY BE AUTHORIZED`.
No ICLR distillation begins automatically.

## PLM-4B-FULL-MASTER-R1 claims — controlling corrected-master record

| Claim | Status | Evidence boundary |
|---|---|---|
| M1 four-budget minimax law `m_M1 asymp q+AB+M+O+P` | **Unchanged / proved** | 14 theorem-like, 9 proof, and 97 display-math environments are byte-identical to M0 |
| Primary contribution | **Rebalanced and frozen** | matching law, two native directional lower mechanisms, opposing-capacity phase phenomenon |
| O/R upper | **Supporting closure; architecture fully attributed** | Abstract, Introduction, bullets, §5, Related Work, Discussion, Conclusion, and table consistently cede TAME-style editing |
| M1 named-class examples | **Corrected** | only encoded separable subclasses satisfying measurable evaluation, countable density, pointwise approximation, and domination are offered |
| Literature coverage | **Passed** | 19 actual primary-source keys cover 11/11 required lineages; no citation padding |
| Reference fields | **Passed** | 18 VERIFIED, one noncritical WARNING for unavailable Yu et al. page numbers, zero unresolved NEEDS FIX/critical UNVERIFIABLE |
| Current-version collision | **Not found under frozen test** | live arXiv/OpenReview histories and full-text theorem comparison through 2026-08-14; search non-hit gives zero novelty credit |
| Official ICLR 2027 template | **Verified and used** | official ZIP URL, HTTP 200, archive/style/BST hashes recorded; anonymous unlimited-page master |
| PDF and visual QA | **Passed** | 21 pages; zero errors/undefined citations/references/duplicate labels/overfull boxes; all pages rendered and inspected |
| Novelty priority, `first`, uniqueness, or new-upper credit | **Not claimed; credit 0** | R1 is attribution/context repair, not a priority proof |
| Unknown-budget adaptation, arbitrary uncoded classes, polynomial time, or broad NN coverage | **Not established and not claimed** | limitations remain explicit |
| ICLR distillation / nine-page artifact | **Not authorized / none** | separate PI gate required; no `paper/iclr2027/` created |

Authorized R1 description: `corrected full technical master for the matching
M1 four-budget law, with primary credit on the two native opposing-capacity
lower mechanisms and an attributed O/R supporting closure`.

Controlling terminal:
`MASTER-R1 CLEARS LITERATURE, ATTRIBUTION, AND OFFICIAL-TEMPLATE GATES`.
Controlling progress:
`80% — CORRECTED FULL MASTER READY; ICLR DISTILLATION MAY BE AUTHORIZED`.

## PLM-4B-Q1-PROOF-CLOSURE-R1 claims — controlling proof-certification audit

| Claim | R1 status | Evidence boundary |
|---|---|---|
| Q1 pair-indexed minimax is well-defined for each fixed nonempty M1 pair | **Proved** | `sup_Gamma inf_{Borel delta_Gamma} sup_P`; no cross-pair selector |
| Q1 matches Gu et al. (A.2) quantifier order | **Proved** | source estimator is tailored to the fixed public class pair |
| Candidate-C0 common untagged estimator is equivalent to Q1 | **False / withdrawn** | learner information and infimum/supremum order differ materially |
| Full Q1 upper characterization | **Not certified** | U01--U24: 9 proved, 15 unresolved, 0 refuted |
| Master concentration and joint initial fits | **Partially proved / unresolved** | curvature and joint localization pass; full simultaneous multiplier/quadratic event absent |
| O upper expected-risk oracle inequality | **Unresolved** | comparator denominator passes; calibration and tail family do not close |
| R upper expected-risk oracle inequality | **Unresolved** | denominator and exact numerator inventory pass; two-sample calibration does not close |
| Inherited Q1 lower | **Unresolved** | quantifier order matches; full M1 hard-pair and variance transfer absent |
| O/P lower under their existing fixed pairs | **Q1/M1 logic passes conditionally** | arbitrary frozen variance-interval membership is not established |
| Full matching four-budget Q1 law | **Not certified and not refuted** | both upper and lower have independent unresolved obligations |
| New assumption, changed rate, or transfer impossibility | **Not established** | Terminal B, C and D lack complete certificates |

Controlling R1 terminal:
`Q1 PROOF-CLOSURE INCONCLUSIVE — RETURN TO PI WITHOUT CREDIT`.
Formal progress remains `85%`; Candidate-C1, manuscript revision, proof
continuation, experiment, upload and submission remain unauthorized.

## PLM-4B-Q1-UPPER-K0 claims — simultaneous-calibration certificate

| Claim | K0 status | Evidence boundary |
|---|---|---|
| Complete R forward term inventory | **Proved complete at K0 scope** | I01--I06 and R01--R18 traced from initial fits, R objective, denominator and numerator |
| D2 outcome empirical-process event | **Proved** | centered `xi f` plus fixed `m0f`, uniformly over represented `Delta G_pi` |
| D1 treatment/covariate event | **Proved** | nested conditioning preserves treatment centering |
| Simultaneous two-sample event | **Proved for every registered `z`** | finite confidence allocation and tower-property deconditioning |
| Product/joint class assumption | **Not needed** | every actual class process has only one varying function index |
| U05/U06 for actual R terms | **Proved** | each multiplier/quadratic row explicitly instantiated |
| U15/U16/U17 | **Proved** | comparator, objective comparison, uniform calibration and fitted substitution |
| Extra deterministic rate term | **None** | explicit `delta_z/sqrt(lambda_R)` and tolerance tails integrate into existing terms |
| Legal M1 falsifier | **Analytically excluded** | uniform-supremum dominance rules out D2 selection amplification |
| Complete Q1 upper or characterization | **Not claimed** | O/global tail/selector and independent lower obligations remain outside K0 |

Controlling K0 terminal:
`SIMULTANEOUS TWO-SAMPLE CALIBRATION PROVED UNDER FROZEN M1`.
This is a scoped proof-correctness signal with zero novelty, Candidate-C1,
manuscript or submission credit. Formal progress remains `85%`.

## PLM-4B-Q1-R-ORACLE-K1 claims — controlling R-branch certificate

| Claim | K1 status | Evidence boundary |
|---|---|---|
| Frozen Q1/M1 R-safe estimator | **Preserved exactly** | R3 split, M1 fits/edit, tuning, floor, clipping and public branch unchanged |
| U01/U02 on R-safe cells | **Proved all-z** | deterministic/base radii dominated by `d_all`; `sqrt(z/n)` retained for arbitrary confidence |
| U18 | **Reproved** | empirical residual denominator, approximation cross terms, upper control and truncation complement |
| U19 | **Reproved algebraically** | six signs derived directly from the frozen numerator and denominator |
| Complete R numerator | **Proved complete** | N01--N10 one-use ledger; calibration/fixed-comparator split explicit |
| Complete all-z tail | **Proved** | includes `d sqrt(z/n)`, `bd sqrt(z/n)/bar t`, `d z/(n bar t)` and cubic confidence |
| U20/U21 expected-L1 R oracle | **Proved** | actual tail integrated term by term; every contribution enters `q+bx+y^2` |
| New deterministic rate, assumption or retuning | **None** | frozen constants/tuning unchanged; zero additions |
| Unique falsifier | **Analytically excluded** | exact rational grid is diagnostic only; uniform inequalities decide |
| O/U23/global upper/lower/full characterization | **Not claimed** | outside K1 and still uncertified here |
| Novelty, Candidate-C1, manuscript or submission credit | **Zero** | proof-correctness certificate only |

Controlling K1 terminal:
`Q1 R-BRANCH EXPECTED-L1 ORACLE BOUND CERTIFIED`.
Formal progress remains `85%`; no continuation is automatic.

## PLM-4B-Q1-O-ORACLE-K2 claims — controlling O-branch certificate

| Claim | K2 status | Evidence boundary |
|---|---|---|
| Frozen Q1/M1 O-safe estimator | **Preserved exactly** | R3 split, M1 fits/pivot edit, `d_pi`, `lambda_O`, `v_-/2` floor, tolerance, fallback, clipping and tie unchanged |
| Borel estimator on every sample | **Proved** | Borel largest-magnitude pivot, dense rational nonpivot chart, countable first-within-`tau_n` selection, zero fallback |
| Exact normalization | **Proved** | `H_mu(a)<infinity` iff `P_1(Ta)=1`; every selected feasible vector satisfies equality exactly |
| Hyperplane nonemptiness/failure | **Proved** | nonempty iff `T_{1:n}!=0`; all-zero probability exponentially small under `E T^2>=v_-` |
| Initial propensity fit | **Proved all-z** | natural `y+bar t` radius is related analytically to frozen `y+bar s`; `sqrt(z/n)` retained |
| Oracle versus fitted denominator | **Separated and proved** | `D_O`, `hat D_O`, and `tilde D_O` distinct; active/inactive floor covered by one-Lipschitz projection |
| O objective/calibration | **Proved** | full `(bar s+sqrt(z/n))/sqrt(lambda_O)` confidence amplification retained; fitted substitution follows uniform event |
| Exact O numerator | **Proved complete** | five additive terms plus one-use structural/failure ledger |
| Complete all-z tail | **Proved** | includes `ad`, `d sqrt(z/n)`, `ad sqrt(z/n)/bar s`, `d z/(n bar s)`, quadratic/cubic confidence and tolerance |
| Expected-L1 O oracle | **Proved** | termwise layer cake and thirteen boundary regimes give `q+a(b+t)+(a+s)^2` |
| New deterministic rate, assumption or retuning | **None** | frozen constants and interface unchanged; zero additions |
| Unique falsifier | **No certified counterexample** | exposes naive `Q^n` shorthand defect; current pivot M1 analytically resolves it; numerical non-hit has no proof status |
| TAME dependence | **Interface-audited; theorem not invoked** | source exact-argmin/high-probability shorthand does not replace the Q1/M1 proof |
| Global selector/lower/variance/Candidate-C1/manuscript | **Not claimed or authorized** | outside K2 |
| Novelty, paper, experiment or submission credit | **Zero** | scoped proof-correctness certificate only |

Controlling K2 terminal:
`Q1 O-BRANCH EXPECTED-L1 ORACLE BOUND CERTIFIED`.
Formal progress remains `85%`; no continuation is automatic.

## PLM-4B-Q1-GLOBAL-UPPER-K3 claims — controlling global upper certificate

| Claim | K3 status | Evidence boundary |
|---|---|---|
| Frozen public four-cell estimator is Borel for each fixed `Gamma` | **Proved** | certified Borel O/R maps, public constant predicates, zero fallback, continuous clipping |
| O-safe/O-unsafe/R-safe/R-unsafe form an exact partition | **Proved** | ties assigned O; safe equalities eligible; zero and `n=1` boundaries audited |
| Safe-cell global risk | **Proved** | O-K2 and R-K1 imported only on their respective certified cells |
| Prompt shortcut `h<=eta/C_rad` and unsafe implies `s>eta/C_rad` | **False / not used** | scale mismatch exposed by analytic falsifier; mirror also invalid |
| Unsafe zero fallback | **Proved under unchanged rule** | proof-only split at `h=(eta/C_rad)/2`; `q` pays upper subrange, `X` pays lower subrange |
| Public selector algebra | **Proved** | `T_selected<=2W` without division, including ties and zeros |
| Envelope algebra | **Proved** | `V<=W<=4V`, `X/5<=V<=6X`, hence `W<=24X` |
| Fixed-pair global expected-L1 upper | **Proved** | four-row assembly gives `sup_P risk<=C(q+X)` |
| Frozen Q1 minimax upper | **Proved** | explicit estimator for each `Gamma`, then `inf` comparison and outer `sup`; no quantifier exchange |
| New assumption, selector change, retuning, or rate leak | **None** | all change counts zero; constants depend only on frozen regularity tuple |
| Matching lower/four-budget characterization | **Not certified** | lower/variance-embedding side remains incomplete and outside K3 |
| Novelty, Candidate-C1, manuscript, experiment or submission credit | **Zero** | scoped upper-correctness certificate only |

Controlling K3 terminal:
`Q1 GLOBAL EXPECTED-L1 UPPER BOUND CERTIFIED`.
Formal progress remains exactly `85%` pending PI reevaluation; no lower or
manuscript continuation is automatic.

## PLM-4B-Q1-GLOBAL-UPPER-K3-R1 claims — controlling radius correction

The preceding K3 section is historical only. Its Terminal A is rejected and
superseded because the additive radii changed branch eligibility.

| Claim | K3-R1 status | Evidence boundary |
|---|---|---|
| K3 additive estimator equals R3/O-K2/R-K1 estimator | **False / rejected** | additive and max radii differ; analytic legal family changes O eligibility |
| Original K3 Terminal A | **Rejected / superseded / noncontrolling** | O theorem was potentially invoked outside its certified exact cell |
| O-K2 certificate | **Preserved** | original max-radius O estimator and theorem untouched |
| R-K1 certificate | **Preserved** | original max-radius R estimator and theorem untouched |
| Corrected max-radius global estimator is Borel | **Proved** | public max predicates, certified branch maps, zero fallback, continuous clipping |
| Corrected four-cell partition | **Proved** | exact orientation and weak/strict max-radius comparisons |
| O-safe certificate interface | **Exact match** | `x<=y`, `C_rad(s vee h_n)<=eta`, tie and equality identical |
| R-safe certificate interface | **Exact match** | `y<x`, `C_rad(t vee h_n)<=eta`, equality identical |
| Max-radius unsafe fallback | **Proved** | log floor or direct `s>delta`/`t>delta`; `3<=12delta^{-2}(q+X)` |
| Selector and envelope algebra | **Re-audited / proved** | radius-independent `T_selected<=2W`, `W<=24X` |
| Corrected fixed-pair global expected-L1 upper | **Proved** | exact four-row assembly |
| Corrected Q1 minimax upper | **Proved** | per-`Gamma` Borel competitor, then outer supremum; no exchange |
| Added assumption, retuning, selector modification, or rate leak | **None** | all change counts zero |
| Lower/matching/variance/Candidate-C1/manuscript | **Not certified or authorized** | outside K3-R1 |

Controlling K3-R1 terminal:
`Q1 GLOBAL UPPER RE-CERTIFIED UNDER AUTHORITATIVE MAX-RADIUS SELECTOR`.
Corrected global-upper certificate count is `1`; formal progress remains
exactly `85%` pending PI reevaluation. No continuation is automatic.

## PLM-4B-P-EQUALVAR-K4 claims — controlling P-boundary refutation

| Claim | K4 status | Evidence boundary |
|---|---|---|
| Law-nonempty variance compatibility | **Characterized** | exactly `v_-<=B0^2`; equality has an explicit legal M1 law |
| Three-point equal-variance moment kernel | **Derived algebraically** | exact probabilities and moment identities; full fuzzy family not certified |
| Universal compatible-interval P lower `c_P s(b wedge s)` | **Refuted** | compatible singleton `[B0^2,B0^2]` forces `pi=0` and admits `O(n^-1/2)` risk |
| Variance-envelope saturation | **Proved** | `E[u^2|X]=B0^2` and `|u|<=B0` force `u=+-B0` equiprobably |
| Propensity collapse at saturation | **Proved** | simultaneous `|T|<=B0` forces `pi=0` for every legal law |
| Boundary target identity | **Proved** | `beta=E[TY]/B0^2` uniformly over every public pair |
| Q1 boundary upper | **Proved** | clipped empirical mean has expected absolute risk `<=1/sqrt(2n)` |
| Positive P term at `(0,1,1,0)` | **Impossible uniformly in n** | requested term is one while the Q1 risk vanishes |
| Interior equal-variance P lower | **Not certified or refuted** | stop rule fired after universal target refutation |
| O/inherited/global lower/Candidate-C1/manuscript | **Not touched or authorized** | outside K4 |
| Novelty, paper, experiment, upload or submission credit | **Zero** | correctness/refutation certificate only |

Controlling K4 terminal:
`EQUAL-VARIANCE P TARGET REFUTED UNDER THE FROZEN MODEL`.
The PI-recorded formal percentage remains `88%` pending an explicit theorem-scope
reclassification; active lower/proof/manuscript/experiment continuations are zero.

## PLM-4B-SCOPE-K5 claims — controlling theorem-scope reclassification

The preceding K4 percentage sentence is historical. K5 implements the PI's
explicit rollback to `60%`; `88%` is no longer a controlling project state.

| Claim | K5 status | Evidence boundary |
|---|---|---|
| Old universal all-compatible-tuple formula | **WITHDRAWN / FALSE** | refuted on the admitted saturation tuple; not restored in K5 |
| E/I/S partition | **PROVED** | E is empty, S is saturated and parametric, I admits a positive fixed-variance mean channel |
| Explicit nonempty-model convention | **REQUIRED** | `v_-<=B0^2` plus nonempty public pairs; E receives no statistical credit |
| Saturation identification | **PROVED MODEL-WIDE** | every S law has `pi=0` and `beta=E[TY]/B0^2` |
| Saturation minimax rate | **PROVED `Theta(q)`** | native Borel moment upper and native all-`n` Le Cam lower, uniformly over budget cells |
| Any nuisance-interaction lower on S | **REFUTED** | the model-wide moment estimator makes all such nonvanishing terms impossible |
| Strict-interior three-point support slack | **PROVED** | exact common variance and both envelopes for a tuple-dependent positive mean interval |
| Interior four-budget formula | **VIABLE BUT UNPROVED** | P, O, anchored-product, and common-stochastic lower certificates remain open |
| Old P lower | **INADMISSIBLE FOR TRANSFER** | residual variance depends on the label |
| K3-R1 corrected global upper | **PRESERVED / CERTIFIED** | K4/K5 do not refute the upper certificate |
| Candidate-C0 and master claims | **SCIENTIFICALLY QUARANTINED / NOT SUBMISSION-READY** | historical files remain byte-identical; no manuscript claim is corrected by K5 |
| Valid universal headline theorem | **0** | no current universal formula survives |
| Certified arbitrary-tuple matching lower | **0** | support feasibility is not a testing lower |
| Submission-ready candidate | **0** | manuscript is quarantined |

Controlling K5 terminal:
`INTERIOR FOUR-BUDGET CHARACTERIZATION REMAINS SCIENTIFICALLY VIABLE; SATURATION HAS A DISTINCT PARAMETRIC RATE`.

Formal progress is `60% — GLOBAL UPPER AND MANUSCRIPT ASSETS PRESERVED, BUT
THE UNIVERSAL MAIN CHARACTERIZATION IS FALSE; CORRECT THEOREM SCOPE UNDER
AUDIT`. The only recommended next decision is whether to authorize one
interior P equal-variance outcome-mixture/Gram proof kernel. No continuation
is automatic.

## PLM-4B-P-INTERIOR-K6 claims — controlling P-component certificate

| Claim | K6 status | Evidence boundary |
|---|---|---|
| K5 three-point channel reused without change | **VERIFIED** | identical `v0,M,L`, support, and probabilities |
| Same residual variance across P labels | **PROVED** | both means use the same fixed channel and have variance `v0=v_-` |
| Outcome marginal equality | **PROVED** | `-Delta eta+kappa=gamma` |
| Observable `TY` equality | **PROVED** | `Delta v0=2eta gamma` cancels the retained `eta^2` term |
| Six raw laws | **PROVED LEGAL** | all atoms positive, normalized, and on one observation space |
| Exact common reference | **PROVED** | side-atom identity plus separate zero-atom check |
| G1 likelihood kernel | **PROVED** | exact formulas, `K0<=s^2/225`, `K1<=s^2/196` |
| G2 direct finite Gram | **PROVED INDEPENDENTLY** | raw coefficients, all Walsh blocks, tensorization, mixture counting |
| Frozen-`p` mixture closeness | **PROVED** | each chi-square `<exp(-511)` in the nonparametric branch; cross-label TV `<1/4` |
| One common public Q1/M1 pair | **PROVED** | both labels/truths included before label; actual all-radii ratio `<=23s/192` |
| Native strict-interior parametric lower | **PROVED** | singleton-M1 two-point Le Cam family for every `n` and budget |
| All-`n` strict-interior P lower | **CERTIFIED** | nonparametric branch plus native `q` lower by maximum, never Bayes-risk addition |
| Explicit P constant | **POSITIVE PER FIXED TUPLE** | `min{M/(4096v_-),3 min(B0/16,B0/(16sqrt(v_-)))/32}` |
| Stronger assumption than strict interior | **NONE** | constants may degenerate as saturation is approached |
| O/anchored/common/global lower | **UNPROVED / UNTOUCHED** | outside K6 |
| Interior four-budget formula | **VIABLE BUT UNPROVED** | P is one certified component only |
| Candidate-C0/master | **SCIENTIFICALLY QUARANTINED / NOT SUBMISSION-READY** | byte-identical; no manuscript work |

Controlling K6 terminal:
`INTERIOR EQUAL-VARIANCE P LOWER CERTIFIED`.

Mandatory scope statement:
`P LOWER CERTIFIED ONLY — INTERIOR FOUR-BUDGET CHARACTERIZATION STILL UNPROVED`.

Formal progress remains `60%`. Certified strict-interior equal-variance P
lower count is `1`; valid universal headline theorem and submission-ready
candidate counts remain `0`. No next lower component is automatically
authorized.

## PLM-4B-O-INTERIOR-K7 claims — controlling O-component certificate

| Claim | K7 status | Evidence boundary |
|---|---|---|
| K6 P acceptance | **RECORDED** | controlling P-component count `1`; pre-K7 progress fixed at `65%` |
| Same three-point treatment law across O labels | **PROVED LEGAL** | common mean `z gamma`, support `{-L,0,L}`, exact treatment residual variance `v0=v_-` |
| Observable `TY` equality | **PROVED** | `Delta(v0+gamma^2)=gamma eta` |
| Conditional outcome means equal | **NOT CLAIMED / GENERALLY FALSE** | label means are `z eta` and `z Delta gamma` |
| Six raw laws | **PROVED LEGAL** | every atom strictly positive, normalized, and on one observation space |
| Exact common reference | **PROVED** | `Delta a_u u=b_u eta` on side atoms; separate zero-atom check |
| Label-1 coefficient | **PROVED** | full outcome tilt cancels exactly, yielding `h_1=b_u/a_u` |
| G1 likelihood kernel | **PROVED** | exact `K0`, `K1`; explicit `K0<=t^2/9`, `K1<=t^2/256` |
| G2 direct finite Gram | **PROVED INDEPENDENTLY** | raw coefficients, Walsh same/opposite/off-coordinate blocks, tensorization and counting |
| Frozen-`p` mixture closeness | **PROVED** | each chi-square `<exp(-511)` and cross-label TV `<1/2` in the nonparametric branch |
| One common public Q1/M1 pair | **PROVED** | `G_mu={0}` and finite `G_pi`; actual all-radii ratio `<=23t/384` |
| Explicit target scale | **PROVED** | `Delta>=M t(a wedge t)/[1024(v0+M^2/16)]` |
| All-`n` strict-interior O lower | **CERTIFIED** | K7 nonparametric branch plus K6 native `q` lower by maximum only |
| Explicit O constant | **POSITIVE PER FIXED TUPLE** | `min{M/[8192(v0+M^2/16)],3d_rho/32}` |
| Stronger assumption than strict interior | **NONE** | tuple constant may degenerate toward saturation |
| Anchored/common/global lower | **UNPROVED / UNTOUCHED** | outside K7 |
| Full interior characterization | **VIABLE BUT UNPROVED** | only P and O components are certified |
| Novelty, Candidate-C1, manuscript, experiment or submission | **UNCERTIFIED / UNAUTHORIZED** | no credit or artifact |

Controlling K7 terminal:
`INTERIOR EQUAL-VARIANCE O LOWER CERTIFIED`.

Mandatory scope statement:
`O AND P LOWER COMPONENTS CERTIFIED ONLY — INTERIOR FULL CHARACTERIZATION STILL UNPROVED`.

Formal progress remains exactly `65%`. Certified strict-interior P and O
lower counts are each `1`; corrected headline theorem and submission-ready
candidate counts remain `0`. No inherited lower or manuscript continuation is
automatically authorized.

## PLM-4B-INHERITED-CORE-K8 claims — source-exact remaining-lower audit

| Claim | K8 status | Evidence boundary |
|---|---|---|
| K7 O acceptance | **RECORDED** | controlling O-component lower count `1`; pre-K8 progress fixed at `70%` |
| `at^2<=O`, `bs^2<=P`, `s^2t^2<=M` | **PROVED ON `[0,1]^4`** | exhaustive two-case arguments, including zero/tie boundaries |
| Product package comparison | **PROVED WITH CONSTANTS 1 AND 2** | `ab+M+O+P <= AB+M+O+P <= 2(ab+M+O+P)` |
| Independent remaining lower obligations | **EXACTLY `ab` AND `M`** | q/P/O already certified; the other three product summands are dominated |
| Gu et al. current version | **VERIFIED v1 ONLY** | official history and fresh PDF; PDF hash matches prior authority |
| Theorem A.1 statement | **SOURCE-EXACTLY EXTRACTED** | Q1-like outer order, `2n`, expected L1, four budgets, stated `q+AB+M` lower |
| Promised proof supplement | **NOT PUBLICLY AVAILABLE IN AUDITED RECORDS** | archive has commented `\input{supp.tex}` but no `supp.tex`; PDF/HTML/author page expose no proof file |
| `ab` source transfer | **NOT CERTIFIED** | `SOURCE STATEMENT ONLY — HARD PAIR NOT RECOVERED` |
| `M=(s wedge t)^2` source transfer | **NOT CERTIFIED** | `SOURCE STATEMENT ONLY — HARD PAIR NOT RECOVERED` |
| Q1 quantifier syntax | **MATCHES AT STATEMENT LEVEL** | does not prove restricted fixed-rho/M1 witness inclusion |
| Equal-variance/arbitrary-rho transfer | **NOT CERTIFIED** | source statement does not expose label variances, supports, or rescaling data |
| M1 transfer | **NOT CERTIFIED** | no hard class representation or exact all-radii witness is public |
| Attribution chain | **TERMINATES AT STATEMENT** | four related `ab` citations require unspecified translation; no unique M proof ancestor |
| Citation-only inherited route | **KILLED** | absence of proof/hard pair defeats direct current-model transfer, not the mathematical rates |
| Global lower/full characterization | **NOT CERTIFIED OR AUTHORIZED** | both remaining component counts stay zero |
| Candidate-C0/master/bibliography | **PRESERVED / QUARANTINED** | no manuscript or bibliography modification |

Controlling K8 terminal:
`CITATION-ONLY INHERITED LOWER ROUTE KILLED`.

Formal progress is exactly `70%`. Corrected global upper and strict-interior
q/P/O lower counts remain `1` each; certified `ab` and `M` lower counts remain
`0`; valid corrected headline theorem and submission-ready candidate remain
`0`. A native `ab` kernel may be considered only by a separate PI decision.

## PLM-4B-AB-NATIVE-K9 claims — controlling native `ab` certificate

| Claim | K9 status | Evidence boundary |
|---|---|---|
| K8 citation-only closure | **ACCEPTED / PRESERVED** | K9 supplies a native proof and does not revive citation transfer |
| Three-point channel | **PROVED LEGAL** | all probabilities positive/normalized; means `+-z eta`; exact common variance `v0=v_-` |
| Native PLM and envelopes | **PROVED** | conditional-mean residuals and all authoritative `B0` bounds hold on each fixed strict-interior tuple |
| Approximation budgets | **PROVED WITH EXPLICIT CONSTANTS** | `eta<=b`, `gamma<=a`, `kappa<=129a/65536<=a` |
| Singleton public Q1/M1 pair | **PROVED** | `G_mu=G_pi={0}` fixed before the label; both all-radius complexities are exactly zero; no latent leak |
| Moment matching | **PROVED** | both labels have `E[Y|X]=z gamma` and `E[TY|X]=eta gamma` |
| Exact common reference | **PROVED AT ALL SIX ATOMS** | `Delta alpha_tau tau=xi_tau(kappa+gamma)`, with the zero atom checked separately and `Q>0` |
| G1 likelihood route | **PROVED** | exact centering; denominator lower bound; `K0<=S/32`, `K1<=S/8` |
| G2 direct Gram route | **PROVED INDEPENDENTLY** | raw same/opposite/off-coordinate blocks agree exactly with G1 |
| Frozen mixture exponent | **PROVED SUFFICIENT** | each label chi-square `<=exp(-511)`; cross-label TV `<1/4`; no retuning |
| Expected-L1 testing | **PROVED** | nonparametric risk `>=3Delta/8=[3m_rho/(8192v0)]ab`; Q1 order preserved |
| All-`n`/all-budget closure | **PROVED** | K6 native `q` lower closes small branches by cases/maximum, never by adding Bayes risks |
| Explicit fixed-rho constant | **POSITIVE** | `c_ab,rho=min{3m_rho/(8192v0),3d_rho/32}>0` |
| Exact-field collision gate | **PASS WITH HIGH OVERLAP RISK** | no direct/routine theorem implication; Gu (2026) Prop. 2.3 is the closest announced product-rate result |
| Method novelty or priority | **NOT CLAIMED** | fuzzy/Walsh/product lower lineage is established prior art |
| Common-stochastic `M` lower | **UNCERTIFIED / UNTOUCHED** | sole remaining lower component; outside K9 |
| Headline theorem/Candidate/manuscript | **NOT ASSEMBLED OR MODIFIED** | protected artifacts remain quarantined and byte-identical |
| Formal percentage | **70% UNCHANGED** | positive K9 signal cannot raise progress before PI acceptance |

Controlling K9 terminal:
`NATIVE EXACT-VARIANCE M1/Q1 ab LOWER CERTIFIED`.

Mandatory boundary:
`ab CERTIFIED; M=(s wedge t)^2 REMAINS THE SOLE UNCERTIFIED LOWER COMPONENT`.

Current certificate counts are: corrected strict-interior global upper `1`;
native strict-interior `q` lower `1`; strict-interior equal-variance P lower
`1`; strict-interior equal-variance O lower `1`; native exact-variance `ab`
lower `1`; common-stochastic `M` lower `0`; valid corrected headline theorem
`0`; submission-ready candidate `0`. All active proof/kernel, assembly,
Candidate/manuscript, experiment, upload and submission counts are `0`.

## PLM-4B-COMMON-STOCHASTIC-K10 claims — controlling `M` certificate

| Claim | K10 status | Evidence boundary |
|---|---|---|
| K9 `ab` acceptance | **RECORDED / PRESERVED** | formal milestone enters K10 at `75%`; K9 credit boundaries unchanged |
| Common three-point treatment channel | **PROVED LEGAL** | strict positive probabilities; exact mean `z gamma`; exact variance `v_-=v0` under both labels |
| Native PLM and envelopes | **PROVED** | strict response atoms, conditional-mean residual, and every authoritative `B0` bound |
| Exact approximation membership | **PROVED** | both truths lie in the one public label-blind class pair; errors exactly zero for arbitrary `a,b` |
| Outcome stochastic budget | **PROVED SEPARATELY** | finite-class Massart bound gives all-radii ratio `<=23w^2/(384s)<s` |
| Propensity stochastic budget | **PROVED SEPARATELY** | finite-class Massart bound gives all-radii ratio `<=23m_rho w^2/(6t)<=23t/384<t` |
| M1/Q1/public information | **PROVED** | finite Borel pointwise-dense representations; full dictionaries public; arbitrary Borel learner retained |
| Exact common reference | **PROVED ON SIX ATOMS** | `Delta alpha_u u=xi_u eta`; zero atom checked without division; explicit denominator margin |
| G1 likelihood kernel | **PROVED** | exact centering and expressions; `K0<w^2/9`, `K1<w^2/256` |
| G2 direct raw Gram | **PROVED INDEPENDENTLY** | same/opposite/off-coordinate blocks are `1+K_l`, `1-K_l`, `1` and agree exactly with G1 |
| Frozen mixture exponent | **PROVED SUFFICIENT** | exact chi-square identity; each label `<exp(-511)`; cross-label TV `<1/4` |
| Expected-L1 testing | **PROVED** | branch risk `>=Delta/8>=m_rho w^2/[8192(v_-+m_rho^2/16)]` |
| All-`n` closure | **PROVED** | zero, small-`n`, small-budget and nonparametric branches exhaustive; K6 `q` used by cases/maximum only |
| Explicit tuple constant | **POSITIVE** | `c_M,rho=min{m_rho/[8192(v_-+m_rho^2/16)],c_q,rho/4}>0` |
| Hostile falsifier | **PASS AS SUPPORT ONLY** | `19/19` tests; three deliberate mutations rejected; non-hit is not proof |
| Attribution | **PRIOR-ART PHENOMENON** | Gu et al. A.1 states squared minimum; Gu Prop. 2.3 is a high-overlap sparse PLM lower |
| K10 novelty/method/standalone paper | **ZERO CREDIT** | K10 is exact native interface closure only |
| Full lower-component set | **INDIVIDUALLY CERTIFIED** | q/P/O/ab/M each has a scoped internal certificate; no assembly executed |
| Headline theorem/Candidate/manuscript | **PENDING / UNTOUCHED** | assembly collision audit and manuscript work require separate PI authorization |
| Formal percentage | **75% UNCHANGED** | positive K10 signal cannot increase progress before later PI acceptance |

Controlling K10 terminal:
`NATIVE EXACT-VARIANCE M1/Q1 COMMON-STOCHASTIC LOWER CERTIFIED`.

Mandatory boundary:
`M=(s wedge t)^2 CERTIFIED; ALL LOWER COMPONENTS ARE INDIVIDUALLY CERTIFIED; HEADLINE ASSEMBLY REMAINS PENDING`.

Current certificate counts are: corrected strict-interior global upper `1`;
native strict-interior q lower `1`; strict-interior equal-variance P lower `1`;
strict-interior equal-variance O lower `1`; native exact-variance `ab` lower
`1`; native exact-variance common-stochastic `M` lower `1`; assembled valid
corrected headline theorem `0`; submission-ready candidate `0`.  All active
proof/kernel, assembly, Candidate/manuscript, experiment, upload and submission
counts are `0`.

## PLM-4B-STRATIFIED-HEADLINE-K11 claims

| Claim | K11 status | Evidence boundary |
|---|---|---|
| K10 acceptance and 82% entry milestone | **RECORDED** | accepts the M component only and authorizes K11 assembly/audit |
| E/I/S theorem | **ASSEMBLED / VALIDATED** | exact frozen strata; no theorem drift |
| Interior upper | **IMPORT PASS** | fixed-public-pair Borel rule, public selector, safe fallback, clipping, all `n`/budgets, fixed-`rho` constant |
| Interior lower | **ASSEMBLY PASS** | same scalar risk; maximum only; factors `5`, `2`, `10`; `c_rho=c_min,rho/10` |
| Empty boundary | **PROVED** | no numerical minimax rate assigned to an empty experiment |
| Saturation boundary | **PROVED** | `pi=0`, `beta=E[TY]/B0^2`, all-pair upper and singleton-pair lower |
| Fixed-`rho` constants | **AUDITED** | lower constants may vanish as `v_-` approaches `B0^2`; no uniform boundary constant claimed |
| Full-headline collision | **NO DIRECT/ROUTINE COLLISION ESTABLISHED** | positive field comparison with thirteen primary full texts; search non-hit receives no novelty credit |
| Gu/TAME attribution | **CONTROLLING PRIOR ART** | approximation product, common stochastic square and calibration/editing architecture are not claimed new |
| O/P differential | **PAPER-LEVEL CANDIDATE CONTRIBUTION** | both necessary in native model and rate-dominating on explicit independent-budget rays |
| Variance phase differential | **PAPER-LEVEL CANDIDATE CONTRIBUTION** | presented as enlarged-envelope identification boundary, not a refutation of other theorems |
| ICLR floor | **CLEARED NARROWLY** | AC `6/10 weak accept`; hostile Reviewer 2 remains `5/10 weak reject` |
| Firstness/novel method | **NOT CLAIMED** | novelty confidence is moderate and conditional on exact field differential |
| Efficient algorithm/unknown-budget adaptation/practical superiority | **NOT CLAIMED** | information-theoretic M1/Borel known-budget theorem only |
| Candidate-C1/manuscript/bibliography/experiment | **UNAUTHORIZED / UNTOUCHED** | requires separate PI decision |
| Formal milestone | **82% CONTINUES** | `88%` may be recommended but is not adopted by K11 |

Single K11 terminal:
`STRATIFIED HEADLINE THEOREM ASSEMBLED — ICLR PAPER FLOOR CLEARED`.

## PLM-4B-CANDIDATE-C1-R0 claims — controlling reconstruction record

| Claim | R0 status | Evidence boundary |
|---|---|---|
| K11 Terminal A and 88% milestone | **ACCEPTED / RECORDED** | PI authorization for reconstruction; 88% is project completion, not acceptance probability |
| Corrected Master-R2 | **COMPLETE, COMPILED, AUDITED, FROZEN** | 12-page evidence-complete technical source; bundle `B4559B...3416`; formal succession still needs PI adoption |
| Candidate-C1 derivation | **AUDITED** | derived only from frozen Master-R2; no Candidate-C0 or loose-kernel scientific import |
| E/I/S theorem | **PRESERVED** | same Q1/M1 expected-L1, `2n`, known-budget, fixed-rho theorem |
| Saturation quantifier | **MANUSCRIPT WORDING CORRECTED** | uniform upper for every legal nonempty pair; outer lower witnessed by one legal singleton pair |
| ICLR 2027 format | **PASS** | unmodified official style; main pages 1--9; references from page 9; appendices from page 10 |
| Compile and PDF QA | **PASS** | 0 errors, undefined references/citations, duplicate labels, overfull/underfull boxes; 14 pages rendered and inspected |
| Double blind and metadata | **PASS** | anonymous review mode; no identity in text or metadata |
| AI disclosure | **PRESENT AND SUBSTANTIAL** | theory, proof, literature, checks, figure and writing roles disclosed |
| Complete independent human verification | **PENDING** | candidate is not submission-ready until human authors verify all claims and sources |
| Fresh collision audit | **NO DIRECT/ROUTINE FULL-HEADLINE COLLISION ESTABLISHED** | theorem-field comparison only; search non-hit gives no novelty credit |
| New generic editor or lower-bound method | **NOT CLAIMED** | TAME/calibration and fuzzy/product/common-stochastic ancestry explicit |
| Five-review result | **7/6/5/6/6; AC WEAK ACCEPT** | strongest residual risk is novelty/significance breadth, not a certified correctness flaw |
| Experiment | **NOT NEEDED / NOT RUN** | analytic figure only; no simulated or empirical evidence |
| Submission-ready status | **NO** | final human/submission audit is not yet authorized or completed |
| Suggested progress | **94% RECOMMENDED, NOT ADOPTED** | controlling PI-adopted milestone remains 88% |
| Upload/submission/arXiv/contact | **PROHIBITED / ZERO** | no external publication action occurred |

Single R0 terminal:
`CANDIDATE-C1 COMPILED AND AUDITED — FINAL SUBMISSION AUDIT MAY BE REQUESTED`.

## PLM-4B-PROOF-COMPLETE-R1 claims — controlling proof-completion record

| Claim | R1 status | Evidence boundary |
|---|---|---|
| R0 Terminal A | **RECLASSIFIED AS OVERSTATED** | a compiled candidate existed, but full-proof and source-integrity gates were open |
| Recursive proof matrix | **66/66 CLOSED** | 65 Type-A leaves; one Type-B leaf; zero OPEN/KILLED |
| Complete upper proof | **CERTIFIED** | Appendix B, (B.1)--(B.33); O/R termwise sigma-fields, tail integration, selector, fallback, and Q1 lift printed |
| External proof dependency | **ONE EXACT TRANSFER** | Lemma 4 maps Bartlett--Bousquet--Mendelson (2005), Theorem 2.1, pp. 1503--1504 |
| q/P/O/ab/M lowers | **CERTIFIED IN PDF** | Appendices C--F give raw laws, public budgets, variance/envelope, common reference, direct Gram, distance, testing, and all-n closure |
| ab constant | **CORRECTED IN R1** | E.12--E.13 and assembly use denominator 16384 after independent factor-two audit |
| Lower assembly | **CERTIFIED** | Appendix G uses only a maximum on one outer minimax scalar and deterministic maximum-to-sum equivalence |
| Empty/saturation | **CERTIFIED SEPARATELY** | Appendix H gives empty-class semantics, identification, moment upper, and singleton Hellinger lower |
| Source integrity | **PASS** | protected R0 retains exactly five frozen defects; Candidate-C1-R1 and Master-R3 have zero |
| Build/page/anonymity | **PASS** | 28 pages; pages 1--9 main; Appendix A after references on page 10; no compile/metadata/anonymity defect |
| Formula visual audit | **PASS** | 56 page images match in 28 pairs; all pages and formula-critical pages inspected |
| Protected assets | **BYTE-IDENTICAL** | R0, Master-R2, Candidate-C1-R0, K3-R1/K5--K11, older manuscripts, style, and bibliography preserved |
| Master-R3 | **COMPLETE PROPOSED TECHNICAL SOURCE** | formal-successor designation not adopted |
| Candidate-C1-R1 | **COMPILED FULL-PROOF CANDIDATE** | independent human verification and submission readiness remain open |
| Suggested milestone | **94% MAY BE REQUESTED, NOT ADOPTED** | controlling phase cannot self-adopt the percentage |
| Upload/submission/public release | **ZERO / PROHIBITED** | no external action occurred or is authorized |

Single R1 terminal:
`FULL PROOF APPENDIX CERTIFIED — HUMAN AUDIT PACKAGE MAY BE REQUESTED`.

The only next PI decision is whether to authorize an independent human proof/source audit package, still excluding upload and submission.

## PLM-4B-C2-REDTEAM-CORRECTION-R1 claims — controlling Candidate-C3 correction record

| Claim | R1 status | Evidence boundary |
|---|---|---|
| Headline E/I/S four-budget rate | **UNCHANGED / SURVIVES** | E2 changes fixed-tuple constants and admissible public classes, not budget or sample exponents |
| Public-class uniformity | **REPAIRED BY MATERIAL FIELD COMPLETION** | fixed `B_G>0` bounds every candidate and represented copy before `sup_Gamma`; unsupported old `8B0` assertion withdrawn |
| Clipping-only repair | **REJECTED** | localized-ball preimage transfer is not implied by contraction without an additional lemma |
| q/P/O/ab/M hard families | **RE-CERTIFIED UNDER E2** | positive lower rescaling plus K0/K1 and P/O/ab/M exact suites |
| Lemma 3 conditional Bernstein statement | **CORRECTED** | conditional independence and centering given the same sigma-field; old wording has an exact counterexample |
| Lemma 5 localized process bridge | **FULLY EXPANDED / CLOSED-A** | finite shells, two processes, confidence allocation, range absorption and boundary cases printed in Appendix B |
| TAME upper architecture | **INHERITED AND EQUATION-MAPPED** | Corollary 3.2 (3.7) maps to `T_mu wedge T_pi`; no generic-upper novelty credit |
| Residual paper claim | **NARROWLY PRESERVED** | matching O/P necessity and exact-model closure plus E/I/S boundary |
| Known budgets, fixed variance, M1/Borel access, no runtime claim | **CONTROLLING LIMITATIONS** | stated in main setup, access table, limitations, and Appendix A/I |
| Master-R5 / Candidate-C3 | **COMPILED AND SOURCE-EQUIVALENT** | 30-file aggregate identical; 33/33 rendered pages pixel-identical; build logs clean |
| AI red-team returns and R1 reviews | **TECHNICAL EVIDENCE ONLY** | all are AI-assisted; independent-human-review credit remains zero |
| Later-version collision and venue significance | **NOT CLOSED** | refresh deferred to a separately authorized second pass/submission-time audit; significance remains borderline |
| Submission-ready / upload / public release | **NO / UNAUTHORIZED** | no external action is performed or implied by this correction |

Controlling R1 terminal, subject to final read-only integrity verification:
`MASTER-R5 AND CANDIDATE-C3 COMPILED — VERIFIED C2 RED-TEAM CORRECTIONS INTEGRATED; FRESH BLIND SECOND PASS REQUIRED`.

Formal progress may not exceed
`90% — CORRECTED CANDIDATE-C3 COMPILED; FRESH AI BLIND SECOND PASS PENDING`.

## PLM-4B-P1-C4-REVISION-R0 claims — bounded positioning revision

| Claim | R0 status | Evidence boundary |
|---|---|---|
| A0 Terminal A and P1 authorization | **ACCEPTED / EXECUTED** | bounded positioning and local definition repair only; P2 and external actions remain closed |
| Headline E/I/S theorem and rate | **UNCHANGED** | no change to theorem, `q,AB,M,O,P`, Q1/M1 order, model, quantifiers, assumptions, or proof strategy |
| Walsh `P_X` convention | **CLOSED LOCALLY** | `m=ceil(log2(p+1))`, Haar-uniform finite dyadic group, and `p` distinct nonzero characters; C--F use one convention |
| “Interior” terminology | **CORRECTED** | now lower-endpoint slack `0<v_-<B_0^2`; no claim that each law's actual `v` is separated from saturation |
| First-statement quantifiers | **FRONT-LOADED** | constant variance, known certificates, represented classes, pair-specific rule, different-pair lowers, and outer max-to-sum stated in the abstract |
| Public budgets | **OPERATIONALLY BOUNDED** | pre-data upper certificates from approximation/complexity analysis; no realized-error oracle or data-adaptive budget theorem |
| Lower assembly | **CLARIFIED / UNCHANGED** | separate legal pairs under one outer scalar, maximum first, deterministic maximum-to-sum; no Bayes-risk addition |
| Jin/Gu/TAME ancestry | **FIELD-COMPARED** | Jin B.1/7.5, Gu A.1, and TAME 3.7 differentiated; no first/novel/priority/collision-free claim |
| COLT boundary | **EXPLICIT** | only fixed-variance, known-budget, represented-class, pair-specific expected-L1 PLM object is claimed closed |
| Figure reproducibility | **PASS** | CSV/PNG exact; PDF raster exact; SVG exact after timestamp/generated-ID normalization |
| Nine-page gate | **PASS** | Conclusion ends page 9 under unchanged ICLR 2027 template; references/Appendix follow |
| Proof regression | **PASS** | core 57/57 and additional P/O/ab/M 51/51; validators, labels, citations, logs, and bibliography clean |
| Master-R6 / Candidate-C4 | **COMPILED / SCIENTIFICALLY IDENTICAL** | 31/31 compared source files and 32/32 rendered pages identical |
| AI internal review | **TECHNICAL EVIDENCE ONLY** | human correctness/source/review credit remains zero |
| G10 fresh blind regression | **PENDING / UNAUTHORIZED** | no new package, reviewer, or external call in R0 |
| Formal progress | **90% UNCHANGED** | 92% may be suggested to a future PI but is not adopted here |
| Submission/upload/public release | **NO / UNAUTHORIZED** | Candidate-C4 is not submission-ready |

Controlling R0 terminal:
`MASTER-R6 AND CANDIDATE-C4 COMPILED — P1 REVISION INTEGRATED; FRESH BLIND REGRESSION PENDING`.
